// Optional Tailwind 3 preset for @roo/kit. Maps classes like `bg-roo-surface` to the kit's CSS
// variables. Use it with `presets: [require('@roo/kit/tailwind-preset')]`.
// The lists below must match src/tokens/names.ts (test/preset.test.ts checks this).

const colourNames = [
  'bg', 'surface', 'raised', 'raised-on-raised', 'raised-hover', 'editor', 'border', 'border-floating', 'bar-edge', 'line', 'control-edge', 'field-edge', 'border-hover', 'field-focus-fill', 'field-focus-fill-floating', 'track', 'row-hover', 'segment-thumb',
  'text', 'muted', 'faint', 'text-2', 'text-3', 'focus',
  'accent', 'accent-text', 'on-accent', 'accent-fill', 'on-accent-fill', 'accent-bg', 'accent-ring',
  'ok', 'ok-text', 'ok-bg', 'warn', 'warn-bg',
  'danger', 'danger-text', 'danger-bg', 'danger-fill', 'del-bg',
  'prod', 'prod-text', 'prod-bg', 'prod-fill', 'prod-pill', 'prod-band', 'prod-band-text',
  'prod-button', 'on-prod',
  'env-local', 'env-testing', 'env-development', 'env-staging', 'env-prod', 'env-none', 'status-green', 'status-blue', 'status-purple', 'status-orange', 'status-orange-fill', 'on-status-orange-fill', 'status-yellow', 'status-gray', 'select', 'select-hover', 'select-outline', 'select-strong', 'on-select-strong', 'select-cell', 'select-cell-outline',
  'drop-edge', 'scrim', 'dialog-scrim', 'skeleton', 'kbd-bg', 'kbd-text',
]

const extensionNames = [
  'chrome', 'tabstrip', 'side', 'card', 'keyword', 'string', 'tile', 'brand-glow-1', 'brand-glow-2',
  'lane-mail', 'lane-sms', 'lane-push', 'lane-http', 'lane-job', 'lane-log', 'lane-err', 'lane-dump', 'lane-file',
  'project-1', 'project-2', 'project-3', 'project-4', 'project-5', 'project-6', 'project-7', 'project-8',
  'level-fatal', 'level-error', 'level-warning', 'level-info', 'level-debug', 'chart-2', 'chart-3',
  'series-1', 'series-2', 'series-3', 'series-4', 'series-5', 'series-6',
  'paper-light', 'paper-dark',
  'method-get', 'method-post', 'method-put', 'method-patch', 'method-delete', 'method-head', 'method-options',
  'variable', 'syntax-string', 'syntax-number',
  'field-fill', 'field-quiet-focus', 'grid-header-text', 'grid-header-line', 'grid-header-divider', 'line-soft', 'lens-fill', 'lens-outline',
  'ansi-0', 'ansi-1', 'ansi-2', 'ansi-3', 'ansi-4', 'ansi-5', 'ansi-6', 'ansi-7',
  'ansi-8', 'ansi-9', 'ansi-10', 'ansi-11', 'ansi-12', 'ansi-13', 'ansi-14', 'ansi-15',
  'ansi-cursor', 'ansi-selection',
]

const roo = {}
for (const name of colourNames) {
  roo[name] = `var(--roo-${name})`
}
roo.x = {}
for (const name of extensionNames) {
  roo.x[name] = `var(--roo-x-${name})`
}

module.exports = {
  theme: {
    extend: {
      colors: { roo },
      fontFamily: {
        roo: 'var(--roo-font-ui)',
        'roo-mono': 'var(--roo-font-mono)',
      },
      boxShadow: {
        'roo-control': 'var(--roo-shadow-control)',
        'roo-card': 'var(--roo-shadow-card)',
        'roo-menu': 'var(--roo-shadow-menu)',
        'roo-dialog': 'var(--roo-shadow-dialog)',
        'roo-panel': 'var(--roo-shadow-panel)',
        'roo-popover': 'var(--roo-shadow-popover)',
        'roo-thumb': 'var(--roo-shadow-thumb)',
      },
      transitionDuration: {
        'roo-fast': 'var(--roo-fast)',
        'roo-base': 'var(--roo-base)',
        'roo-slow': 'var(--roo-slow)',
        'roo-draw': 'var(--roo-draw)',
        'roo-tick': 'var(--roo-tick)',
      },
      transitionTimingFunction: {
        'roo-ease': 'var(--roo-ease)',
        'roo-spring': 'var(--roo-spring)',
        'roo-exit': 'var(--roo-exit)',
      },
      fontSize: {
        'roo-11': '11px',
        'roo-12': '12px',
        'roo-13': '13px',
        'roo-15': '15px',
        'roo-20': '20px',
      },
    },
  },
}
