# Font sources

Both families are licensed under the SIL Open Font License 1.1 (text next to each file).
Files are the latin subset, upright, variable weight axis, copied from the Fontsource npm packages
(registry.npmjs.org) on 2026-11-07. Only the woff2 file and the licence were kept; no npm dependency.

| Family | File | Package | Version | Upstream | Weights |
|---|---|---|---|---|---|
| Geist | geist.woff2 (29,400 B) | @fontsource-variable/geist | 5.3.0 | https://github.com/vercel/geist-font | 100-900 |
| Geist Mono | geist-mono.woff2 (23,128 B) | @fontsource-variable/geist-mono | 5.3.0 | https://github.com/vercel/geist-font | 100-900 |

Latin only: other scripts fall back to the system font stack in `--roo-font-ui` / `--roo-font-mono`.
Italic files were left out (the UI does not use italics); add them the same way if that changes.
