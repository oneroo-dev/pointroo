# Third-party notices for @roo/kit

@roo/kit itself is MIT (see LICENSE), copyright Oneroo.

## Bundled fonts (SIL Open Font License 1.1)

The licence text for each family sits next to its file in `fonts/`. Sources and versions:
`fonts/SOURCES.md`.

| Family | Copyright | Licence file |
|---|---|---|
| Geist | 2024 The Geist Project Authors | fonts/OFL-geist.txt |
| Geist Mono | 2024 The Geist Project Authors | fonts/OFL-geist-mono.txt |

Apps that bundle the kit (including closed-source apps) must ship these licence texts, for example
by listing them in their own THIRD_PARTY_NOTICES.

## Icons (Lucide, ISC licence)

The kit draws most of its icons from Lucide, installed as the `lucide` dependency (never copied into the kit's source).
Apps that bundle the kit must ship this notice.

```
ISC License

Copyright (c) 2026 Lucide Icons and Contributors

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted, provided that the above
copyright notice and this permission notice appear in all copies.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
```

Lucide's own licence file also carries the Feather MIT notice for the icons derived from Feather (several of the kit's,
such as check, command, database, lock and x), reproduced here:

```
The MIT License (MIT) (for the icons derived from Feather)

Copyright (c) 2013-present Cole Bemis

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

## Peer dependencies (not bundled, installed by the app)

- vue - MIT
- reka-ui - MIT
