export type RooAppearanceMode = 'light' | 'dark'
export type RooDensity = 'compact' | 'roomy'
export type RooTypeScale = 0 | 1 | 2
export type RooMotion = 'family' | 'calm' | 'still'
export type RooAppearanceKind = 'theme' | 'layout' | 'preset'

/** What the person picked: ids only, no data. */
export interface RooAppearanceChoice {
  theme?: string
  layout?: string
  preset?: string
  appearance?: RooAppearanceMode | 'system'
}

/** What the window ends up with after the family base, brand, theme, layout, settings and the lock are applied. */
export interface ResolvedAppearance {
  appearance: RooAppearanceMode
  density: RooDensity
  typeScale: RooTypeScale
  motion: RooMotion
  /** Token name (no `--roo-`) to value, for the current appearance. */
  tokens: Record<string, string>
}

/**
 * Injected by the app: the kit never touches the filesystem. Electron and Tauri apps read their store in the main
 * process and pass these four functions.
 */
export interface AppearanceStore {
  readChoice: () => Promise<RooAppearanceChoice | null>
  readFile: (kind: RooAppearanceKind, id: string) => Promise<unknown>
  watch: (callback: () => void) => () => void
  writeChoice: (choice: RooAppearanceChoice) => Promise<void>
}
