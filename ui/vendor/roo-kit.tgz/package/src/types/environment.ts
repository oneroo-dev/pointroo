/** Family rule (Raja, 2026-11-09): an unclassified connection is treated as production. */
export type RooEnvironment = 'local' | 'staging' | 'prod' | 'unclassified'

/** The environment word the rail item, dot and pill accept: the four environments plus the two tags that also arrive as a word. Apps map RooEnvironment exhaustively, so those two never join it. */
export type RooEnvironmentWord = RooEnvironment | 'testing' | 'development'

/**
 * Where a context stands. Every state except `connected` is drawn as a dashed ring plus the word, in the
 * environment's text colour (conflict C5). The hollow ring means unclassified only.
 */
export type RooContextState = 'connected' | 'connecting' | 'reconnecting' | 'offline' | 'switching' | 'stopped' | 'signed-out'

/** Why the band under the Bar is showing (conflict C13). A closed set; `read-only` on prod is the safe default, never a reason. */
export type BandReason = 'unclassified' | 'guards-off' | 'first-connect' | 'first-prod' | 'staff-prod' | 'view-as'

/**
 * One guard as the app reports it. The kit never loosens a guard from the renderer; it only reports the state it is
 * given. `looser` is true while the guard is looser than ITS OWN default for that environment, so a local connection
 * whose guard is off by default has `looser: false`.
 */
export interface GuardState {
  id: string
  label: string
  looser: boolean
}

/** The environment tag (family rule "Tag and guard are two free choices"): colour and label only, it turns no guard on or off. */
export type RooTag = 'local' | 'testing' | 'development' | 'staging' | 'production' | 'none'

/** The five guard levels, loosest first. Read-only is a separate switch, never a level. */
export type RooGuardLevel = 'silent' | 'alert' | 'alert-except-reads' | 'safe' | 'safe-except-reads'

/** A tag plus its guard. `guardPicked` is true once the user chose the guard, so a tag change leaves it alone. */
export interface RooEnvironmentChoice {
  tag: RooTag
  guard: RooGuardLevel
  guardPicked: boolean
}
