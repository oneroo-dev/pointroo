/** A chord, or one chord per platform: `{ mac: 'Cmd+1', other: 'Alt+1' }`. */
export type ShortcutKeys = string | { mac: string; other: string }

/** `ready` runs; `unwired` is planned and `reserved` is held back. Neither runs or matches a key, both still claim their chord. */
export type ShortcutStatus = 'ready' | 'unwired' | 'reserved'

/** What a command's run receives. `digit` is the digit pressed for a chord written as a range such as `Mod+[1-9]`. */
export interface ShortcutRunContext {
  digit?: number
}

/**
 * One command and its keys. Keys are written the family way: `Mod+Shift+T`, `Mod+Alt+B`, `Ctrl+1`, a digit range
 * `Mod+[1-9]`, or a physical key by KeyboardEvent.code, `Mod+Shift+code:BracketRight`.
 */
export interface Shortcut {
  id: string
  keys: ShortcutKeys
  /** A second key set for the same command; the menu shows the first. */
  altKeys?: ShortcutKeys
  label: string
  /** A shorter label for tight lists such as the key map; the menus and the Jump keep `label`. */
  shortLabel?: string
  /** The label for the current state ("Hide sidebar" or "Show sidebar"). */
  labelFor?: (state: unknown) => string
  /** The command is available only while this returns true. */
  when?: () => boolean
  /** The region that must hold focus, such as `grid` or `editor`. */
  region?: string
  /** The scope in which the keys are live (default 'global'). One chord may be bound in two different non-global scopes. */
  scope?: string
  /** Default 'ready'. */
  status?: ShortcutStatus
  /** The menu the command appears in, for the native menu bar. */
  menu?: string
  /** `yield`: inside the suite the suite takes this key and the app's command stays in its menu and the Jump. */
  suite?: 'yield'
}
