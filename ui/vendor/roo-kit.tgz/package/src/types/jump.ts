import type { RooEnvironment } from './environment'

/** What the alternate action (Cmd Enter) does for a row, in words, shown in the palette footer. */
export interface JumpAlternate {
  label: string
}

/** One row in the Jump palette. */
export interface JumpRow {
  id: string
  label: string
  /** The section the row is grouped under. */
  section: string
  icon?: string
  /** Quiet text at the right: a time, a count, a path. */
  meta?: string
  /** Keys, in the family spelling (see Shortcut.keys). */
  keys?: string
  /** Prod and unclassified rows render the dot shape and the word. */
  environment?: RooEnvironment
  alternate?: JumpAlternate
  /** Runs the row. `alt` is true for Cmd Enter. The palette never confirms: a prod row's run shows the app's own confirm. */
  run?: (alt: boolean) => void
  disabled?: boolean
  busy?: boolean
  danger?: boolean
}

/** Something that supplies rows to the Jump. The three family prefixes are fixed; a provider may declare one more. */
export interface JumpProvider {
  id: string
  section: string
  /** The words for this provider's section heading and prefix hint, in sentence case. Without it the kit words the section. */
  word?: string
  /** At most one extra prefix, listed in the footer hints. `>`, `?` and `@` belong to the family. */
  prefix?: string
  /** Rows shown before "Show all"; never above five. */
  limit?: number
  query: (text: string) => JumpRow[] | Promise<JumpRow[]>
}
