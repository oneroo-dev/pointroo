/** Who is running the app: on its own, or hosted inside the Oneroo suite. The suite's density wins over a hosted app's. */
export type RooHostKind = 'standalone' | 'suite'

/** A roo link as `@roo/links` builds it (a string the receiving app understands). */
export type RooHostLink = string

/**
 * What a kit part may ask of the window around it. The suite and each standalone app provide one; components read it
 * and never reach for the platform themselves.
 */
export interface RooHost {
  kind: RooHostKind
  /** Show an app (and optionally a link inside it) in the suite. */
  show: (app: string, link?: RooHostLink) => void | Promise<void>
  /** Show an app beside the current one in a split. */
  split: (app: string, link?: RooHostLink) => void | Promise<void>
  /** Open a web address outside the app. */
  openExternal: (url: string) => void | Promise<void>
  /** Go back to the app a link came from (the trail chip). */
  back: () => void | Promise<void>
  /** Set the Dock badge count; 0 clears it. The mark never badges. */
  setBadge: (count: number) => void | Promise<void>
  /** Whether an app is installed on this machine. */
  isInstalled: (app: string) => boolean | Promise<boolean>
}
