import type { RooIconName } from '../icons/paths'

/** The kind of thing a context is, drawn as a glyph before the environment word. All eleven names are in the kit's icon set. */
export const ROO_CONTEXT_KINDS = [
  'connection',
  'project',
  'bucket',
  'host',
  'workspace',
  'environment',
  'laptop',
  'server',
  'container',
  'pod',
  'command',
] as const satisfies readonly RooIconName[]

export type RooContextKind = (typeof ROO_CONTEXT_KINDS)[number]
