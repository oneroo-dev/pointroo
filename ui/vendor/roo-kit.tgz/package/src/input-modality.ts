// Family rule (Raja, 2026-11-10): focus rings show only after keyboard navigation, never after a click.
// Chrome's :focus-visible alone lights up after any key (Cmd+R, Esc), so we track the last input ourselves
// and base.css hides rings while html[data-input='mouse'].

export type InputModality = 'mouse' | 'keyboard'

const NAVIGATION_KEYS = new Set(['Tab', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Home', 'End', 'PageUp', 'PageDown'])

/** Call once at app start. Returns a function that stops tracking and clears the attribute. */
export function trackInputModality(root: HTMLElement = document.documentElement): () => void {
  const ownerDocument = root.ownerDocument
  const setModality = (modality: InputModality) => {
    if (root.dataset.input !== modality) root.dataset.input = modality
  }
  const onKeyDown = (event: KeyboardEvent) => {
    if (NAVIGATION_KEYS.has(event.key)) setModality('keyboard')
  }
  const onPointerDown = () => setModality('mouse')

  setModality('mouse')
  ownerDocument.addEventListener('keydown', onKeyDown, true)
  ownerDocument.addEventListener('pointerdown', onPointerDown, true)
  ownerDocument.addEventListener('mousedown', onPointerDown, true)

  return () => {
    ownerDocument.removeEventListener('keydown', onKeyDown, true)
    ownerDocument.removeEventListener('pointerdown', onPointerDown, true)
    ownerDocument.removeEventListener('mousedown', onPointerDown, true)
    delete root.dataset.input
  }
}
