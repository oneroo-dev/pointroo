// Plain TypeScript: the confirm-strength rules with no Vue, so a main process can import them through '@roo/kit/environment'.
// Keep this file and everything it imports free of .vue files, vue, @vueuse and reka-ui.
import { isGuardLevel, migrateEnvironment } from './environment'
import type { RooEnvironment, RooGuardLevel } from './types/environment'

/** How a person confirms: press and hold, two presses, or one press after a short arm delay. */
export type ConfirmMethod = 'hold' | 'two-step' | 'press'

/**
 * What the action does. 'delete', 'replace' and 'drop' are destructive; 'write' is any other change; 'unlock' turns a
 * read-only connection off, and is always its own confirm, never folded into the write that follows it. 'export-unmasked'
 * sends real, unmasked data out of the app: on prod and unclassified it counts as destructive, on local and staging it is
 * a plain confirm.
 */
export type ConfirmActionKind = 'delete' | 'replace' | 'drop' | 'write' | 'unlock' | 'export-unmasked'

/**
 * How hard a confirm is. 'plain-confirm' is a normal button. 'armed-press' is a normal button locked for the arm delay
 * (0.5 s) with no hold. 'hold' is press and hold. 'hold-and-type' also asks for the server name.
 */
export type ConfirmRequirement = 'plain-confirm' | 'armed-press' | 'hold' | 'hold-and-type'

/**
 * What `chooseConfirmRequirement` returns for a guard level: the four confirm strengths plus 'none' (the guard does not
 * ask), 'blocked' (read-only refuses the write) and 'system-auth' (Safe levels: the app asks for Touch ID or the system
 * login; the kit only reports the requirement).
 */
export type GuardRequirement = ConfirmRequirement | 'none' | 'blocked' | 'system-auth'

/** The family default method. One constant: Raja's answer to D2 flips it, nothing else. */
export const DEFAULT_CONFIRM_METHOD: ConfirmMethod = 'hold'

/** On a local or staging connection, up to this many items is a plain danger button. */
export const PLAIN_CONFIRM_MAX_COUNT = 10

/** On prod and unclassified, a write or delete that touches more than this many rows counts as destructive. */
export const BULK_WRITE_ROW_LIMIT = 10000

/** On prod and unclassified, a write or delete that touches more than this share of the table counts as destructive. */
export const BULK_WRITE_TABLE_SHARE = 0.1

/** The kinds of action that destroy or overwrite something. */
export function isDestructiveConfirmKind(kind: ConfirmActionKind): boolean {
  return kind === 'delete' || kind === 'replace' || kind === 'drop' || kind === 'export-unmasked'
}

/** A write or delete that is destructive in effect: over the row limit, over the table share, or with no WHERE. */
function isBulkWrite(input: { rowCount?: number | undefined; tableRowCount?: number | undefined; unbounded?: boolean | undefined }): boolean {
  if (input.unbounded === true) return true
  if (input.rowCount === undefined) return false
  if (input.rowCount > BULK_WRITE_ROW_LIMIT) return true
  return input.tableRowCount !== undefined && input.rowCount > input.tableRowCount * BULK_WRITE_TABLE_SHARE
}

/**
 * How hard a confirm is (family rule, replacing conflict C14). On prod and unclassified connections:
 * - every destructive action (delete, replace, drop) gets the hold;
 * - the typed name is added when it covers more than one item, includes any folder, or is a replace or a drop, so a
 *   single-file delete is hold only;
 * - a write that destroys nothing is a plain button with a 0.5 s arm and no hold;
 * - turning read-only off is its own confirm and is an armed press, with no hold and no typed name;
 * - a write or delete that is destructive in effect is treated as destructive, with the hold and the typed name: more
 *   than BULK_WRITE_ROW_LIMIT rows (exactly the limit is not bulk), more than BULK_WRITE_TABLE_SHARE of the table when
 *   `tableRowCount` is known (exactly the share is not bulk), or `unbounded` (an UPDATE or DELETE with no WHERE);
 * - an unmasked export ('export-unmasked') is destructive: the hold and the typed name.
 * `bulk` on staging is an armed press; it changes nothing on any other environment.
 * On local and staging: ten or fewer items is a plain button; more than ten destructive items hold, and never ask for a
 * name. The bulk-write inputs do not apply there, and an unmasked export is a plain confirm.
 */
interface ConfirmInputBase {
  kind: ConfirmActionKind
  /** How many items the action touches. */
  itemCount: number
  /** Any folder among them (a folder delete reaches everything inside it). */
  includesFolder?: boolean
  /** Rows the write or delete reaches. Applies to kind 'write' and 'delete'. */
  rowCount?: number | undefined
  /** Rows in the whole table, when known. Applies to kind 'write' and 'delete'. */
  tableRowCount?: number | undefined
  /** An UPDATE or DELETE with no WHERE. Applies to kind 'write' and 'delete'. */
  unbounded?: boolean | undefined
  /** A bulk action the app has already scoped (many items, one intent). On staging it asks for the armed press. */
  bulk?: boolean | undefined
}

/** Tag and guard are two free choices: the guard level decides what asks, the tag plays no part. */
export interface GuardConfirmInput extends ConfirmInputBase {
  guard: RooGuardLevel
  /** The separate read-only switch. On, a write is 'blocked' outright. */
  readOnly?: boolean | undefined
  /** The action is a read (SELECT, EXPLAIN, SHOW, ls, and so on; each app names its own). Default false. */
  isRead?: boolean | undefined
}

/** @deprecated Pass the guard level (`guard`, `readOnly`, `isRead`) instead. Kept so apps on the old call keep working; it goes through `migrateEnvironment`. */
export interface EnvironmentConfirmInput extends ConfirmInputBase {
  /** @deprecated Use `guard`. */
  environment: RooEnvironment
}

export function chooseConfirmRequirement(input: GuardConfirmInput): GuardRequirement
/** @deprecated Pass the guard level instead of the environment. */
export function chooseConfirmRequirement(input: EnvironmentConfirmInput): ConfirmRequirement
export function chooseConfirmRequirement(input: GuardConfirmInput | EnvironmentConfirmInput): GuardRequirement {
  if ('guard' in input && isGuardLevel(input.guard)) return guardConfirmRequirement(input)
  return environmentConfirmRequirement(input as EnvironmentConfirmInput)
}

function guardConfirmRequirement(input: GuardConfirmInput): GuardRequirement {
  const isRead = input.isRead === true
  if (input.readOnly === true && !isRead && input.kind !== 'unlock') return 'blocked'
  // Silent never asks, except to unlock and to export unmasked data: those keep the strict confirm.
  if (input.guard === 'silent') return input.kind === 'unlock' || input.kind === 'export-unmasked' ? strictConfirmRequirement(input) : 'none'
  if (isRead && (input.guard === 'alert-except-reads' || input.guard === 'safe-except-reads')) return 'none'
  if (input.guard === 'safe' || input.guard === 'safe-except-reads') return 'system-auth'
  if (isRead) return 'plain-confirm'
  return strictConfirmRequirement(input)
}

/** @deprecated The old environment signature: production and no tag are strict, local, testing, development and staging stay lenient as they always were (even though migrated staging now has a stricter guard). */
function environmentConfirmRequirement(input: EnvironmentConfirmInput): ConfirmRequirement {
  const choice = migrateEnvironment(input.environment)
  const requirement = choice.tag !== 'production' && choice.tag !== 'none' ? lenientConfirmRequirement(input) : strictConfirmRequirement(input)
  // Bulk only ever raises staging: a plain confirm becomes the armed press, a hold stays a hold.
  if (input.bulk === true && choice.tag === 'staging' && requirement === 'plain-confirm') return 'armed-press'
  return requirement
}

/** The warning matrix (the old prod and unclassified rules): holds, typed names and armed presses by kind and size. */
function strictConfirmRequirement(input: ConfirmInputBase): ConfirmRequirement {
  const destructive = isDestructiveConfirmKind(input.kind)
  if (input.kind === 'unlock') return 'armed-press'
  if (input.kind === 'export-unmasked') return 'hold-and-type'
  if ((input.kind === 'write' || input.kind === 'delete') && isBulkWrite(input)) return 'hold-and-type'
  if (!destructive) return 'armed-press'
  const needsName = input.itemCount > 1 || input.includesFolder === true || input.kind === 'replace' || input.kind === 'drop'
  return needsName ? 'hold-and-type' : 'hold'
}

/** The old local and staging rules, kept for the deprecated environment call only. */
function lenientConfirmRequirement(input: ConfirmInputBase): ConfirmRequirement {
  if (isDestructiveConfirmKind(input.kind) && input.kind !== 'export-unmasked' && input.itemCount > PLAIN_CONFIRM_MAX_COUNT) return 'hold'
  return 'plain-confirm'
}
