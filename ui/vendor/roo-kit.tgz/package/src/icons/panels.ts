// The kit's own drawing of the panel glyphs (sidebar, pane, panel). Lucide draws their outer box with rx 2 on the 24 grid,
// which reads as nearly sharp. Raja 2026-11-18: the bar controls take the workspace dropdown's 9px corner, and the toggle
// icon should match it scaled down. rx 4.5 on the 24 grid is about 3px at 16px, the same shape as the 9px box.
// Same geometry as Lucide otherwise (box 18 by 18 at 3,3 and one divider line), keyed by Lucide's kebab-case name so
// RooIcon can use these first and fall back to Lucide for every other icon.
import type { LucideIconNode } from './lucide'

export const ROO_PANEL_RADIUS = 4.5

const box = ['rect', { width: '18', height: '18', x: '3', y: '3', rx: String(ROO_PANEL_RADIUS) }] as const

export const ROO_PANEL_NODES: Readonly<Record<string, LucideIconNode>> = {
  'panel-left': [box, ['path', { d: 'M9 3v18' }]],
  'panel-right': [box, ['path', { d: 'M15 3v18' }]],
  'panel-bottom': [box, ['path', { d: 'M3 15h18' }]],
}
