// Which reasons put the band under the Bar (conflict C13). The kit reports the state the app gives it and has no
// setter: loosening a guard is requested by the page and confirmed in the main process, never by a kit part.
import { GUARD_LEVELS, defaultGuardFor, tagForEnvironment } from './environment'
import type { BandReason, RooEnvironment, RooGuardLevel, RooTag } from './types/environment'

/** The closed set of band reasons, strongest first. `staff-prod` and `view-as` are passed to the banner directly by an adopting app and are never produced by `bandReasons`. `read-only` on prod is the safe default, never a reason. */
export const BAND_REASONS: readonly BandReason[] = ['unclassified', 'guards-off', 'first-prod', 'first-connect', 'staff-prod', 'view-as']

export function isBandReason(value: unknown): value is BandReason {
  return typeof value === 'string' && (BAND_REASONS as readonly string[]).includes(value)
}

/**
 * One guard as the app reports it. `order` lists the guard's values tightest first, and `defaultValue` is that
 * guard's own default for this environment (a local connection whose guard is off by default has `defaultValue: 'off'`).
 */
export interface BandGuard {
  id: string
  value: string
  defaultValue: string
  order: readonly string[]
}

export interface BandInput {
  /** The connection's tag (family rules, 2026-11-17). No tag is a normal choice and never shows a band. */
  tag?: RooTag
  /** The connection's guard level. The band shows `guards-off` when it is looser than the tag's own default. */
  guard?: RooGuardLevel
  /** @deprecated Pass `tag` and `guard`. The old environment word, mapped to a tag by the same function the contract uses. */
  environment?: RooEnvironment
  /** @deprecated Pass `tag: 'none'`. An unclassified connection, mapped to No tag like `environment: 'unclassified'`. */
  unclassified?: boolean
  /** First connect to a production connection in this session (once per session). */
  firstConnect?: boolean
  /** The first production connection ever (the one tall form). */
  firstProd?: boolean
  /** Other guards the app reports, each against its own default. */
  guards?: readonly BandGuard[]
}

/** True while the guard is looser than ITS OWN default. A value or default missing from `order` cannot be shown safe. */
export function isGuardLooser(guard: BandGuard): boolean {
  if (guard.value === guard.defaultValue) return false
  const valueIndex = guard.order.indexOf(guard.value)
  const defaultIndex = guard.order.indexOf(guard.defaultValue)
  if (valueIndex === -1 || defaultIndex === -1) return true
  return valueIndex > defaultIndex
}

/** The ids of the guards that are looser than their own default, in the order given. */
export function looserGuardIds(guards: readonly BandGuard[] = []): string[] {
  return guards.filter(isGuardLooser).map((guard) => guard.id)
}

/** True while the level is looser than the tag's own default guard. A tighter guard never shows the band. */
export function isGuardLevelLooser(tag: RooTag, guard: RooGuardLevel): boolean {
  return GUARD_LEVELS.indexOf(guard) < GUARD_LEVELS.indexOf(defaultGuardFor(tag))
}

/**
 * The reasons the band shows, strongest first (guards-off, first-prod, first-connect). The band shows only when a guard
 * is looser than its own default, or this is a first connect to production: No tag gives none, a local connection with
 * the default guard gives none, and production at its default guard gives none until first connect. The deprecated
 * `environment` and `unclassified` inputs are mapped to a tag first, by the same function the contract uses, so an old
 * unclassified connection is No tag and gets no band (Raja, 2026-11-17: "No band for No tag"; family rules 9053bc4).
 * `unclassified` stays in BandReason only for RooProdBanner's deprecated prop.
 */
export function bandReasons(input: BandInput): BandReason[] {
  const reasons: BandReason[] = []
  const legacyEnvironment: RooEnvironment | undefined = input.unclassified === true ? 'unclassified' : input.environment
  const tag: RooTag = input.tag ?? (legacyEnvironment === undefined ? 'none' : tagForEnvironment(legacyEnvironment))
  const production = tag === 'production'
  const guardLooser = input.guard !== undefined && isGuardLevelLooser(tag, input.guard)
  if (guardLooser || looserGuardIds(input.guards).length > 0) reasons.push('guards-off')
  if (production && input.firstProd === true) reasons.push('first-prod')
  if (production && input.firstConnect === true) reasons.push('first-connect')
  return reasons
}
