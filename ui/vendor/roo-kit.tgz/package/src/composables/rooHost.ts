import { inject, provide, type InjectionKey } from 'vue'
import type { RooHost } from '../types/host'

const rooHostKey: InjectionKey<RooHost> = Symbol('roo-host')

/**
 * What an app is given when nothing provided a host: it is on its own, and every ask does nothing. A part never reaches
 * for the platform itself, so an unprovided host cannot open anything by accident.
 */
export const standaloneRooHost: RooHost = {
  kind: 'standalone',
  show: () => undefined,
  split: () => undefined,
  openExternal: () => undefined,
  back: () => undefined,
  setBadge: () => undefined,
  isInstalled: () => false,
}

/** The suite and each standalone app call this once near the root, with their own implementation. */
export function provideRooHost(host: RooHost): void {
  provide(rooHostKey, host)
}

export function useRooHost(): RooHost {
  return inject(rooHostKey, standaloneRooHost)
}
