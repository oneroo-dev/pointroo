// What a window remembers between launches (its widths, which parts are open). The app injects a synchronous
// storage, normally one the preload filled before the renderer started, so the first render already has the right
// state and nothing jumps. The kit never reaches for the platform itself.
import { ref, watch, type Ref } from 'vue'

/** A synchronous string store. In Electron this is the preload's copy of the window state. */
export interface WindowMemoryStorage {
  read: (key: string) => string | null
  write: (key: string, value: string) => void
  remove?: (key: string) => void
}

export interface WindowMemoryOptions<Value extends object> {
  /** The state a first launch, a corrupt entry or a schema change starts from. */
  defaults: Value
  /** Bump when the shape changes; an entry saved under another version is dropped, never half-read. */
  version?: number
  /** Present: the entry belongs to this window. Absent: it is shared by every window of the app. */
  windowId?: string
}

export interface WindowMemory<Value extends object> {
  state: Ref<Value>
  /** The storage key this memory reads and writes. */
  storageKey: string
  /** Back to the defaults, and forget the saved entry. */
  reset: () => void
}

interface Envelope {
  version: number
  value: unknown
}

export function windowMemoryKey(key: string, windowId?: string): string {
  return windowId === undefined ? `roo:app:${key}` : `roo:window:${windowId}:${key}`
}

function isPlainObject(candidate: unknown): candidate is Record<string, unknown> {
  return typeof candidate === 'object' && candidate !== null && !Array.isArray(candidate)
}

function readSaved<Value extends object>(storage: WindowMemoryStorage, storageKey: string, version: number, defaults: Value): Value {
  const raw = storage.read(storageKey)
  if (raw === null) return structuredClone(defaults)
  try {
    const envelope = JSON.parse(raw) as Envelope
    if (!isPlainObject(envelope) || envelope.version !== version || !isPlainObject(envelope.value)) return structuredClone(defaults)
    // Only keys the defaults know are read, so a stale or hand-edited entry cannot add state the window never asked for.
    const merged = structuredClone(defaults) as Record<string, unknown>
    for (const name of Object.keys(merged)) {
      const saved = envelope.value[name]
      if (saved !== undefined && typeof saved === typeof merged[name]) merged[name] = saved
    }
    return merged as Value
  } catch {
    return structuredClone(defaults)
  }
}

/** The state is available synchronously on the first line after the call, and every change is written back. */
export function useWindowMemory<Value extends object>(
  key: string,
  storage: WindowMemoryStorage,
  options: WindowMemoryOptions<Value>,
): WindowMemory<Value> {
  const version = options.version ?? 1
  const storageKey = windowMemoryKey(key, options.windowId)
  const state = ref(readSaved(storage, storageKey, version, options.defaults)) as Ref<Value>
  let forgetting = false

  watch(
    state,
    (value) => {
      if (forgetting) return
      const envelope: Envelope = { version, value }
      storage.write(storageKey, JSON.stringify(envelope))
    },
    { deep: true, flush: 'sync' },
  )

  function reset(): void {
    forgetting = true
    storage.remove?.(storageKey)
    state.value = structuredClone(options.defaults)
    forgetting = false
  }

  return { state, storageKey, reset }
}
