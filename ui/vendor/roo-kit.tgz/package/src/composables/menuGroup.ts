import type { InjectionKey } from 'vue'

/** Provided by a menu group whose items are all destructive (RooContextMenu's `destructive` slot). */
export const ROO_MENU_DESTRUCTIVE_GROUP: InjectionKey<boolean> = Symbol('roo-menu-destructive-group')
