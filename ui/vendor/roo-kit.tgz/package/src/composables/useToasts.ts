import { readonly, shallowRef, type Ref } from 'vue'
import type { RooIconName } from '../icons/paths'
import { createAnnouncer, useAnnouncer, type Announcer } from './useAnnouncer'

/** Toasts hold 2.6 s (conflict C15: timing is locked). */
export const TOAST_DURATION_MS = 2600
export const TOAST_STACK_LIMIT = 3
/** A held toast starts its usual timer anyway after this long, so a forgotten release cannot leave it up for good. */
export const TOAST_HOLD_CEILING_MS = 15_000

export type ToastTone = 'ok' | 'muted' | 'warn'

export interface ToastAction {
  label: string
  run: () => void
}

/** Why a toast left: closed by the user or code, ran out of time, its action or Undo was used, or the stack pushed it out. */
export type ToastEndReason = 'dismissed' | 'expired' | 'action' | 'undo' | 'replaced'

/** The toast's own width: a number is pixels, a string is any CSS length. */
export type ToastWidth = number | string

export interface ToastOptions {
  /** Repeats with the same key coalesce into one toast with a count. */
  key?: string
  title?: string
  message: string
  /** A second, quieter line. */
  detail?: string
  tone?: ToastTone
  /** Shows an Undo button. `undoNewest()` runs the newest one. */
  undo?: () => void
  action?: ToastAction
  /** Replaces the tone's glyph. */
  icon?: RooIconName
  /** Cuts every line of the body to one line with an ellipsis. */
  singleLine?: boolean
  width?: ToastWidth
  /**
   * `true` waits for `release(id)` before the 2.6 s timer starts, for work the toast reports on; it ends at the ceiling anyway.
   * A number is how many milliseconds the toast stays instead of 2.6 s; `0` keeps it until it is dismissed.
   */
  hold?: boolean | number
  /** Say it through the announcer (default). `false` skips the live-region announcement. */
  announce?: boolean
  /** Called once when the toast leaves, with the reason. A repeat that coalesces into it does not end it. */
  onEnd?: (reason: ToastEndReason) => void
  /** Called once when the toast first appears (not when a repeat coalesces into it). */
  onShow?: (toast: RooToastItem) => void
}

export interface RooToastItem {
  id: number
  key: string | undefined
  title: string
  message: string
  detail: string
  tone: ToastTone
  count: number
  hasUndo: boolean
  action: ToastAction | undefined
  icon: RooIconName | undefined
  singleLine: boolean
  width: ToastWidth | undefined
  held: boolean
}

/** What `update` can change on a toast that is still up. `duration` restarts the timer; nothing else does. */
export interface ToastPatch {
  title?: string
  message?: string
  detail?: string
  tone?: ToastTone
  icon?: RooIconName | undefined
  singleLine?: boolean
  width?: ToastWidth | undefined
  action?: ToastAction | undefined
  /** Replaces Undo; leaving it out keeps it, `null` removes it. */
  undo?: (() => void) | null
  /** A new stay in milliseconds, counted from now; `0` keeps the toast until it is dismissed. */
  duration?: number
}

interface Entry {
  item: RooToastItem
  undo: (() => void) | undefined
  onEnd: ((reason: ToastEndReason) => void) | undefined
  /** The full stay in milliseconds; 0 means it never expires. */
  duration: number
  remaining: number
  startedAt: number
  timer: ReturnType<typeof setTimeout> | undefined
  held: boolean
  interacting: boolean
  holdTimer: ReturnType<typeof setTimeout> | undefined
}

export interface ToastStore {
  toasts: Readonly<Ref<readonly RooToastItem[]>>
  push(options: ToastOptions): number
  /** Changes a live toast in place: no new enter animation, and the timer keeps running unless the patch sets a duration. */
  update(id: number, patch: ToastPatch): void
  dismiss(id: number): void
  release(id: number): void
  pause(id: number): void
  resume(id: number): void
  runUndo(id: number): void
  runAction(id: number): void
  undoNewest(): boolean
  /** Ends the newest toast with the reason 'dismissed'. */
  dismissNewest(): void
  clear(): void
}

/**
 * The toast queue. A stack of three, oldest leaves first; hover and focus pause one toast (the app calls pause and resume,
 * RooToast does); the clock runs only while the window has focus; announcements go through the one announcer, so a toast
 * carries no live region of its own.
 */
export function createToastStore(announcer: Announcer = createAnnouncer()): ToastStore {
  const visible = shallowRef<readonly RooToastItem[]>([])
  const entries = new Map<number, Entry>()
  let windowBlurred = false
  let nextId = 1

  function publish(): void {
    visible.value = [...entries.values()].map((entry) => entry.item)
  }

  function running(entry: Entry): boolean {
    return !entry.held && !entry.interacting && !windowBlurred && entry.duration > 0
  }

  function disarm(entry: Entry): void {
    if (entry.timer === undefined) return
    clearTimeout(entry.timer)
    entry.timer = undefined
    entry.remaining = Math.max(0, entry.remaining - (Date.now() - entry.startedAt))
  }

  function arm(entry: Entry): void {
    if (entry.timer !== undefined || !running(entry)) return
    entry.startedAt = Date.now()
    entry.timer = setTimeout(() => end(entry.item.id, 'expired'), entry.remaining)
  }

  function end(id: number, reason: ToastEndReason): void {
    const entry = entries.get(id)
    if (!entry) return
    clearTimeout(entry.timer)
    clearTimeout(entry.holdTimer)
    entries.delete(id)
    publish()
    entry.onEnd?.(reason)
  }

  function dismiss(id: number): void {
    end(id, 'dismissed')
  }

  function onWindowBlur(): void {
    windowBlurred = true
    for (const entry of entries.values()) disarm(entry)
  }

  function onWindowFocus(): void {
    windowBlurred = false
    for (const entry of entries.values()) arm(entry)
  }

  if (typeof window !== 'undefined') {
    window.addEventListener('blur', onWindowBlur)
    window.addEventListener('focus', onWindowFocus)
  }

  function release(id: number): void {
    const entry = entries.get(id)
    if (!entry || !entry.held) return
    clearTimeout(entry.holdTimer)
    entry.held = false
    entry.item = { ...entry.item, held: false }
    publish()
    arm(entry)
  }

  function push(options: ToastOptions): number {
    const existing = options.key === undefined ? undefined : [...entries.values()].find((entry) => entry.item.key === options.key)
    const spoken = options.title ? `${options.title}. ${options.message}` : options.message

    if (existing) {
      disarm(existing)
      existing.remaining = existing.duration
      existing.undo = options.undo ?? existing.undo
      existing.item = {
        ...existing.item,
        title: options.title ?? existing.item.title,
        message: options.message,
        detail: options.detail ?? existing.item.detail,
        count: existing.item.count + 1,
        hasUndo: Boolean(options.undo ?? existing.undo),
        action: options.action ?? existing.item.action,
        icon: options.icon ?? existing.item.icon,
      }
      publish()
      arm(existing)
      if (options.announce !== false) announcer.announce(spoken)
      return existing.item.id
    }

    const id = nextId++
    const held = options.hold === true
    const duration = typeof options.hold === 'number' ? Math.max(0, options.hold) : TOAST_DURATION_MS
    const entry: Entry = {
      item: {
        id,
        key: options.key,
        title: options.title ?? '',
        message: options.message,
        detail: options.detail ?? '',
        tone: options.tone ?? 'muted',
        count: 1,
        hasUndo: Boolean(options.undo),
        action: options.action,
        icon: options.icon,
        singleLine: options.singleLine ?? false,
        width: options.width,
        held,
      },
      undo: options.undo,
      onEnd: options.onEnd,
      duration,
      remaining: duration,
      startedAt: Date.now(),
      timer: undefined,
      held,
      interacting: false,
      holdTimer: undefined,
    }
    entries.set(id, entry)
    while (entries.size > TOAST_STACK_LIMIT) {
      const oldest = entries.keys().next().value
      if (oldest === undefined) break
      end(oldest, 'replaced')
    }
    publish()
    if (held) entry.holdTimer = setTimeout(() => release(id), TOAST_HOLD_CEILING_MS)
    else arm(entry)
    if (options.announce !== false) announcer.announce(spoken)
    options.onShow?.(entry.item)
    return id
  }

  function update(id: number, patch: ToastPatch): void {
    const entry = entries.get(id)
    if (!entry) return
    const next = { ...entry.item }
    if (patch.title !== undefined) next.title = patch.title
    if (patch.message !== undefined) next.message = patch.message
    if (patch.detail !== undefined) next.detail = patch.detail
    if (patch.tone !== undefined) next.tone = patch.tone
    if ('icon' in patch) next.icon = patch.icon
    if (patch.singleLine !== undefined) next.singleLine = patch.singleLine
    if ('width' in patch) next.width = patch.width
    if ('action' in patch) next.action = patch.action
    if (patch.undo !== undefined) {
      entry.undo = patch.undo ?? undefined
      next.hasUndo = patch.undo !== null
    }
    entry.item = next
    if (patch.duration !== undefined) {
      disarm(entry)
      entry.duration = Math.max(0, patch.duration)
      entry.remaining = entry.duration
      arm(entry)
    }
    publish()
  }

  function pause(id: number): void {
    const entry = entries.get(id)
    if (!entry) return
    disarm(entry)
    entry.interacting = true
  }

  function resume(id: number): void {
    const entry = entries.get(id)
    if (!entry) return
    entry.interacting = false
    arm(entry)
  }

  function runUndo(id: number): void {
    const entry = entries.get(id)
    if (!entry?.undo) return
    const undo = entry.undo
    end(id, 'undo')
    undo()
  }

  function runAction(id: number): void {
    const entry = entries.get(id)
    if (!entry?.item.action) return
    const run = entry.item.action.run
    end(id, 'action')
    run()
  }

  function undoNewest(): boolean {
    const newest = [...entries.values()].reverse().find((entry) => entry.undo)
    if (!newest) return false
    runUndo(newest.item.id)
    return true
  }

  function dismissNewest(): void {
    const newest = [...entries.keys()].pop()
    if (newest !== undefined) dismiss(newest)
  }

  function clear(): void {
    for (const id of [...entries.keys()]) dismiss(id)
  }

  return { toasts: readonly(visible) as Readonly<Ref<readonly RooToastItem[]>>, push, update, dismiss, release, pause, resume, runUndo, runAction, undoNewest, dismissNewest, clear }
}

let sharedStore: ToastStore | undefined

/** The app-wide toast queue, announcing through the app-wide announcer. RooToastStack renders it. */
export function useToasts(): ToastStore {
  sharedStore ??= createToastStore(useAnnouncer())
  return sharedStore
}
