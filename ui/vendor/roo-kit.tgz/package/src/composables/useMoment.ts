import { computed, getCurrentScope, onScopeDispose, ref, type CSSProperties } from 'vue'

export type RooMoment = 'tick' | 'pop'

/** Close to `--roo-tick` and `--roo-base`; the CSS owns the real durations, these only end the "playing" flag. */
export const MOMENT_PLAY_MS: Record<RooMoment, number> = { tick: 200, pop: 220 }

/** How long the still twin stays marked under reduced motion. */
export const MOMENT_STILL_MS = 600

export interface MomentOptions {
  /** Defaults to the OS setting or an app that set data-motion="still" on <html>. */
  reducedMotion?: () => boolean
}

function prefersReducedMotion(): boolean {
  if (typeof document !== 'undefined' && document.documentElement.getAttribute('data-motion') === 'still') return true
  return typeof window !== 'undefined' && typeof window.matchMedia === 'function'
    ? window.matchMedia('(prefers-reduced-motion: reduce)').matches
    : false
}

/**
 * A one-shot motion with its reduced-motion twin built in. `trigger()` plays a tick (a check drawing itself) or a pop (a
 * small arrival). Bind `style` and, to replay on a repeat, use `pulse` as the element's key. Under reduced motion nothing
 * moves; `still` is true for a moment instead, for a colour or outline change that needs no motion.
 */
export function useMoment(kind: RooMoment, options: MomentOptions = {}) {
  const reduced = options.reducedMotion ?? prefersReducedMotion
  const playing = ref(false)
  const still = ref(false)
  const pulse = ref(0)
  let timer: ReturnType<typeof setTimeout> | undefined

  const style = computed<CSSProperties | undefined>(() => {
    if (!playing.value) return undefined
    return kind === 'tick'
      ? { animation: 'roo-tick var(--roo-tick) var(--roo-ease) 1 both' }
      : { animation: 'roo-pop var(--roo-base) var(--roo-spring) 1 both' }
  })

  function trigger(): void {
    clearTimeout(timer)
    pulse.value += 1
    if (reduced()) {
      playing.value = false
      still.value = true
      timer = setTimeout(() => {
        still.value = false
      }, MOMENT_STILL_MS)
      return
    }
    playing.value = true
    timer = setTimeout(() => {
      playing.value = false
    }, MOMENT_PLAY_MS[kind])
  }

  if (getCurrentScope()) onScopeDispose(() => clearTimeout(timer))

  return { playing, still, pulse, style, trigger }
}
