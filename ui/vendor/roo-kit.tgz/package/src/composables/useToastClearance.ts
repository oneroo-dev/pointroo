// Bottom-anchored action areas (an editor tray, a sheet footer) publish how far they rise above the window bottom, and the
// toast stack sits above the tallest one so a toast never covers a button. Apps can also set --roo-toast-clearance by hand.
import { computed, onScopeDispose, shallowRef, watch, type ComputedRef, type Ref } from 'vue'

const registeredClearances = shallowRef<ReadonlyMap<symbol, number>>(new Map())

/** The largest registered clearance in px, or 0 when no area is registered. */
export const toastClearance: ComputedRef<number> = computed(() => {
  let largest = 0
  for (const clearance of registeredClearances.value.values()) largest = Math.max(largest, clearance)
  return largest
})

function setClearance(key: symbol, clearance: number | undefined): void {
  const next = new Map(registeredClearances.value)
  if (clearance === undefined) next.delete(key)
  else next.set(key, clearance)
  registeredClearances.value = next
}

function measureClearance(element: Element): number {
  return Math.max(0, Math.round(window.innerHeight - element.getBoundingClientRect().top))
}

/**
 * Registers the element as a bottom-anchored area while it exists. Its clearance follows its size (and the window's) and is
 * withdrawn when the element goes away or the owning scope ends.
 */
export function useToastClearance(target: Ref<Element | null | undefined>): void {
  const key = Symbol('toast-clearance')
  let observer: ResizeObserver | undefined
  let observed: Element | undefined

  function update(): void {
    if (observed) setClearance(key, measureClearance(observed))
  }

  function release(): void {
    observer?.disconnect()
    observer = undefined
    observed = undefined
    window.removeEventListener('resize', update)
    setClearance(key, undefined)
  }

  watch(
    target,
    (element) => {
      release()
      if (!element) return
      observed = element
      if (typeof ResizeObserver !== 'undefined') {
        observer = new ResizeObserver(update)
        observer.observe(element)
      }
      window.addEventListener('resize', update)
      update()
    },
    { immediate: true, flush: 'post' },
  )

  onScopeDispose(release)
}
