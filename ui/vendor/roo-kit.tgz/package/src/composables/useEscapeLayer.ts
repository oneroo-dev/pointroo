// Esc ordering for kit overlays. reka listens for Escape on `window` in the bubble phase, registered when its layer opens,
// so an app's own window or element keydown listener (registered earlier) runs first and sees defaultPrevented false.
// While at least one kit layer is open, one capture-phase listener on `window` runs before everything else, marks the Esc
// as consumed with preventDefault, and remembers the event, so any later listener can skip it.
import { onScopeDispose, watch } from 'vue'

interface EscapeLayer {
  /** Closes a layer that reka does not manage (one that is not a DismissableLayer), when it is the top layer. */
  onEscape?: () => void
  /** Asked before the layer, when on top, consumes an Esc. True lets this one Esc through: not prevented, not consumed, layer stays open. */
  passEscape?: (event: KeyboardEvent) => boolean
}

export interface EscapeLayerOptions {
  passEscape?: (event: KeyboardEvent) => boolean
}

export interface EscapeLayerHandle {
  /**
   * True when this layer was the top kit layer when the Esc arrived. Pass the event reka hands to escapeKeyDown: the answer
   * is fixed at the capture phase, so a layer that closed itself in that phase (an armed confirm) still counts as the top,
   * and the layer under it does not close on the same Esc.
   */
  isTop(event?: KeyboardEvent): boolean
  /** True when this layer was on top and let this Esc through (passEscape returned true). */
  passed(event: KeyboardEvent): boolean
}

// Open layers, oldest first. reka closes its own top layer; a non-reka layer on top is closed here, so a card opened by
// hover closes on Esc wherever focus is, instead of the Esc being consumed while the card stays open.
const openLayers: EscapeLayer[] = []
const consumedEvents = new WeakSet<KeyboardEvent>()
const topLayerByEvent = new WeakMap<KeyboardEvent, EscapeLayer | undefined>()
const passedByEvent = new WeakMap<KeyboardEvent, EscapeLayer>()

function captureEscape(event: KeyboardEvent): void {
  if (event.key !== 'Escape' || event.isComposing) return
  const top = openLayers.at(-1)
  topLayerByEvent.set(event, top)
  if (top?.passEscape?.(event)) {
    passedByEvent.set(event, top)
    return
  }
  event.preventDefault()
  consumedEvents.add(event)
  top?.onEscape?.()
}

function enterLayer(layer: EscapeLayer): void {
  openLayers.push(layer)
  if (openLayers.length === 1) window.addEventListener('keydown', captureEscape, { capture: true })
}

function leaveLayer(layer: EscapeLayer): void {
  const index = openLayers.indexOf(layer)
  if (index === -1) return
  openLayers.splice(index, 1)
  if (openLayers.length === 0) window.removeEventListener('keydown', captureEscape, { capture: true })
}

/**
 * Registers the calling overlay as an open kit layer while `open()` is true; unregisters on false and on scope dispose.
 * Pass `onEscape` for a layer reka does not manage (or that disarms itself); it runs when that layer is on top.
 * `options.passEscape` lets a chosen Esc through while this layer is on top (see EscapeLayer). Returns `isTop` and `passed`
 * for a reka layer's escapeKeyDown handler.
 */
export function useEscapeLayer(open: () => boolean, onEscape?: () => void, options: EscapeLayerOptions = {}): EscapeLayerHandle {
  const layer: EscapeLayer = {}
  if (onEscape !== undefined) layer.onEscape = onEscape
  if (options.passEscape !== undefined) layer.passEscape = options.passEscape
  const handle: EscapeLayerHandle = {
    isTop(event) {
      if (event && topLayerByEvent.has(event)) return topLayerByEvent.get(event) === layer
      return openLayers.at(-1) === layer
    },
    passed: (event) => passedByEvent.get(event) === layer,
  }
  if (typeof window === 'undefined') return { isTop: () => true, passed: () => false }
  let registered = false
  const apply = (isOpen: boolean): void => {
    if (isOpen === registered) return
    registered = isOpen
    if (isOpen) enterLayer(layer)
    else leaveLayer(layer)
  }
  watch(() => Boolean(open()), apply, { immediate: true, flush: 'sync' })
  onScopeDispose(() => apply(false))
  return handle
}

/** True while any kit overlay is open, and so is about to consume Esc. */
export function isOverlayOpen(): boolean {
  return openLayers.length > 0
}

/** True when a kit overlay consumed this Esc event. An app's window-level Esc action should check this, not defaultPrevented: an Esc a popover passed through stays unconsumed. */
export function consumedByOverlay(event: KeyboardEvent): boolean {
  return consumedEvents.has(event)
}
