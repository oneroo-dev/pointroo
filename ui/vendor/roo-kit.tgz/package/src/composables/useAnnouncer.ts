import { readonly, ref, type Ref } from 'vue'

/** How long a message stays in its region before it is cleared, so the same words can be said again later. */
export const ANNOUNCER_CLEAR_MS = 1500

export interface AnnounceOptions {
  /** Interrupts the reader. For things that need attention now (a lost connection), never for confirmations. */
  assertive?: boolean
}

export interface Announcer {
  polite: Readonly<Ref<string>>
  assertive: Readonly<Ref<string>>
  /** Returns false when the message is empty or is still in either region (it is not said twice). */
  announce(message: string, options?: AnnounceOptions): boolean
  /** Empties both regions and cancels their timers. */
  reset(): void
}

/**
 * The family has one announcer: one polite and one assertive region, mounted once by RooLiveRegion. Everything that
 * wants to be spoken (toasts, the Ledge, state changes) goes through it, so nothing is read twice. A message that is
 * still in either region is dropped, and a region clears itself after it was read.
 */
export function createAnnouncer(): Announcer {
  const polite = ref('')
  const assertive = ref('')
  let politeTimer: ReturnType<typeof setTimeout> | undefined
  let assertiveTimer: ReturnType<typeof setTimeout> | undefined

  function announce(message: string, options: AnnounceOptions = {}): boolean {
    const text = message.trim()
    if (!text) return false
    if (polite.value === text || assertive.value === text) return false
    if (options.assertive) {
      clearTimeout(assertiveTimer)
      assertive.value = text
      assertiveTimer = setTimeout(() => {
        assertive.value = ''
      }, ANNOUNCER_CLEAR_MS)
    } else {
      clearTimeout(politeTimer)
      polite.value = text
      politeTimer = setTimeout(() => {
        polite.value = ''
      }, ANNOUNCER_CLEAR_MS)
    }
    return true
  }

  function reset(): void {
    clearTimeout(politeTimer)
    clearTimeout(assertiveTimer)
    polite.value = ''
    assertive.value = ''
  }

  return { polite: readonly(polite), assertive: readonly(assertive), announce, reset }
}

const sharedAnnouncer = createAnnouncer()

/** The app-wide announcer. RooLiveRegion renders it. */
export function useAnnouncer(): Announcer {
  return sharedAnnouncer
}
