import { readonly, shallowRef } from 'vue'
import type { RooHost } from '../types/host'

/** Where the person came from. An app name reads "from Tableroo"; a label is an in-app place ("Queue · job 9f3c"). */
export interface TrailSource {
  app?: string
  label?: string
}

/**
 * The trail a link leaves behind: set on arrival, cleared when the person moves on (opens something else, closes the
 * item, or goes back). It stays in the suite too: `back` asks the host.
 */
export function createTrail(host?: Pick<RooHost, 'back'>) {
  const current = shallowRef<TrailSource | undefined>(undefined)
  return {
    source: readonly(current),
    arrive(source: TrailSource): void {
      current.value = source
    },
    movedOn(): void {
      current.value = undefined
    },
    async back(): Promise<void> {
      await host?.back()
      current.value = undefined
    },
  }
}

export type Trail = ReturnType<typeof createTrail>
