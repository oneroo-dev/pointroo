// True while a media query matches, following changes. Without matchMedia (server render, some test hosts) it is false.
import { onScopeDispose, ref, type Ref } from 'vue'

export const REDUCED_MOTION_QUERY = '(prefers-reduced-motion: reduce)'
export const TOUCH_QUERY = '(hover: none), (pointer: coarse)'

export function useMediaMatch(queryText: string): Ref<boolean> {
  const matches = ref(false)
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return matches
  const query = window.matchMedia(queryText)
  matches.value = query.matches
  const onChange = (event: MediaQueryListEvent): void => {
    matches.value = event.matches
  }
  query.addEventListener('change', onChange)
  onScopeDispose(() => query.removeEventListener('change', onChange))
  return matches
}
