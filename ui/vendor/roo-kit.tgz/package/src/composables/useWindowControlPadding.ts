import { onMounted, ref, toValue, watch, type MaybeRefOrGetter, type Ref } from 'vue'
import { detectBarPlatform, type RooBarPlatform } from '../components/RooBar.vue'

/** The side a floating panel asks to open on, before any flip. */
export type FloatingSide = 'top' | 'bottom' | 'left' | 'right'

export interface CollisionPadding {
  top: number
  right: number
  bottom: number
  left: number
}

/** The small clearance every floating panel keeps from the window edge. */
export const DEFAULT_COLLISION_PADDING = 8

const CAPTION_PROBE_ATTRIBUTE = 'data-roo-caption-probe'

function readPixels(element: Element, property: string): number {
  const parsed = Number.parseFloat(getComputedStyle(element).getPropertyValue(property))
  return Number.isFinite(parsed) ? parsed : 0
}

/**
 * The width the Windows and Linux caption buttons take at the window's end: the space between the title bar overlay and the
 * window edge, the same measure RooBar's end spacer uses. Zero when no overlay is drawn.
 */
function measureCaptionWidth(): number {
  const probe = document.createElement('div')
  probe.setAttribute(CAPTION_PROBE_ATTRIBUTE, '')
  probe.setAttribute('aria-hidden', 'true')
  probe.style.cssText = 'position:fixed;visibility:hidden;pointer-events:none;height:0;width:calc(100vw - env(titlebar-area-x, 0px) - env(titlebar-area-width, 100vw))'
  document.body.appendChild(probe)
  const width = probe.getBoundingClientRect().width
  probe.remove()
  return Number.isFinite(width) ? width : 0
}

/**
 * Collision padding that keeps a floating panel off the window controls. Reka's padding is a rectangle inset from every
 * edge, so it cannot exclude one corner. Faithful approach: the controls live in the bar, so only a trigger that sits in the
 * bar (its top above the bar's bottom edge) can put a panel over them. For such a trigger whose panel opens above or below
 * (or with no side given) the top padding is the bar height (a panel never sits in the bar, it flips below). A panel that
 * opens to the left or right is beside the trigger, inside the bar, so it keeps the small top padding and stays in the bar.
 * The side that holds the controls gets their width plus the small padding (8px of air beyond the controls, never max of the two): the traffic inset on
 * macOS (left), the caption width on Windows and Linux (right). Anywhere else, on the web surface and on a bar with platform web, only the small padding.
 */
export function windowControlPadding(trigger: Element | null | undefined, side?: FloatingSide): CollisionPadding {
  const padding: CollisionPadding = {
    top: DEFAULT_COLLISION_PADDING,
    right: DEFAULT_COLLISION_PADDING,
    bottom: DEFAULT_COLLISION_PADDING,
    left: DEFAULT_COLLISION_PADDING,
  }
  // A slot root that is a fragment or a v-if gives a text or comment node, not an element (Markroo, 2026-11-17).
  if (!(trigger instanceof Element) || typeof document === 'undefined') return padding
  if (!trigger.closest("[data-surface='desktop']")) return padding
  const barHeight = readPixels(trigger, '--roo-bar-h')
  if (barHeight <= 0 || trigger.getBoundingClientRect().top >= barHeight) return padding
  const platformAttribute = trigger.closest('[data-platform]')?.getAttribute('data-platform')
  const platform = (platformAttribute as RooBarPlatform | null) ?? detectBarPlatform()
  // A browser-hosted bar has no window controls, so nothing needs clearing: only the small padding.
  if (platform === 'web') return padding
  if (side !== 'left' && side !== 'right') padding.top = Math.max(padding.top, barHeight)
  if (platform === 'mac') padding.left = readPixels(trigger, '--roo-traffic-inset') + DEFAULT_COLLISION_PADDING
  else padding.right = measureCaptionWidth() + DEFAULT_COLLISION_PADDING
  return padding
}

function defaultPadding(): CollisionPadding {
  return {
    top: DEFAULT_COLLISION_PADDING,
    right: DEFAULT_COLLISION_PADDING,
    bottom: DEFAULT_COLLISION_PADDING,
    left: DEFAULT_COLLISION_PADDING,
  }
}

/**
 * The one way a floating panel gets its collision padding: pass the result as reka's `collision-padding`. It holds the small
 * clearance on every side and is measured again with windowControlPadding each time `open` turns true, so a token change or a
 * resized window is read fresh. `anchor` is the element the panel hangs from, or a reka trigger or anchor component (its
 * `$el` is used); with no anchor the small padding stays. `side` is the side the panel asks to open on, when it is fixed: a
 * left or right panel does not take the bar-height top padding (see windowControlPadding).
 */
export function useCollisionPadding(
  open: MaybeRefOrGetter<boolean>,
  anchor: Ref<unknown>,
  side?: MaybeRefOrGetter<FloatingSide | undefined>,
): Ref<CollisionPadding> {
  const collisionPadding = ref<CollisionPadding>(defaultPadding())
  function measure(): void {
    const target = anchor.value
    const element = target instanceof Element ? target : (target as { $el?: Element } | null | undefined)?.$el
    collisionPadding.value = windowControlPadding(element, toValue(side))
  }
  watch(() => toValue(open), (isOpen) => {
    if (isOpen) measure()
  }, { flush: 'sync' })
  onMounted(() => {
    if (toValue(open)) measure()
  })
  return collisionPadding
}
