// The one rule for the letter on a workspace or connection tile: the first grapheme of the trimmed name, uppercased.
// RooLetterTile and RooWorkspaceMark both call it, so the two never disagree (Raja's lead, 2026-11-19).

// Typed here rather than through Intl.Segmenter, so apps whose TypeScript lib predates ES2022 still compile (Tinkeroo).
type GraphemeSegmenter = { segment(input: string): Iterable<{ segment: string }> }
type GraphemeSegmenterConstructor = new (locale: undefined, options: { granularity: 'grapheme' }) => GraphemeSegmenter
const SegmenterConstructor = typeof Intl === 'undefined' ? undefined : (Intl as unknown as { Segmenter?: GraphemeSegmenterConstructor }).Segmenter
const graphemeSegmenter = SegmenterConstructor ? new SegmenterConstructor(undefined, { granularity: 'grapheme' }) : undefined

/** The first whole character of the name, uppercased. An empty or blank name gives an empty string. */
export function firstLetter(name: string): string {
  const trimmed = name.trim()
  if (trimmed === '') return ''
  const first = graphemeSegmenter ? ([...graphemeSegmenter.segment(trimmed)][0]?.segment ?? '') : (Array.from(trimmed)[0] ?? '')
  return first.toUpperCase()
}
