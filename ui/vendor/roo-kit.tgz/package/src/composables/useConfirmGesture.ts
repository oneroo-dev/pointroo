import { computed, getCurrentScope, onScopeDispose, ref, watch, type ComputedRef, type Ref } from 'vue'
import { useEscapeLayer, consumedByOverlay } from './useEscapeLayer'
import { useHoldToConfirm } from './useHoldToConfirm'

/** How long a hold takes to confirm. */
export const CONFIRM_HOLD_MS = 1500
/** Press twice: how long the second press may take after the first. */
export const CONFIRM_ARM_WINDOW_MS = 3000

export type ConfirmGestureMethod = 'hold' | 'two-step'
export type ConfirmGesturePhase = 'holding' | 'tap' | 'armed' | 'idle'

export interface ConfirmGestureOptions {
  /** The family setting: hold the button, or press it twice. Read on every press. */
  method: () => ConfirmGestureMethod
  /** Whether this press needs confirming at all. A press that does not runs the action at once and opens nothing. */
  guarded: () => boolean
  /** The action itself. Runs once per confirmed gesture, or once per unguarded press. */
  action: () => void
  /** What the button does, as a verb for the gesture line ("delete", "run"). */
  verb?: string
  /**
   * True while something the popover asks for is missing (a typed server name that does not match yet). A blocked press
   * opens the popover and does nothing else: no hold starts, nothing arms, the action cannot run. A hold or an arm that
   * is running when this turns true is cancelled. Read on every press, so a getter over a ref works.
   */
  blocked?: () => boolean
  /** The hint while blocked. Defaults to "Fill in the field to <verb>". */
  blockedHint?: string
  /** Where the popover state lives. Pass a ref to share it (a v-model); without one the gesture keeps its own. */
  open?: Ref<boolean>
  holdMs?: number
  armWindowMs?: number
}

export interface ConfirmGesture {
  /** The popover is showing. */
  open: Ref<boolean>
  /** The first of two presses has landed and the second is awaited. */
  armed: Ref<boolean>
  /** A hold is running. */
  holding: Ref<boolean>
  /** 0 to 1 while a hold runs, 0 otherwise. */
  progress: Ref<number>
  /** The gesture is blocked (see `blocked` in the options). */
  blocked: ComputedRef<boolean>
  phase: ComputedRef<ConfirmGesturePhase | null>
  /** The gesture half of the popover's one line ("Hold to delete", "Keep holding to delete", "Press again to delete"); the popover adds "· Change". */
  hint: ComputedRef<string>
  onPointerdown(event?: PointerEvent): void
  onPointerup(): void
  onPointerleave(): void
  onPointercancel(): void
  /** A click. `event.detail === 0` means Enter or Space made it, and that always uses press twice. */
  onClick(event?: MouseEvent): void
  onKeydown(event: KeyboardEvent): void
  onBlur(): void
  /** Closes the popover and stops whatever is running (Esc, an outside click, the popover's own close). */
  dismiss(): void
  /**
   * Everything a trigger needs, as one object for `v-bind`, so an app can put the gesture on its own element instead of
   * RooHoldButton: the pointer, click, key and blur handlers, `aria-haspopup`, `aria-expanded`, the `data-armed` and
   * `data-holding` attributes the kit styles read, and `touch-action: none` so a touch hold is not taken for a scroll.
   * Usage: `<button v-bind="gesture.bindings.value">Clear cache</button>`. It is reactive, so bind the `.value`.
   */
  bindings: ComputedRef<ConfirmGestureBindings>
}

export interface ConfirmGestureBindings {
  onPointerdown: (event: PointerEvent) => void
  onPointerup: () => void
  onPointerleave: () => void
  onPointercancel: () => void
  onClick: (event: MouseEvent) => void
  onKeydown: (event: KeyboardEvent) => void
  onBlur: () => void
  'aria-haspopup': 'dialog'
  'aria-expanded': boolean
  'data-armed': true | undefined
  'data-holding': true | undefined
  style: { touchAction: 'none' }
}

function prefersReducedMotion(): boolean {
  if (typeof document !== 'undefined' && document.documentElement.classList.contains('roo-force-reduced')) return true
  if (typeof document !== 'undefined' && document.documentElement.getAttribute('data-motion') === 'still') return true
  return typeof window !== 'undefined' && typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
}

/**
 * The gesture behind "destructive and prod actions confirm on the button itself" (family rule, 2026-11-14), generalised
 * from Tinkeroo's useRunConfirmGesture. Hold: press and hold the button; the popover opens and the fill rises; a full
 * hold runs the action once; letting go, leaving the button, Esc or blur stops it, and the popover stays open so it can be
 * read. Press twice: the first press opens the popover and arms; a second press within the arm window runs the action.
 * Enter and Space always use press twice, even when the method is hold. Reduced motion keeps the hold and only leaves the
 * fill animation out (the hint text still turns to "Keep holding"). While `blocked` the popover opens and nothing else happens.
 */
export function useConfirmGesture(options: ConfirmGestureOptions): ConfirmGesture {
  const holdMs = options.holdMs ?? CONFIRM_HOLD_MS
  const armWindowMs = options.armWindowMs ?? CONFIRM_ARM_WINDOW_MS
  const verb = options.verb ?? 'continue'
  const open = options.open ?? ref(false)
  const armed = ref(false)
  const letGo = ref(false)
  const reducedMotion = ref(false)
  let armTimer: ReturnType<typeof setTimeout> | undefined

  const hold = useHoldToConfirm(holdMs)
  const blocked = computed(() => options.blocked?.() ?? false)

  function clearArm(): void {
    clearTimeout(armTimer)
    armTimer = undefined
    armed.value = false
  }

  function dismiss(): void {
    hold.cancel()
    letGo.value = false
    clearArm()
    open.value = false
  }

  function run(): void {
    hold.cancel()
    letGo.value = false
    clearArm()
    open.value = false
    options.action()
  }

  hold.onConfirm(() => {
    letGo.value = false
    clearArm()
    open.value = false
    options.action()
  })

  // A hold the kit ended itself (window blur, tab hidden) leaves the popover open with nothing driving it.
  watch(
    hold.holding,
    (now, was) => {
      if (was && !now && !hold.confirmed.value) letGo.value = true
    },
    { flush: 'sync' },
  )

  // The field the popover asks for went wrong while a hold or an arm was running: stop both, leave the popover open.
  watch(
    blocked,
    (now) => {
      if (!now) return
      hold.cancel()
      clearArm()
    },
    { flush: 'sync' },
  )

  function arm(): void {
    open.value = true
    armed.value = true
    letGo.value = false
    clearTimeout(armTimer)
    armTimer = setTimeout(dismiss, armWindowMs)
  }

  function stopHold(): void {
    if (!hold.holding.value) return
    hold.cancel()
    letGo.value = true
  }

  function onPointerdown(event?: PointerEvent): void {
    if (!options.guarded() || options.method() !== 'hold') return
    if (event && (event.isPrimary === false || event.button > 0)) return
    if (blocked.value) {
      open.value = true
      return
    }
    clearArm()
    letGo.value = false
    reducedMotion.value = prefersReducedMotion()
    open.value = true
    hold.start()
  }

  function onClick(event?: MouseEvent): void {
    if (!options.guarded()) {
      options.action()
      return
    }
    const keyboard = event !== undefined && event.detail === 0
    if (options.method() === 'hold' && !keyboard) return
    if (blocked.value) {
      open.value = true
      return
    }
    if (armed.value) run()
    else arm()
  }

  // While armed, holding or showing its popover, the gesture is a kit layer: the innermost one, so one Esc ends it before
  // any popover or dialog around it closes. The layer's Esc handler runs in the capture phase.
  useEscapeLayer(() => open.value || hold.holding.value || armed.value, dismiss)

  function onKeydown(event: KeyboardEvent): void {
    // An Esc the kit already consumed went to the top layer (this gesture's, or one above it); never dismiss twice.
    if (event.key === 'Escape' && !consumedByOverlay(event) && (open.value || hold.holding.value)) dismiss()
  }

  function onBlur(): void {
    stopHold()
  }

  if (getCurrentScope()) {
    onScopeDispose(() => {
      clearTimeout(armTimer)
      hold.cancel()
    })
  }

  const phase = computed<ConfirmGesturePhase | null>(() => {
    if (!open.value) return null
    if (blocked.value) return 'idle'
    if (hold.holding.value) return 'holding'
    if (armed.value) return 'armed'
    return letGo.value ? 'tap' : 'idle'
  })

  const hint = computed(() => {
    if (blocked.value && open.value) return options.blockedHint ?? `Fill in the field to ${verb}`
    switch (phase.value) {
      case 'armed':
        return `Press again to ${verb}`
      case 'holding':
        return `Keep holding to ${verb}`
      case 'tap':
      case 'idle':
        return `Hold to ${verb}`
      default:
        return ''
    }
  })

  const bindings = computed<ConfirmGestureBindings>(() => ({
    onPointerdown,
    onPointerup: stopHold,
    onPointerleave: stopHold,
    onPointercancel: stopHold,
    onClick,
    onKeydown,
    onBlur,
    'aria-haspopup': 'dialog',
    'aria-expanded': open.value,
    'data-armed': armed.value || undefined,
    'data-holding': hold.holding.value || undefined,
    style: { touchAction: 'none' },
  }))

  return {
    open,
    armed,
    holding: hold.holding,
    progress: hold.progress,
    blocked,
    phase,
    hint,
    onPointerdown,
    onPointerup: stopHold,
    onPointerleave: stopHold,
    onPointercancel: stopHold,
    onClick,
    onKeydown,
    onBlur,
    dismiss,
    bindings,
  }
}
