// One registry of commands that the menu bar, the context menus, the commands provider of the Jump and the key map all
// read, so every surface shows the same words and keys. Keys are written as chords: 'Mod+Shift+K', where Mod is Cmd on
// macOS and Ctrl elsewhere. Reserved suite keys are refused at registration (C18).
import { getCurrentScope, onScopeDispose, ref } from 'vue'
import type { Shortcut, ShortcutKeys, ShortcutRunContext, ShortcutStatus } from '../types/shortcuts'

export type ShortcutPlatform = 'mac' | 'other'

export interface ParsedKeys {
  /** Cmd on macOS, Ctrl elsewhere. */
  mod: boolean
  cmd: boolean
  ctrl: boolean
  alt: boolean
  shift: boolean
  /** The key, lower case, as KeyboardEvent.key spells it. A physical key is `code:` plus the lower case code; a range is `[1-9]`. */
  key: string
  /** Set for `code:BracketRight`: the KeyboardEvent.code the chord is matched on. */
  code?: string
  /** Set for `[1-9]`: the first and last digit the chord covers. */
  digits?: { first: number; last: number }
}

/** A Shortcut (types/shortcuts.ts) that can run. `showKeyWhen` false hides the key in menus and the Jump. */
export interface ShortcutCommand extends Shortcut {
  /** Required while the status is 'ready'; an unwired or reserved entry never runs. */
  run?: (context?: ShortcutRunContext) => void
  showKeyWhen?: () => boolean
}

export interface MenuEntry {
  id: string
  label: string
  /** The native menu the command belongs to, when the command names one. */
  menu?: string
  accelerator?: string
  /** Set by the 'neutral' format instead of `accelerator`: the chord in parts, for a shell that builds its own accelerator. */
  keys?: NeutralKeys
  enabled: boolean
}

/** The serialised menu format: 'electron' and 'tauri' emit accelerator strings, 'neutral' emits the parts. */
export type MenuFormat = 'electron' | 'tauri' | 'neutral'

export interface NeutralKeys {
  mod: boolean
  cmd: boolean
  ctrl: boolean
  alt: boolean
  shift: boolean
  key: string
  code?: string
}

export interface KeyPart {
  text: string
  spoken: string
}

const MODIFIER_NAMES: Record<string, 'mod' | 'cmd' | 'ctrl' | 'alt' | 'shift'> = {
  mod: 'mod',
  cmd: 'cmd',
  command: 'cmd',
  meta: 'cmd',
  ctrl: 'ctrl',
  control: 'ctrl',
  alt: 'alt',
  option: 'alt',
  shift: 'shift',
}

export function parseKeys(chord: string): ParsedKeys {
  const parsed: ParsedKeys = { mod: false, cmd: false, ctrl: false, alt: false, shift: false, key: '' }
  const pieces = chord.split('+')
  for (const [index, piece] of pieces.entries()) {
    const isLast = index === pieces.length - 1
    const modifier = MODIFIER_NAMES[piece.toLowerCase()]
    if (modifier !== undefined && !isLast) parsed[modifier] = true
    else if (isLast && piece !== '') {
      const range = /^\[(\d)-(\d)\]$/.exec(piece)
      if (range) {
        parsed.digits = { first: Number(range[1]), last: Number(range[2]) }
        if (parsed.digits.first > parsed.digits.last) throw new Error(`[shortcuts] "${chord}" has a backwards digit range`)
        parsed.key = piece
      } else if (piece.toLowerCase().startsWith('code:') && piece.length > 5) {
        parsed.code = piece.slice(5)
        parsed.key = `code:${parsed.code.toLowerCase()}`
      } else parsed.key = piece.toLowerCase()
    }
  }
  if (parsed.key === '') throw new Error(`[shortcuts] "${chord}" has no key`)
  if (parsed.key === 'esc') parsed.key = 'escape'
  if (parsed.key === 'space') parsed.key = ' '
  return parsed
}

export function detectPlatform(): ShortcutPlatform {
  if (typeof navigator === 'undefined') return 'other'
  return /mac|iphone|ipad/i.test(navigator.platform || navigator.userAgent) ? 'mac' : 'other'
}

const KEY_WORDS: Record<string, { mac: string; other: string; spoken: string }> = {
  // ⏎, not ↵ or ↩: the system font has neither at full size, and ⏎ shares the height and baseline of ⌘ (Raja OK'd it, 2026-11-16).
  enter: { mac: '⏎', other: 'Enter', spoken: 'Enter' },
  tab: { mac: '⇥', other: 'Tab', spoken: 'Tab' },
  backspace: { mac: '⌫', other: 'Backspace', spoken: 'Backspace' },
  delete: { mac: '⌦', other: 'Delete', spoken: 'Delete' },
  escape: { mac: 'Esc', other: 'Esc', spoken: 'Escape' },
  arrowup: { mac: '↑', other: '↑', spoken: 'Up arrow' },
  arrowdown: { mac: '↓', other: '↓', spoken: 'Down arrow' },
  arrowleft: { mac: '←', other: '←', spoken: 'Left arrow' },
  arrowright: { mac: '→', other: '→', spoken: 'Right arrow' },
  ' ': { mac: 'Space', other: 'Space', spoken: 'Space' },
  '\\': { mac: '\\', other: '\\', spoken: 'Backslash' },
  '/': { mac: '/', other: '/', spoken: 'Slash' },
  ',': { mac: ',', other: ',', spoken: 'Comma' },
  '.': { mac: '.', other: '.', spoken: 'Period' },
  '[': { mac: '[', other: '[', spoken: 'Left bracket' },
  ']': { mac: ']', other: ']', spoken: 'Right bracket' },
  '=': { mac: '=', other: '=', spoken: 'Equals' },
  '-': { mac: '-', other: '-', spoken: 'Minus' },
}

/** The character a physical key prints on a US layout, shown for a `code:` chord. */
const CODE_CHARACTERS: Record<string, string> = {
  bracketleft: '[',
  bracketright: ']',
  backslash: '\\',
  slash: '/',
  comma: ',',
  period: '.',
  minus: '-',
  equal: '=',
  semicolon: ';',
  quote: "'",
  backquote: '`',
}

function codeCharacter(code: string): string {
  const lower = code.toLowerCase()
  const digit = /^(?:digit|numpad)(\d)$/.exec(lower)
  if (digit) return digit[1] as string
  const letter = /^key([a-z])$/.exec(lower)
  if (letter) return (letter[1] as string).toUpperCase()
  return CODE_CHARACTERS[lower] ?? code
}

/** The keycaps of a chord, in the platform's order: Ctrl, Alt, Shift, then Cmd on macOS; Ctrl, Alt, Shift elsewhere. */
export function keyParts(chord: string, platform: ShortcutPlatform = detectPlatform()): KeyPart[] {
  const parsed = parseKeys(chord)
  const mac = platform === 'mac'
  const ctrl = parsed.ctrl || (parsed.mod && !mac)
  const cmd = parsed.cmd || (parsed.mod && mac)
  const parts: KeyPart[] = []
  if (ctrl) parts.push({ text: mac ? '⌃' : 'Ctrl', spoken: 'Control' })
  if (parsed.alt) parts.push({ text: mac ? '⌥' : 'Alt', spoken: mac ? 'Option' : 'Alt' })
  if (parsed.shift) parts.push({ text: mac ? '⇧' : 'Shift', spoken: 'Shift' })
  if (cmd) parts.push({ text: '⌘', spoken: 'Command' })
  if (parsed.digits) {
    parts.push({ text: `${parsed.digits.first}–${parsed.digits.last}`, spoken: `${parsed.digits.first} to ${parsed.digits.last}` })
    return parts
  }
  const printed = parsed.code === undefined ? parsed.key : codeCharacter(parsed.code).toLowerCase()
  const named = KEY_WORDS[printed]
  parts.push(named ? { text: mac ? named.mac : named.other, spoken: named.spoken } : { text: printed.toUpperCase(), spoken: printed.toUpperCase() })
  return parts
}

/** Cmd, Shift, Alt and Ctrl as glyphs on macOS, as words elsewhere. */
export function formatKeys(chord: string, platform: ShortcutPlatform = detectPlatform()): string {
  return keyParts(chord, platform)
    .map((part) => part.text)
    .join(platform === 'mac' ? '' : '+')
}

/** The chord as a screen reader should say it. */
export function spokenKeys(chord: string, platform: ShortcutPlatform = detectPlatform()): string {
  return keyParts(chord, platform)
    .map((part) => part.spoken)
    .join(' ')
}

const ACCELERATOR_KEYS: Record<string, string> = {
  arrowup: 'Up',
  arrowdown: 'Down',
  arrowleft: 'Left',
  arrowright: 'Right',
  escape: 'Escape',
  enter: 'Enter',
  ' ': 'Space',
}

/** Electron has no digit range, so a range chord has no accelerator. */
function accelerator(chord: string): string | undefined {
  const parsed = parseKeys(chord)
  if (parsed.digits) return undefined
  const pieces: string[] = []
  if (parsed.mod) pieces.push('CommandOrControl')
  if (parsed.cmd) pieces.push('Command')
  if (parsed.ctrl) pieces.push('Control')
  if (parsed.alt) pieces.push('Alt')
  if (parsed.shift) pieces.push('Shift')
  const printedKey = parsed.code === undefined ? parsed.key : codeCharacter(parsed.code).toLowerCase()
  const named = ACCELERATOR_KEYS[printedKey]
  const key = named ?? (printedKey.length === 1 ? printedKey.toUpperCase() : printedKey.charAt(0).toUpperCase() + printedKey.slice(1))
  return [...pieces, key].join('+')
}

const TAURI_KEYS: Record<string, string> = {
  arrowup: 'Up',
  arrowdown: 'Down',
  arrowleft: 'Left',
  arrowright: 'Right',
  escape: 'Escape',
  enter: 'Enter',
  tab: 'Tab',
  backspace: 'Backspace',
  delete: 'Delete',
  ' ': 'Space',
}

/** Tauri reads a menu accelerator by physical key, so punctuation is named by its code ("BracketRight"). */
const TAURI_PUNCTUATION: Record<string, string> = {
  '[': 'BracketLeft',
  ']': 'BracketRight',
  '\\': 'Backslash',
  '/': 'Slash',
  ',': 'Comma',
  '.': 'Period',
  '-': 'Minus',
  '=': 'Equal',
  ';': 'Semicolon',
  "'": 'Quote',
  '`': 'Backquote',
}

/** Tauri 2 accelerator: CmdOrCtrl, Cmd, Ctrl, Alt, Shift, then the key. A range chord has none. */
function tauriAccelerator(chord: string): string | undefined {
  const parsed = parseKeys(chord)
  if (parsed.digits) return undefined
  const pieces: string[] = []
  if (parsed.mod) pieces.push('CmdOrCtrl')
  if (parsed.cmd) pieces.push('Cmd')
  if (parsed.ctrl) pieces.push('Ctrl')
  if (parsed.alt) pieces.push('Alt')
  if (parsed.shift) pieces.push('Shift')
  const printedKey = parsed.code === undefined ? parsed.key : codeCharacter(parsed.code).toLowerCase()
  const key = TAURI_KEYS[printedKey] ?? TAURI_PUNCTUATION[printedKey] ?? (printedKey.length === 1 ? printedKey.toUpperCase() : printedKey.charAt(0).toUpperCase() + printedKey.slice(1))
  return [...pieces, key].join('+')
}

function neutralKeys(chord: string): NeutralKeys | undefined {
  const parsed = parseKeys(chord)
  if (parsed.digits) return undefined
  return { mod: parsed.mod, cmd: parsed.cmd, ctrl: parsed.ctrl, alt: parsed.alt, shift: parsed.shift, key: parsed.key, ...(parsed.code !== undefined ? { code: parsed.code } : {}) }
}

/** Cmd Shift O, Cmd Shift D and Ctrl 1 to 9 belong to the suite; an app never binds them. A range is checked member by member. */
function reservedReason(chord: string): string | undefined {
  const parsed = parseKeys(chord)
  const commandLike = parsed.mod || parsed.cmd
  if (commandLike && parsed.shift && !parsed.ctrl && !parsed.alt && (parsed.key === 'o' || parsed.key === 'd')) return 'Cmd Shift O and Cmd Shift D belong to the suite'
  if (parsed.ctrl && !parsed.alt && !parsed.shift && !commandLike) {
    const covers = parsed.digits ? parsed.digits.last >= 1 : /^[1-9]$/.test(parsed.key)
    if (covers) return 'Ctrl 1 to 9 belong to the suite'
  }
  return undefined
}

function isSplitChord(chord: string): boolean {
  const parsed = parseKeys(chord)
  return (parsed.mod || parsed.cmd) && !parsed.shift && !parsed.alt && !parsed.ctrl && parsed.key === '\\'
}

/** Every concrete key a parsed chord stands for: one, or each digit of a range. */
function memberKeys(parsed: ParsedKeys): string[] {
  if (!parsed.digits) return [parsed.key]
  const members: string[] = []
  for (let digit = parsed.digits.first; digit <= parsed.digits.last; digit += 1) members.push(String(digit))
  return members
}

function sameChord(first: ParsedKeys, second: ParsedKeys, platform: ShortcutPlatform): boolean {
  const resolve = (parsed: ParsedKeys) => ({
    cmd: parsed.cmd || (parsed.mod && platform === 'mac'),
    ctrl: parsed.ctrl || (parsed.mod && platform !== 'mac'),
    alt: parsed.alt,
    shift: parsed.shift,
  })
  const a = resolve(first)
  const b = resolve(second)
  if (a.cmd !== b.cmd || a.ctrl !== b.ctrl || a.alt !== b.alt || a.shift !== b.shift) return false
  const secondMembers = memberKeys(second)
  return memberKeys(first).some((member) => secondMembers.includes(member))
}

/** The digit an event types, from its key or, when Alt changed the key, from its code. */
function eventDigit(event: KeyboardEvent): number | undefined {
  if (/^\d$/.test(event.key)) return Number(event.key)
  const fromCode = /^(?:Digit|Numpad)(\d)$/.exec(event.code)
  return fromCode ? Number(fromCode[1]) : undefined
}

/** Whether the event is the chord; for a digit range, `digit` says which one. */
function eventMatches(event: KeyboardEvent, chord: string, platform: ShortcutPlatform): { digit?: number } | undefined {
  const parsed = parseKeys(chord)
  const wantsCmd = parsed.cmd || (parsed.mod && platform === 'mac')
  const wantsCtrl = parsed.ctrl || (parsed.mod && platform !== 'mac')
  const modifiersMatch = event.metaKey === wantsCmd && event.ctrlKey === wantsCtrl && event.altKey === parsed.alt && event.shiftKey === parsed.shift
  if (!modifiersMatch) return undefined
  if (parsed.digits) {
    const digit = eventDigit(event)
    return digit !== undefined && digit >= parsed.digits.first && digit <= parsed.digits.last ? { digit } : undefined
  }
  if (parsed.code !== undefined) return event.code.toLowerCase() === parsed.code.toLowerCase() ? {} : undefined
  return event.key.toLowerCase() === parsed.key ? {} : undefined
}

const GLOBAL_SCOPE = 'global'

function scopeOf(command: ShortcutCommand): string {
  return command.scope ?? GLOBAL_SCOPE
}

function statusOf(command: ShortcutCommand): ShortcutStatus {
  return command.status ?? 'ready'
}

/** The chord for a platform: a plain string is the same everywhere; an object names one chord per platform. */
export function resolveKeys(keys: ShortcutKeys, platform: ShortcutPlatform): string {
  return typeof keys === 'string' ? keys : keys[platform]
}

export interface ShortcutRegistryOptions {
  platform?: ShortcutPlatform
}

export function createShortcutRegistry(options: ShortcutRegistryOptions = {}) {
  const platform = options.platform ?? detectPlatform()
  const commands = new Map<string, ShortcutCommand>()
  const currentScope = ref(GLOBAL_SCOPE)

  function chordsOf(command: ShortcutCommand): string[] {
    return [resolveKeys(command.keys, platform), command.altKeys === undefined ? '' : resolveKeys(command.altKeys, platform)].filter((chord) => chord !== '')
  }

  /** The scope a keydown is matched in when `handleKeydown` is not given one. */
  function setActiveScope(scope: string): void {
    currentScope.value = scope
  }

  function activeScope(): string {
    return currentScope.value
  }

  function register(command: ShortcutCommand): () => void {
    if (statusOf(command) === 'ready' && command.run === undefined) throw new Error(`[shortcuts] "${command.id}" is ready but has no run`)
    for (const chord of chordsOf(command)) {
      const reason = reservedReason(chord)
      if (reason !== undefined) throw new Error(`[shortcuts] ${chord} is reserved (${reason}); "${command.id}" cannot bind it`)
      if (isSplitChord(chord) && command.suite !== 'yield') {
        console.warn(`[shortcuts] keys.suite: "${command.id}" binds Cmd \\ without suite: 'yield'; inside the suite the suite takes this chord`)
      }
      for (const other of commands.values()) {
        if (other.id === command.id) continue
        const otherScope = scopeOf(other)
        const ownScope = scopeOf(command)
        if (otherScope !== ownScope && otherScope !== GLOBAL_SCOPE && ownScope !== GLOBAL_SCOPE) continue
        const clash = chordsOf(other).find((otherChord) => sameChord(parseKeys(otherChord), parseKeys(chord), platform))
        if (clash !== undefined) throw new Error(`[shortcuts] ${chord} is already bound to "${other.id}"; "${command.id}" cannot take it`)
      }
    }
    commands.set(command.id, command)
    return () => {
      if (commands.get(command.id) === command) commands.delete(command.id)
    }
  }

  function get(id: string): ShortcutCommand | undefined {
    return commands.get(id)
  }

  function all(): ShortcutCommand[] {
    return [...commands.values()]
  }

  function keysFor(id: string, which: 'primary' | 'alternate' = 'primary'): string {
    const command = commands.get(id)
    if (!command) return ''
    const keys = which === 'alternate' ? command.altKeys : command.keys
    return keys === undefined ? '' : resolveKeys(keys, platform)
  }

  /** The chord the menus show: the first key set, or the second when the command has only that one. */
  function keysForMenu(id: string): string {
    const command = commands.get(id)
    if (!command) return ''
    return chordsOf(command)[0] ?? ''
  }

  /** The chords of a command for this platform, primary first, empty while `showKeyWhen` hides them. */
  function chordsFor(id: string): string[] {
    const command = commands.get(id)
    return command && keyShown(command) ? chordsOf(command) : []
  }

  function keyShown(command: ShortcutCommand): boolean {
    return command.showKeyWhen === undefined || command.showKeyWhen()
  }

  /** The text a menu, the Jump or the key map draws for a command's key; empty while the key is hidden or absent. */
  function kbdFor(id: string, which?: 'primary' | 'alternate'): string {
    const command = commands.get(id)
    if (!command || !keyShown(command)) return ''
    const chord = which === undefined ? keysForMenu(id) : keysFor(id, which)
    return chord === '' ? '' : formatKeys(chord, platform)
  }

  function spokenFor(id: string, which?: 'primary' | 'alternate'): string {
    const command = commands.get(id)
    if (!command || !keyShown(command)) return ''
    const chord = which === undefined ? keysForMenu(id) : keysFor(id, which)
    return chord === '' ? '' : spokenKeys(chord, platform)
  }

  function labelFor(id: string, state?: unknown): string {
    const command = commands.get(id)
    if (!command) return ''
    return state !== undefined && command.labelFor ? command.labelFor(state) : command.label
  }

  function enabled(id: string): boolean {
    const command = commands.get(id)
    return command !== undefined && statusOf(command) === 'ready' && (command.when === undefined || command.when())
  }

  function run(id: string, context?: ShortcutRunContext): boolean {
    const command = commands.get(id)
    if (!command || !enabled(id)) return false
    command.run?.(context)
    return true
  }

  /**
   * Runs the command whose chord this event is. Returns true, and prevents the default, when one ran. A command in the
   * active scope wins over a global one; a command in any other scope is not considered. Unwired and reserved entries never match.
   */
  function handleKeydown(event: KeyboardEvent, options: { scope?: string } = {}): boolean {
    if (event.isComposing) return false
    const active = options.scope ?? currentScope.value
    const passes = active === GLOBAL_SCOPE ? [GLOBAL_SCOPE] : [active, GLOBAL_SCOPE]
    for (const wanted of passes) {
      for (const command of commands.values()) {
        if (scopeOf(command) !== wanted || !enabled(command.id)) continue
        for (const chord of chordsOf(command)) {
          const matched = eventMatches(event, chord, platform)
          if (!matched) continue
          event.preventDefault()
          command.run?.(matched.digit === undefined ? undefined : { digit: matched.digit })
          return true
        }
      }
    }
    return false
  }

  function serialiseForMenu(state?: unknown, options: { format?: MenuFormat } = {}): MenuEntry[] {
    const format = options.format ?? 'electron'
    return all().map((command) => {
      const chord = keyShown(command) ? keysForMenu(command.id) : ''
      let keyFields: { accelerator?: string; keys?: NeutralKeys } = {}
      if (chord !== '') {
        if (format === 'neutral') {
          const keys = neutralKeys(chord)
          if (keys !== undefined) keyFields = { keys }
        } else {
          const text = format === 'tauri' ? tauriAccelerator(chord) : accelerator(chord)
          if (text !== undefined) keyFields = { accelerator: text }
        }
      }
      return {
        id: command.id,
        label: labelFor(command.id, state),
        ...(command.menu !== undefined ? { menu: command.menu } : {}),
        ...keyFields,
        enabled: enabled(command.id),
      }
    })
  }

  function byRegion(): { region: string; commands: ShortcutCommand[] }[] {
    const groups = new Map<string, ShortcutCommand[]>()
    for (const command of commands.values()) {
      const region = command.region ?? 'General'
      groups.set(region, [...(groups.get(region) ?? []), command])
    }
    return [...groups.entries()].map(([region, grouped]) => ({ region, commands: grouped }))
  }

  return { platform, register, get, all, chordsFor, setActiveScope, activeScope, keysFor, keysForMenu, kbdFor, spokenFor, labelFor, enabled, run, handleKeydown, serialiseForMenu, byRegion }
}

export type ShortcutRegistry = ReturnType<typeof createShortcutRegistry>

let sharedRegistry: ShortcutRegistry | undefined

/** The app's one registry. A command registered inside a component's scope is dropped when the scope stops. */
export function useShortcuts(): ShortcutRegistry {
  sharedRegistry ??= createShortcutRegistry()
  const registry = sharedRegistry
  return {
    ...registry,
    register(command) {
      const unregister = registry.register(command)
      if (getCurrentScope()) onScopeDispose(unregister)
      return unregister
    },
  }
}
