// Swipe to dismiss, our own small pointer handler (no dependency). The tracker is plain state so it can be tested without a
// pointer; useSwipeDismiss wires it to pointer events on one element. A swipe dismisses when it travels far enough, or
// when it is fast enough (distance over time above SWIPE_VELOCITY, the same rule Sonner uses). Only the dismiss side moves
// the element freely; the other side is held back.
import { onBeforeUnmount, shallowRef, type Ref } from 'vue'

export const SWIPE_DISTANCE_PX = 80
/** Pixels per millisecond. */
export const SWIPE_VELOCITY = 0.11
/** How much of a drag against the dismiss side the element follows. */
export const SWIPE_RESISTANCE = 0.15

export type SwipeOutcome = 'dismiss' | 'cancel'

export interface SwipeTracker {
  start(x: number, time: number): void
  /** Returns the offset the element should show, in pixels. */
  move(x: number, time: number): number
  end(time: number): SwipeOutcome
  cancel(): void
  readonly active: boolean
}

/** direction 1 dismisses by moving right, -1 by moving left. */
export function createSwipeTracker(direction: 1 | -1 = 1): SwipeTracker {
  let active = false
  let startX = 0
  let startTime = 0
  let offset = 0
  let lastTime = 0

  return {
    start(x, time) {
      active = true
      startX = x
      startTime = time
      lastTime = time
      offset = 0
    },
    move(x, time) {
      if (!active) return 0
      const delta = (x - startX) * direction
      offset = delta >= 0 ? delta : delta * SWIPE_RESISTANCE
      lastTime = time
      return offset * direction
    },
    end(time) {
      if (!active) return 'cancel'
      active = false
      const elapsed = Math.max(1, (time > lastTime ? time : lastTime) - startTime)
      const travelled = offset
      if (travelled <= 0) return 'cancel'
      if (travelled >= SWIPE_DISTANCE_PX || travelled / elapsed > SWIPE_VELOCITY) return 'dismiss'
      return 'cancel'
    },
    cancel() {
      active = false
      offset = 0
    },
    get active() {
      return active
    },
  }
}

export interface SwipeDismissOptions {
  onDismiss: () => void
  direction?: 1 | -1
  /** Pointer targets that must not start a swipe (buttons, links). */
  ignore?: string
}

export interface SwipeDismiss {
  /** The current offset in pixels, for a CSS variable. */
  offset: Ref<number>
  swiping: Ref<boolean>
  onPointerdown(event: PointerEvent): void
  onPointermove(event: PointerEvent): void
  onPointerup(event: PointerEvent): void
  onPointercancel(event: PointerEvent): void
}

export function useSwipeDismiss(options: SwipeDismissOptions): SwipeDismiss {
  const tracker = createSwipeTracker(options.direction ?? 1)
  const offset = shallowRef(0)
  const swiping = shallowRef(false)
  const ignore = options.ignore ?? 'button, a, input, textarea, select'

  function finish(outcome: SwipeOutcome): void {
    swiping.value = false
    if (outcome === 'dismiss') options.onDismiss()
    else offset.value = 0
  }

  onBeforeUnmount(() => tracker.cancel())

  return {
    offset,
    swiping,
    onPointerdown(event) {
      if (event.button !== 0 && event.pointerType === 'mouse') return
      if (event.target instanceof Element && event.target.closest(ignore) !== null) return
      tracker.start(event.clientX, event.timeStamp)
      swiping.value = true
      const target = event.currentTarget as Element | null
      target?.setPointerCapture?.(event.pointerId)
    },
    onPointermove(event) {
      if (!tracker.active) return
      offset.value = tracker.move(event.clientX, event.timeStamp)
    },
    onPointerup(event) {
      if (!tracker.active) return
      const target = event.currentTarget as Element | null
      target?.releasePointerCapture?.(event.pointerId)
      finish(tracker.end(event.timeStamp))
    },
    onPointercancel() {
      if (!tracker.active) return
      tracker.cancel()
      finish('cancel')
    },
  }
}
