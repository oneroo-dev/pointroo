import type { InjectionKey } from 'vue'

/** True inside a RooWindow. A RooBar there wraps its leading and pill slots in one box, which the roomy web shell turns into the
 *  header's first column, as wide as the sidebar below it (anatomy.css, --roo-window-sidebar-edge). A bar outside a window keeps
 *  its slots as its own children. */
export const ROO_WINDOW_SHELL: InjectionKey<boolean> = Symbol('roo-window-shell')
