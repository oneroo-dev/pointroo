import { computed, toValue, type MaybeRefOrGetter } from 'vue'

/** The motion tokens `--roo-stagger` and `--roo-stagger-max`, in ms. A test keeps these equal to the CSS. */
export const SETTLE_STAGGER_STEP_MS = 20
export const SETTLE_STAGGER_CAP_MS = 120

/**
 * The first rows of a result arrive one after another (the Settle move). Put `className` on the list and
 * `indexStyle(index)` on each row; the motion layer turns the index into a delay and caps the total, and drops the
 * whole thing under reduced motion.
 */
export function useSettleStagger(count: MaybeRefOrGetter<number>) {
  const lastIndex = computed(() => Math.max(0, Math.floor(toValue(count)) - 1))

  function indexStyle(index: number): { '--roo-index': number } {
    return { '--roo-index': Math.min(Math.max(0, index), lastIndex.value) }
  }

  const totalMs = computed(() => Math.min(lastIndex.value * SETTLE_STAGGER_STEP_MS, SETTLE_STAGGER_CAP_MS))

  return { className: 'roo-stagger', indexStyle, totalMs }
}
