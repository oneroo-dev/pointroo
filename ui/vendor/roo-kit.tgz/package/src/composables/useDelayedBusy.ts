import { onScopeDispose, getCurrentScope, ref, toValue, watch, type MaybeRefOrGetter } from 'vue'

export const BUSY_DELAY_MS = 300
export const SLOW_AFTER_MS = 2000

/**
 * Busy feedback that stays out of the way: `busy` turns on only if the promise is still pending after `showAfterMs`
 * (so a quick answer shows nothing at all), and `slow` turns on after `slowAfterMs` (time for a "still working" line).
 * Both clear when the promise settles, however it settles. A new promise starts over and the old one is ignored.
 */
export function useDelayedBusy(
  source: MaybeRefOrGetter<Promise<unknown> | null | undefined>,
  showAfterMs: number = BUSY_DELAY_MS,
  slowAfterMs: number = SLOW_AFTER_MS,
) {
  const busy = ref(false)
  const slow = ref(false)
  let busyTimer: ReturnType<typeof setTimeout> | undefined
  let slowTimer: ReturnType<typeof setTimeout> | undefined
  let generation = 0

  function stop(): void {
    clearTimeout(busyTimer)
    clearTimeout(slowTimer)
    busy.value = false
    slow.value = false
  }

  function start(promise: Promise<unknown> | null | undefined): void {
    generation += 1
    const mine = generation
    stop()
    if (!promise) return
    busyTimer = setTimeout(() => {
      if (mine === generation) busy.value = true
    }, showAfterMs)
    slowTimer = setTimeout(() => {
      if (mine === generation) slow.value = true
    }, slowAfterMs)
    const settle = () => {
      if (mine === generation) stop()
    }
    promise.then(settle, settle)
  }

  // The promise travels inside an array: Vue attaches its own catch to a promise a getter returns, which would report a rejection twice.
  watch(() => [toValue(source)] as const, ([promise]) => start(promise), { immediate: true, flush: 'sync' })

  if (getCurrentScope()) {
    onScopeDispose(() => {
      generation += 1
      stop()
    })
  }

  return { busy, slow }
}
