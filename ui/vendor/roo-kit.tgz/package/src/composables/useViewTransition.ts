// A route or card-to-page change as a View Transition, where the browser has one (progressive enhancement, no polyfill).
// Call it around the state change: `await runRooViewTransition(() => router.push(path))`. The update always runs exactly
// once. The browser's cross-fade is skipped under reduced motion, data-motion="still" and the desktop surface, so those
// get the plain instant change. Give a card and its page header the same `view-transition-name` for a shared element.
import { readRooSurface } from '../surface'

interface ViewTransitionDocument {
  startViewTransition?: (update: () => void | Promise<void>) => { finished: Promise<unknown> }
}

function motionIsOff(): boolean {
  if (typeof document === 'undefined') return true
  if (readRooSurface() === 'desktop') return true
  if (document.documentElement.getAttribute('data-motion') === 'still') return true
  return typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches
}

/** Runs `update` inside a View Transition when the browser supports it and motion is on; otherwise runs it plainly. */
export async function runRooViewTransition(update: () => void | Promise<void>): Promise<void> {
  const start = typeof document === 'undefined' ? undefined : (document as unknown as ViewTransitionDocument).startViewTransition
  if (start === undefined || motionIsOff()) {
    await update()
    return
  }
  const transition = start.call(document, update)
  try {
    await transition.finished
  } catch {
    // A skipped or interrupted transition still ran the update, so there is nothing to undo.
  }
}
