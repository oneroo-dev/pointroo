import { getCurrentScope, onScopeDispose, ref, type Ref } from 'vue'

export interface HoldToConfirm {
  /** 0 while idle, rises to 1 while held, stays 1 after a confirm until released. */
  progress: Ref<number>
  /** True from a confirm until the next release (cancel); a new hold cannot start meanwhile. */
  confirmed: Ref<boolean>
  /** True from start() until confirm or cancel. */
  holding: Ref<boolean>
  start(): void
  /** Release or abort: stops the hold, resets progress and unlocks after a confirm. */
  cancel(): void
  onConfirm(callback: () => void): void
}

/** Shortest hold the kit accepts, so a 0 or tiny duration can never confirm by accident. */
export const MINIMUM_HOLD_MS = 300

/**
 * Press and hold to confirm a risky action. Progress follows requestAnimationFrame against
 * performance.now(). While a hold runs, leaving the window or hiding the tab cancels it. After a
 * confirm the hold stays locked until released, so a second finger or key cannot confirm twice.
 * Safe to import without a DOM: it only touches window and document while a hold runs.
 */
export interface HoldToConfirmOptions {
  /** Checked again at the exact moment of confirm; false cancels the hold instead. */
  canConfirm?: () => boolean
}

export function useHoldToConfirm(
  durationMs: number | (() => number),
  options: HoldToConfirmOptions = {},
): HoldToConfirm {
  const progress = ref(0)
  const confirmed = ref(false)
  const confirmCallbacks: Array<() => void> = []
  let startedAt = 0
  let currentDurationMs = MINIMUM_HOLD_MS
  let frame = 0
  const holding = ref(false)

  function readDuration(): number {
    const value = typeof durationMs === 'function' ? durationMs() : durationMs
    return Number.isFinite(value) ? Math.max(value, MINIMUM_HOLD_MS) : MINIMUM_HOLD_MS
  }

  function cancelWhenHidden(): void {
    if (document.visibilityState === 'hidden') cancel()
  }

  function listen(): void {
    window.addEventListener('blur', cancel)
    document.addEventListener('visibilitychange', cancelWhenHidden)
  }

  function stopListening(): void {
    if (typeof window === 'undefined') return
    window.removeEventListener('blur', cancel)
    document.removeEventListener('visibilitychange', cancelWhenHidden)
    window.removeEventListener('pointerup', cancel)
    window.removeEventListener('keyup', cancel)
  }

  // After a confirm, any pointer or key release anywhere unlocks, so a release that the button
  // never saw (hidden, moved, focus lost) cannot leave it stuck.
  function listenForRelease(): void {
    window.addEventListener('pointerup', cancel)
    window.addEventListener('keyup', cancel)
  }

  function stopFrame(): void {
    if (frame !== 0) cancelAnimationFrame(frame)
    frame = 0
  }

  function tick(): void {
    if (!holding.value) return
    progress.value = Math.min((performance.now() - startedAt) / currentDurationMs, 1)
    if (progress.value < 1) {
      frame = requestAnimationFrame(tick)
      return
    }
    if (options.canConfirm && !options.canConfirm()) {
      cancel()
      return
    }
    holding.value = false
    confirmed.value = true
    stopFrame()
    stopListening()
    listenForRelease()
    for (const callback of confirmCallbacks) callback()
  }

  function start(): void {
    if (holding.value || confirmed.value || typeof window === 'undefined') return
    holding.value = true
    currentDurationMs = readDuration()
    startedAt = performance.now()
    progress.value = 0
    listen()
    frame = requestAnimationFrame(tick)
  }

  function cancel(): void {
    holding.value = false
    confirmed.value = false
    stopFrame()
    stopListening()
    progress.value = 0
  }

  if (getCurrentScope()) {
    onScopeDispose(() => {
      cancel()
      confirmCallbacks.length = 0
    })
  }

  return {
    progress,
    confirmed,
    holding,
    start,
    cancel,
    onConfirm(callback) {
      confirmCallbacks.push(callback)
    },
  }
}
