import type { Ref } from 'vue'

export type RovingOrientation = 'horizontal' | 'vertical' | 'both'

const DISABLED_ITEM = '[disabled], [aria-disabled="true"], [hidden], [data-roving-skip]'

/**
 * The index a key moves to inside a roving group, or null when the key is not a movement key for this orientation.
 * The ends wrap, so the arrow past the last item lands on the first.
 */
export function rovingTarget(key: string, orientation: RovingOrientation, index: number, count: number): number | null {
  if (count <= 0) return null
  if (key === 'Home') return 0
  if (key === 'End') return count - 1
  const forward = key === 'ArrowDown' ? 'vertical' : key === 'ArrowRight' ? 'horizontal' : null
  const backward = key === 'ArrowUp' ? 'vertical' : key === 'ArrowLeft' ? 'horizontal' : null
  const axis = forward ?? backward
  if (axis === null || (orientation !== 'both' && orientation !== axis)) return null
  const from = index < 0 ? 0 : index
  return forward !== null ? (from + 1) % count : (from - 1 + count) % count
}

export interface RovingOptions {
  /** Matches every item of the group, for example `[data-roving-item]`. */
  itemSelector: string
  orientation: RovingOrientation
  /** Called after focus moved by key, for groups that select as focus moves (tabs, radios). */
  onMove?: (item: HTMLElement) => void
}

export interface RovingTabindex {
  onKeydown(event: KeyboardEvent): void
  onFocusin(event: FocusEvent): void
  /** Re-applies the single tab stop; call it after mount and after every update. */
  sync(): void
}

function isSelectedMarker(item: HTMLElement): boolean {
  const current = item.getAttribute('aria-current')
  return (
    item.getAttribute('aria-selected') === 'true' ||
    item.getAttribute('aria-checked') === 'true' ||
    (current !== null && current !== 'false') ||
    item.getAttribute('data-selected') === 'true'
  )
}

/**
 * One tab stop for a group of items: the item last focused, else the selected one, else the first. Arrow keys, Home and
 * End move it. The tabindex attributes are written on the elements directly, so an item component needs no prop for it.
 */
export function useRovingTabindex(container: Ref<HTMLElement | null>, options: RovingOptions): RovingTabindex {
  let current: HTMLElement | null = null

  function every(): HTMLElement[] {
    const root = container.value
    return root === null ? [] : Array.from(root.querySelectorAll<HTMLElement>(options.itemSelector))
  }

  function items(): HTMLElement[] {
    return every().filter((item) => !item.matches(DISABLED_ITEM))
  }

  function sync(): void {
    const all = items()
    for (const item of every()) if (!all.includes(item)) item.setAttribute('tabindex', '-1')
    if (all.length === 0) return
    // Focus is elsewhere: the tab stop goes back to the selected item.
    if (container.value !== null && !container.value.contains(document.activeElement)) current = null
    const stop = (current !== null && all.includes(current) ? current : null) ?? all.find(isSelectedMarker) ?? all[0]!
    for (const item of all) item.setAttribute('tabindex', item === stop ? '0' : '-1')
  }

  function onFocusin(event: FocusEvent): void {
    const item = (event.target as HTMLElement | null)?.closest<HTMLElement>(options.itemSelector) ?? null
    if (item === null || !items().includes(item)) return
    current = item
    sync()
  }

  function onKeydown(event: KeyboardEvent): void {
    if (event.altKey || event.ctrlKey || event.metaKey) return
    const origin = (event.target as HTMLElement | null)?.closest<HTMLElement>(options.itemSelector) ?? null
    if (origin === null) return
    const all = items()
    const index = all.indexOf(origin)
    const target = rovingTarget(event.key, options.orientation, index, all.length)
    if (target === null || index < 0) return
    event.preventDefault()
    const next = all[target]!
    current = next
    sync()
    next.focus()
    options.onMove?.(next)
  }

  return { onKeydown, onFocusin, sync }
}
