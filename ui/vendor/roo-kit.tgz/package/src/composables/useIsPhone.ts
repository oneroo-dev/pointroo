// True while the viewport is phone width (under 720 px), which is where the explain pattern turns a popover or a side
// panel into a bottom sheet. Reads matchMedia, so it follows rotation and window resizes; without matchMedia it is false.
import { onScopeDispose, ref, type Ref } from 'vue'

export const PHONE_MAX_WIDTH = 719
export const PHONE_QUERY = `(max-width: ${PHONE_MAX_WIDTH}px)`

export function useIsPhone(): Ref<boolean> {
  const isPhone = ref(false)
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return isPhone
  const query = window.matchMedia(PHONE_QUERY)
  isPhone.value = query.matches
  const onChange = (event: MediaQueryListEvent): void => {
    isPhone.value = event.matches
  }
  query.addEventListener('change', onChange)
  onScopeDispose(() => query.removeEventListener('change', onChange))
  return isPhone
}
