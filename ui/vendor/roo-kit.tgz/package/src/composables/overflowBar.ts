import type { InjectionKey } from 'vue'
import type { RooIconName } from '../icons/paths'

/** What a RooOverflowItem tells its bar. The values are read when needed, so they follow the item's props. */
export interface OverflowItemEntry {
  readonly identifier: number
  readonly element: HTMLElement | null
  readonly priority: number
  readonly pinned: boolean
  readonly label: string
  readonly icon: RooIconName | undefined
  readonly disabled: boolean
  run(): void
}

export interface OverflowBarContext {
  nextIdentifier(): number
  register(entry: OverflowItemEntry): void
  unregister(identifier: number): void
  /** An item's content changed, so its width may have. */
  invalidate(): void
  isFolded(identifier: number): boolean
}

export const ROO_OVERFLOW_BAR: InjectionKey<OverflowBarContext> = Symbol('roo-overflow-bar')
