import { getCurrentScope, onScopeDispose, ref, watch, type Ref, type WatchSource } from 'vue'

/** The family arm delay: a plain press stays locked this long after the confirm appears (Pingroo, D2). */
export const ARM_DELAY_MS = 500

/** Shortest delay the kit accepts, so a 0 or tiny delay can never unlock a press that the person did not mean. */
export const MINIMUM_ARM_DELAY_MS = 250

export interface ArmDelay {
  /** False from the start (and from every restart) until the delay has passed. */
  ready: Ref<boolean>
  /** Lock again and start the delay over. */
  restart(): void
  /** True when a press may confirm now: the delay has passed and the key is not an auto-repeat of a held key. */
  accepts(event?: { repeat?: boolean }): boolean
}

/**
 * A short lock on a plain press, so a key that was already down when the confirm appeared (a held Enter, a double
 * click) cannot confirm it. It ignores auto-repeating keydown events for good, and it starts over whenever `key`
 * changes (the target of the confirm changed under the person's finger). Safe to import without a DOM.
 */
export function useArmDelay(delayMs: number | (() => number) = ARM_DELAY_MS, key?: WatchSource<unknown>): ArmDelay {
  const ready = ref(false)
  let timer: ReturnType<typeof setTimeout> | undefined

  function readDelay(): number {
    const value = typeof delayMs === 'function' ? delayMs() : delayMs
    return Number.isFinite(value) ? Math.max(value, MINIMUM_ARM_DELAY_MS) : MINIMUM_ARM_DELAY_MS
  }

  function restart(): void {
    clearTimeout(timer)
    ready.value = false
    timer = setTimeout(() => {
      ready.value = true
    }, readDelay())
  }

  function accepts(event?: { repeat?: boolean }): boolean {
    if (event?.repeat) return false
    return ready.value
  }

  restart()
  if (key !== undefined) watch(key, restart)
  if (getCurrentScope()) onScopeDispose(() => clearTimeout(timer))

  return { ready, restart, accepts }
}
