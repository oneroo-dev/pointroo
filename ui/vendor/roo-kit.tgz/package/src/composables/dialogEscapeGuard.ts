import type { InjectionKey } from 'vue'

/**
 * A part inside a RooDialog that has its own Esc step to take first (a search field with words in it) registers a guard.
 * The dialog asks its guards when Esc arrives: a guard that returns true took the Esc (it cleared the words), so the dialog stays
 * open; when none does, Esc closes the dialog as it always has. The returned function removes the guard.
 */
export type DialogEscapeGuard = () => boolean
export type RegisterDialogEscapeGuard = (guard: DialogEscapeGuard) => () => void

export const dialogEscapeGuardKey: InjectionKey<RegisterDialogEscapeGuard> = Symbol('roo-dialog-escape-guard')
