import type { JumpRow } from '../types/jump'
import type { RooEnvironment } from '../types/environment'

/** Words are lowercase source text; the capitals, where there are any, come from CSS. */
export const NOT_INSTALLED_WORD = 'not installed'

/** One place a thing can be opened. `link` is the draft an `@roo/links` builder turns into a link; it never reaches a row. */
export interface OpenInTarget {
  /** The app's id, as the host knows it ("tableroo"). */
  app: string
  /** The name shown to people ("Tableroo"). */
  name: string
  link: object
  environment?: RooEnvironment
  /** Confirm even when the environment is not prod (a file object, which names an endpoint nobody classified). */
  alwaysConfirm?: boolean
  /** Where to send a person whose machine does not have the app. */
  notInstalledUrl?: string
}

export type LinkBuilder = (link: never) => string

export interface OpenInRow extends JumpRow {
  app: string
  /** The built link; empty for a website row. */
  url: string
  kind: 'link' | 'website'
  alwaysConfirm: boolean
  notInstalledUrl?: string
}

/** Prod and unclassified targets always wait for the app's confirm; so does a target marked `alwaysConfirm`. */
export function needsConfirm(row: Pick<OpenInRow, 'environment' | 'alwaysConfirm'>): boolean {
  return row.alwaysConfirm || row.environment === 'prod' || row.environment === 'unclassified'
}

/**
 * One row per target. A target whose link will not build (any throw, or a result that is not text) has no row at all,
 * so a malformed draft is never offered. `installed` answers per app; undefined means not known yet, treated as installed.
 */
export function buildOpenInRows(
  targets: OpenInTarget[],
  buildLink: LinkBuilder,
  installed: (app: string) => boolean | undefined = () => undefined,
): OpenInRow[] {
  const rows: OpenInRow[] = []
  targets.forEach((target, index) => {
    let url: string
    try {
      const built: unknown = buildLink(target.link as never)
      if (typeof built !== 'string' || built === '') return
      url = built
    } catch {
      return
    }
    const missing = installed(target.app) === false
    const row: OpenInRow = {
      id: `open-in:${target.app}:${index}`,
      label: `Open in ${target.name}`,
      section: 'open in',
      app: target.app,
      url: missing ? '' : url,
      kind: missing ? 'website' : 'link',
      alwaysConfirm: target.alwaysConfirm ?? false,
      alternate: { label: 'Open in a split' },
    }
    if (target.environment) row.environment = target.environment
    if (missing) {
      row.meta = NOT_INSTALLED_WORD
      row.disabled = !target.notInstalledUrl
      if (target.notInstalledUrl) row.notInstalledUrl = target.notInstalledUrl
      delete row.alternate
    }
    rows.push(row)
  })
  return rows
}
