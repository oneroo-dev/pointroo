// F6 and Shift F6 move focus between the regions of a window (sidebar, main, tray), in the order they sit in the page.
import { getCurrentScope, onScopeDispose } from 'vue'

const FOCUSABLE = 'a[href], button:not(:disabled), input:not(:disabled), select:not(:disabled), textarea:not(:disabled), [tabindex]:not([tabindex="-1"])'

export function createRegionRegistry() {
  const regions = new Map<string, () => HTMLElement | null>()

  function register(id: string, element: () => HTMLElement | null): () => void {
    regions.set(id, element)
    return () => {
      if (regions.get(id) === element) regions.delete(id)
    }
  }

  function elements(): { id: string; element: HTMLElement }[] {
    const present: { id: string; element: HTMLElement }[] = []
    for (const [id, find] of regions) {
      const element = find()
      if (element?.isConnected) present.push({ id, element })
    }
    return present.sort((first, second) => (first.element.compareDocumentPosition(second.element) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1))
  }

  /** The ids of the regions that are in the page, in page order. */
  function order(): string[] {
    return elements().map((entry) => entry.id)
  }

  /** The region that holds focus now, or undefined when focus is outside every region. */
  function current(): string | undefined {
    const active = typeof document === 'undefined' ? null : document.activeElement
    return elements().find((entry) => active !== null && entry.element.contains(active))?.id
  }

  function focus(id: string): boolean {
    const target = elements().find((entry) => entry.id === id)?.element
    if (!target) return false
    const inside = target.matches(FOCUSABLE) ? target : target.querySelector<HTMLElement>(FOCUSABLE)
    if (inside) inside.focus()
    else {
      if (!target.hasAttribute('tabindex')) target.setAttribute('tabindex', '-1')
      target.focus()
    }
    return true
  }

  function move(step: 1 | -1): void {
    const ids = order()
    if (ids.length === 0) return
    const at = ids.indexOf(current() ?? '')
    const next = at === -1 ? (step === 1 ? 0 : ids.length - 1) : (at + step + ids.length) % ids.length
    focus(ids[next]!)
  }

  const next = () => move(1)
  const previous = () => move(-1)

  /** F6 goes forward, Shift F6 back. Returns true when it handled the key. */
  function handleKeydown(event: KeyboardEvent): boolean {
    if (event.key !== 'F6' || event.ctrlKey || event.metaKey || event.altKey) return false
    event.preventDefault()
    if (event.shiftKey) previous()
    else next()
    return true
  }

  return { register, order, current, focus, next, previous, handleKeydown }
}

export type RegionRegistry = ReturnType<typeof createRegionRegistry>

let sharedRegions: RegionRegistry | undefined

/** The window's one region registry. A region registered inside a component's scope is dropped when the scope stops. */
export function useRegions(): RegionRegistry {
  sharedRegions ??= createRegionRegistry()
  const registry = sharedRegions
  return {
    ...registry,
    register(id, element) {
      const unregister = registry.register(id, element)
      if (getCurrentScope()) onScopeDispose(unregister)
      return unregister
    },
  }
}
