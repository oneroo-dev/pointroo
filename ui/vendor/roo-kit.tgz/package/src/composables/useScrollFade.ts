// Tells a scrolling element which of its edges has more to scroll, so a style can fade only that edge.
// `top` is true once scrolled down; `bottom` is true while more is below. Both are false when everything fits.
// Call `update` from the element's scroll event (a template listener goes away with the element). Size changes are
// watched here with a ResizeObserver, which is disconnected when the component unmounts.
import { onBeforeUnmount, onMounted, ref, type Ref } from 'vue'

export function useScrollFade(element: Ref<HTMLElement | null>) {
  const top = ref(false)
  const bottom = ref(false)
  let resizeObserver: ResizeObserver | undefined

  function update(): void {
    const target = element.value
    if (!target) return
    top.value = target.scrollTop > 0.5
    bottom.value = target.scrollTop + target.clientHeight < target.scrollHeight - 0.5
  }

  onMounted(() => {
    const target = element.value
    if (!target) return
    update()
    if (typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(update)
      resizeObserver.observe(target)
    }
  })

  onBeforeUnmount(() => {
    resizeObserver?.disconnect()
  })

  return { top, bottom, update }
}
