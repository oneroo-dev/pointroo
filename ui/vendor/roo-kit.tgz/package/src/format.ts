// Time as people read it (T17): relative under a day, a clock after, the exact time for a tooltip.
// formatKeys lives in K4. Nothing here reads the clock unless the caller omits `now`.

export interface FormatRelativeOptions {
  /** BCP 47 tag; defaults to the runtime's locale. */
  locale?: string
  /** IANA zone for the clock form and the exact form; defaults to the runtime's zone. */
  timeZone?: string
}

export interface FormattedTime {
  /** "just now", "5 min ago", "3 h ago", or a clock form once a day has passed. */
  text: string
  /** The full local date and time, for a tooltip. */
  exact: string
  /** Milliseconds until `text` can change; the caller re-renders then. Never below 1 000. */
  nextChangeMs: number
}

/** How often a list of relative times re-renders. */
export const RELATIVE_TICK_MS = 30_000

const minuteMs = 60_000
const hourMs = 60 * minuteMs
const dayMs = 24 * hourMs

export function formatRelative(time: number | Date, now: number | Date = Date.now(), options: FormatRelativeOptions = {}): FormattedTime {
  const timeMs = typeof time === 'number' ? time : time.getTime()
  const nowMs = typeof now === 'number' ? now : now.getTime()
  const zone = options.timeZone === undefined ? {} : { timeZone: options.timeZone }
  const exact = new Intl.DateTimeFormat(options.locale, { dateStyle: 'medium', timeStyle: 'medium', ...zone }).format(timeMs)
  const age = Math.max(0, nowMs - timeMs)

  if (age < minuteMs) return { text: 'just now', exact, nextChangeMs: Math.max(1_000, minuteMs - age) }
  if (age < hourMs) {
    const minutes = Math.floor(age / minuteMs)
    return { text: `${minutes} min ago`, exact, nextChangeMs: Math.max(1_000, (minutes + 1) * minuteMs - age) }
  }
  if (age < dayMs) {
    const hours = Math.floor(age / hourMs)
    return { text: `${hours} h ago`, exact, nextChangeMs: Math.max(1_000, (hours + 1) * hourMs - age) }
  }

  const sameYear = new Date(timeMs).getFullYear() === new Date(nowMs).getFullYear()
  const clock = new Intl.DateTimeFormat(options.locale, {
    ...(sameYear ? {} : { year: 'numeric' }),
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
    ...zone,
  }).format(timeMs)
  return { text: clock, exact, nextChangeMs: Number.POSITIVE_INFINITY }
}
