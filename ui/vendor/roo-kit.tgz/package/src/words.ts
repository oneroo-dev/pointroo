// Health and status words as one constant (T16). Written lowercase; capitals, where a part wants them, come from CSS.

/** How a thing the app watches is doing. */
export const HEALTH_WORDS = ['ok', 'slow', 'down'] as const

/** What a connection, process or service is doing now. */
export const STATUS_WORDS = [
  'starting',
  'running',
  'stopped',
  'switching',
  'connecting',
  'reconnecting',
  'offline',
  'disconnected',
  'restarting',
  'failed',
  'checking',
  'unreachable',
  'no access',
] as const

export type HealthWord = (typeof HEALTH_WORDS)[number]
export type StatusWord = (typeof STATUS_WORDS)[number]

export function isHealthWord(value: string): value is HealthWord {
  return (HEALTH_WORDS as readonly string[]).includes(value)
}

export function isStatusWord(value: string): value is StatusWord {
  return (STATUS_WORDS as readonly string[]).includes(value)
}
