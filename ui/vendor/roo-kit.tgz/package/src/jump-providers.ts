import type { ShortcutRegistry } from './composables/useShortcuts'
import type { JumpProvider, JumpRow } from './types/jump'

/**
 * The `commands` provider of the Jump. It reads the same registry as the menus and the key map, so a command carries the
 * same words and the same key on every surface. A command whose `when` is false stays listed, disabled.
 */
export function commandsProvider(registry: ShortcutRegistry, options: { state?: unknown } = {}): JumpProvider {
  return {
    id: 'commands',
    section: 'commands',
    query(text: string): JumpRow[] {
      const needle = text.trim().toLowerCase()
      return registry
        .all()
        .filter((command) => registry.labelFor(command.id, options.state).toLowerCase().includes(needle))
        .map((command): JumpRow => {
          const chord = registry.kbdFor(command.id) === '' ? undefined : registry.keysForMenu(command.id)
          return {
            id: command.id,
            section: 'commands',
            label: registry.labelFor(command.id, options.state),
            ...(chord !== undefined ? { keys: chord } : {}),
            ...(registry.enabled(command.id) ? {} : { disabled: true }),
            run: () => {
              registry.run(command.id)
            },
          }
        })
    },
  }
}
