// Test helpers for apps: mount a component under the kit's root providers, so no app reads reka's private context keys.
// Needs @vue/test-utils, which every consuming app already has as a dev dependency.
import { mount, type VueWrapper } from '@vue/test-utils'
import { defineComponent, h, nextTick, reactive, type Component, type VNodeChild } from 'vue'
import RooTooltipProvider from '../components/RooTooltipProvider.vue'

/** Wraps its default slot in every root provider the kit needs. Today that is RooTooltipProvider. */
export const RooTestProviders = defineComponent({
  name: 'RooTestProviders',
  setup(_, { slots }) {
    return () => h(RooTooltipProvider, null, { default: () => slots.default?.() })
  },
})

export interface MountWithRooOptions {
  props?: Record<string, unknown>
  slots?: Record<string, string | ((properties: Record<string, unknown>) => VNodeChild)>
  attachTo?: Element | string
  global?: Record<string, unknown>
}

/**
 * Mounts `component` inside RooTestProviders and returns the wrapper of the component itself, so `find`, `text`,
 * `props` and `emitted` read the component and `setProps` updates it.
 */
export function mountWithRoo(component: Component, options: MountWithRooOptions = {}): VueWrapper {
  const state = reactive<Record<string, unknown>>({ ...options.props })
  const slots = Object.fromEntries(
    Object.entries(options.slots ?? {}).map(([name, slot]) => [name, typeof slot === 'string' ? () => slot : slot]),
  )
  const host = defineComponent({
    name: 'RooTestHost',
    setup() {
      return () => h(RooTestProviders, null, { default: () => h(component, { ...state }, slots) })
    },
  })
  const mountOptions: Record<string, unknown> = { global: options.global }
  if (options.attachTo !== undefined) mountOptions.attachTo = options.attachTo
  const hostWrapper = mount(host, mountOptions)
  const wrapper = hostWrapper.findComponent(component as never) as VueWrapper
  wrapper.unmount = () => hostWrapper.unmount()
  wrapper.setProps = async (next: Record<string, unknown>) => {
    Object.assign(state, next)
    await nextTick()
  }
  return wrapper
}
export { alignProbe, alignProbeSource } from './align-probe'
export { tapTargetProbe, tapTargetProbeSource } from './tap-target-probe'
