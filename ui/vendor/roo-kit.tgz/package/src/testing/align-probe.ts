// Alignment probe for render harnesses (family rule "One text line per column", 2026-11-13).
// Run in the page, for example with Playwright: `const report = await page.evaluate(alignProbeSource)`.
// It finds the left edge of the first text glyph or icon in each visible block, groups the edges by column,
// and reports near-misses: two edges 1 to 12 css px apart in the same column. Equal edges and real indents
// (16 px or more) pass. The page can mark a column root with `data-align-column` and opt a block out with
// `data-align-ignore`. A full-width boxed control (search field, filling segmented control) marked `data-align-box`
// is measured by its box edge, not its text, so it lines up box to box with its neighbours.
// A ghost button (RooButton variant ghost, `.roo-button[data-variant="ghost"]`) has no visible box, so the eye lines up its
// label: it is measured by its first text glyph or icon, never by its box, unless it or an ancestor carries `data-align-box`.
// Pair it with RooButton `flush`, which moves the label onto the column's text line (Tableroo, 2026-11-20).
// Without marks, each aside, main, section, nav or region of at least 160 px is treated as a column, unless it is a
// horizontal row (a flex container whose direction is row): a title bar is a row, not a column.
// A named line crosses containers: every visible element carrying the same `data-align-line="<name>"` must share a
// left edge, measured like a column block (first glyph or icon; the element's own box edge when the element or an
// ancestor has `data-align-box`). Use it to check a title bar crumb against the text line of the content column below.
// Misses of 1 to 12 px are reported in nearMisses with the column `line:<name>`; `lines` counts the names found.
// A column compares only its own blocks, so a nested panel with its own inset (a detail pane inside a column) can
// hide a miss: mark such a panel `data-align-column` so it becomes a column of its own (Stackroo, 2026-11-14).
// Centred icons: when a block's leading icon or box is narrower than its block and sits on (within 4 px of) the block's centre line, the
// block is centred, and two centred blocks in a column are compared by centre line, not left edge (a 28 px card icon and
// a 12 px plus icon in one rail column are aligned). A centred block against a left-aligned one still compares left edges.
// RooCheckbox is measured by its box (`.roo-checkbox-box`), not its label; RooSegmented by its outer edge, not its first
// option (Tableroo, 2026-11-23).
// A chip is measured by its box when it is the first thing in a block: the project switcher's tick box (the check inside it sits
// 4 px in) and a RooKbd key cap (its glyph sits inside its padding) line up by their visible edge (kit-admin-w1-gaps, 2026-11-23).

export interface AlignNearMiss { column: string; first: string; firstLeft: number; second: string; secondLeft: number; distance: number }
interface LeadingEdge { left: number; centre: number | null }
export interface AlignReport { columns: number; lines: number; nearMisses: AlignNearMiss[]; passed: boolean }

export function alignProbe(options: { nearMissMinimum?: number; nearMissMaximum?: number } = {}): AlignReport {
  const nearMissMinimum = options.nearMissMinimum ?? 1
  const nearMissMaximum = options.nearMissMaximum ?? 12

  function isVisible(element: Element): boolean {
    const style = getComputedStyle(element)
    if (style.visibility === 'hidden' || style.display === 'none' || Number(style.opacity) === 0) return false
    const rect = element.getBoundingClientRect()
    return rect.width > 0 && rect.height > 0
  }

  const chipSelector = '.roo-switcher-box, .roo-kbd'

  function firstLeadingEdge(element: Element): LeadingEdge | null {
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT)
    let node: Node | null = walker.currentNode
    while (node) {
      if (node.nodeType === Node.TEXT_NODE && (node.textContent ?? '').trim().length > 0) {
        const range = document.createRange()
        const text = node.textContent ?? ''
        const start = text.length - text.trimStart().length
        range.setStart(node, start)
        range.setEnd(node, start + 1)
        const rect = range.getBoundingClientRect()
        if (rect.width > 0) return { left: rect.left, centre: null }
      }
      if (node.nodeType === Node.ELEMENT_NODE && (node as Element).matches(chipSelector) && isVisible(node as Element)) {
        return { left: (node as Element).getBoundingClientRect().left, centre: null }
      }
      if (node.nodeType === Node.ELEMENT_NODE && ((node as Element).tagName === 'svg' || (node as Element).tagName === 'IMG') && isVisible(node as Element)) {
        const iconRect = (node as Element).getBoundingClientRect()
        return { left: iconRect.left, centre: iconRect.left + iconRect.width / 2 }
      }
      node = walker.nextNode()
    }
    return null
  }

  function firstGlyphLeft(element: Element): number | null {
    return firstLeadingEdge(element)?.left ?? null
  }

  function describe(element: Element): string {
    const label = (element.getAttribute('aria-label') || element.textContent || '').trim().replace(/\s+/g, ' ')
    return `${element.tagName.toLowerCase()}${element.className && typeof element.className === 'string' ? '.' + element.className.trim().split(/\s+/).join('.') : ''} "${label.slice(0, 40)}"`
  }

  function alignBoxOf(block: Element): Element | null {
    return block.hasAttribute('data-align-box') ? block : block.querySelector('[data-align-box]')
  }

  const centredTolerance = 4
  const ghostButtonSelector = '.roo-button[data-variant="ghost"]'
  // Kit controls whose first glyph is not their visible edge: the checkbox label sits right of its box, the segmented
  // control's first option sits inside its inset.
  const outerEdgeSelector = '.roo-checkbox-box, .roo-segmented'
  function outerEdgeOf(block: Element): Element | null {
    const wrapper = block.matches('.roo-checkbox') ? block : block.querySelector('.roo-checkbox')
    if (wrapper) return wrapper.querySelector('.roo-checkbox-box')
    return block.matches(outerEdgeSelector) ? block : block.querySelector('.roo-segmented')
  }

  function leadingEdgeOf(block: Element): LeadingEdge | null {
    const box = alignBoxOf(block)
    if (box && !(box.matches(ghostButtonSelector) && !box.hasAttribute('data-align-box'))) return { left: box.getBoundingClientRect().left, centre: null }
    const outer = outerEdgeOf(block)
    if (outer) return { left: outer.getBoundingClientRect().left, centre: null }
    const edge = firstLeadingEdge(block)
    if (edge === null || edge.centre === null) return edge
    // Centred: the icon is narrower than its block and its centre is within a few px of the block's centre (a centre line
    // that is itself 1 to 4 px off is the miss to report, so the tolerance matches the near-miss window, not zero).
    const blockRect = block.getBoundingClientRect()
    const blockCentre = blockRect.left + blockRect.width / 2
    const iconWidth = (edge.centre - edge.left) * 2
    const isCentred = blockRect.width - iconWidth >= 2 && Math.abs(edge.centre - blockCentre) <= centredTolerance
    return { left: edge.left, centre: isCentred ? edge.centre : null }
  }

  const marked = [...document.querySelectorAll('[data-align-column]')]
  function isHorizontalRow(element: Element): boolean {
    const style = getComputedStyle(element)
    return (style.display === 'flex' || style.display === 'inline-flex') && style.flexDirection.startsWith('row')
  }
  const columns = marked.length > 0 ? marked : [...document.querySelectorAll('aside, main, section, nav, [role="region"]')].filter((element) => isVisible(element) && element.getBoundingClientRect().width >= 160 && !isHorizontalRow(element))

  const nearMisses: AlignNearMiss[] = []
  for (const column of columns) {
    const blocks = [...column.children].filter((child) => isVisible(child) && !child.hasAttribute('data-align-ignore'))
    const edges = blocks
      .map((block) => ({ block, edge: leadingEdgeOf(block) }))
      .filter((entry): entry is { block: Element; edge: LeadingEdge } => entry.edge !== null)
      .map((entry) => ({ block: entry.block, left: entry.edge.left, centre: entry.edge.centre }))
    for (let first = 0; first < edges.length; first += 1) {
      for (let second = first + 1; second < edges.length; second += 1) {
        const firstEdge = edges[first]!
        const secondEdge = edges[second]!
        const bothCentred = firstEdge.centre !== null && secondEdge.centre !== null
        const firstPosition = bothCentred ? firstEdge.centre! : firstEdge.left
        const secondPosition = bothCentred ? secondEdge.centre! : secondEdge.left
        const distance = Math.abs(firstPosition - secondPosition)
        if (distance >= nearMissMinimum && distance <= nearMissMaximum) {
          nearMisses.push({
            column: describe(column),
            first: describe(firstEdge.block),
            firstLeft: Math.round(firstPosition * 10) / 10,
            second: describe(secondEdge.block),
            secondLeft: Math.round(secondPosition * 10) / 10,
            distance: Math.round(distance * 10) / 10,
          })
        }
      }
    }
  }

  const lineGroups = new Map<string, { element: Element; left: number }[]>()
  for (const element of document.querySelectorAll('[data-align-line]')) {
    const name = element.getAttribute('data-align-line') ?? ''
    if (name === '' || !isVisible(element) || element.closest('[data-align-ignore]')) continue
    const left = element.closest('[data-align-box]') ? element.getBoundingClientRect().left : firstGlyphLeft(element)
    if (left === null) continue
    const group = lineGroups.get(name) ?? []
    group.push({ element, left })
    lineGroups.set(name, group)
  }
  for (const [name, group] of lineGroups) {
    for (let first = 0; first < group.length; first += 1) {
      for (let second = first + 1; second < group.length; second += 1) {
        const firstEdge = group[first]!
        const secondEdge = group[second]!
        const distance = Math.abs(firstEdge.left - secondEdge.left)
        if (distance >= nearMissMinimum && distance <= nearMissMaximum) {
          nearMisses.push({
            column: `line:${name}`,
            first: describe(firstEdge.element),
            firstLeft: Math.round(firstEdge.left * 10) / 10,
            second: describe(secondEdge.element),
            secondLeft: Math.round(secondEdge.left * 10) / 10,
            distance: Math.round(distance * 10) / 10,
          })
        }
      }
    }
  }
  return { columns: columns.length, lines: lineGroups.size, nearMisses, passed: nearMisses.length === 0 }
}

// Source string for page.evaluate in harnesses that cannot import modules into the page.
export const alignProbeSource = `(${alignProbe.toString()})()`
