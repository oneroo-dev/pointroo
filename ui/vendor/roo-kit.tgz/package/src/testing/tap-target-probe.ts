// Tap-target probe for render harnesses, next to alignProbe. Run it in the page on a coarse-pointer context (Playwright with hasTouch):
// `const report = await page.evaluate(tapTargetProbeSource)`. It reads every element marked `data-touch-target` (RooButton, RooIconButton),
// takes the larger of its visible box and its invisible ::before hit area on each axis, and reports any that are under the minimum (44 by default).
// A control that says `clipped` (a hold-to-confirm icon button, whose overflow clips the hit area) is reported as clipped, never as passing.

export interface TapTargetFailure { selector: string; width: number; height: number; reason: 'small' | 'clipped' }
export interface TapTargetReport { checked: number; failures: TapTargetFailure[]; passed: boolean }

export function tapTargetProbe(options: { minimum?: number } = {}): TapTargetReport {
  const minimum = options.minimum ?? 44
  const failures: TapTargetFailure[] = []
  const elements = Array.from(document.querySelectorAll<HTMLElement>('[data-touch-target]'))
  let checked = 0

  function describe(element: HTMLElement): string {
    const label = element.getAttribute('aria-label') ?? element.textContent?.trim().slice(0, 24) ?? ''
    return `${element.tagName.toLowerCase()}.${Array.from(element.classList)[0] ?? ''}[${label}]`
  }

  for (const element of elements) {
    const box = element.getBoundingClientRect()
    if (box.width === 0 || box.height === 0) continue
    checked += 1
    if (element.getAttribute('data-touch-target') === 'clipped') {
      failures.push({ selector: describe(element), width: box.width, height: box.height, reason: 'clipped' })
      continue
    }
    const pseudo = getComputedStyle(element, '::before')
    const pseudoWidth = pseudo.position === 'absolute' ? parseFloat(pseudo.width) || 0 : 0
    const pseudoHeight = pseudo.position === 'absolute' ? parseFloat(pseudo.height) || 0 : 0
    const width = Math.max(box.width, pseudoWidth)
    const height = Math.max(box.height, pseudoHeight)
    if (width < minimum - 0.5 || height < minimum - 0.5) failures.push({ selector: describe(element), width, height, reason: 'small' })
  }
  return { checked, failures, passed: failures.length === 0 }
}

export const tapTargetProbeSource = `(${tapTargetProbe.toString()})()`
