// A plain-DOM twin of RooEnvDot :tag for pages with no Vue, such as the confirm card in an Electron main window.
// It writes the same classes and attributes RooEnvDot renders, so the dot rules in env-dot.css (src/static/roo-env-dot.css) style it.
// Keep this file free of vue and .vue imports.
import { TAG_LABELS, TAG_SHAPES } from '../environment'
import type { RooContextState, RooTag } from '../types/environment'

export interface TagDotOptions {
  /** A state other than connected draws the dashed ring, as on RooEnvDot. */
  state?: RooContextState | 'custom' | undefined
  /** Replaces the hidden word. */
  label?: string | undefined
}

/** Builds the dot RooEnvDot draws for a tag: the mark span plus the visually hidden word, in the given document. */
export function createTagDot(document: Document, tag: RooTag, options: TagDotOptions = {}): HTMLElement {
  const stateName = options.state && options.state !== 'connected' ? options.state : undefined
  const base = options.label ?? TAG_LABELS[tag]
  const hiddenWord = options.label !== undefined || !stateName || stateName === 'custom' ? base : `${base} ${stateName.replace('-', ' ')}`

  const dot = document.createElement('span')
  dot.className = 'roo-env-dot'
  dot.setAttribute('data-tag', tag)
  dot.setAttribute('data-shape', TAG_SHAPES[tag])
  dot.setAttribute('data-prod-like', String(tag === 'production'))
  if (stateName !== undefined) dot.setAttribute('data-state', stateName)

  const mark = document.createElement('span')
  mark.className = stateName === 'connecting' ? 'roo-env-dot-mark roo-move-breathe' : 'roo-env-dot-mark'
  mark.setAttribute('aria-hidden', 'true')

  const word = document.createElement('span')
  word.className = 'roo-visually-hidden'
  word.textContent = hiddenWord

  dot.append(mark, word)
  return dot
}
