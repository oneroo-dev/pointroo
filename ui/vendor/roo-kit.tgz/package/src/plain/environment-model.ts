// DOM-free entry for main processes (Electron main, Node) whose tsconfig has no DOM lib: the tag and guard logic and its types.
// Keep this file and everything it imports free of DOM types, .vue files, vue, @vueuse, reka-ui, composables and stores.
// It must not export createTagDot: that needs DOM types and lives in ./environment.
export * from '../environment'
export type { RooEnvironment, RooEnvironmentWord, RooTag, RooGuardLevel, RooEnvironmentChoice, RooContextState } from '../types/environment'
export {
  BULK_WRITE_ROW_LIMIT,
  BULK_WRITE_TABLE_SHARE,
  DEFAULT_CONFIRM_METHOD,
  PLAIN_CONFIRM_MAX_COUNT,
  chooseConfirmRequirement,
  isDestructiveConfirmKind,
} from '../confirm-requirement'
export type {
  ConfirmActionKind,
  ConfirmMethod,
  ConfirmRequirement,
  EnvironmentConfirmInput,
  GuardConfirmInput,
  GuardRequirement,
} from '../confirm-requirement'
