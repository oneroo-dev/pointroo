// Vue-free entry for main processes and other code with no .vue loader: the tag and guard logic, its types and createTagDot, the plain-DOM tag dot.
// Keep this file and everything it imports free of .vue files, vue, @vueuse, reka-ui, composables and stores.
// The model part lives in ./environment-model (no DOM types at all); this file adds only the tag dot.
export * from './environment-model'
export { createTagDot } from './tag-dot'
export type { TagDotOptions } from './tag-dot'
