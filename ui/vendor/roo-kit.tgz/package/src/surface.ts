// The surface an app runs on. A desktop app (Tinkeroo, Stackroo, Tableroo, Pingroo, Shellroo, Fileroo, Markroo, Oneroo) sets
// the desktop surface once, at start-up, and every decorative motion in the kit ends (see "Motion by surface" in the family
// rules and src/tokens/motion.css). A web app leaves the surface alone and keeps the kit's motion.
export const ROO_SURFACE_ATTRIBUTE = 'data-surface'

export type RooSurface = 'desktop' | 'web'

/** One part of the kit whose motion still runs on the desktop surface, and why. */
export interface DesktopFunctionalMotion {
  /** The class the part carries; the same class is named in the :not() list of motion.css. */
  selector: string
  component: string
  reason: string
}

/**
 * The only motion that still runs on the desktop surface: it is functional feedback, never decoration. Everything else
 * (menus, popovers, panels, tabs, dialogs, toasts, hover and press changes, the prod banner) is instant.
 */
export const DESKTOP_FUNCTIONAL_MOTION: readonly DesktopFunctionalMotion[] = [
  { selector: '.roo-hold-fill', component: 'RooHoldButton', reason: 'the hold-to-confirm fill follows the real hold' },
  { selector: '.roo-progress-line-bar', component: 'RooProgressLine', reason: 'progress that tracks real work, and the running line while the work length is unknown' },
  { selector: '.roo-spinner', component: 'RooButton', reason: 'the busy indicator' },
  { selector: '.roo-icon-turning', component: 'RooIcon', reason: 'the busy indicator, as a turning icon' },
  { selector: '.roo-dialog-line', component: 'RooDialog', reason: 'the running line while a dialog action works' },
  { selector: '.roo-skeleton-bar', component: 'RooSkeleton', reason: 'the loading placeholder, a busy indicator' },
]

/** Sets the surface on the root element (the document by default) and returns the surface now set. */
export function setRooSurface(surface: RooSurface, root: Element | undefined = typeof document === 'undefined' ? undefined : document.documentElement): RooSurface {
  if (root === undefined) return surface
  if (surface === 'desktop') root.setAttribute(ROO_SURFACE_ATTRIBUTE, 'desktop')
  else root.removeAttribute(ROO_SURFACE_ATTRIBUTE)
  return surface
}

/** The surface set on the root element; an app that has not opted in is 'web'. */
export function readRooSurface(root: Element | undefined = typeof document === 'undefined' ? undefined : document.documentElement): RooSurface {
  return root?.getAttribute(ROO_SURFACE_ATTRIBUTE) === 'desktop' ? 'desktop' : 'web'
}
