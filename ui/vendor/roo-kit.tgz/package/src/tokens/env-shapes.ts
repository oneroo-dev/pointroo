// The environment marks as SVG path data, for stacks that do not run the Vue parts (T11). Each shape is drawn in a
// 12 by 12 box. Colour is never the only signal, so every environment has its own shape; the hollow ring means
// unclassified only, and the dashed ring is the not-connected state (conflicts C5 and C6).
// Plain Node can run this file (type stripping), so it uses no enums and no imports.

export interface EnvShapeElement {
  /** SVG path data using only M, L, A, H, V, Z in absolute or relative form. */
  d: string
  paint: 'fill' | 'stroke'
  /** Stroke width in box units; only for `paint: 'stroke'`. */
  strokeWidth?: number
  /** Stroke dash pattern in box units, such as "2 2". */
  dash?: string
}

export interface EnvShape {
  viewBox: string
  /** The colour token (no --roo- prefix) the shape is drawn in; null when it takes the context environment colour. */
  token: string | null
  /** Who uses it, in words. */
  use: string
  elements: EnvShapeElement[]
}

function circle(centreX: number, centreY: number, radius: number): string {
  return `M${centreX - radius} ${centreY}a${radius} ${radius} 0 1 0 ${radius * 2} 0a${radius} ${radius} 0 1 0 ${-radius * 2} 0Z`
}

export const ENV_SHAPES: Record<string, EnvShape> = {
  circle: {
    viewBox: '0 0 12 12',
    token: 'env-local',
    use: 'local',
    elements: [{ d: circle(6, 6, 4), paint: 'fill' }],
  },
  diamond: {
    viewBox: '0 0 12 12',
    token: 'env-staging',
    use: 'staging',
    elements: [{ d: 'M6 1.5L10.5 6L6 10.5L1.5 6Z', paint: 'fill' }],
  },
  'ringed-dot': {
    viewBox: '0 0 12 12',
    token: 'env-prod',
    use: 'prod',
    elements: [
      { d: circle(6, 6, 2.5), paint: 'fill' },
      { d: circle(6, 6, 4.75), paint: 'stroke', strokeWidth: 1.25 },
    ],
  },
  'hollow-ring': {
    viewBox: '0 0 12 12',
    token: 'env-none',
    use: 'unclassified only',
    elements: [{ d: circle(6, 6, 4), paint: 'stroke', strokeWidth: 2 }],
  },
  'dashed-ring': {
    viewBox: '0 0 12 12',
    token: null,
    use: 'any not-connected state (connecting, reconnecting, offline, switching, stopped, signed-out), drawn in the environment colour',
    elements: [{ d: circle(6, 6, 4.5), paint: 'stroke', strokeWidth: 1, dash: '2 2' }],
  },
}
