// The Settle system as data (FAMILY-DIRECTION.md section 5). tokens.json exports this next to the timing tokens so a
// stack that cannot read CSS animates the same way. test/tokens-motion.test.ts checks every name here against
// motion.css: the duration and easing tokens exist, the keyframes exist, and every move has a reduced twin in words.
// Plain Node can run this file (type stripping), so it uses no enums and no imports.

export interface Move {
  /** The timing token (no --roo- prefix) that sets the duration; `null` when a fixed value is stated in `duration`. */
  durationToken: string | null
  /** A literal duration for moves with no token ("300ms", "2200ms"); null for a move that loops while work runs. */
  duration: string | null
  /** The easing token (no --roo- prefix), or `linear`. */
  easing: string
  /** How far it travels, as the direction states it ("4px"), or `none`. */
  travel: string
  /** The @keyframes name in motion.css, or `null` for a move built from transitions. */
  keyframes: string | null
  /** Where it is used, in the direction's words. */
  use: string
  /** What happens instead under reduced motion, in words. Never empty. */
  reduced: string
}

export const MOVES: Record<string, Move> = {
  settle: { durationToken: 'base', duration: null, easing: 'ease', travel: '4px', keyframes: 'roo-settle', use: 'anything that enters: rows, cards, panes, the Jump palette, sheets (sheets travel 8px)', reduced: 'appears at once' },
  clear: { durationToken: 'fast', duration: null, easing: 'exit', travel: 'none', keyframes: 'roo-clear', use: 'anything that leaves', reduced: 'disappears at once' },
  glide: { durationToken: 'base', duration: null, easing: 'ease', travel: 'to the new row', keyframes: 'roo-glide', use: 'lists, trees, the active tab, the segmented control thumb', reduced: 'jumps' },
  pop: { durationToken: 'base', duration: null, easing: 'ease', travel: 'scale .98 to 1', keyframes: 'roo-pop', use: 'popovers, menus, tooltips, the Pill when it changes environment', reduced: 'fade only' },
  fill: { durationToken: 'hold', duration: null, easing: 'linear', travel: 'left to right', keyframes: null, use: 'hold-to-confirm; release drains it back in 150ms', reduced: 'the label counts down; the two-press method is always offered' },
  draw: { durationToken: 'draw', duration: null, easing: 'linear', travel: 'clockwise from the Pill corner', keyframes: null, use: 'the prod Frame, once per connect', reduced: 'the frame appears at once' },
  tick: { durationToken: 'tick', duration: null, easing: 'spring', travel: 'the stroke draws', keyframes: 'roo-tick', use: 'commit, send, upload done, copied', reduced: 'appears at once' },
  sweep: { durationToken: null, duration: '200ms', easing: 'ease', travel: 'left to right', keyframes: null, use: 'AI writes into the editor; a gutter mark fades over 1.2s', reduced: 'text appears at once, the mark stays until the next edit' },
  stagger: { durationToken: 'stagger', duration: null, easing: 'ease', travel: 'none', keyframes: 'roo-settle', use: 'first rows of a run, a folder, an arrival group; 20ms apart, 120ms total cap', reduced: 'all at once' },
  hop: { durationToken: null, duration: '300ms', easing: 'spring', travel: '3px', keyframes: 'roo-hop', use: 'the Ledge mark, once, when a job over 5s finishes in the background', reduced: 'badge only' },
  line: { durationToken: null, duration: null, easing: 'ease', travel: 'along the top edge', keyframes: 'roo-line', use: 'loading over 300ms; loops only while working', reduced: 'still bar, half drawn' },
  breathe: { durationToken: null, duration: '2200ms', easing: 'ease', travel: 'none', keyframes: 'roo-breathe', use: 'a live dot, only while live', reduced: 'still dot' },
}

/** The progress Line (S3): a 2px bar on the top edge of the surface doing the work. */
export const LINE = {
  height: '2px',
  /** The timing token that sets how long work runs before the Line appears. */
  delayToken: 'line-delay',
  reduced: 'still bar, half drawn (indeterminate) or exact (determinate)',
  determinate: 'value 0 to 1',
}
