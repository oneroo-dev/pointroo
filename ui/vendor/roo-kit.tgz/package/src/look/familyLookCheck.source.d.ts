export interface LookMismatch {
  rule: string
  message: string
  targets: string[]
  values: Record<string, number>
}
export function familyLookCheck(root?: ParentNode): LookMismatch[]
