// The family look check: measures what must match across the UI (title bar items, keycap glyphs, selection marks, row
// heights, icon sizes, loading indicators) and lists every difference over 1px. The logic lives in familyLookCheck.source.js,
// so tools/look-check.mjs can inject the same code into a running app.
export { familyLookCheck } from './familyLookCheck.source.js'
export type { LookMismatch } from './familyLookCheck.source.js'
