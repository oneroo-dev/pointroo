// The one source of the family look check. Plain JS with no imports and every helper inside the function, so
// tools/look-check.mjs can inject it into a running app over the DevTools protocol, and familyLookCheck.ts re-exports it
// for tests and app gates. Do not add imports or top-level helpers here.

/**
 * Measures what must match across the family UI and returns the differences over 1px.
 * @param {ParentNode} [root]
 * @returns {{ rule: string, message: string, targets: string[], values: Record<string, number> }[]}
 */
export function familyLookCheck(root = document) {
  const TOLERANCE = 1
  const ARROW_INK = 14 / 24
  const CAP_HEIGHT = 0.705
  const mismatches = []

  const view = (root.ownerDocument || root).defaultView || window
  const rectOf = (element) => element.getBoundingClientRect()
  const styleOf = (element, pseudo) => view.getComputedStyle(element, pseudo)
  const round = (value) => Math.round(value * 100) / 100
  const pixels = (value) => {
    const parsed = parseFloat(value)
    return Number.isNaN(parsed) ? undefined : parsed
  }

  const describe = (element) => {
    const text = (element.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 24)
    const classes = typeof element.className === 'string' ? element.className.trim().split(/\s+/).filter(Boolean).slice(0, 2) : []
    const label = element.tagName.toLowerCase() + (element.id ? '#' + element.id : '') + classes.map((name) => '.' + name).join('')
    return text ? label + ' "' + text + '"' : label
  }

  const visible = (element) => {
    const rect = rectOf(element)
    if (rect.width <= 0 || rect.height <= 0) return false
    const style = styleOf(element)
    return style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0'
  }

  // Content gone or on its way out: an ancestor inside the box is at opacity 0, or the element or an ancestor runs a
  // finite animation that ends at opacity 0 (a busy button's held label fading behind its spinner). A shot can land mid-fade; once the fade ends the content
  // is invisible, so it is measured as already gone. Infinite animations (the spin itself) never count.
  const fadingOut = (element, box) => {
    for (let node = element; node && node !== box.parentElement; node = node.parentElement) {
      if (node !== element && styleOf(node).opacity === '0') return true
      if (typeof node.getAnimations !== 'function') continue
      for (const animation of node.getAnimations()) {
        if (animation.playState === 'finished' || animation.playState === 'idle') continue
        const effect = animation.effect
        const timing = effect && effect.getComputedTiming ? effect.getComputedTiming() : undefined
        if (!timing || timing.iterations === Infinity) continue
        const frames = effect.getKeyframes ? effect.getKeyframes() : []
        const last = frames[frames.length - 1]
        if (last && last.opacity !== undefined && parseFloat(last.opacity) === 0) return true
      }
    }
    return false
  }

  const report = (rule, message, elements, values) => {
    mismatches.push({ rule, message, targets: elements.map(describe), values })
  }

  const spread = (numbers) => Math.max(...numbers) - Math.min(...numbers)

  // Title bar: every control the same height and on one centre line.
  for (const bar of root.querySelectorAll('.roo-bar')) {
    const controls = []
    const collect = (parent) => {
      for (const child of parent.children) {
        if (child.classList.contains('roo-bar-spacer') || child.classList.contains('roo-bar-overlay-end')) continue
        if (child.getAttribute('role') === 'separator' || child.classList.contains('roo-divider')) continue
        if (child.classList.contains('roo-bar-slot')) {
          const slot = child.getAttribute('data-slot')
          if (slot === 'tabs' || slot === 'crumb') continue
          collect(child)
          continue
        }
        if (visible(child)) controls.push(child)
      }
    }
    collect(bar)
    if (controls.length > 1) {
      const heights = controls.map((control) => rectOf(control).height)
      const centres = controls.map((control) => rectOf(control).top + rectOf(control).height / 2)
      if (spread(heights) > TOLERANCE) {
        report('bar-height', 'Title bar items are not the same height: ' + heights.map(round).join(', ') + ' px.', controls, {
          min: round(Math.min(...heights)),
          max: round(Math.max(...heights)),
        })
      }
      if (spread(centres) > TOLERANCE) {
        report('bar-centre', 'Title bar items do not share one vertical centre: ' + centres.map(round).join(', ') + ' px.', controls, {
          min: round(Math.min(...centres)),
          max: round(Math.max(...centres)),
        })
      }
    }
    if (controls.length > 0 && bar.getAttribute('data-platform') === 'mac') {
      const inset = pixels(styleOf(bar).getPropertyValue('--roo-traffic-inset'))
      const first = controls.reduce((best, control) => (rectOf(control).left < rectOf(best).left ? control : best))
      const gap = rectOf(first).left - rectOf(bar).left
      if (inset !== undefined && Math.abs(gap - inset) > TOLERANCE) {
        report('bar-traffic-gap', 'The first title bar item starts ' + round(gap) + ' px from the window edge; --roo-traffic-inset is ' + round(inset) + ' px.', [first], {
          gap: round(gap),
          inset: round(inset),
        })
      }
    }
  }

  // Keycaps: glyphs at one visual height (an arrow icon inks 14/24 of its box; text caps are 0.705 of the font size).
  const glyphHeight = (glyph) =>
    glyph.getAttribute('data-glyph') === 'arrow' ? rectOf(glyph).height * ARROW_INK : pixels(styleOf(glyph).fontSize) * CAP_HEIGHT
  const keycapGroups = new Map()
  for (const keycap of root.querySelectorAll('.roo-kbd, .roo-static-kbd, .roo-menu-item-shortcut, .roo-tooltip-shortcut')) {
    const glyphs = [...keycap.querySelectorAll('[data-glyph]')].filter(visible)
    if (glyphs.length === 0) continue
    const heights = glyphs.map(glyphHeight)
    if (spread(heights) > TOLERANCE) {
      report('keycap-glyph', 'Glyphs in one keycap are not the same height: ' + heights.map(round).join(', ') + ' px.', [keycap], {
        min: round(Math.min(...heights)),
        max: round(Math.max(...heights)),
      })
    }
    const list = keycap.closest('[role="menu"], .roo-menu, ul, ol') || (keycap.parentElement && keycap.parentElement.parentElement)
    if (!list) continue
    if (!keycapGroups.has(list)) keycapGroups.set(list, [])
    keycapGroups.get(list).push({ keycap, height: Math.max(...heights) })
  }
  for (const entries of keycapGroups.values()) {
    if (entries.length < 2) continue
    const heights = entries.map((entry) => entry.height)
    if (spread(heights) > TOLERANCE) {
      report('keycap-siblings', 'Keycaps in one list have different glyph heights: ' + heights.map(round).join(', ') + ' px.', entries.map((entry) => entry.keycap), {
        min: round(Math.min(...heights)),
        max: round(Math.max(...heights)),
      })
    }
  }

  // Selected rows: the mark's gap to the row edge against its gap to the first icon or text.
  for (const row of root.querySelectorAll('.roo-selected-row')) {
    if (!visible(row)) continue
    const mark = styleOf(row, '::before')
    if (mark.content === 'none' || mark.content === 'normal' || mark.content === '') continue
    const markLeft = pixels(mark.left)
    const markWidth = pixels(mark.width)
    if (markLeft === undefined || markWidth === undefined) continue
    const rowRect = rectOf(row)
    const first = [...row.children].find((child) => visible(child))
    if (!first) continue
    const edgeGap = markLeft
    const textGap = rectOf(first).left - rowRect.left - (markLeft + markWidth)
    if (textGap < 0) {
      report('selected-overlap', 'The selection mark overlaps the row content: edge gap ' + round(edgeGap) + ' px, text gap ' + round(textGap) + ' px.', [row, first], {
        edgeGap: round(edgeGap),
        textGap: round(textGap),
      })
    } else if (textGap < edgeGap - TOLERANCE) {
      report('selected-gap', 'The selection mark is closer to the text (' + round(textGap) + ' px) than to the row edge (' + round(edgeGap) + ' px).', [row, first], {
        edgeGap: round(edgeGap),
        textGap: round(textGap),
      })
    }
  }

  // Rails: an icon rail never shows a selection mark (Raja, 2026-11-17: "no orange thing on this"). Rail items use roo-fill-only.
  const railSelector = '.roo-rail, [data-rail], nav[aria-label*="rail" i]'
  const rails = new Set(root.querySelectorAll(railSelector))
  for (const tile of root.querySelectorAll('[data-rail-tile]')) {
    if (tile.parentElement) rails.add(tile.parentElement)
  }
  const markedInRail = new Set()
  for (const rail of rails) {
    for (const row of rail.querySelectorAll('.roo-selected-row')) {
      if (markedInRail.has(row)) continue
      const mark = styleOf(row, '::before')
      if (mark.content === 'none' || mark.content === 'normal' || mark.content === '' || mark.content === undefined) continue
      const markWidth = pixels(mark.width)
      if (markWidth === undefined || markWidth <= 0) continue
      markedInRail.add(row)
      report('rail-mark', 'A selection mark shows inside an icon rail (' + round(markWidth) + ' px wide); rail items use roo-fill-only.', [row], {
        markWidth: round(markWidth),
      })
    }
  }

  // Rows in one list the same height; icons in one row the same size.
  const rowSelector = '[role="menuitem"], [role="menuitemcheckbox"], [role="option"], [role="treeitem"], .roo-row, .roo-tree-row, .roo-menu-item, .roo-listbox-option'
  const rowGroups = new Map()
  for (const row of root.querySelectorAll(rowSelector)) {
    if (!visible(row) || !row.parentElement) continue
    const mainClass = typeof row.className === 'string' ? row.className.split(/\s+/).find((name) => name.startsWith('roo-') && !name.includes('selected')) || '' : ''
    const signature = (row.getAttribute('role') || '') + '|' + mainClass
    const key = row.parentElement
    if (!rowGroups.has(key)) rowGroups.set(key, new Map())
    const bySignature = rowGroups.get(key)
    if (!bySignature.has(signature)) bySignature.set(signature, [])
    bySignature.get(signature).push(row)
  }
  for (const bySignature of rowGroups.values()) {
    for (const rows of bySignature.values()) {
      if (rows.length < 2) continue
      const heights = rows.map((row) => rectOf(row).height)
      if (spread(heights) > TOLERANCE) {
        report('row-height', 'Rows in one list are not the same height: ' + heights.map(round).join(', ') + ' px.', rows, {
          min: round(Math.min(...heights)),
          max: round(Math.max(...heights)),
        })
      }
    }
  }
  for (const row of root.querySelectorAll(rowSelector)) {
    const icons = [...row.querySelectorAll('svg')].filter(visible)
    if (icons.length < 2) continue
    const sizes = icons.map((icon) => Math.max(rectOf(icon).width, rectOf(icon).height))
    if (spread(sizes) > TOLERANCE) {
      report('row-icons', 'Icons in one row are not the same size: ' + sizes.map(round).join(', ') + ' px.', [row], {
        min: round(Math.min(...sizes)),
        max: round(Math.max(...sizes)),
      })
    }
  }

  // Loading: a spinner or busy indicator must not sit on top of text or an icon in the same box.
  const spinnerSelector = '.roo-spinner, [role="progressbar"], [class*="spinner"], [class*="spin-"], [class*="loading"], [class*="loader"]'
  for (const spinner of root.querySelectorAll(spinnerSelector)) {
    if (!visible(spinner)) continue
    const spinnerRect = rectOf(spinner)
    const box = spinner.parentElement
    if (!box) continue
    const others = [...box.querySelectorAll('*')].filter((element) => {
      if (element === spinner || spinner.contains(element) || element.contains(spinner)) return false
      const nearest = element.closest(spinnerSelector)
      if (nearest && nearest !== element) return false
      if (!visible(element)) return false
      if (fadingOut(element, box)) return false
      const isIcon = element.tagName.toLowerCase() === 'svg'
      const hasOwnText = [...element.childNodes].some((node) => node.nodeType === 3 && (node.textContent || '').trim() !== '')
      return isIcon || hasOwnText
    })
    for (const other of others) {
      const otherRect = rectOf(other)
      const overlapWidth = Math.min(spinnerRect.right, otherRect.right) - Math.max(spinnerRect.left, otherRect.left)
      const overlapHeight = Math.min(spinnerRect.bottom, otherRect.bottom) - Math.max(spinnerRect.top, otherRect.top)
      if (overlapWidth > TOLERANCE && overlapHeight > TOLERANCE) {
        report('loading-overlap', 'A loading indicator overlaps content by ' + round(overlapWidth) + ' x ' + round(overlapHeight) + ' px.', [spinner, other], {
          overlapWidth: round(overlapWidth),
          overlapHeight: round(overlapHeight),
        })
      }
    }
  }

  // Settings rows: in a row at least 480 px wide the label column is never squeezed under 180 px.
  for (const settingRow of root.querySelectorAll('.roo-setting-row')) {
    if (!visible(settingRow)) continue
    const rowWidth = rectOf(settingRow).width
    if (rowWidth < 480) continue
    const labelColumn = settingRow.querySelector('.roo-setting-row-text')
    if (!labelColumn) continue
    const labelWidth = rectOf(labelColumn).width
    if (labelWidth < 179) {
      report('setting-label-squeezed', 'A settings label column is ' + round(labelWidth) + ' px wide in a ' + round(rowWidth) + ' px row; it must stay at least 180 px.', [settingRow, labelColumn], {
        labelWidth: round(labelWidth),
        rowWidth: round(rowWidth),
      })
    }
  }

  // Table rows: every row's first cell starts at the same x. A pseudo-element on a <tr> (a selection mark, say) becomes an
  // extra table cell and pushes that row's cells right; the DOM shows nothing, the geometry does (Bugroo, 2026-11-17).
  for (const table of root.querySelectorAll('table')) {
    const rows = [...table.rows].filter((row) => row.cells.length > 0 && visible(row))
    if (rows.length < 2) continue
    const firstLeft = rectOf(rows[0].cells[0]).left
    for (const row of rows.slice(1)) {
      const left = rectOf(row.cells[0]).left
      if (Math.abs(left - firstLeft) > TOLERANCE) {
        report('table-row-shifted', 'A table row starts its first cell at ' + round(left) + ' px where the first row starts at ' + round(firstLeft) + ' px; a ::before on the <tr> is the usual cause.', [rows[0], row], {
          firstLeft: round(firstLeft),
          rowLeft: round(left),
        })
      }
    }
  }

  return mismatches
}
