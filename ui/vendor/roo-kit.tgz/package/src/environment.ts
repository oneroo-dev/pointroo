import type { RooIconName } from './icons/paths'
import type { RooEnvironmentChoice, RooGuardLevel, RooTag } from './types/environment'

/*
 * The kit's copy of the contract's environment module (packages/contract/src/environment/index.mjs). Both run the same
 * fixtures (environment.choice and environment.migrate), so they cannot drift.
 */

/** The tag list in the order a picker shows it: No tag last. */
export const ROO_TAGS: readonly RooTag[] = ['local', 'testing', 'development', 'staging', 'production', 'none']

/** The five guard levels in the order a picker shows them (the family rule, 1 to 5). This is not strictness: see GUARD_STRICTNESS. */
export const GUARD_LEVELS: readonly RooGuardLevel[] = ['silent', 'alert', 'alert-except-reads', 'safe', 'safe-except-reads']

/** The five guard levels by strictness, loosest first. The "except reads" levels skip reads, so they sit below their plain twins. */
export const GUARD_STRICTNESS: readonly RooGuardLevel[] = ['silent', 'alert-except-reads', 'alert', 'safe-except-reads', 'safe']

/** The place of a guard level in GUARD_STRICTNESS: 0 is the loosest. */
export function guardRank(level: RooGuardLevel): number {
  return GUARD_STRICTNESS.indexOf(level)
}

/** True when moving from one guard to the other lowers the guard (the new one is looser). */
export function isLooserGuard(from: RooGuardLevel, to: RooGuardLevel): boolean {
  return guardRank(to) < guardRank(from)
}

/** The stricter of two guard levels. A tie returns the first. */
export function stricterGuard(first: RooGuardLevel, second: RooGuardLevel): RooGuardLevel {
  return guardRank(second) > guardRank(first) ? second : first
}

const failSafeGuard: RooGuardLevel = 'alert-except-reads'

export function isTag(value: unknown): value is RooTag {
  return typeof value === 'string' && (ROO_TAGS as readonly string[]).includes(value)
}

export function isGuardLevel(value: unknown): value is RooGuardLevel {
  return typeof value === 'string' && (GUARD_LEVELS as readonly string[]).includes(value)
}

/** Picking the production tag pre-picks "Alert, except reads"; every other tag, and no tag, is Silent. */
export function defaultGuardFor(tag: RooTag): RooGuardLevel {
  return tag === 'production' ? 'alert-except-reads' : 'silent'
}

/** A fresh choice: the tag with its own default guard, not yet picked. */
export function newChoice(tag: string = 'none'): RooEnvironmentChoice {
  const safeTag: RooTag = isTag(tag) ? tag : 'none'
  return { tag: safeTag, guard: defaultGuardFor(safeTag), guardPicked: false }
}

/** The user changes the tag: a picked guard stays, an unpicked guard follows the new tag's default. */
export function changeTag(choice: RooEnvironmentChoice, tag: string): RooEnvironmentChoice {
  if (!isTag(tag)) return { ...choice }
  return { tag, guard: choice.guardPicked ? choice.guard : defaultGuardFor(tag), guardPicked: choice.guardPicked }
}

/** The user picks a guard level: from then on it stays through tag changes. */
export function changeGuard(choice: RooEnvironmentChoice, guard: string): RooEnvironmentChoice {
  if (!isGuardLevel(guard)) return { ...choice }
  return { tag: choice.tag, guard, guardPicked: true }
}

/**
 * A stored row's environment, old or new, as a tag plus guard. Never throws. 'prod' is production plus "Alert, except
 * reads"; 'unclassified', a missing value and any unknown value are no tag plus "Alert, except reads", marked picked so a
 * tag change cannot loosen them; the old named environments keep their tag with that tag's default guard.
 */
export function migrateEnvironment(old: unknown): RooEnvironmentChoice {
  if (old !== null && typeof old === 'object') {
    const record = old as { tag?: unknown; guard?: unknown; guardPicked?: unknown }
    if (isTag(record.tag) && isGuardLevel(record.guard)) return { tag: record.tag, guard: record.guard, guardPicked: record.guardPicked === true }
  }
  const word = typeof old === 'string' ? old.trim().toLowerCase() : ''
  if (word === 'prod' || word === 'production') return { tag: 'production', guard: failSafeGuard, guardPicked: false }
  if (word === 'staging') return { tag: 'staging', guard: failSafeGuard, guardPicked: true }
  if (word === 'local' || word === 'testing' || word === 'development') return newChoice(word)
  return { tag: 'none', guard: failSafeGuard, guardPicked: true }
}

/** The tag an old environment word maps to, through the same function the contract uses: 'unclassified' is no tag. */
export function tagForEnvironment(old: unknown): RooTag {
  return migrateEnvironment(old).tag
}

/** The words a picker and the pill show for each tag. Source words stay lowercase. */
export const TAG_LABELS: Record<RooTag, string> = {
  local: 'local',
  testing: 'testing',
  development: 'development',
  staging: 'staging',
  production: 'production',
  none: 'no tag',
}

/** The guard level words, as the guard picker and the footer guard word show them. */
export const GUARD_LABELS: Record<RooGuardLevel, string> = {
  silent: 'Silent',
  alert: 'Alert',
  'alert-except-reads': 'Alert, except reads',
  safe: 'Safe',
  'safe-except-reads': 'Safe, except reads',
}

/** The icon beside each guard level word: a muted bell for Silent, a ringing bell for the Alert levels, a fingerprint for the Safe levels. */
export const GUARD_ICONS: Record<RooGuardLevel, RooIconName> = {
  silent: 'bell-off',
  alert: 'bell-ring',
  'alert-except-reads': 'bell-ring',
  safe: 'fingerprint',
  'safe-except-reads': 'fingerprint',
}

/** The shape each tag's dot draws (data-shape on RooEnvDot), so colour is never the only signal. Shared by the Vue dot and the plain one. */
export const TAG_SHAPES: Record<RooTag, string> = {
  local: 'circle',
  testing: 'square',
  development: 'triangle',
  staging: 'diamond',
  production: 'target',
  none: 'dash',
}
