<script setup lang="ts">
// The confirm for a destructive or prod action: a small popover attached to the button that started it, never a centred
// dialog with a second button. It only draws what it is given. The trigger keeps focus, so the popover never takes it, and
// the one line after the rows carries the gesture and the method ("Hold to send · Change"), its text a polite live region that follows the gesture. A press on the trigger itself is the gesture, not an
// outside click. The `input` slot sits between the rows and the hint, for a typed confirmation (a server name): pair it with
// the `blocked` option of useConfirmGesture so the gesture cannot complete until the field matches. Crimson belongs to prod only: the prod word (lowercase, crimson, never a tag) shows when `prod` is true and never otherwise.
import { Comment, Fragment, Text, computed, onScopeDispose, ref, toRef, useSlots, watch, type VNode } from 'vue'
import { PopoverAnchor, PopoverContent, PopoverPortal, PopoverRoot } from 'reka-ui'
import { useId } from 'reka-ui'
import { useEscapeLayer } from '../composables/useEscapeLayer'
import { useCollisionPadding } from '../composables/useWindowControlPadding'

export interface RooConfirmRow {
  term: string
  detail: string
}

const props = withDefaults(
  defineProps<{
    open: boolean
    title: string
    prod?: boolean
    /** The prod word. Source text is lowercase; the capitals are drawn by the style. */
    prodLabel?: string
    rows?: RooConfirmRow[]
    /** The gesture half of the one line ("Hold to send", "Keep holding to send", "Press again to send"); the Change link follows it. */
    hint: string
    /**
     * @deprecated Ignored under the one-line rule: the popover draws one gesture line ("Hold to send · Change") and no
     * separate method line. Kept as an optional prop for one release so existing callers still typecheck; remove it.
     */
    methodLabel?: string
    /** The panel width: a number is pixels, a string is any CSS length. */
    width?: number | string
    /** Which side of the button the panel opens on; `top` is for a button near the window's bottom edge. */
    side?: 'bottom' | 'top'
    /** The id of the one line, so a field can be aria-describedby it. Generated and unique when not given. */
    lineId?: string
  }>(),
  { prod: false, prodLabel: 'prod', rows: () => [], width: 300, side: 'bottom' },
)

const generatedLineId = useId(undefined, 'roo-confirm-line')
const resolvedLineId = computed(() => props.lineId || generatedLineId)
defineExpose({ lineId: resolvedLineId })

const slots = useSlots()

function hasContent(nodes: VNode[] | undefined): boolean {
  return (nodes ?? []).some((node) => {
    if (node.type === Comment) return false
    if (node.type === Text) return typeof node.children === 'string' && node.children.trim() !== ''
    if (node.type === Fragment) return Array.isArray(node.children) && hasContent(node.children as VNode[])
    return true
  })
}

function hasChangeLink(): boolean {
  return hasContent(slots.change?.())
}

const panelWidth = computed(() => (typeof props.width === 'number' ? `${props.width}px` : props.width))

const emit = defineEmits<{ dismiss: [] }>()

useEscapeLayer(() => props.open)

// The popover never takes focus. It dismisses on a press outside (not on the trigger or inside a menu), on Escape, and on
// focus moving away only when the user pressed a key since it opened (Tab, Shift+Tab or any other) and focus landed on
// something other than the trigger or the element that held focus when it opened. Focus moves with no key pressed since
// opening are script moves (menus handing focus back, a view switching) and are ignored, so nothing here chases an element
// or depends on timing.
let focusHolder: Element | null = null
let keyPressedSinceOpen = false

function onDocumentKeyDown(): void {
  keyPressedSinceOpen = true
}

// reka reports one Escape through both its escape event and its dismiss event; the escape handler emits, and the dismiss
// that follows in the same turn is dropped, so the parent hears Escape once.
let escapeHandled = false

function onEscapeKeyDown(event: KeyboardEvent): void {
  event.preventDefault()
  escapeHandled = true
  setTimeout(() => (escapeHandled = false), 0)
  emit('dismiss')
}

const anchorReference = ref<unknown>(null)
const collisionPadding = useCollisionPadding(toRef(props, 'open'), anchorReference)

function onOpenChange(isOpen: boolean): void {
  if (!isOpen && !escapeHandled) emit('dismiss')
}

watch(
  () => props.open,
  (isOpen) => {
    if (typeof document === 'undefined') return
    document.removeEventListener('keydown', onDocumentKeyDown, true)
    focusHolder = null
    keyPressedSinceOpen = false
    if (!isOpen) return
    const active = document.activeElement
    focusHolder = active instanceof Element && active !== document.body ? active : null
    document.addEventListener('keydown', onDocumentKeyDown, true)
  },
  { immediate: true, flush: 'sync' },
)

onScopeDispose(() => {
  if (typeof document !== 'undefined') document.removeEventListener('keydown', onDocumentKeyDown, true)
})

function isOnHolder(target: Element): boolean {
  return focusHolder !== null && (target === focusHolder || focusHolder.contains(target))
}

function keepOnTrigger(event: Event): void {
  const detail = (event as CustomEvent<{ originalEvent?: Event }>).detail
  const original = detail?.originalEvent
  const target = original?.target ?? event.target
  if (!(target instanceof Element)) {
    if (original instanceof FocusEvent) event.preventDefault()
    return
  }
  if (target.closest('[data-roo-confirm-anchor]') || target.closest('[role="menu"]')) {
    event.preventDefault()
    return
  }
  if (!(original instanceof FocusEvent)) return
  if (!keyPressedSinceOpen || target === document.body || isOnHolder(target)) event.preventDefault()
}
</script>

<template>
  <PopoverRoot :open="open" @update:open="onOpenChange">
    <PopoverAnchor ref="anchorReference" class="roo-confirm-popover-anchor" data-roo-confirm-anchor><slot /></PopoverAnchor>
    <PopoverPortal>
      <PopoverContent
        class="roo-confirm-popover"
        :side="side"
        align="end"
        :style="{ width: panelWidth }"
        :side-offset="8"
        :collision-padding="collisionPadding"
        :aria-label="title"
        data-roo-confirm-popover
        :data-prod="prod || undefined"
        @open-auto-focus.prevent
        @close-auto-focus.prevent
        @escape-key-down="onEscapeKeyDown"
        @interact-outside="keepOnTrigger"
      >
        <div class="roo-confirm-popover-head">
          <strong v-if="prod" class="roo-confirm-popover-word" data-roo-confirm-prod>{{ prodLabel }}</strong>
          <b class="roo-confirm-popover-title" data-roo-confirm-title>{{ title }}</b>
        </div>
        <dl v-if="rows.length > 0" class="roo-confirm-popover-rows">
          <div v-for="row in rows" :key="row.term" class="roo-confirm-popover-row" data-roo-confirm-row>
            <dt>{{ row.term }}</dt>
            <dd>{{ row.detail }}</dd>
          </div>
        </dl>
        <div v-if="$slots.input" class="roo-confirm-popover-input" data-roo-confirm-input><slot name="input" /></div>
        <div v-if="$slots.extra" class="roo-confirm-popover-input" data-roo-confirm-extra><slot name="extra" /></div>
        <p :id="resolvedLineId" class="roo-confirm-popover-line" data-roo-confirm-line>
          <span class="roo-confirm-popover-hint" data-roo-confirm-hint aria-live="polite">{{ hint }}</span>
          <template v-if="hasChangeLink()">
            <span class="roo-confirm-popover-separator" aria-hidden="true"> · </span>
            <span class="roo-confirm-popover-change"><slot name="change" /></span>
          </template>
        </p>
      </PopoverContent>
    </PopoverPortal>
  </PopoverRoot>
</template>

<!-- Not scoped: reka puts the panel inside its own popper div, so a scoped id would land on that wrapper. -->
<style>
@layer roo-components {
  .roo-confirm-popover-anchor {
    display: inline-flex;
  }

  .roo-confirm-popover {
    z-index: 80;
    box-sizing: border-box;
    width: 300px;
    border: 1px solid transparent;
    border-radius: var(--roo-radius-popover);
    background: var(--roo-surface);
    padding: var(--roo-p-space-3);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-13);
    color: var(--roo-text);
    box-shadow: var(--roo-shadow-popover);
    animation: roo-pop var(--roo-fast) var(--roo-ease) both;
    transform-origin: var(--reka-popover-content-transform-origin, var(--reka-popper-transform-origin, center));
  }

  .roo-confirm-popover[data-state='closed'] {
    animation: roo-pop-out calc(var(--roo-fast) * 0.625) var(--roo-exit) both;
  }

  .roo-confirm-popover-head {
    display: flex;
    min-width: 0;
    align-items: center;
    gap: var(--roo-p-space-2);
  }

  .roo-confirm-popover-title {
    min-width: 0;
    font-weight: 600;
    letter-spacing: var(--roo-p-tracking-heading-sm);
  }

  /* The prod word, as the palette meta line draws it: a lowercase word in the prod crimson, no tag, no fill, at the title's size. */
  .roo-confirm-popover-word {
    flex: none;
    color: var(--roo-prod-text);
    font-weight: 600;
  }

  .roo-confirm-popover-rows {
    display: grid;
    grid-template-columns: max-content 1fr;
    gap: 3px var(--roo-p-space-3);
    margin: var(--roo-p-space-2) 0 0;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }

  .roo-confirm-popover-row {
    display: contents;
  }

  .roo-confirm-popover-row dt {
    font-weight: 500;
  }

  .roo-confirm-popover-row dd {
    min-width: 0;
    margin: 0;
  }

  .roo-confirm-popover-input {
    margin: var(--roo-p-space-2) 0 0;
  }

  .roo-confirm-popover-input > :is(input, textarea) {
    box-sizing: border-box;
    width: 100%;
  }

  .roo-confirm-popover-line {
    display: flex;
    min-width: 0;
    align-items: center;
    margin: var(--roo-p-space-2) 0 0;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    line-height: 20px;
    white-space: pre;
  }

  .roo-confirm-popover-hint {
    color: var(--roo-text);
    font-weight: 500;
  }

  .roo-confirm-popover-change > :is(button, a) {
    border: 0;
    border-radius: var(--roo-p-radius-small);
    background: transparent;
    padding: 0 2px;
    color: var(--roo-text);
    font: inherit;
    text-decoration: underline;
    text-underline-offset: 2px;
    cursor: default;
  }

  .roo-confirm-popover-change > :is(button, a):hover {
    background: var(--roo-raised-on-raised);
  }

  .roo-confirm-popover-change > :is(button, a):focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 1px;
  }

  /* An invisible tap area of at least --roo-touch-target on a coarse pointer (family rule F6, Fable review). The drawn size never changes. */
  @media (pointer: coarse) {
    .roo-confirm-popover-change > :is(button, a) {
      position: relative;
    }

    .roo-confirm-popover-change > :is(button, a)::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2));
    }
  }
}
</style>
