<script setup lang="ts">
// The sidebar: a search slot, a tree of rows and groups, and a caption slot. The whole tree is one Tab stop (the
// selected row, else the first); Up, Down, Home and End move it, and each row answers Left and Right itself.
// `readonly` makes a read-only tree: rows show but do not select, reorder or offer actions.
// `placement="sidebar"` goes to the tree: rows stand on the field's edges, on the group head's columns (see RooTree).
// The label names the navigation landmark only; the tree inside it carries no second name, so a screen reader says it once.
import RooTree from './RooTree.vue'

withDefaults(defineProps<{ label: string; multiselectable?: boolean; readonly?: boolean; placement?: 'tree' | 'sidebar' }>(), { multiselectable: false, readonly: false, placement: 'tree' })
</script>

<template>
  <nav class="roo-sidebar" :aria-label="label">
    <div v-if="$slots.search" class="roo-sidebar-search"><slot name="search" /></div>
    <RooTree class="roo-sidebar-tree" :multiselectable="multiselectable" :readonly="readonly" :placement="placement"><slot /></RooTree>
    <div v-if="$slots.caption" class="roo-sidebar-caption"><slot name="caption" /></div>
  </nav>
</template>

<style scoped>
@layer roo-components {
  .roo-sidebar {
    display: flex;
    width: 100%;
    min-width: 0;
    min-height: 0;
    flex-direction: column;
    box-sizing: border-box;
    background: var(--roo-x-chrome);
    color: var(--roo-text);
  }

  .roo-sidebar-search {
    flex: none;
    padding: 8px;
  }

  /* The row list has the same room above and below its rows as at its sides (Raja, 2026-11-28: "not matching top padding"): the
     tree pads its sides by --roo-tree-inset, and the block padding is that inset less the gap each row keeps round itself. */
  .roo-sidebar-tree {
    min-height: 0;
    flex: 1 1 auto;
    overflow-y: auto;
    padding-block: calc(var(--roo-tree-inset) - var(--roo-tree-row-gap));
  }

  /* The caption's text starts on the sidebar's text line (--roo-tree-text-line), where the tree rows and group heads start. */
  .roo-sidebar-caption {
    flex: none;
    padding: 8px var(--roo-tree-text-line);
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
}
</style>
