<script setup lang="ts">
import { useAnnouncer, type Announcer } from '../composables/useAnnouncer'

const props = defineProps<{
  /** Defaults to the app-wide announcer. A test or an isolated surface passes its own. */
  announcer?: Announcer | undefined
}>()

const announcer = props.announcer ?? useAnnouncer()
</script>

<template>
  <div class="roo-live-region">
    <div class="roo-visually-hidden" role="status" aria-live="polite" aria-atomic="true">{{ announcer.polite.value }}</div>
    <div class="roo-visually-hidden" role="alert" aria-live="assertive" aria-atomic="true">{{ announcer.assertive.value }}</div>
  </div>
</template>
