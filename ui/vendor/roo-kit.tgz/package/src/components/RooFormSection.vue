<script setup lang="ts">
// One section of a settings form: the title (and an optional description) in a column on the left, a card holding the fields on the
// right. The section is a container, so it answers to the width it really has, not the window: under 600 px of section width the title
// sits on top and the card goes under it at full width. Put the fields in the default slot; RooSettingRow, RooInput and the like sit
// inside the card as they are. The title column is a fixed band and the card column is capped at a readable measure; spare width stays
// on the right, so stacked sections share one left edge.
defineProps<{
  /** The section's name. */
  title: string
  /** One quiet line under the title. The `description` slot replaces it. */
  description?: string | undefined
}>()
</script>

<template>
  <section class="roo-form-section">
    <div class="roo-form-section-grid">
      <div class="roo-form-section-intro">
        <h3 class="roo-form-section-title">{{ title }}</h3>
        <p v-if="description || $slots.description" class="roo-form-section-description"><slot name="description">{{ description }}</slot></p>
      </div>
      <div class="roo-form-section-card"><slot /></div>
    </div>
  </section>
</template>

<style scoped>
@layer roo-components {
  .roo-form-section {
    container-type: inline-size;
    container-name: roo-form-section;
    font-family: var(--roo-font-ui);
    color: var(--roo-text);
  }

  .roo-form-section-grid {
    display: grid;
    grid-template-columns: var(--roo-form-title-w) minmax(0, var(--roo-form-card-max-w));
    justify-content: start;
    gap: var(--roo-space-section);
    align-items: start;
  }

  .roo-form-section-intro {
    display: flex;
    min-width: 0;
    flex-direction: column;
    gap: var(--roo-p-space-1);
  }

  .roo-form-section-title {
    margin: 0;
    font-size: var(--roo-p-size-15);
    font-weight: 600;
  }

  .roo-form-section-description {
    margin: 0;
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-form-section-card {
    min-width: 0;
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-p-radius-card);
    background: var(--roo-surface);
    padding: var(--roo-p-space-2) var(--roo-space-card);
  }

  @container roo-form-section (max-width: 599px) {
    .roo-form-section-grid {
      grid-template-columns: minmax(0, 1fr);
      gap: var(--roo-space-group);
    }
  }
}
</style>
