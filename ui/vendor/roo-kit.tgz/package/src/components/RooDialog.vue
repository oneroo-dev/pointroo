<script setup lang="ts">
import { computed, onBeforeUnmount, provide, ref, useSlots, watch } from 'vue'
import {
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogOverlay,
  DialogPortal,
  DialogRoot,
  DialogTitle,
  DialogTrigger,
} from 'reka-ui'
import type { FocusOutsideEvent, PointerDownOutsideEvent } from 'reka-ui'
import { dialogEscapeGuardKey, type DialogEscapeGuard } from '../composables/dialogEscapeGuard'
import { useEscapeLayer } from '../composables/useEscapeLayer'
import RooIconButton from './RooIconButton.vue'
import {
  dialogFallbackMinimum,
  dialogMinimumBySize,
  keepInView,
  readTokenPixels,
  resizeRectangle,
  type DialogBounds,
  type DialogEdges,
  type DialogRectangle,
} from './RooDialogResize'

// The root is renderless, so attributes passed to <RooDialog> (data-align-column, data-testid, class) land on the visible
// panel, the .roo-dialog element, which is portalled out of the caller's tree.
defineOptions({ inheritAttrs: false })

type FocusTarget = string | HTMLElement | (() => HTMLElement | null)

const props = withDefaults(
  defineProps<{
    title?: string
    description?: string
    /** 'settings' is the full-bleed settings window: 900 by 660 (clamped to the window), no body padding, a hairline under the head strip, and always the comfortable density whatever the app's. Put a RooSettingsLayout in the body. */
    size?: 'sm' | 'md' | 'lg' | 'settings'
    /** Where the title sits in the head: 'start' (default) or 'center' (a TablePlus sheet). A centred title keeps equal room each side, so a close button does not push it off centre. */
    titleAlign?: 'start' | 'center'
    modal?: boolean
    closeOnEsc?: boolean
    closeOnOutsideClick?: boolean
    showCloseButton?: boolean
    tone?: 'default' | 'prod'
    /**
     * 'dialog' is the centred panel it has always been. 'sheet' drops from under the Bar at 360, 448 or 640 (`size`).
     * 'alert' is centred at 360, or at `width`.
     */
    kind?: 'dialog' | 'sheet' | 'alert'
    /**
     * The layer behind the panel. 'blur' is the dimmed, blurred scrim a dialog and an alert have always had. 'plain' dims
     * without blur. 'none' draws no tint at all (the layer still catches an outside click). Left out, a sheet is 'plain'
     * and every other kind is 'blur'.
     */
    scrim?: 'blur' | 'plain' | 'none' | undefined
    /** An alert's width (a number is px). Written as a custom property, never as a style attribute. */
    width?: number | string | undefined
    /** An action is running: a thin line runs along the top edge and the body is marked busy. */
    busy?: boolean
    /** A multi-step flow: the footer shows "Step 2 of 3" before the actions. */
    step?: { index: number; count: number } | undefined
    /** Enter in a text field presses the footer button marked `data-enter-runs="probe"` or `"primary"`. */
    enterRuns?: 'probe' | 'primary' | undefined
    /** Where focus goes on close when the element that opened the dialog is gone: a selector, an element or a function. */
    returnFocusTo?: FocusTarget | undefined
    /** The primary action is destructive: the button marked `data-dialog-cancel` takes initial focus. */
    destructive?: boolean
    /** The dialog can be dragged larger or smaller from its four edges and its bottom-right grip (a TablePlus sheet). Off by default. */
    resizable?: boolean
    /** A saved height in px, to restore a size (with `width`, which is the saved width when `resizable`). Never smaller than the minimum. */
    height?: number | undefined
    /** The least width in px a drag or key can reach. Left out, it is the size preset's width. */
    minWidth?: number | undefined
    /** The least height in px a drag or key can reach. Left out, it is the size preset's least height. */
    minHeight?: number | undefined
    /** Written as data-size-key on the panel. The app saves and restores the size by this key; the kit stores nothing. */
    sizeKey?: string | undefined
  }>(),
  {
    title: '',
    description: '',
    size: 'md',
    titleAlign: 'start',
    modal: true,
    closeOnEsc: true,
    closeOnOutsideClick: true,
    showCloseButton: true,
    tone: 'default',
    kind: 'dialog',
    scrim: undefined,
    width: undefined,
    busy: false,
    step: undefined,
    enterRuns: undefined,
    returnFocusTo: undefined,
    destructive: false,
    resizable: false,
    height: undefined,
    minWidth: undefined,
    minHeight: undefined,
    sizeKey: undefined,
  },
)

const emit = defineEmits<{
  open: []
  close: []
  /** Esc on an open dialog. Call `keepOpen()` to keep it open; the Esc is consumed either way (see useEscapeLayer). */
  'escape-key-down': [event: KeyboardEvent, control: { keepOpen: () => void }]
  'pointer-down-outside': [event: PointerDownOutsideEvent]
  'focus-outside': [event: FocusOutsideEvent]
  'interact-outside': [event: PointerDownOutsideEvent | FocusOutsideEvent]
  'open-auto-focus': [event: Event]
  'close-auto-focus': [event: Event]
  /** A resize ended (a drag released, or a key pressed on the grip): the new size in px. Save it by `size-key`. */
  resize: [size: { width: number; height: number }]
}>()
const slots = useSlots()

if (!props.title.trim() && !slots.title) {
  console.warn('[RooDialog] title is empty. A dialog needs a title for its accessible name.')
}

const isModalOpen = defineModel<boolean>('open', { default: false })
useEscapeLayer(() => isModalOpen.value)

// Roomy density only where the app already opted in: the attribute is read when the dialog opens, and a dialog never
// sets data-density on an unadopted app (section 0.1). It goes on the dialog content only, which is where portalled
// children (a RooSelect, a RooMenu) look for [data-density]. A compact app keeps its dialog compact: the content is then
// the form tier (22 tall controls, 13px type, set by the .roo-dialog rule below), so a dialog is not a roomy island
// of 32px controls in a compact window. The settings size is the one exception: it is always comfortable (Raja, 2026-11-23), so it
// sets roomy on its own content whatever the app's density (and RooSettingsLayout sets it on its root, which is what wins over the
// compact form tier above for everything inside the layout).
const roomy = ref(false)
function readDensity(): void {
  roomy.value = typeof document !== 'undefined' && document.documentElement.hasAttribute('data-density') && document.documentElement.getAttribute('data-density') !== 'compact'
}
readDensity()

let opener: HTMLElement | null = null
function rememberOpener(): void {
  opener = typeof document === 'undefined' ? null : (document.activeElement as HTMLElement | null)
}
if (isModalOpen.value) rememberOpener()

watch(isModalOpen, (open) => {
  if (open) {
    readDensity()
    rememberOpener()
    emit('open')
  } else emit('close')
})

const openModal = () => (isModalOpen.value = true)
const closeModal = () => (isModalOpen.value = false)
const toggleModal = () => (isModalOpen.value = !isModalOpen.value)

// The open dialog is an Esc layer (useEscapeLayer), so the Esc arrives here already prevented and marked consumed: the
// default is no veto signal any more. An app keeps the dialog open by calling keepOpen() in its escape-key-down handler.
// A part inside the dialog (RooSettingsLayout's search field) may take the Esc first: its guard returns true and the dialog stays open.
const escapeGuards = new Set<DialogEscapeGuard>()
provide(dialogEscapeGuardKey, (guard) => {
  escapeGuards.add(guard)
  return () => void escapeGuards.delete(guard)
})

function onEscapeKeyDown(event: KeyboardEvent): void {
  event.preventDefault()
  let kept = [...escapeGuards].some((guard) => guard())
  emit('escape-key-down', event, { keepOpen: () => (kept = true) })
  if (!props.closeOnEsc || kept) return
  isModalOpen.value = false
}

// Dragging the window by the strip above the overlay must never close the dialog.
function startedOnDragStrip(event: PointerDownOutsideEvent | FocusOutsideEvent): boolean {
  const target = (event.detail?.originalEvent?.target ?? event.target) as Element | null
  return Boolean(target?.closest?.('.roo-dialog-drag-strip'))
}

function onPointerDownOutside(event: PointerDownOutsideEvent): void {
  emit('pointer-down-outside', event)
  if (!props.closeOnOutsideClick || startedOnDragStrip(event)) event.preventDefault()
}

function onFocusOutside(event: FocusOutsideEvent): void {
  emit('focus-outside', event)
  if (!props.closeOnOutsideClick) event.preventDefault()
}

function onInteractOutside(event: PointerDownOutsideEvent | FocusOutsideEvent): void {
  emit('interact-outside', event)
  if (!props.closeOnOutsideClick || startedOnDragStrip(event)) event.preventDefault()
}

function eventElement(event: Event): HTMLElement | null {
  const element = (event.currentTarget ?? event.target) as HTMLElement | null
  return element instanceof HTMLElement ? element : null
}

// A destructive dialog never lands on its primary action: Cancel takes the first focus.
function onOpenAutoFocus(event: Event): void {
  writePanelProperties()
  emit('open-auto-focus', event)
  if (event.defaultPrevented || !props.destructive) return
  const cancel = eventElement(event)?.querySelector<HTMLElement>('[data-dialog-cancel]')
  if (!cancel) return
  event.preventDefault()
  cancel.focus()
}

function resolveReturnTarget(): HTMLElement | null {
  const target = props.returnFocusTo
  if (target === undefined) return null
  if (typeof target === 'string') return document.querySelector<HTMLElement>(target)
  return typeof target === 'function' ? target() : target
}

// Focus goes back to the element that opened the dialog. When that element is gone (a menu item that closed, a row that
// re-rendered), `returnFocusTo` is the fallback, so focus never falls to the page body.
function onCloseAutoFocus(event: Event): void {
  emit('close-auto-focus', event)
  if (event.defaultPrevented) return
  const openerIsGone = opener === null || opener === document.body || !opener.isConnected
  if (!openerIsGone) return
  const fallback = resolveReturnTarget()
  if (!fallback) return
  event.preventDefault()
  fallback.focus()
}

function onKeydown(event: KeyboardEvent): void {
  if (!props.enterRuns || event.key !== 'Enter' || event.repeat || event.isComposing) return
  const target = event.target as HTMLElement | null
  if (target?.closest('textarea, button, a, select, [role="button"], [contenteditable="true"]')) return
  const action = eventElement(event)?.querySelector<HTMLElement>(
    `[data-enter-runs="${props.enterRuns}"]:not(:disabled):not([aria-disabled="true"])`,
  )
  if (!action) return
  event.preventDefault()
  action.click()
}

const contentReference = ref<{ $el?: HTMLElement } | null>(null)
watch(
  [contentReference, () => props.width],
  ([content, width]) => {
    const element = content?.$el
    if (!element?.style) return
    if (props.resizable) return element.style.removeProperty('--roo-dialog-width')
    if (width === undefined || width === '') element.style.removeProperty('--roo-dialog-width')
    else element.style.setProperty('--roo-dialog-width', typeof width === 'number' ? `${width}px` : width)
  },
  { flush: 'post' },
)

// Resizing (opt in with `resizable`). The panel starts centred by the frame. A drag or a key switches it to an explicit
// rectangle (left, top, width, height, measured against the frame), so it keeps its top-left while it grows; closing the
// dialog forgets the position (it is centred again on the next open) and keeps the size. All numbers reach the panel as custom
// properties, never as a style attribute.
const savedWidth = computed(() => {
  const value = typeof props.width === 'string' ? Number.parseFloat(props.width) : props.width
  return props.resizable && value !== undefined && Number.isFinite(value) ? value : null
})
const savedHeight = computed(() => (props.resizable && props.height !== undefined && Number.isFinite(props.height) ? props.height : null))
const resizedWidth = ref<number | null>(savedWidth.value)
const resizedHeight = ref<number | null>(savedHeight.value)
const resizedLeft = ref<number | null>(null)
const resizedTop = ref<number | null>(null)
const isResizing = ref(false)
const isSized = computed(() => props.resizable && (resizedWidth.value !== null || resizedHeight.value !== null))
const isPositioned = computed(() => props.resizable && resizedLeft.value !== null && resizedTop.value !== null)

watch([savedWidth, savedHeight], ([width, height]) => {
  resizedWidth.value = width
  resizedHeight.value = height
})

const keyboardStep = 1 // grid steps for an arrow key
const keyboardLargeStep = 8 // grid steps for Shift+arrow

function minimumSize() {
  const preset = dialogMinimumBySize[props.size] ?? dialogFallbackMinimum
  return { width: props.minWidth ?? preset.width, height: props.minHeight ?? preset.height }
}

function panelElement(): HTMLElement | null {
  const element = contentReference.value?.$el
  return element instanceof HTMLElement ? element : null
}

// The room a dialog may take: the frame minus the kit page margin on every side. Coordinates are relative to the frame.
function resizeBounds(): DialogBounds | null {
  const frame = panelElement()?.parentElement
  if (!frame) return null
  const frameRectangle = frame.getBoundingClientRect()
  const margin = readTokenPixels('--roo-p-space-4', 16) // fallback: the 16 px page margin, when the token cannot be read
  return { left: margin, top: margin, right: frameRectangle.width - margin, bottom: frameRectangle.height - margin }
}

function measureRectangle(): DialogRectangle | null {
  const panel = panelElement()
  const frame = panel?.parentElement
  const bounds = resizeBounds()
  if (!panel || !frame || !bounds) return null
  const panelRectangle = panel.getBoundingClientRect()
  const frameRectangle = frame.getBoundingClientRect()
  return keepInView(
    { left: panelRectangle.left - frameRectangle.left, top: panelRectangle.top - frameRectangle.top, width: panelRectangle.width, height: panelRectangle.height },
    minimumSize(),
    bounds,
  )
}

function applyRectangle(rectangle: DialogRectangle): void {
  resizedLeft.value = rectangle.left
  resizedTop.value = rectangle.top
  resizedWidth.value = rectangle.width
  resizedHeight.value = rectangle.height
}

function emitResize(): void {
  if (resizedWidth.value === null || resizedHeight.value === null) return
  emit('resize', { width: Math.round(resizedWidth.value), height: Math.round(resizedHeight.value) })
}

const resizeEdges: Record<'north' | 'south' | 'east' | 'west', DialogEdges> = {
  north: { top: true },
  south: { bottom: true },
  east: { right: true },
  west: { left: true },
}
const cornerEdges: DialogEdges = { right: true, bottom: true }
let stopDrag: (() => void) | null = null

function startResize(event: MouseEvent, edges: DialogEdges): void {
  if (!props.resizable || event.button !== 0) return
  const start = measureRectangle()
  const bounds = resizeBounds()
  if (!start || !bounds) return
  event.preventDefault()
  stopDrag?.()
  applyRectangle(start)
  isResizing.value = true
  const originX = event.clientX
  const originY = event.clientY
  const onMove = (moveEvent: MouseEvent): void =>
    applyRectangle(resizeRectangle(start, edges, moveEvent.clientX - originX, moveEvent.clientY - originY, minimumSize(), resizeBounds() ?? bounds))
  const finish = (): void => {
    stopDrag?.()
    emitResize()
  }
  window.addEventListener('pointermove', onMove)
  window.addEventListener('pointerup', finish)
  window.addEventListener('pointercancel', finish)
  stopDrag = () => {
    window.removeEventListener('pointermove', onMove)
    window.removeEventListener('pointerup', finish)
    window.removeEventListener('pointercancel', finish)
    isResizing.value = false
    stopDrag = null
  }
}

const arrowDirections: Record<string, [number, number]> = {
  ArrowRight: [1, 0],
  ArrowLeft: [-1, 0],
  ArrowDown: [0, 1],
  ArrowUp: [0, -1],
}

function onGripKeydown(event: KeyboardEvent): void {
  const direction = arrowDirections[event.key]
  if (!direction || !props.resizable) return
  const start = measureRectangle()
  const bounds = resizeBounds()
  if (!start || !bounds) return
  event.preventDefault()
  const gridStep = readTokenPixels('--roo-p-space-1', 4) // fallback: the 4 px grid, when the token cannot be read
  const distance = gridStep * (event.shiftKey ? keyboardLargeStep : keyboardStep)
  applyRectangle(resizeRectangle(start, cornerEdges, direction[0] * distance, direction[1] * distance, minimumSize(), bounds))
  emitResize()
}

// A smaller window pulls the panel back into view: it slides first and shrinks only when it cannot fit.
function onWindowResize(): void {
  if (!isPositioned.value) return
  const rectangle = measureRectangle()
  if (rectangle) applyRectangle(rectangle)
}
watch(isPositioned, (positioned) => {
  if (typeof window === 'undefined') return
  if (positioned) window.addEventListener('resize', onWindowResize)
  else window.removeEventListener('resize', onWindowResize)
})
watch(isModalOpen, (open) => {
  if (open) return
  stopDrag?.()
  resizedLeft.value = null
  resizedTop.value = null
})
onBeforeUnmount(() => {
  stopDrag?.()
  if (typeof window !== 'undefined') window.removeEventListener('resize', onWindowResize)
})

// Written whenever a value changes, and again when the panel mounts (a reopened dialog is a new element that has none).
function writePanelProperties(): void {
  const element = panelElement()
  if (!element?.style) return
  const values: Record<string, number | null> = {
    '--roo-dialog-w': resizedWidth.value,
    '--roo-dialog-h': resizedHeight.value,
    '--roo-dialog-left': resizedLeft.value,
    '--roo-dialog-top': resizedTop.value,
    '--roo-dialog-min-w': props.resizable ? minimumSize().width : null,
    '--roo-dialog-min-h': props.resizable ? minimumSize().height : null,
  }
  for (const [name, value] of Object.entries(values)) {
    if (props.resizable && value !== null) element.style.setProperty(name, `${value}px`)
    else element.style.removeProperty(name)
  }
}
watch(
  [contentReference, resizedWidth, resizedHeight, resizedLeft, resizedTop, () => props.resizable, () => props.size, () => props.minWidth, () => props.minHeight],
  writePanelProperties,
  { flush: 'post' },
)

const scrimStyle = computed(() => props.scrim ?? (props.kind === 'sheet' ? 'plain' : 'blur'))
const hasDescription = computed(() => Boolean(props.description || slots.description))
const hasFooter = computed(() => Boolean(slots.footer || slots.actions || props.step))

defineExpose({ openModal, closeModal, toggleModal, isModalOpen })
</script>

<template>
  <DialogRoot v-model:open="isModalOpen" :modal="modal">
    <DialogTrigger v-if="$slots.trigger" as-child>
      <slot name="trigger" />
    </DialogTrigger>

    <DialogPortal>
      <DialogOverlay class="roo-dialog-overlay" :data-scrim="scrimStyle" :data-passive="modal ? undefined : ''" />
      <!-- Family rule: the window still drags by its title bar while a dialog is open (Electron and Tauri). -->
      <div v-if="modal && isModalOpen" class="roo-dialog-drag-strip" data-tauri-drag-region aria-hidden="true" />
      <div class="roo-dialog-frame" :data-kind="kind">
        <DialogContent
          ref="contentReference"
          v-bind="{ ...$attrs, ...(hasDescription ? {} : { 'aria-describedby': undefined }) }"
          class="roo-dialog"
          :data-size="size"
          :data-tone="tone"
          :data-kind="kind"
          :data-density="roomy || size === 'settings' ? 'roomy' : undefined"
          :data-resizable="resizable ? '' : undefined"
          :data-sized="isSized ? '' : undefined"
          :data-positioned="isPositioned ? '' : undefined"
          :data-resizing="isResizing ? '' : undefined"
          :data-size-key="sizeKey"
          :aria-busy="busy || undefined"
          @escape-key-down="onEscapeKeyDown"
          @pointer-down-outside="onPointerDownOutside"
          @focus-outside="onFocusOutside"
          @interact-outside="onInteractOutside"
          @open-auto-focus="onOpenAutoFocus"
          @close-auto-focus="onCloseAutoFocus"
          @keydown="onKeydown"
        >
          <!-- TODO(kit2-K5): the Line below is a stand-in; the lead swaps it for RooProgressLine at K5's merge. -->
          <div v-if="busy" class="roo-dialog-line" role="progressbar" aria-label="Working" aria-busy="true" />
          <div class="roo-dialog-head" :data-closable="showCloseButton ? '' : undefined" :data-title-align="titleAlign">
            <DialogTitle as="h2" class="roo-dialog-title">
              <span v-if="tone === 'prod'" class="roo-dialog-prod-tag">prod</span>
              <slot name="title">{{ title }}</slot>
            </DialogTitle>
            <div v-if="$slots.headerEnd" class="roo-dialog-header-end"><slot name="headerEnd" /></div>
          </div>
          <DialogDescription v-if="hasDescription" class="roo-dialog-description">
            <slot name="description">{{ description }}</slot>
          </DialogDescription>
          <div v-if="$slots.reason" class="roo-dialog-reason"><slot name="reason" /></div>

          <DialogClose v-if="showCloseButton" as-child>
            <RooIconButton class="roo-dialog-close" icon="x" label="Close" size="sm" />
          </DialogClose>

          <div v-if="$slots.fields" class="roo-dialog-fields"><slot name="fields" /></div>
          <div class="roo-dialog-body"><slot /></div>
          <div v-if="$slots.facts" class="roo-dialog-facts"><slot name="facts" /></div>

          <div v-if="hasFooter" class="roo-dialog-footer">
            <span v-if="step" class="roo-dialog-step">Step {{ step.index }} of {{ step.count }}</span>
            <slot name="footer"><slot name="actions" /></slot>
          </div>

          <template v-if="resizable">
            <div
              v-for="(edges, edge) in resizeEdges"
              :key="edge"
              class="roo-dialog-edge"
              :data-edge="edge"
              aria-hidden="true"
              @pointerdown="startResize($event, edges)"
            />
            <button type="button" class="roo-dialog-grip" aria-label="Resize dialog" @pointerdown="startResize($event, cornerEdges)" @keydown="onGripKeydown">
              <span class="roo-dialog-grip-mark" aria-hidden="true" />
            </button>
          </template>
        </DialogContent>
      </div>
    </DialogPortal>
  </DialogRoot>
</template>

<style scoped>
@layer roo-components {
  .roo-dialog-overlay {
    position: fixed;
    inset: 0;
    z-index: 50;
    background: var(--roo-dialog-scrim);
    backdrop-filter: blur(var(--roo-dialog-blur));
    animation: roo-fade var(--roo-base) var(--roo-ease) both;
  }

  .roo-dialog-overlay[data-scrim='plain'] {
    backdrop-filter: none;
  }

  .roo-dialog-overlay[data-scrim='none'] {
    background: transparent;
    backdrop-filter: none;
  }

  .roo-dialog-overlay[data-state='closed'] {
    animation: roo-clear var(--roo-fast) var(--roo-exit) both;
  }

  .roo-dialog-overlay[data-passive] {
    pointer-events: none;
  }

  .roo-dialog-drag-strip {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 51;
    height: var(--roo-window-drag-height);
    pointer-events: auto;
    -webkit-app-region: drag;
    app-region: drag;
  }

  .roo-dialog-frame {
    position: fixed;
    inset: 0;
    top: var(--roo-window-drag-height);
    z-index: 50;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: var(--roo-p-space-4);
    pointer-events: none;
  }

  /* A sheet hangs from under the Bar. */
  .roo-dialog-frame[data-kind='sheet'] {
    top: var(--roo-bar-h);
    align-items: flex-start;
  }

  .roo-dialog {
    position: relative;
    width: 100%;
    max-width: 448px;
    max-height: 100%;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-p-radius-large);
    background: var(--roo-surface);
    /* No side padding here: each part carries its own side inset, so the body's scrollbar sits at the panel edge. */
    padding: var(--roo-dialog-inset) 0;
    text-align: left;
    font-family: var(--roo-font-ui);
    color: var(--roo-text);
    box-shadow: var(--roo-shadow-panel);
    outline: none;
    pointer-events: auto;
    animation: roo-pop var(--roo-base) var(--roo-spring) both;
  }

  /* The form tier (TablePlus: dialogs and sheets are one step roomier than workspace chrome): under compact density the controls inside
     are 22 tall with 13px type, where the chrome around them is 20 and 12. Custom properties inherit, so no component takes a prop. */
  :root[data-density='compact'] .roo-dialog {
    --roo-control-h: calc(26px + var(--roo-scale) * 2px);
    --roo-control-h-large: calc(26px + var(--roo-scale) * 2px);
    --roo-field-h: calc(26px + var(--roo-scale) * 2px);
    --roo-search-h: calc(26px + var(--roo-scale) * 2px);
    --roo-segmented-h: calc(26px + var(--roo-scale) * 2px);
    --roo-ui-size: calc(13px + var(--roo-scale) * 1px);
    --roo-control-line: 16px;
  }

  .roo-dialog[data-size='sm'] {
    max-width: 360px;
  }

  .roo-dialog[data-size='md'] {
    max-width: 448px;
  }

  .roo-dialog[data-size='lg'] {
    max-width: 640px;
  }

  /* The settings window (RooSettingsLayout lives in its body): full bleed. The dialog has no padding, the head is a strip the height of
     the Bar with a hairline under it, and the close button sits on the title's centre line. The body takes the rest and does not
     scroll, because the layout inside scrolls its own panes. The two numbers are layout sizes: the window width, and its height range. */
  .roo-dialog[data-size='settings'] {
    max-width: 900px; /* layout: the settings window width (TablePlus settings, 900 by 660) */
    height: 660px; /* layout: the settings window height; max-height 100% clamps it to the window */
    min-height: min(480px, 100%); /* layout: never shorter than 480 unless the window is */
    padding: 0;
  }

  .roo-dialog[data-size='settings'] .roo-dialog-head {
    box-sizing: border-box;
    height: var(--roo-bar-h);
    /* The title starts on the nav's glyph column: the nav's side padding plus the tree's text line. */
    padding-inline-start: calc(var(--roo-p-space-2) + var(--roo-tree-text-line));
    border-bottom: 1px solid var(--roo-border);
  }

  .roo-dialog[data-size='settings'] .roo-dialog-head[data-title-align='center'] {
    padding-inline: calc(var(--roo-dialog-inset) + 32px); /* layout: the close button's width, mirrored */
  }

  .roo-dialog[data-size='settings'] .roo-dialog-close {
    top: calc(var(--roo-bar-h) / 2);
    transform: translateY(-50%);
  }

  .roo-dialog[data-size='settings'] .roo-dialog-body {
    display: flex;
    flex-direction: column;
    overflow: hidden;
    padding: 0;
  }

  .roo-dialog[data-kind='alert'] {
    max-width: var(--roo-dialog-width, 360px);
  }

  /* Resizable: the saved or dragged size and position arrive as custom properties. The preset's max-width gives way, and the
     panel stays inside the frame (and so inside the kit page margin) until a drag sets an explicit rectangle. */
  .roo-dialog[data-resizable] {
    min-width: min(var(--roo-dialog-min-w, 0px), 100%);
    transition: none;
  }

  .roo-dialog[data-resizable][data-sized] {
    max-width: 100%;
    width: var(--roo-dialog-w, 100%);
    height: var(--roo-dialog-h, auto);
  }

  .roo-dialog[data-resizable][data-positioned] {
    position: absolute;
    left: var(--roo-dialog-left);
    top: var(--roo-dialog-top);
    max-width: none;
    max-height: none;
  }

  .roo-dialog[data-resizing] {
    user-select: none;
  }

  /* The edge zones are invisible. 8 px (on the 4 px grid) is a layout size: a strip wide enough to grab inside the hairline border. */
  .roo-dialog-edge {
    position: absolute;
    z-index: 2;
  }

  .roo-dialog-edge[data-edge='north'],
  .roo-dialog-edge[data-edge='south'] {
    left: 0;
    right: 0;
    height: 8px; /* layout: edge hit zone */
    cursor: ns-resize;
  }

  .roo-dialog-edge[data-edge='east'],
  .roo-dialog-edge[data-edge='west'] {
    top: 0;
    bottom: 0;
    width: 8px; /* layout: edge hit zone */
    cursor: ew-resize;
  }

  .roo-dialog-edge[data-edge='north'] {
    top: 0;
  }

  .roo-dialog-edge[data-edge='south'] {
    bottom: 0;
  }

  .roo-dialog-edge[data-edge='east'] {
    right: 0;
  }

  .roo-dialog-edge[data-edge='west'] {
    left: 0;
  }

  /* The corner grip: a button (so it takes focus and the arrow keys) drawn as three diagonal strokes in the bottom-right triangle. */
  .roo-dialog-grip {
    position: absolute;
    z-index: 3;
    right: 2px; /* layout: inside the border, clear of the footer's inset */
    bottom: 2px; /* layout: inside the border, clear of the footer's inset */
    width: 16px; /* layout: grip hit zone */
    height: 16px; /* layout: grip hit zone */
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    border: 0;
    border-radius: var(--roo-p-radius-small);
    background: transparent;
    color: var(--roo-faint);
    cursor: nwse-resize;
  }

  .roo-dialog-grip-mark {
    display: block;
    width: 100%;
    height: 100%;
    background: linear-gradient(
      135deg,
      transparent 0 52%,
      currentColor 52% 58%,
      transparent 58% 70%,
      currentColor 70% 76%,
      transparent 76% 88%,
      currentColor 88% 94%,
      transparent 94%
    );
  }

  .roo-dialog-grip:hover {
    color: var(--roo-muted);
  }

  .roo-dialog-grip:focus-visible {
    color: var(--roo-muted);
    outline: 2px solid var(--roo-focus);
    outline-offset: 0;
  }

  @media (prefers-reduced-motion: reduce) {
    .roo-dialog[data-resizable] {
      transition: none;
    }
  }

  .roo-dialog[data-kind='sheet'] {
    animation: roo-dialog-sheet-settle var(--roo-base) var(--roo-ease) both;
  }

  /* After the sheet rule, which has the same weight: a closing dialog of any kind runs Clear, never its open animation. */
  .roo-dialog[data-state='closed'] {
    animation: roo-pop-out var(--roo-fast) var(--roo-exit) both;
  }

  .roo-dialog[data-tone='prod'] {
    border-color: var(--roo-prod);
  }

  .roo-dialog-head,
  .roo-dialog-description,
  .roo-dialog-reason,
  .roo-dialog-fields,
  .roo-dialog-facts,
  .roo-dialog-footer {
    flex: none;
    padding-inline: var(--roo-dialog-inset);
  }

  .roo-dialog-head {
    display: flex;
    align-items: center;
    gap: var(--roo-p-space-2);
  }

  .roo-dialog-title {
    flex: 1 1 auto;
    min-width: 0;
    margin: 0;
    font-size: var(--roo-p-size-15);
    font-weight: 600;
  }

  .roo-dialog-prod-tag {
    display: inline-block;
    margin-right: var(--roo-p-space-2);
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-prod-pill);
    padding: 1px 6px;
    font-size: var(--roo-p-size-12);
    font-weight: 600;
    color: var(--roo-on-prod);
  }

  .roo-dialog-head[data-closable] {
    padding-right: calc(var(--roo-dialog-inset) + 32px);
  }

  /* Centred: the same room on both sides (the close button's 32 on each), so the title's centre is the panel's centre. */
  .roo-dialog-head[data-title-align='center'] {
    padding-inline: var(--roo-dialog-inset);
  }

  .roo-dialog-head[data-title-align='center'][data-closable] {
    padding-inline: calc(var(--roo-dialog-inset) + 32px); /* layout: the close button's width, mirrored */
  }

  .roo-dialog-head[data-title-align='center'] .roo-dialog-title {
    text-align: center;
  }

  .roo-dialog-header-end {
    display: flex;
    flex: none;
    align-items: center;
    gap: var(--roo-p-space-2);
  }

  .roo-dialog-description {
    margin: 4px 0 0;
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-dialog-reason {
    margin-top: var(--roo-p-space-2);
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-dialog-close {
    position: absolute;
    top: 12px;
    right: 12px;
  }

  .roo-dialog-fields {
    margin-top: var(--roo-p-space-4);
  }

  .roo-dialog-body {
    flex: 1 1 auto;
    min-height: 0;
    overflow-y: auto;
    padding-inline: var(--roo-dialog-inset);
    padding-top: var(--roo-p-space-4);
  }

  /* The gap to the footer lives inside the body, so the scroll box runs down to the footer line. */
  .roo-dialog-body:has(+ .roo-dialog-footer) {
    padding-bottom: var(--roo-dialog-inset);
  }

  .roo-dialog-body + .roo-dialog-footer {
    margin-top: 0;
  }

  .roo-dialog-facts {
    margin-top: var(--roo-p-space-3);
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-dialog-footer {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: var(--roo-p-space-2);
    margin-top: var(--roo-dialog-inset);
  }

  .roo-dialog-step {
    margin-right: auto;
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  /* The stand-in Line: it waits --roo-line-delay before it shows, so a quick action never flashes it. */
  .roo-dialog-line {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 2px;
    overflow: hidden;
    opacity: 0;
    animation: roo-fade var(--roo-fast) var(--roo-ease) var(--roo-line-delay) both;
  }

  .roo-dialog-line::before {
    content: '';
    position: absolute;
    inset: 0;
    background: var(--roo-accent);
    animation: roo-line 1200ms var(--roo-ease) infinite;
  }

  @keyframes roo-dialog-sheet-settle {
    from {
      opacity: 0;
      transform: translateY(-8px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
}
</style>
