<script setup lang="ts">
// The menu panel. It remembers the element that had focus when it opened (the trigger) and gives focus back to it on
// close, even when the app re-rendered the trigger in between. `copyAs` adds the Copy as submenu: Text, JSON, then the
// app's own formats, one keyboard path (ArrowRight opens, Enter picks, ArrowLeft or Escape goes back).
import { DropdownMenuContent, DropdownMenuPortal, DropdownMenuRoot, DropdownMenuTrigger } from 'reka-ui'
import { ref, watch } from 'vue'
import RooMenuItem from './RooMenuItem.vue'
import { useEscapeLayer } from '../composables/useEscapeLayer'
import { useCollisionPadding } from '../composables/useWindowControlPadding'

export interface RooCopyFormat {
  id: string
  label: string
}

withDefaults(
  defineProps<{
    align?: 'start' | 'center' | 'end'
    side?: 'top' | 'bottom' | 'left' | 'right'
    /** Add the Copy as submenu after the items. */
    copyAs?: boolean
    /** The app's own copy formats, listed after Text and JSON. */
    copyFormats?: RooCopyFormat[]
  }>(),
  { align: 'start', side: 'bottom', copyAs: false, copyFormats: () => [] },
)
const emit = defineEmits<{ 'copy-as': [formatId: string] }>()
const open = defineModel<boolean>('open', { default: false })
const triggerReference = ref<unknown>(null)
const collisionPadding = useCollisionPadding(open, triggerReference)
useEscapeLayer(() => open.value)

const builtInFormats: RooCopyFormat[] = [
  { id: 'text', label: 'Text' },
  { id: 'json', label: 'JSON' },
]

let trigger: HTMLElement | null = null
watch(
  open,
  (isOpen) => {
    if (isOpen) trigger = typeof document === 'undefined' ? null : (document.activeElement as HTMLElement | null)
  },
  { flush: 'sync' },
)

// Esc is consumed here and marked handled (preventDefault), so a window-level Esc action knows the menu already took it.
// reka dismisses on Esc without preventing the default, and a prevented default would stop its own dismissal, so the
// menu closes itself.
function onEscapeKeyDown(event: KeyboardEvent): void {
  event.preventDefault()
  open.value = false
}

function onCloseAutoFocus(event: Event): void {
  if (event.defaultPrevented || trigger === null || trigger === document.body || !trigger.isConnected) return
  event.preventDefault()
  trigger.focus()
}
</script>

<template>
  <DropdownMenuRoot v-model:open="open">
    <DropdownMenuTrigger ref="triggerReference" as-child>
      <slot name="trigger" />
    </DropdownMenuTrigger>
    <DropdownMenuPortal>
      <DropdownMenuContent :align="align" :side="side" :side-offset="6" :collision-padding="collisionPadding" class="roo-menu" @escape-key-down="onEscapeKeyDown" @close-auto-focus="onCloseAutoFocus">
        <slot />
        <RooMenuItem v-if="copyAs" icon="copy">
          Copy as
          <template #submenu>
            <RooMenuItem v-for="format in [...builtInFormats, ...copyFormats]" :key="format.id" @select="emit('copy-as', format.id)">
              {{ format.label }}
            </RooMenuItem>
          </template>
        </RooMenuItem>
      </DropdownMenuContent>
    </DropdownMenuPortal>
  </DropdownMenuRoot>
</template>

<!-- Not scoped: reka puts the panel inside its own popper div, so a scoped id would land on that
     wrapper and never reach .roo-menu. The roo- prefix keeps the class safe. -->
<style>
@layer roo-components {
  .roo-menu {
    z-index: 80;
    min-width: 176px;
    box-sizing: border-box;
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-radius-popover);
    background: var(--roo-surface);
    padding: var(--roo-menu-panel-pad);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-ui-size);
    color: var(--roo-text);
    box-shadow: var(--roo-shadow-panel);
    animation: roo-pop var(--roo-fast) var(--roo-ease) both;
    transform-origin: var(--reka-dropdown-menu-content-transform-origin, var(--reka-popper-transform-origin, center));
  }

  /* Where an app has opted in: the lighter popover shadow. */
  :root[data-density] .roo-menu {
    box-shadow: var(--roo-shadow-popover);
  }

  /* Clear out when the menu closes, for every app: without a closed animation Presence can keep the menu mounted. */
  .roo-menu[data-state='closed'] {
    animation: roo-pop-out var(--roo-fast) var(--roo-exit) both;
  }
}
</style>
