<script setup lang="ts">
import { onBeforeUnmount, ref, watch } from 'vue'

const props = withDefaults(
  defineProps<{
    /** Whether the work is under way. The line shows after `delay`, never for quick work. */
    busy?: boolean
    /** Milliseconds before the line appears. 300 by default; 0 inside a row. */
    delay?: number
    /** 0 to 100 for a determinate line; leave out for an indeterminate one. */
    value?: number | undefined
    placement?: 'top' | 'bottom'
    label?: string
  }>(),
  { busy: true, delay: 300, value: undefined, placement: 'top', label: 'Loading' },
)

const shown = ref(false)
let timer: ReturnType<typeof setTimeout> | undefined

function sync(): void {
  clearTimeout(timer)
  if (!props.busy) {
    shown.value = false
    return
  }
  if (props.delay <= 0) {
    shown.value = true
    return
  }
  timer = setTimeout(() => {
    shown.value = true
  }, props.delay)
}

watch(() => props.busy, sync, { immediate: true })
onBeforeUnmount(() => clearTimeout(timer))

function clamped(value: number): number {
  return Math.min(100, Math.max(0, value))
}
</script>

<template>
  <div
    v-if="shown"
    class="roo-progress-line"
    role="progressbar"
    :aria-label="label"
    aria-valuemin="0"
    aria-valuemax="100"
    :aria-valuenow="value === undefined ? undefined : clamped(value)"
    :data-placement="placement"
    :data-determinate="value === undefined ? undefined : 'true'"
  >
    <span class="roo-progress-line-bar" :style="value === undefined ? undefined : { transform: `scaleX(${clamped(value) / 100})` }" />
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-progress-line {
    position: absolute;
    right: 0;
    left: 0;
    height: 2px;
    overflow: hidden;
    pointer-events: none;
  }

  .roo-progress-line[data-placement='top'] {
    top: 0;
  }

  .roo-progress-line[data-placement='bottom'] {
    bottom: 0;
  }

  .roo-progress-line-bar {
    display: block;
    width: 100%;
    height: 100%;
    background: var(--roo-accent);
    animation: roo-line 1100ms var(--roo-ease) infinite;
  }

  /* Reduced motion: no moving bar. An indeterminate line is a static, partly filled bar from the start edge, so it still
     reads as work under way without anything travelling. */
  @media (prefers-reduced-motion: reduce) {
    .roo-progress-line:not([data-determinate='true']) .roo-progress-line-bar {
      transform: scaleX(0.4);
      transform-origin: left center;
      animation: none;
    }
  }

  .roo-progress-line[data-determinate='true'] .roo-progress-line-bar {
    transform-origin: left center;
    animation: none;
    transition: transform var(--roo-base) var(--roo-ease);
  }
}
</style>
