<script setup lang="ts">
// The two-column body of a settings window (put it in a RooDialog size="settings"): a nav column on the raised surface, flush
// from the head to the window's bottom edge, with a search field above a RooSidebar of RooTreeRow rows (32 tall, each with a 22
// coloured icon tile), and a pane at the right that scrolls by itself: a page title and one line under it, then RooSettingsGroup
// cards of RooSettingRow. Always the comfortable density, whatever the app's (it sets data-density="roomy" on its own root).
// Keyboard: Up, Down, Home and End move through the nav (one Tab stop, the tree's own), and the selection follows focus. Down in the
// search field steps into the nav; Esc with words in the field clears them first (inside a RooDialog, which asks the layout). Typing in the field filters the sections by label and
// `keywords`; when the chosen section drops out, the first match is chosen. Under 560 px of layout width (a container query, so a
// narrow dialog or a side panel counts as much as a narrow window) the nav collapses into a select above the pane.
// The default slot is the page of the chosen section; its scope is `{ section }`. Nothing here sets a width or a padding the
// dialog or the rows already own: the nav takes the tree's rows as they are, with the kit's selection fill and pill.
import { computed, inject, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { dialogEscapeGuardKey } from '../composables/dialogEscapeGuard'
import type { RooIconName } from '../icons/paths'
import RooIcon from './RooIcon.vue'
import RooInput from './RooInput.vue'
import RooSelect from './RooSelect.vue'
import RooSidebar from './RooSidebar.vue'
import RooTreeRow from './RooTreeRow.vue'

export interface RooSettingsSection {
  id: string
  label: string
  /** A glyph before the label in the nav, white on a rounded square tile. */
  icon?: RooIconName
  /** The tile's fill, any CSS colour (a token such as var(--roo-accent)). Left out, the tile is the neutral graphite. */
  color?: string
  /** One quiet line under the page title. */
  description?: string
  /** Extra words the search finds this section by (the names of the settings on its page). */
  keywords?: readonly string[]
}

const props = withDefaults(
  defineProps<{
    sections: readonly RooSettingsSection[]
    /** Names the nav landmark. */
    label?: string
    searchPlaceholder?: string
    /** Shown in the pane when the search matches no section. */
    emptyText?: string
  }>(),
  { label: 'Settings', searchPlaceholder: 'Search settings', emptyText: 'No settings match.' },
)

const section = defineModel<string>('section', { required: true })
const query = defineModel<string>('query', { default: '' })

const visibleSections = computed(() => {
  const words = query.value.trim().toLowerCase()
  if (words === '') return props.sections
  return props.sections.filter((entry) => [entry.label, ...(entry.keywords ?? [])].some((text) => text.toLowerCase().includes(words)))
})

const currentSection = computed(() => props.sections.find((entry) => entry.id === section.value))
const selectOptions = computed(() => visibleSections.value.map((entry) => ({ value: entry.id, label: entry.label })))

// A search that hides the chosen section moves the choice to the first match, so the pane never shows a page the nav hides.
watch(visibleSections, (list) => {
  if (list.length > 0 && !list.some((entry) => entry.id === section.value)) section.value = list[0]!.id
})

const searchField = ref<{ $el?: HTMLElement } | null>(null)
const side = ref<HTMLElement | null>(null)

function focusSearch(): void {
  searchField.value?.$el?.querySelector<HTMLInputElement>('input')?.focus()
}

async function focusCurrentRow(): Promise<void> {
  await nextTick()
  const rows = Array.from(side.value?.querySelectorAll<HTMLElement>('[role=treeitem]') ?? [])
  const target = rows.find((row) => row.getAttribute('aria-selected') === 'true') ?? rows[0]
  target?.focus()
}

function onSearchKeydown(event: KeyboardEvent): void {
  if (event.isComposing) return
  if (event.key === 'ArrowDown') {
    event.preventDefault()
    void focusCurrentRow()
  }
}

// Esc with words in the search clears them first and keeps the dialog open; the next Esc closes it (the dialog asks this guard).
const registerEscapeGuard = inject(dialogEscapeGuardKey, undefined)
let removeEscapeGuard: (() => void) | undefined
onMounted(() => {
  removeEscapeGuard = registerEscapeGuard?.(() => {
    if (query.value === '') return false
    query.value = ''
    return true
  })
})
onBeforeUnmount(() => removeEscapeGuard?.())

// The selection follows focus: arrowing through the nav changes the page at once, the way the system settings window does.
function onNavFocusin(event: FocusEvent): void {
  const row = (event.target as HTMLElement | null)?.closest<HTMLElement>('[role=treeitem]')
  const id = row?.getAttribute('data-section-id')
  if (id && id !== section.value) section.value = id
}

defineExpose({ focusSearch })
defineSlots<{ default?: (scope: { section: RooSettingsSection | undefined }) => unknown; 'nav-footer'?: () => unknown }>()
</script>

<template>
  <div class="roo-settings-layout" data-density="roomy">
    <div class="roo-settings-layout-frame">
      <div ref="side" class="roo-settings-layout-side" data-on-raised="true" data-align-column>
        <div class="roo-settings-layout-search" @keydown="onSearchKeydown">
          <RooInput ref="searchField" v-model="query" type="search" :placeholder="searchPlaceholder" :aria-label="searchPlaceholder" autocomplete="off" spellcheck="false" />
        </div>
        <RooSidebar class="roo-settings-layout-nav" :label="label" placement="sidebar" @focusin="onNavFocusin">
          <RooTreeRow
            v-for="entry in visibleSections"
            :key="entry.id"
            :label="entry.label"
            :selected="entry.id === section"
            :data-section-id="entry.id"
            @select="section = entry.id"
          >
            <template v-if="entry.icon" #tile>
              <span class="roo-settings-layout-tile" :style="entry.color ? { '--roo-settings-tile-fill': entry.color } : undefined"><RooIcon :name="entry.icon" :size="14" /></span>
            </template>
          </RooTreeRow>
        </RooSidebar>
        <p v-if="$slots['nav-footer']" class="roo-settings-layout-foot"><slot name="nav-footer" /></p>
        <div class="roo-settings-layout-select">
          <RooSelect v-model="section" :options="selectOptions" :label="label" hide-label size="md" />
        </div>
      </div>
      <section class="roo-settings-layout-pane" :aria-label="currentSection?.label ?? label" data-align-column>
        <p v-if="visibleSections.length === 0" class="roo-settings-layout-empty" role="status">{{ emptyText }}</p>
        <template v-else>
          <h3 class="roo-settings-layout-title">{{ currentSection?.label }}</h3>
          <p v-if="currentSection?.description" class="roo-settings-layout-subtitle">{{ currentSection.description }}</p>
          <slot :section="currentSection" />
        </template>
      </section>
    </div>
  </div>
</template>

<style scoped>
@layer roo-components {
  /* The layout is the container, so the nav answers to the width the layout really has, in a dialog, a side panel or a window. */
  .roo-settings-layout {
    container-type: inline-size;
    container-name: roo-settings-layout;
    flex: 1 1 auto;
    min-height: 0;
    min-width: 0;
    width: 100%;
    font-family: var(--roo-font-ui);
    color: var(--roo-text);
  }

  .roo-settings-layout-frame {
    display: grid;
    grid-template-columns: var(--roo-settings-nav-w) minmax(0, 1fr);
    height: 100%;
    min-height: 0;
    /* layout: the nav column width, a fifth of the window between 176 and 220 (TablePlus 210, Tinkeroo 176 to 232) */
    --roo-settings-nav-w: clamp(176px, 24%, 220px);
  }

  .roo-settings-layout-side {
    display: flex;
    min-height: 0;
    flex-direction: column;
    background: var(--roo-raised);
    border-inline-end: 1px solid var(--roo-border);
  }

  /* The field stands in the same inset column as the rows (the sidebar placement has no tree inset), and its glyph is as wide as a
     row's tile glyph (the tile less 4 each side), in a cell as wide as the tile, so the field's glyph and its typed text start on
     the x of the rows' glyphs and labels. */
  .roo-settings-layout-search {
    --roo-tree-inset: var(--roo-tree-sidebar-inset);
    --roo-search-glyph: calc(var(--roo-tile-md) - var(--roo-p-space-2));
    flex: none;
    padding: var(--roo-p-space-2);
  }

  .roo-settings-layout-search :deep(.roo-field-box[data-search='true'] .roo-field-leading) {
    width: var(--roo-tile-md);
  }

  /* The tree stands on the raised column: the sidebar's own fill steps aside, and a selected row takes the raised hover step, the
     way a list row does on a raised strip, because the plain selection fill is the column's own colour there. */
  /* Rows 32 tall (a 22 tile and 5 above and below), the TablePlus and Tinkeroo nav row. */
  .roo-settings-layout-nav {
    --roo-tree-row-h: calc(var(--roo-tile-md) + var(--roo-p-space-2) + 2px);
    flex: 1 1 auto;
    padding-inline: var(--roo-p-space-2);
    background: transparent;
  }

  /* The coloured square before a section name: a white glyph on the section's colour. */
  .roo-settings-layout-tile {
    display: inline-grid;
    place-items: center;
    width: var(--roo-tile-md);
    height: var(--roo-tile-md);
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-settings-tile-fill, var(--roo-x-tile));
    color: var(--roo-p-white);
  }

  .roo-settings-layout-nav :deep(.roo-tree-row[aria-selected='true'] .roo-tree-row-tile),
  .roo-settings-layout-nav :deep(.roo-tree-row:hover .roo-tree-row-tile) {
    color: var(--roo-p-white);
  }

  .roo-settings-layout-foot {
    flex: none;
    margin: 0;
    /* The footer's text starts on the x of the rows' tile glyphs: the nav's side padding, the tree's text line, and the tile's 4 of room round its glyph. */
    padding: var(--roo-p-space-3) var(--roo-p-space-4) var(--roo-p-space-3) calc(var(--roo-p-space-2) + var(--roo-tree-text-line) + var(--roo-p-space-1));
    border-top: 1px solid var(--roo-border);
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-settings-layout-nav :deep(.roo-tree-row[aria-selected='true']),
  .roo-settings-layout-nav :deep(.roo-tree-row[aria-selected='true']:hover) {
    background: var(--roo-raised-hover);
  }

  /* Hover on the raised column: the kit's neutral step, 10% in the dark look and 5% in the light look (as the table row and the list row). */
  .roo-settings-layout-nav :deep(.roo-tree-row:hover:not([aria-selected='true'])) {
    background: color-mix(in srgb, var(--roo-text) 10%, transparent);
  }

  .roo-settings-layout-nav :deep(.roo-tree-row:hover:not([aria-selected='true']):not(:root[data-appearance='dark'] *, .dark *)) {
    background: color-mix(in srgb, var(--roo-text) 5%, transparent);
  }

  .roo-settings-layout-select {
    display: none;
    flex: 1 1 auto;
    min-width: 0;
  }

  .roo-settings-layout-pane {
    min-width: 0;
    min-height: 0;
    overflow-y: auto;
    background: var(--roo-bg);
    padding: var(--roo-p-space-6) var(--roo-p-space-6) var(--roo-p-space-8);
    /* A control tabbed to at the pane's edge keeps room for its focus ring. */
    scroll-padding: var(--roo-p-space-2);
  }

  .roo-settings-layout-title {
    margin: 0;
    font-size: var(--roo-p-size-20);
    font-weight: 600;
    line-height: 1.25;
  }

  .roo-settings-layout-subtitle {
    margin: var(--roo-p-space-1) 0 0;
    font-size: var(--roo-p-size-13);
    color: var(--roo-muted);
  }

  .roo-settings-layout-pane > :deep(.roo-settings-group) {
    margin-top: var(--roo-p-space-6);
  }

  .roo-settings-layout-empty {
    margin: 0;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-13);
  }

  /* Narrow: one column. The side becomes a strip with the search and the select side by side, and the tree is not shown. */
  @container roo-settings-layout (max-width: 559px) { /* layout: below this width the nav is a select */
    .roo-settings-layout-frame {
      grid-template-columns: minmax(0, 1fr);
      grid-template-rows: auto minmax(0, 1fr);
    }

    .roo-settings-layout-side {
      flex-direction: row;
      align-items: center;
      gap: var(--roo-p-space-2);
      padding: var(--roo-p-space-2);
      border-inline-end: 0;
      border-bottom: 1px solid var(--roo-border);
    }

    .roo-settings-layout-search {
      flex: 1 1 0;
      min-width: 0;
      padding: 0;
    }

    .roo-settings-layout-nav {
      display: none;
    }

    .roo-settings-layout-select {
      display: block;
      flex: 1 1 0;
    }

    .roo-settings-layout-foot {
      display: none;
    }
  }
}
</style>
