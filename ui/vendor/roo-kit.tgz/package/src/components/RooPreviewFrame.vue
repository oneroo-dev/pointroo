<script setup lang="ts">
// A safe box for HTML the app has already cleaned (mail previews first). The html goes into an iframe with an empty sandbox
// (no scripts, no same origin, no popups, no forms) through srcdoc, and the document carries a strict content security policy
// (see RooPreviewDocument). The part never cleans html itself: that stays in the app. While `blockedImages` is on, images may
// only be data: URLs and a Show images button asks the app to allow more (`show-images`). `disabled` draws no iframe at all,
// only the reason, so nothing is built or loaded. The `header` slot sits above the toolbar (subject, from, to, and the
// HTML / Text / Source switch); the width switch (Desktop, or Mobile at 375px) is built in unless `widthSwitch` is off.
import { computed } from 'vue'
import RooButton from './RooButton.vue'
import RooIcon from './RooIcon.vue'
import RooSegmented from './RooSegmented.vue'
import { PREVIEW_MOBILE_WIDTH, buildPreviewDocument } from './RooPreviewDocument'

const props = withDefaults(
  defineProps<{
    /** Html the app has already cleaned. */
    html: string
    /** The accessible name of the iframe. */
    title: string
    blockedImages?: boolean
    disabled?: boolean
    /** Shown instead of the preview while `disabled`: "Preview is off on production". */
    disabledReason?: string
    /** Draw the Desktop and Mobile switch. */
    widthSwitch?: boolean
  }>(),
  { blockedImages: false, disabled: false, disabledReason: '', widthSwitch: true },
)

const width = defineModel<'desktop' | 'mobile'>('width', { default: 'desktop' })
const emit = defineEmits<{ 'show-images': [] }>()
defineSlots<{ header?: () => unknown; 'disabled-action'?: () => unknown }>()

const widthOptions = [
  { value: 'desktop', label: 'Desktop' },
  { value: 'mobile', label: 'Mobile' },
]
const widthModel = computed({
  get: () => width.value,
  set: (value: string) => {
    width.value = value === 'mobile' ? 'mobile' : 'desktop'
  },
})

const sourceDocument = computed(() => buildPreviewDocument(props.html, props.blockedImages))
const iframeStyle = computed(() => ({ width: width.value === 'mobile' ? `${PREVIEW_MOBILE_WIDTH}px` : '100%' }))
</script>

<template>
  <div class="roo-preview">
    <div v-if="$slots.header" class="roo-preview-header"><slot name="header" /></div>

    <div v-if="disabled" class="roo-preview-disabled" role="status">
      <RooIcon name="lock" :size="20" />
      <span class="roo-preview-reason">{{ disabledReason }}</span>
      <slot name="disabled-action" />
    </div>

    <template v-else>
      <div v-if="widthSwitch || blockedImages" class="roo-preview-toolbar">
        <RooSegmented v-if="widthSwitch" v-model="widthModel" :options="widthOptions" label="Preview width" />
        <RooButton v-if="blockedImages" class="roo-preview-show-images" size="sm" @click="emit('show-images')">
          <template #icon><RooIcon name="eye" :size="16" /></template>
          Show images
        </RooButton>
      </div>
      <div class="roo-preview-stage" :data-width="width">
        <iframe class="roo-preview-iframe" sandbox="" referrerpolicy="no-referrer" :title="title" :srcdoc="sourceDocument" :style="iframeStyle"></iframe>
      </div>
    </template>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-preview {
    display: flex;
    min-height: 0;
    flex-direction: column;
    gap: var(--roo-p-space-2);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-13);
    color: var(--roo-text);
  }

  .roo-preview-header {
    display: flex;
    flex-direction: column;
    gap: var(--roo-p-space-1);
  }

  .roo-preview-toolbar {
    display: flex;
    align-items: center;
    gap: var(--roo-p-space-2);
  }

  .roo-preview-show-images {
    margin-left: auto;
  }

  .roo-preview-stage {
    display: flex;
    min-height: 240px;
    flex: 1;
    justify-content: center;
    overflow: auto;
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-p-radius-card);
    background: var(--roo-raised);
    padding: var(--roo-p-space-2);
  }

  .roo-preview-iframe {
    max-width: 100%;
    min-height: 100%;
    flex-shrink: 0;
    border: 0;
    border-radius: var(--roo-p-radius-small);
    color-scheme: light;
  }

  .roo-preview-disabled {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: var(--roo-p-space-2);
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-p-radius-card);
    background: var(--roo-raised);
    padding: var(--roo-space-section);
    text-align: center;
    color: var(--roo-muted);
  }

  .roo-preview-reason {
    font-size: var(--roo-p-size-15);
    font-weight: 600;
    color: var(--roo-text);
  }
}
</style>
