<script setup lang="ts">
// Wrap a router view (or any swapped page) to fade and rise pages in and fade the old one out: <RooRouteTransition><RouterView /></RooRouteTransition>.
// Vue's Transition with the kit's .roo-route-* classes (src/tokens/motion.css), out-in so two pages are never on screen at once.
// Timed by --roo-base, so reduced motion, data-motion="still" and the desktop surface make the change instant.
import { Transition } from 'vue'
</script>

<template>
  <Transition name="roo-route" mode="out-in">
    <slot />
  </Transition>
</template>
