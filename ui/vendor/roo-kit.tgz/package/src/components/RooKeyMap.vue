<script lang="ts">
/** One designed group of the key map: its heading, and which commands it holds, by region name or by command id. */
export interface KeyMapGroup {
  id: string
  label: string
  region?: string
  ids?: string[]
}
</script>

<script setup lang="ts">
// The `?` sheet: every registered command, grouped by region (or by the app's own `groups`), with a search over labels and
// keys in the header. It reads the same registry as the menus and the Jump, so the words and keys are the ones they show.
// Esc clears a search first and closes the sheet on the next press (RooDialog's keepOpen).
import { computed, ref, watch } from 'vue'
import { formatKeys, spokenKeys, useShortcuts, type ShortcutCommand, type ShortcutRegistry } from '../composables/useShortcuts'
import RooDialog from './RooDialog.vue'
import RooKbd from './RooKbd.vue'

const props = withDefaults(
  defineProps<{
    registry?: ShortcutRegistry | undefined
    title?: string
    /** 'show' lists planned and reserved entries with a word; 'hide' lists wired entries only. */
    planned?: 'show' | 'hide'
    /** An ordered list of groups; commands in none go last under "Other". Without it, groups are the commands' regions. */
    groups?: KeyMapGroup[] | undefined
    /** Two fixed columns (the default, as before) never reflow mid-group; 1 stacks every group. */
    columns?: 1 | 2
  }>(),
  { registry: undefined, title: 'Keyboard shortcuts', planned: 'show', groups: undefined, columns: 2 },
)
const open = defineModel<boolean>('open', { default: false })

const registry = computed(() => props.registry ?? useShortcuts())
const search = ref('')
watch(open, (isOpen) => {
  if (isOpen) search.value = ''
})

function onEscapeKeyDown(_event: KeyboardEvent, control: { keepOpen: () => void }): void {
  if (search.value === '') return
  search.value = ''
  control.keepOpen()
}

function chordsOf(command: ShortcutCommand): string[] {
  return registry.value.chordsFor(command.id)
}

/** The word a row shows for an entry that cannot run yet; a ready entry shows none. */
function statusWord(command: ShortcutCommand): string {
  return command.status === 'unwired' ? 'Planned' : command.status === 'reserved' ? 'Reserved' : ''
}

function rowLabel(command: ShortcutCommand): string {
  return command.shortLabel ?? registry.value.labelFor(command.id)
}

function haystack(command: ShortcutCommand): string {
  const platform = registry.value.platform
  const pieces = [registry.value.labelFor(command.id), command.shortLabel ?? '', statusWord(command), ...chordsOf(command).flatMap((chord) => [chord, formatKeys(chord, platform), spokenKeys(chord, platform)])]
  return pieces.join(' ').toLowerCase()
}

interface Section {
  id: string
  label: string
  commands: ShortcutCommand[]
}

const visibleCommands = computed(() => {
  const needle = search.value.trim().toLowerCase()
  return registry.value.all().filter((command) => (props.planned === 'show' || (command.status ?? 'ready') === 'ready') && (needle === '' || haystack(command).includes(needle)))
})

const sections = computed<Section[]>(() => {
  const commands = visibleCommands.value
  if (props.groups === undefined) {
    const byRegion = new Map<string, ShortcutCommand[]>()
    for (const command of commands) {
      const region = command.region ?? 'General'
      byRegion.set(region, [...(byRegion.get(region) ?? []), command])
    }
    return [...byRegion.entries()].map(([region, grouped]) => ({ id: region, label: region, commands: grouped }))
  }
  const placed = new Set<string>()
  const result: Section[] = props.groups.map((group) => {
    const named = (group.ids ?? []).flatMap((id) => commands.filter((command) => command.id === id && !placed.has(id)))
    for (const command of named) placed.add(command.id)
    const inRegion = group.region === undefined ? [] : commands.filter((command) => !placed.has(command.id) && (command.region ?? 'General') === group.region)
    for (const command of inRegion) placed.add(command.id)
    return { id: group.id, label: group.label, commands: [...named, ...inRegion] }
  })
  result.push({ id: 'other', label: 'Other', commands: commands.filter((command) => !placed.has(command.id)) })
  return result.filter((section) => section.commands.length > 0)
})

/** Whole groups, in order, split once so the first column holds about half the rows. */
const columnSections = computed<Section[][]>(() => {
  if (props.columns === 1) return [sections.value]
  const total = sections.value.reduce((sum, section) => sum + section.commands.length + 1, 0)
  const first: Section[] = []
  let used = 0
  for (const section of sections.value) {
    if (first.length > 0 && used >= total / 2) break
    first.push(section)
    used += section.commands.length + 1
  }
  return [first, sections.value.slice(first.length)]
})
</script>

<template>
  <RooDialog v-model:open="open" :title="title" kind="sheet" size="lg" @escape-key-down="onEscapeKeyDown">
    <template #headerEnd>
      <input v-model="search" class="roo-keymap-search" type="search" autocomplete="off" spellcheck="false" aria-label="Search shortcuts" placeholder="Search shortcuts" />
    </template>
    <div class="roo-keymap">
      <div v-if="sections.length > 0" class="roo-keymap-groups" :data-columns="columns">
        <div v-for="(column, columnIndex) in columnSections" :key="columnIndex" class="roo-keymap-column">
          <section v-for="group in column" :key="group.id" class="roo-keymap-group" :data-group="group.id">
            <h3 class="roo-keymap-heading">{{ group.label }}</h3>
            <div v-for="command in group.commands" :key="command.id" class="roo-keymap-row" :data-status="command.status ?? 'ready'">
              <span class="roo-keymap-label">{{ rowLabel(command) }}</span>
              <span v-if="statusWord(command) !== ''" class="roo-keymap-status">{{ statusWord(command) }}</span>
              <span class="roo-keymap-keys">
                <RooKbd v-for="chord in chordsOf(command)" :key="chord" :keys="chord" :platform="registry.platform" />
              </span>
            </div>
          </section>
        </div>
      </div>
      <p v-else class="roo-keymap-empty">No shortcuts match</p>
    </div>
    <template v-if="$slots.footer" #footer><slot name="footer" /></template>
  </RooDialog>
</template>

<style scoped>
@layer roo-components {
  .roo-keymap {
    display: flex;
    flex-direction: column;
    gap: var(--roo-p-space-3);
  }

  .roo-keymap-search {
    width: 220px;
    height: var(--roo-control-h);
    box-sizing: border-box;
    padding: 0 var(--roo-p-space-2);
    border: 1px solid var(--roo-control-edge);
    border-radius: var(--roo-p-radius-medium);
    background: var(--roo-surface);
    color: var(--roo-text);
    font: inherit;
  }

  .roo-keymap-groups {
    display: grid;
    grid-template-columns: repeat(var(--roo-keymap-columns, 1), minmax(0, 1fr));
    column-gap: var(--roo-p-space-6);
    align-items: start;
  }

  .roo-keymap-groups[data-columns='2'] {
    --roo-keymap-columns: 2;
  }

  .roo-keymap-group {
    margin-bottom: var(--roo-p-space-3);
  }

  .roo-keymap-heading {
    margin: 0 0 var(--roo-p-space-1);
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    font-weight: 600;
    white-space: nowrap;
  }

  .roo-keymap-row {
    display: flex;
    min-height: var(--roo-row-h);
    align-items: center;
    justify-content: space-between;
    gap: var(--roo-p-space-3);
  }

  .roo-keymap-label {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-keymap-row[data-status='unwired'],
  .roo-keymap-row[data-status='reserved'] {
    color: var(--roo-muted);
  }

  .roo-keymap-status {
    flex: none;
    margin-left: auto;
    font-size: var(--roo-p-size-12);
  }

  .roo-keymap-keys {
    display: inline-flex;
    flex: none;
    gap: var(--roo-p-space-1);
  }

  .roo-keymap-empty {
    margin: 0;
    color: var(--roo-muted);
  }
}
</style>
