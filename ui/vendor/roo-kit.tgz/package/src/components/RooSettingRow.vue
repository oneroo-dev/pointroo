<script setup lang="ts">
// One row of a settings screen: the label (and an optional one-line description) on the text side, the control on the other.
// The row is a container, so the layout answers to the width the row really has, not the window: a side panel narrows the
// pane without changing the window. From 480 px of row width the text column is at least 180 px and the control column is up
// to 280 px, end-aligned. Under 480 px the text sits on top and the control goes under it at full width. A control made only
// of buttons is an action, not a field: it keeps its own size and stays at the end of the row, beside the text, at every
// width (Pingroo O-4, 2026-11-18). The control in the default slot takes a max width and shrinks; never give it a fixed
// width. With `stack` the narrow layout is used at every width.
import { computed, useId } from 'vue'

const props = withDefaults(
  defineProps<{
    /** The setting's name. */
    label: string
    /** One quiet line under the label. The `description` slot replaces it. */
    description?: string | undefined
    /** The id of the control in the slot. With it the label is a real <label for>; without it the control wrapper is labelled by the label. */
    for?: string | undefined
    disabled?: boolean
    /** Forces the narrow layout at every width: the text on top, the control under it at full width. Use it for a control that never fits 280 px, such as a path field with buttons, a text area or a wide choice group. */
    stack?: boolean
  }>(),
  { description: undefined, for: undefined, disabled: false, stack: false },
)

const labelId = useId()
const descriptionId = useId()
const hasDescription = computed(() => Boolean(props.description))
</script>

<template>
  <div class="roo-setting-row" :data-disabled="disabled ? '' : undefined" :data-stack="stack ? '' : undefined">
    <div class="roo-setting-row-grid">
      <div class="roo-setting-row-text">
        <label v-if="props.for" :id="labelId" class="roo-setting-row-label" :for="props.for"><slot name="label">{{ label }}</slot></label>
        <span v-else :id="labelId" class="roo-setting-row-label"><slot name="label">{{ label }}</slot></span>
        <p v-if="hasDescription || $slots.description" :id="descriptionId" class="roo-setting-row-description">
          <slot name="description">{{ description }}</slot>
        </p>
      </div>
      <div
        class="roo-setting-row-control"
        :role="props.for ? undefined : 'group'"
        :aria-labelledby="props.for ? undefined : labelId"
        :aria-describedby="hasDescription || $slots.description ? descriptionId : undefined"
      >
        <slot />
      </div>
    </div>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-setting-row {
    container-type: inline-size;
    container-name: roo-setting-row;
    font-family: var(--roo-font-ui);
    color: var(--roo-text);
    padding-block: var(--roo-p-space-3);
  }

  .roo-setting-row-grid {
    display: grid;
    grid-template-columns: minmax(0, 1fr);
    align-items: start;
    gap: var(--roo-p-space-2);
  }

  .roo-setting-row-text {
    min-width: 0;
  }

  .roo-setting-row-label {
    display: block;
    font-size: var(--roo-p-size-13);
    line-height: 18px;
    font-weight: 500;
    overflow-wrap: break-word;
  }

  .roo-setting-row-description {
    margin: var(--roo-p-space-1) 0 0;
    font-size: var(--roo-p-size-12);
    line-height: 16px;
    color: var(--roo-muted);
  }

  .roo-setting-row-control {
    min-width: 0;
    display: flex;
    justify-content: flex-start;
  }

  .roo-setting-row-control > :deep(*) {
    max-width: 100%;
    min-width: 0;
  }

  /* Stacked, a field takes the full width (family rule). A switch or checkbox keeps its own size. */
  .roo-setting-row-control > :deep(:not(.roo-switch):not(.roo-checkbox):not(.roo-button):not(.roo-button-reason):not(.roo-state-mark)) {
    flex: 1 1 auto;
  }

  /* Actions: a control holding only buttons and/or status marks stays beside the text at the end of the row, at every width, never stretched
     or centred under the text. */
  .roo-setting-row:not([data-stack]) .roo-setting-row-grid:has(> .roo-setting-row-control > *):not(:has(> .roo-setting-row-control > :not(.roo-button):not(.roo-button-reason):not(.roo-state-mark))) {
    grid-template-columns: minmax(0, 1fr) auto;
    align-items: center;
    column-gap: var(--roo-p-space-3);
  }

  .roo-setting-row:not([data-stack]) .roo-setting-row-grid:not(:has(> .roo-setting-row-control > :not(.roo-button):not(.roo-button-reason):not(.roo-state-mark))) .roo-setting-row-control {
    justify-content: flex-end;
    gap: var(--roo-p-space-2);
  }

  /* An inline switch (RooSwitch inline) is an action too: it stays beside the text, at the end of the row, at every width. */
  .roo-setting-row:not([data-stack]) .roo-setting-row-grid:has(> .roo-setting-row-control > .roo-switch[data-inline]) {
    grid-template-columns: minmax(0, 1fr) auto;
    align-items: center;
    column-gap: var(--roo-p-space-3);
  }

  .roo-setting-row:not([data-stack]) .roo-setting-row-grid:has(> .roo-setting-row-control > .roo-switch[data-inline]) .roo-setting-row-control {
    justify-content: flex-end;
  }

  .roo-setting-row[data-disabled] .roo-setting-row-text {
    opacity: 0.6;
  }

  /* The two columns only apply when the row is wide and not stacked. A stacked row keeps the single column above. */
  @container roo-setting-row (min-width: 480px) {
    .roo-setting-row:not([data-stack]) .roo-setting-row-grid {
      grid-template-columns: minmax(180px, 1fr) fit-content(280px);
      align-items: center;
      column-gap: var(--roo-p-space-4);
    }

    .roo-setting-row:not([data-stack]) .roo-setting-row-control {
      justify-content: flex-end;
    }

    .roo-setting-row:not([data-stack]) .roo-setting-row-control > :deep(:not(.roo-switch):not(.roo-checkbox)) {
      flex: 0 1 auto;
    }
  }
}
</style>
