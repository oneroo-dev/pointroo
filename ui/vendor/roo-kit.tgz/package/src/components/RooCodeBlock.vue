<script setup lang="ts">
// A read-only block of code with a copy button. No syntax highlighting: a config snippet needs none, and a highlighter weighs
// more than the block. The code is drawn verbatim in the mono font and scrolls sideways rather than wrapping. `label` is a small
// heading ("MCP config"); `language` is shown as plain text beside it. The copy button writes the exact `code` string to the
// clipboard, shows a check for about a second and a half, and says "Copied" to screen readers through a polite live region.
// Where the clipboard is missing or refuses, the code is selected instead, so Ctrl or Cmd + C finishes the job.
import { onBeforeUnmount, ref } from 'vue'
import RooIconButton from './RooIconButton.vue'

const COPIED_MILLISECONDS = 1500

const props = withDefaults(
  defineProps<{
    code: string
    label?: string
    /** Shown as text only, never used to colour the code. */
    language?: string
  }>(),
  { label: '', language: '' },
)

const codeElement = ref<HTMLElement | null>(null)
const copied = ref(false)
let resetTimer: ReturnType<typeof setTimeout> | undefined

function selectCode(): void {
  const element = codeElement.value
  if (!element || typeof window === 'undefined' || !window.getSelection) return
  const range = document.createRange()
  range.selectNodeContents(element)
  const selection = window.getSelection()
  selection?.removeAllRanges()
  selection?.addRange(range)
}

async function copy(): Promise<void> {
  try {
    if (typeof navigator === 'undefined' || !navigator.clipboard?.writeText) throw new Error('clipboard unavailable')
    await navigator.clipboard.writeText(props.code)
  } catch {
    selectCode()
    return
  }
  copied.value = true
  clearTimeout(resetTimer)
  resetTimer = setTimeout(() => {
    copied.value = false
  }, COPIED_MILLISECONDS)
}

onBeforeUnmount(() => clearTimeout(resetTimer))
</script>

<template>
  <figure class="roo-code-block">
    <figcaption class="roo-code-block-header">
      <span v-if="label" class="roo-code-block-label">{{ label }}</span>
      <span v-if="language" class="roo-code-block-language">{{ language }}</span>
      <RooIconButton class="roo-code-block-copy" :icon="copied ? 'check' : 'copy'" :label="copied ? 'Copied' : 'Copy'" size="xs" variant="ghost" data-roo-code-copy :data-copied="copied ? 'true' : undefined" @click="copy" />
    </figcaption>
    <pre class="roo-code-block-pre" tabindex="0"><code ref="codeElement" class="roo-code-block-code">{{ code }}</code></pre>
    <span class="roo-visually-hidden" role="status" aria-live="polite" aria-atomic="true">{{ copied ? 'Copied' : '' }}</span>
  </figure>
</template>

<style>
@layer roo-components {
  .roo-code-block {
    position: relative;
    margin: 0;
    min-width: 0;
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-radius-inner);
    background: var(--roo-raised);
    color: var(--roo-text);
    overflow: hidden;
  }

  .roo-code-block-header {
    display: flex;
    align-items: center;
    gap: var(--roo-p-space-2);
    min-height: var(--roo-icon-button);
    padding-inline: var(--roo-p-space-3) var(--roo-p-space-1);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    line-height: 1;
    color: var(--roo-muted);
  }

  .roo-code-block-label {
    font-weight: 600;
    color: var(--roo-text);
  }

  .roo-code-block-copy {
    margin-inline-start: auto;
  }

  .roo-code-block-pre {
    margin: 0;
    padding: var(--roo-p-space-2) var(--roo-p-space-3) var(--roo-p-space-3);
    overflow-x: auto;
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
    line-height: 1.6;
    white-space: pre;
    tab-size: 2;
  }

  .roo-code-block-pre:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: -2px;
  }

  .roo-code-block-code {
    font: inherit;
  }
}
</style>
