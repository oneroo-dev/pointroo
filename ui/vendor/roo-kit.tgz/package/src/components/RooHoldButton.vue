<script setup lang="ts">
// The button a destructive or prod action is confirmed on. It spreads the gesture's `bindings` (pointer, click, key and
// blur handlers plus aria and data attributes) onto a RooButton and draws the hold fill. Variants: neutral (secondary),
// primary, danger and prod. Each has its own fill and armed look, because a neutral tint is invisible on crimson and an
// inverted button is unreadable on a variant that is already coloured:
//   secondary and primary: a text tint fills; armed inverts to the text colour with the surface colour as label.
//   danger: a crimson text tint fills; armed is solid crimson text colour with the surface colour as label.
//   prod: solid prod crimson with white label; the fill is a lighter tint in light and a deeper one in dark (white on a
//   lighter dark crimson misses 4.5:1); armed turns to the surface with a crimson label and ring.
// While armed (press twice) its own label becomes "Press again to <verb>", so the second press lands in the same place.
// The `icon` slot is the leading icon. To confirm on a trigger that is not a RooHoldButton, bind
// `gesture.bindings.value` onto your own element instead (see useConfirmGesture). The popover is RooConfirmPopover,
// wrapped around this button and fed from the same gesture.
import { computed } from 'vue'
import type { ConfirmGesture } from '../composables/useConfirmGesture'
import RooButton from './RooButton.vue'

const props = withDefaults(
  defineProps<{
    gesture: ConfirmGesture
    label: string
    /** What the button does ("delete", "run"): the armed label reads "Press again to <verb>". */
    verb: string
    variant?: 'primary' | 'secondary' | 'solid-neutral' | 'ghost' | 'danger' | 'prod'
    size?: 'sm' | 'md' | 'lg'
    disabled?: boolean
  }>(),
  { variant: 'secondary', size: 'md', disabled: false },
)

const shownLabel = computed(() => (props.gesture.armed.value ? `Press again to ${props.verb}` : props.label))
const fillStyle = computed(() => ({ transform: `scaleX(${props.gesture.progress.value})` }))
</script>

<template>
  <RooButton class="roo-hold-button" :variant="variant" :size="size" :disabled="disabled" v-bind="gesture.bindings.value">
    <template v-if="$slots.icon" #icon><slot name="icon" /></template>
    <span class="roo-hold-fill" :style="fillStyle" aria-hidden="true"></span>
    <span class="roo-hold-label">{{ shownLabel }}</span>
  </RooButton>
</template>

<style>
@layer roo-components {
  .roo-hold-button {
    overflow: hidden;
    isolation: isolate;
    touch-action: none;
  }

  /* Neutral tint: the confirm is not crimson, because only prod is. The solid-neutral variant takes this same tint over its raised-on-raised fill, and the armed look below (inverted text fill) as the secondary does. */
  .roo-hold-fill {
    position: absolute;
    inset: 0;
    z-index: -1;
    background: color-mix(in srgb, var(--roo-text) 12%, transparent);
    transform-origin: left center;
    transform: scaleX(0);
    transition: transform 150ms var(--roo-exit);
  }

  .roo-hold-button[data-variant='primary'] .roo-hold-fill {
    background: color-mix(in srgb, var(--roo-p-white) 30%, transparent);
  }

  .roo-hold-button[data-variant='danger'] .roo-hold-fill {
    background: color-mix(in srgb, var(--roo-danger-text) 14%, transparent);
  }

  /* Lighter than the crimson in light; in dark white on a lighter crimson misses 4.5:1, so the fill goes deeper instead. */
  .roo-hold-button[data-variant='prod'] .roo-hold-fill {
    background: color-mix(in srgb, var(--roo-p-white) 18%, transparent);
  }

  :root[data-appearance='dark'] .roo-hold-button[data-variant='prod'] .roo-hold-fill,
  .dark .roo-hold-button[data-variant='prod'] .roo-hold-fill {
    background: color-mix(in srgb, var(--roo-p-graphite) 25%, transparent);
  }

  .roo-hold-button[data-holding='true'] .roo-hold-fill {
    transition: none;
  }

  /* Reduced motion skips the fill animation, not the hold: the popover line still turns to "Keep holding to ...". */
  .roo-force-reduced .roo-hold-fill,
  [data-motion='still'] .roo-hold-fill {
    display: none;
  }

  @media (prefers-reduced-motion: reduce) {
    .roo-hold-fill {
      display: none;
    }
  }

  /* RooButton's own variant rules are scoped (one more attribute) and its hover rules add a pseudo-class, so the armed look
     repeats the variant attribute and :not(:disabled) to outrank both, whatever order the layers load in. */
  .roo-hold-button.roo-button[data-variant][data-armed='true']:not(:disabled) {
    border-color: var(--roo-text);
    background: var(--roo-text);
    color: var(--roo-surface);
    filter: none;
  }

  .roo-hold-button.roo-button[data-variant='danger'][data-armed='true']:not(:disabled) {
    border-color: var(--roo-danger-text);
    background: var(--roo-danger-text);
    color: var(--roo-surface);
  }

  .roo-hold-button.roo-button[data-variant='prod'][data-armed='true']:not(:disabled) {
    border-color: var(--roo-prod-text);
    background: var(--roo-surface);
    color: var(--roo-prod-text);
    box-shadow: inset 0 0 0 1px var(--roo-prod-text);
  }
}
</style>
