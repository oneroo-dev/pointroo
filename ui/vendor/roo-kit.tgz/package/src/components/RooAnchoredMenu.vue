<script setup lang="ts">
// A RooMenu that opens at a point, for the right-click menus of a rail item or a tab. It is internal to the navigation
// parts; K4's RooContextMenu replaces it. TODO(kit2-K4): swap this for RooContextMenu when it lands.
import RooMenu from './RooMenu.vue'

defineProps<{ x: number; y: number }>()
const open = defineModel<boolean>('open', { default: false })
</script>

<template>
  <RooMenu v-model:open="open">
    <template #trigger>
      <span class="roo-anchored-menu-anchor" aria-hidden="true" :style="{ left: `${x}px`, top: `${y}px` }" />
    </template>
    <slot />
  </RooMenu>
</template>

<style scoped>
@layer roo-components {
  .roo-anchored-menu-anchor {
    position: fixed;
    width: 0;
    pointer-events: none;
  }
}
</style>
