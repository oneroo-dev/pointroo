<script lang="ts">
export type TrayTone = 'default' | 'warn' | 'danger'

export interface RooTrayItem {
  id: string
  text: string
  tone?: TrayTone
  /** Higher shows first. Items of equal priority show in the order they were queued. */
  priority?: number
  /** The one action ("Retry"). */
  actionLabel?: string
  /** Shown only with an action; a way out that is not the action. */
  cancelLabel?: string
}

/** The item the tray shows: the highest priority, and the earliest queued among equals. */
export function pickTrayItem(items: readonly RooTrayItem[]): RooTrayItem | undefined {
  let best: RooTrayItem | undefined
  for (const item of items) {
    if (best === undefined || (item.priority ?? 0) > (best.priority ?? 0)) best = item
  }
  return best
}

/** How many items wait behind the one shown. */
export function trayWaiting(items: readonly RooTrayItem[]): number {
  return Math.max(0, items.length - 1)
}
</script>

<script setup lang="ts">
// A one-line strip above the Ledge for something the window wants to say that is not a toast: a job's progress, a
// recoverable problem. It holds a queue and shows one item at a time, the highest priority first. A new item
// Settles up; the item that leaves Clears down. The words are spoken through a polite live region that is always in
// the page (an empty region that fills is read; a region that arrives full is not). The visible text is hidden from
// assistive technology so it is not read twice. The action and cancel are real buttons.
import { computed, ref, watch } from 'vue'

const props = withDefaults(defineProps<{ items: RooTrayItem[]; label?: string }>(), { label: 'Notices' })
const emit = defineEmits<{ action: [id: string]; cancel: [id: string] }>()

const current = computed(() => pickTrayItem(props.items))
const waiting = computed(() => trayWaiting(props.items))
const spoken = ref('')

watch(
  current,
  (item) => {
    spoken.value = item?.text ?? ''
  },
  { immediate: true },
)
</script>

<template>
  <div class="roo-tray" :data-empty="current === undefined" role="region" :aria-label="label">
    <span class="roo-visually-hidden" role="status" aria-live="polite" aria-atomic="true">{{ spoken }}</span>
    <Transition name="roo-tray" mode="out-in">
      <div v-if="current" :key="current.id" class="roo-tray-line" :data-tone="current.tone ?? 'default'">
        <span class="roo-tray-text" aria-hidden="true">{{ current.text }}</span>
        <span v-if="waiting > 0" class="roo-tray-waiting">{{ waiting }} more</span>
        <button v-if="current.actionLabel" type="button" class="roo-tray-action" @click="emit('action', current.id)">
          {{ current.actionLabel }}
        </button>
        <button v-if="current.actionLabel && current.cancelLabel" type="button" class="roo-tray-cancel" @click="emit('cancel', current.id)">
          {{ current.cancelLabel }}
        </button>
      </div>
    </Transition>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-tray {
    flex: none;
  }

  .roo-tray[data-empty='true'] {
    height: 0;
  }

  .roo-tray-line {
    display: flex;
    height: var(--roo-tray-h);
    box-sizing: border-box;
    align-items: center;
    gap: 8px;
    border-top: 1px solid var(--roo-border);
    background: var(--roo-surface);
    padding-inline: 12px;
    color: var(--roo-text);
    font-size: var(--roo-p-size-12);
    white-space: nowrap;
  }

  .roo-tray-text {
    min-width: 0;
    flex: 1 1 auto;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .roo-tray-line[data-tone='warn'] .roo-tray-text {
    color: var(--roo-warn);
  }

  .roo-tray-line[data-tone='danger'] .roo-tray-text {
    color: var(--roo-danger-text);
  }

  .roo-tray-waiting {
    flex: none;
    color: var(--roo-muted);
  }

  .roo-tray-action,
  .roo-tray-cancel {
    height: 20px;
    flex: none;
    border: 1px solid var(--roo-control-edge);
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-surface);
    padding-inline: 8px;
    color: var(--roo-text);
    font: inherit;
    white-space: nowrap;
    cursor: default;
  }

  .roo-tray-cancel {
    border-color: transparent;
    color: var(--roo-muted);
  }

  .roo-tray-action:hover,
  .roo-tray-cancel:hover {
    background: var(--roo-raised);
  }

  .roo-tray-enter-active {
    animation: roo-settle var(--roo-base) var(--roo-ease) both;
  }

  .roo-tray-leave-active {
    animation: roo-clear var(--roo-fast) var(--roo-exit) both;
  }
}
</style>
