<script setup lang="ts">
// A square tile for an app's mark. The artwork comes from the slot: the kit ships none (the kangaroo is the apps' own).
withDefaults(
  defineProps<{
    size?: 16 | 24 | 48 | 64
    /** The app's name. Without it the tile is decoration and hidden from assistive tech. */
    name?: string
  }>(),
  { size: 24, name: '' },
)
</script>

<template>
  <span
    class="roo-app-tile"
    :data-size="size"
    :role="name ? 'img' : undefined"
    :aria-label="name || undefined"
    :aria-hidden="name ? undefined : 'true'"
  >
    <slot />
  </span>
</template>

<style scoped>
@layer roo-components {
  .roo-app-tile {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    flex: none;
    width: 24px;
    height: 24px;
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-x-tile);
    color: var(--roo-p-white);
    overflow: hidden;
  }

  .roo-app-tile[data-size='16'] {
    width: 16px;
    height: 16px;
  }

  .roo-app-tile[data-size='48'] {
    width: 48px;
    height: 48px;
  }

  .roo-app-tile[data-size='64'] {
    width: 64px;
    height: 64px;
  }

  .roo-app-tile > :slotted(svg) {
    width: 72%;
    height: 72%;
  }

  /* Graphite on a dark menu is 1.2:1, so dark gets a one pixel ring. Inset, so it takes no room and is a full ring. */
  :root[data-appearance='dark'] .roo-app-tile,
  .dark .roo-app-tile {
    box-shadow: inset 0 0 0 1px var(--roo-control-edge);
  }
}
</style>
