<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import { buildOpenInRows, needsConfirm, type LinkBuilder, type OpenInRow, type OpenInTarget } from '../composables/openIn'
import { useRooHost } from '../composables/rooHost'
import RooEnvDot from './RooEnvDot.vue'

// "Open in" rows for one thing. Each row is built with the shared link builder (@roo/links buildLink, passed in so the MIT
// kit carries no dependency on it); a draft that will not build has no row. In the suite a row asks the host to show the
// app, or split it with Cmd Enter. On its own the app gets `open-link` and does the opening. A prod or unclassified target
// (or one marked alwaysConfirm) waits for the app's own confirm first, on both paths; no confirm given means no.
const props = defineProps<{
  targets: OpenInTarget[]
  buildLink: LinkBuilder
  /** The app's confirm for a prod or unclassified target. Resolve true to go on. */
  confirm?: (row: OpenInRow) => boolean | Promise<boolean>
}>()

const emit = defineEmits<{ 'open-link': [payload: { app: string; url: string }] }>()

const host = useRooHost()
const installed = ref<Record<string, boolean>>({})

async function checkInstalled(): Promise<void> {
  const answers: Record<string, boolean> = {}
  await Promise.all(
    props.targets.map(async (target) => {
      try {
        answers[target.app] = Boolean(await host.isInstalled(target.app))
      } catch {
        answers[target.app] = false
      }
    }),
  )
  installed.value = answers
}

onMounted(checkInstalled)
watch(() => props.targets.map((target) => target.app).join(','), checkInstalled)

const rows = computed(() => buildOpenInRows(props.targets, props.buildLink, (app) => installed.value[app]))

async function activate(row: OpenInRow, split: boolean): Promise<void> {
  if (row.disabled) return
  if (row.kind === 'website') {
    if (row.notInstalledUrl) await host.openExternal(row.notInstalledUrl)
    return
  }
  if (needsConfirm(row)) {
    const allowed = props.confirm ? await props.confirm(row) : false
    if (!allowed) return
  }
  if (host.kind === 'suite') {
    await (split ? host.split(row.app, row.url) : host.show(row.app, row.url))
    return
  }
  emit('open-link', { app: row.app, url: row.url })
}

function onKeydown(event: KeyboardEvent, row: OpenInRow): void {
  if (event.key !== 'Enter' || !(event.metaKey || event.ctrlKey)) return
  event.preventDefault()
  void activate(row, true)
}
</script>

<template>
  <ul v-if="rows.length" class="roo-open-in">
    <li v-for="row in rows" :key="row.id">
      <button
        type="button"
        class="roo-open-in-row"
        :disabled="row.disabled"
        :data-kind="row.kind"
        :data-env="row.environment"
        @click="activate(row, false)"
        @keydown="onKeydown($event, row)"
      >
        <RooEnvDot v-if="row.environment === 'prod' || row.environment === 'unclassified'" :environment="row.environment" />
        <span class="roo-open-in-label">{{ row.label }}</span>
        <span v-if="row.meta" class="roo-open-in-meta">{{ row.meta }}</span>
        <span v-if="row.kind === 'website' && !row.disabled" class="roo-open-in-meta">opens in your browser</span>
      </button>
    </li>
  </ul>
</template>

<style scoped>
@layer roo-components {
  .roo-open-in {
    display: flex;
    flex-direction: column;
    margin: 0;
    padding: 0;
    list-style: none;
  }

  .roo-open-in-row {
    display: flex;
    align-items: center;
    gap: var(--roo-p-space-2);
    width: 100%;
    min-height: var(--roo-menu-row-h, 32px);
    padding: 0 var(--roo-p-space-3);
    border: 0;
    border-radius: var(--roo-p-radius-small);
    background: transparent;
    color: var(--roo-text);
    font: inherit;
    font-size: var(--roo-p-size-13);
    text-align: start;
    white-space: nowrap;
    cursor: default;
  }

  .roo-open-in-row:hover:not(:disabled) {
    background: var(--roo-select);
  }

  .roo-open-in-row:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: -2px;
  }

  .roo-open-in-row:disabled {
    color: var(--roo-faint);
    opacity: 1;
  }

  .roo-open-in-row:disabled :is(svg, .roo-open-in-meta) {
    color: var(--roo-faint);
  }

  .roo-open-in-label {
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .roo-open-in-meta {
    flex: none;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }
}
</style>
