<script setup lang="ts">
// The app's mark in the title bar (family rule, Raja 2026-11-17): the glyph from the app's icon. Order (Raja 2026-11-19):
// traffic lights, then the app mark, then the sidebar toggle, then the pill. Put it first in the Bar's `leading` slot, before the toggle.
//
// Look (Raja 2026-11-19, option B, bare glyph): just the glyph. No box, no fill, no border, no hover or pressed state, not
// focusable, default cursor, so it reads as a logo and not as a button. It is not a button and carries no name. The box
// keeps the bar control height (--roo-bar-control-h, 32px) so the glyph stays on the bar's centre line, with 4px of space on
// each side. The glyph is 26px and sits 1px below the middle (the size from the earlier tile; the B mockup only tried 16 to
// 24px and no size was picked, so this is still open).
//
// A slot only, like RooMark: the kit ships no roo artwork (the kangaroo is the apps' own, and the MIT kit never holds it).
// The app puts its own svg element in the default slot; the box sizes any child svg to 26x26, 1px low. The app handles light and dark
// itself (its own two groups, or a swap); the extracted art is in docs/handover/records/icons/marks/<app>-mark-<theme>.svg.
//
// Vertical centre: the Bar is --roo-bar-h (44px) tall and every slot centres its children on the Bar's middle, so the
// mark, the 32px controls, the pill and its tile, the tabs and the keycaps share one centre line. The macOS traffic lights
// are 12px, so for them to share it too the app sets Electron's trafficLightPosition y to (barHeight - 12) / 2 = 16
// at the 44px bar (x is the app's own choice; the Bar's --roo-traffic-inset of 92px starts content 20px after the green light, given lights at x 20).
</script>

<template>
  <span v-if="$slots.default" class="roo-app-mark" aria-hidden="true"><slot /></span>
</template>

<style scoped>
@layer roo-components {
  .roo-app-mark {
    display: grid;
    place-items: center;
    flex: none;
    height: var(--roo-bar-control-h);
    padding: 0 4px;
    cursor: default;
  }

  .roo-app-mark > :slotted(svg) {
    display: block;
    /* A square icon size, not a layout height: the width sets it and the aspect ratio keeps it square, so the 4px grid lint (heights and spacing) does not apply. */
    width: 26px;
    aspect-ratio: 1;
    /* An app svg carries width="20" height="20"; author CSS beats that attribute, so height auto lets the aspect ratio keep it square. */
    height: auto;
    transform: translateY(1px);
  }
}
</style>
