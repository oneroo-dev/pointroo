<script setup lang="ts">
import { computed } from 'vue'
import { useRooHost } from '../composables/rooHost'

// A web address that leaves the app. It opens through the host, never by navigating the window, and says so in words.
// Anything that is not http or https is shown as plain text and never opened.
const props = defineProps<{ url: string }>()

const host = useRooHost()

const openable = computed(() => /^https?:\/\//i.test(props.url))

function open(event: MouseEvent): void {
  event.preventDefault()
  void host.openExternal(props.url)
}
</script>

<template>
  <a v-if="openable" class="roo-external-link" :href="url" @click="open">
    <slot />
    <span class="roo-visually-hidden">, opens in your browser</span>
  </a>
  <span v-else class="roo-external-link-plain"><slot /></span>
</template>

<style scoped>
@layer roo-components {
  .roo-external-link {
    color: var(--roo-accent-text);
    text-decoration: underline;
    text-underline-offset: 2px;
  }

  .roo-external-link:hover {
    text-decoration-thickness: 2px;
  }

  .roo-external-link:active {
    color: var(--roo-text);
  }

  .roo-external-link:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
    border-radius: var(--roo-p-radius-small);
  }
}
</style>
