<script setup lang="ts">
// Faint meta text: a time, a count or a size beside a title. Tabular figures so a column of times lines up, the faint text
// colour and the density's small type size (--roo-ui-size-small: 11 comfortable, 10 compact). `as="time"` renders a <time>.
withDefaults(defineProps<{ as?: 'span' | 'time' }>(), { as: 'span' })
</script>

<template>
  <component :is="as" class="roo-meta"><slot /></component>
</template>

<style scoped>
@layer roo-components {
  .roo-meta {
    color: var(--roo-faint);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
    white-space: nowrap;
  }
}
</style>
