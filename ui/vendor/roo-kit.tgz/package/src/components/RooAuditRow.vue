<script setup lang="ts">
// One row of an audit log: who (avatar or initials and a name), what they did in a sentence, an optional reason, when, and an
// optional marker such as "Support" for an action taken by staff. It is a RooListRow (so the density row heights, the hover fill
// and the inset come from there) with the actor's avatar in the tile, the sentence on the title line, the marker and the time at
// its end, and the reason below. The sentence wraps, never truncates: an audit line that hides half its words is not a record.
// The reason shows two lines, then "Show more" (only when there is more); the button is a kit ghost button, so it gets the
// touch hit area too. The time reads as a relative figure ("12 min ago") and the exact local time shows in a tooltip, which
// needs one RooTooltipProvider above it. Relative figures re-render by themselves (formatRelative says when each can change).
// Give the list `role="list"` and each row `role="listitem"`: attributes pass to the row.
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useId } from 'reka-ui'
import { formatRelative } from '../format'
import RooAvatar from './RooAvatar.vue'
import RooButton from './RooButton.vue'
import RooChip from './RooChip.vue'
import RooListRow from './RooListRow.vue'
import RooMeta from './RooMeta.vue'
import RooTooltip from './RooTooltip.vue'

const props = withDefaults(
  defineProps<{
    /** The person who did it. */
    actor: string
    /** Their picture; without one the initials show. */
    actorSrc?: string | undefined
    /** What they did, as a sentence tail: "viewed the issue list". */
    action: string
    /** Why, in their words (a ticket sentence). Two lines, then "Show more". */
    reason?: string
    /** When it happened: a Date, milliseconds, or an ISO string. */
    time: Date | number | string
    /** A short marker after the sentence, such as "Support" for an action by staff. */
    marker?: string
    /** For a test or a frame: the moment "now" is measured from. Defaults to the clock. */
    now?: number | undefined
  }>(),
  { actorSrc: undefined, reason: '', marker: '', now: undefined },
)

const timeMs = computed(() => (props.time instanceof Date ? props.time.getTime() : typeof props.time === 'number' ? props.time : Date.parse(props.time)))
const clock = ref(props.now ?? Date.now())
const formatted = computed(() => formatRelative(timeMs.value, clock.value))

let refreshTimer: ReturnType<typeof setTimeout> | undefined
function scheduleRefresh(): void {
  clearTimeout(refreshTimer)
  if (props.now !== undefined || !Number.isFinite(formatted.value.nextChangeMs)) return
  refreshTimer = setTimeout(() => {
    clock.value = Date.now()
    scheduleRefresh()
  }, formatted.value.nextChangeMs)
}

const reasonId = useId(undefined, 'roo-audit-reason')
const reasonElement = ref<HTMLElement | null>(null)
const expanded = ref(false)
const expandable = ref(false)
let resizeObserver: ResizeObserver | undefined

/** The reason is clipped at two lines when its content is taller than the box it sits in. Read while collapsed only. */
function measure(): void {
  const element = reasonElement.value
  if (!element || expanded.value) return
  expandable.value = element.scrollHeight > element.clientHeight + 1
}

onMounted(() => {
  scheduleRefresh()
  measure()
  if (typeof ResizeObserver !== 'undefined' && reasonElement.value) {
    resizeObserver = new ResizeObserver(measure)
    resizeObserver.observe(reasonElement.value)
  }
})
onBeforeUnmount(() => {
  clearTimeout(refreshTimer)
  resizeObserver?.disconnect()
})
watch(
  () => props.reason,
  async () => {
    expanded.value = false
    await nextTick()
    measure()
  },
)
watch(() => props.now, (value) => {
  if (value !== undefined) clock.value = value
})

const toggleLabel = computed(() => (expanded.value ? 'Show less' : 'Show more'))
</script>

<template>
  <RooListRow class="roo-audit-row" :data-expanded="expanded ? 'true' : undefined">
    <template #tile><RooAvatar :name="actor" :src="actorSrc" :size="24" /></template>
    <template #title>
      <strong class="roo-audit-actor">{{ actor }}</strong>
      <span class="roo-audit-action">{{ ' ' }}{{ action }}</span>
    </template>
    <template #title-trailing>
      <RooChip v-if="marker" class="roo-audit-marker" :label="marker" tone="accent" size="small" />
      <RooTooltip :text="formatted.exact" side="top" align="end">
        <RooMeta as="time" class="roo-audit-time" :datetime="Number.isFinite(timeMs) ? new Date(timeMs).toISOString() : undefined">{{ formatted.text }}</RooMeta>
      </RooTooltip>
    </template>
    <template v-if="reason" #subtitle>
      <span :id="reasonId" ref="reasonElement" class="roo-audit-reason" :data-expanded="expanded ? 'true' : undefined">
        <span class="roo-audit-reason-label">Reason:</span>{{ ' ' }}<span class="roo-audit-reason-text">{{ reason }}</span>
      </span>
      <RooButton v-if="expandable || expanded" class="roo-audit-toggle" variant="ghost" size="ledge" flush :aria-expanded="expanded" :aria-controls="reasonId" @click="expanded = !expanded">
        {{ toggleLabel }}
      </RooButton>
    </template>
  </RooListRow>
</template>

<style scoped>
@layer roo-components {
  /* A log is read in long runs: a little more air than a menu row, and the avatar sits on the first line, not the middle. */
  .roo-audit-row {
    align-items: flex-start;
    min-height: 0;
    padding-block: var(--roo-p-space-3);
  }

  .roo-audit-row :deep(.roo-list-row-main) {
    align-items: flex-start;
  }

  /* The tile is exactly the first text line tall (13 px at 1.4) and centres the 24 px avatar on it, so the avatar and the actor's
     name share one centre line with no padding to tune. The avatar overflows the tile equally above and below, into the row's own padding. */
  .roo-audit-row :deep(.roo-list-row-tile) {
    height: calc(var(--roo-ui-size) * 1.4);
    align-self: flex-start;
    overflow: visible;
  }

  /* The sentence wraps whole; the time and marker stay at the end of its first line. */
  .roo-audit-row :deep(.roo-list-row-title) {
    align-items: flex-start;
    overflow: visible;
    white-space: normal;
  }

  .roo-audit-row :deep(.roo-list-row-title-text) {
    flex: 1 1 0;
    overflow: visible;
    text-overflow: clip;
    white-space: normal;
    align-self: auto;
    line-height: 1.4;
    overflow-wrap: anywhere;
  }

  .roo-audit-row :deep(.roo-list-row-title-trailing) {
    align-self: flex-start;
    min-height: 1.4em;
    margin-inline-start: var(--roo-p-space-3);
  }

  .roo-audit-actor {
    font-weight: var(--roo-p-weight-semibold);
  }

  .roo-audit-action {
    color: var(--roo-text);
  }

  .roo-audit-time {
    cursor: default;
  }

  .roo-audit-row :deep(.roo-list-row-subtitle) {
    overflow: visible;
    white-space: normal;
    margin-top: 2px;
  }

  .roo-audit-reason {
    display: -webkit-box;
    overflow: hidden;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    line-height: 1.4;
    overflow-wrap: anywhere;
    white-space: normal;
  }

  .roo-audit-reason[data-expanded='true'] {
    display: block;
    -webkit-line-clamp: unset;
  }

  .roo-audit-reason-label {
    color: var(--roo-faint);
    font-weight: var(--roo-p-weight-medium);
  }

  .roo-audit-toggle {
    display: flex;
    margin-top: 2px;
  }
}
</style>
