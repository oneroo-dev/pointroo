<script setup lang="ts">
// The "How it works" panel a RooPageIntro opens: 400 px from the right below the title bar on a desktop width (non-modal, so
// the page stays usable, and it closes on Close and Esc only), a bottom sheet over a scrim on a phone. Contents in a fixed
// order: what it is (two sentences), an example with real numbers, when you would use it, "Read the full guide". Focus moves
// to Close on open and back to the link that opened it on close. Give it the same id as RooPageIntro's `howControls`.
import { useIsPhone } from '../composables/useIsPhone'
import RooIcon from './RooIcon.vue'
import RooSheet from './RooSheet.vue'

defineOptions({ inheritAttrs: false })

/** One row of the example: a label and a value, with the number or word set in the mono face when `mono` is true. */
export interface RooHowExampleRow {
  term: string
  value: string
  mono?: boolean
}

withDefaults(
  defineProps<{
    /** "How reliability targets work". */
    title: string
    /** "Also called SLOs, short for service level objectives." One muted line under the title. */
    aka?: string | undefined
    /** The example as label and value rows. The `example` slot replaces it. */
    example?: readonly RooHowExampleRow[] | undefined
    guideHref?: string | undefined
    guideLabel?: string
    whatLabel?: string
    exampleLabel?: string
    whenLabel?: string
  }>(),
  {
    aka: undefined,
    example: undefined,
    guideHref: undefined,
    guideLabel: 'Read the full guide',
    whatLabel: 'What it is',
    exampleLabel: 'An example',
    whenLabel: 'When you would use it',
  },
)

const open = defineModel<boolean>('open', { default: false })
const isPhone = useIsPhone()
</script>

<template>
  <RooSheet v-bind="$attrs" v-model:open="open" :title="title" side="auto" :modal="isPhone" esc-hint class="roo-how">
    <p v-if="aka" class="roo-how-aka">{{ aka }}</p>
    <template v-if="$slots.what">
      <p class="roo-how-label">{{ whatLabel }}</p>
      <div class="roo-how-text"><slot name="what" /></div>
    </template>
    <template v-if="example || $slots.example">
      <p class="roo-how-label">{{ exampleLabel }}</p>
      <slot name="example">
        <dl class="roo-how-example">
          <template v-for="row in example" :key="row.term">
            <dt>{{ row.term }}</dt>
            <dd :class="{ 'roo-how-mono': row.mono }">{{ row.value }}</dd>
          </template>
        </dl>
      </slot>
    </template>
    <template v-if="$slots.when">
      <p class="roo-how-label">{{ whenLabel }}</p>
      <div class="roo-how-text"><slot name="when" /></div>
    </template>
    <a v-if="guideHref" class="roo-how-guide" :href="guideHref" target="_blank" rel="noopener">
      {{ guideLabel }}<RooIcon name="new-tab" :size="14" />
    </a>
  </RooSheet>
</template>

<style scoped>
@layer roo-components {
  .roo-how-aka {
    margin: 0 0 var(--roo-p-space-1);
    font-size: var(--roo-p-size-12);
    line-height: 16px;
    color: var(--roo-muted);
  }

  .roo-how-label {
    margin: var(--roo-p-space-6) 0 var(--roo-p-space-2);
    font-size: var(--roo-p-size-12);
    line-height: 16px;
    font-weight: 600;
    color: var(--roo-muted);
  }

  .roo-how-text {
    font-size: var(--roo-p-size-13);
    line-height: 20px;
  }

  .roo-how-text :deep(p) {
    margin: 0 0 var(--roo-p-space-2);
  }

  .roo-how-example {
    display: grid;
    grid-template-columns: 112px minmax(0, 1fr);
    gap: var(--roo-p-space-1) var(--roo-p-space-3);
    margin: 0 0 var(--roo-p-space-3);
    font-size: var(--roo-p-size-13);
    line-height: 18px;
  }

  .roo-how-example dt {
    color: var(--roo-muted);
  }

  .roo-how-example dd {
    margin: 0;
  }

  .roo-how-mono {
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
  }

  .roo-how-guide {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-1);
    margin-top: var(--roo-p-space-4);
    border-radius: var(--roo-p-radius-small);
    font-weight: 500;
    color: var(--roo-accent-text);
    text-decoration: none;
  }

  .roo-how-guide:hover {
    text-decoration: underline;
    text-underline-offset: 3px;
  }
}
</style>
