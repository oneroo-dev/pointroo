<script setup lang="ts">
// A tree of RooTreeRow rows (and RooSidebarGroup groups) outside a sidebar: role=tree, one Tab stop (the selected row, else the
// first), Up, Down, Home and End move it, and each row answers Left and Right itself. It insets its rows --roo-tree-inset from its own
// edges, and each row pads up to the shared text line (--roo-tree-text-line, 12px), so a row's text starts on one x. RooSidebar renders this same tree.
// `label` names the tree for screen readers; leave it out when a landmark around the tree already carries the name.
// `placement="sidebar"` stands the rows on the sidebar field's edges (no inset) with the chevron, icon and text on the group head's
// columns (see --roo-tree-sidebar-inset and --roo-sidebar-chevron-gap); put it on the tree, and on a group that is used without a tree.
// `readonly` makes a read-only tree: rows show but do not select, reorder or offer actions.
import { computed, onMounted, onUpdated, provide, ref } from 'vue'
import { useRovingTabindex } from '../composables/useRovingTabindex'

const props = withDefaults(defineProps<{ label?: string | undefined; multiselectable?: boolean; readonly?: boolean; placement?: 'tree' | 'sidebar' }>(), { label: undefined, multiselectable: false, readonly: false, placement: 'tree' })

provide('roo-sidebar-readonly', computed(() => props.readonly))

const tree = ref<HTMLElement | null>(null)
const roving = useRovingTabindex(tree, { itemSelector: '[data-roving-item]', orientation: 'vertical' })
onMounted(roving.sync)
onUpdated(roving.sync)
</script>

<template>
  <div
    ref="tree"
    class="roo-tree"
    role="tree"
    :aria-label="label"
    :aria-multiselectable="multiselectable ? 'true' : undefined"
    :aria-readonly="readonly ? 'true' : undefined"
    :data-placement="placement === 'sidebar' ? 'sidebar' : undefined"
    @keydown="roving.onKeydown"
    @focusin="roving.onFocusin"
  >
    <slot />
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-tree {
    box-sizing: border-box;
    padding-inline: var(--roo-tree-inset);
  }

  .roo-tree[data-placement='sidebar'] {
    --roo-tree-inset: var(--roo-tree-sidebar-inset);
    --roo-tree-chevron-gap: var(--roo-sidebar-chevron-gap);
    --roo-tree-indent: calc(var(--roo-tree-chevron) + var(--roo-sidebar-chevron-gap));
  }
}
</style>
