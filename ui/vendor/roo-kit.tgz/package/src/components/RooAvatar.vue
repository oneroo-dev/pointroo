<script setup lang="ts">
// The signed-in person in the title bar: their picture, or their initials when there is none or it fails to load.
// Round, no hover change; it is not a button (the app wraps it in one when it opens a menu).
import { computed, ref, watch } from 'vue'

const props = withDefaults(
  defineProps<{
    name: string
    src?: string | undefined
    /** Pixels. Default is the title bar control height. */
    size?: number
    /** Show one initial instead of two, for a small badge. */
    single?: boolean
  }>(),
  { src: undefined, size: 32, single: false },
)

const failed = ref(false)
watch(
  () => props.src,
  () => {
    failed.value = false
  },
)

const showImage = computed(() => Boolean(props.src) && !failed.value)

const initials = computed(() => {
  const words = props.name.trim().split(/\s+/).filter((word) => word !== '')
  if (words.length === 0) return ''
  const first = Array.from(words[0] ?? '')[0] ?? ''
  const last = !props.single && words.length > 1 ? (Array.from(words[words.length - 1] ?? '')[0] ?? '') : ''
  return `${first}${last}`.toUpperCase()
})

const dimensions = computed(() => ({ '--roo-avatar-size': `${props.size}px` }))
</script>

<template>
  <span class="roo-avatar" role="img" :aria-label="name" :style="dimensions">
    <img v-if="showImage" class="roo-avatar-image" :src="src" alt="" draggable="false" @error="failed = true" />
    <span v-else class="roo-avatar-initials" aria-hidden="true">{{ initials }}</span>
  </span>
</template>

<style scoped>
@layer roo-components {
  .roo-avatar {
    display: inline-grid;
    flex: none;
    place-items: center;
    box-sizing: border-box;
    width: var(--roo-avatar-size, var(--roo-bar-control-h));
    height: var(--roo-avatar-size, var(--roo-bar-control-h));
    overflow: hidden;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-raised);
    color: var(--roo-text);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    font-weight: 600;
    line-height: 1;
    user-select: none;
  }

  .roo-avatar-image {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
}
</style>
