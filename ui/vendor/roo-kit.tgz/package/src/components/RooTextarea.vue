<script setup lang="ts">
import { computed, nextTick, onMounted, ref, watch } from 'vue'
import { useId } from 'reka-ui'

const model = defineModel<string>()

const props = withDefaults(
  defineProps<{
    label?: string
    hint?: string
    error?: string
    placeholder?: string
    /** The height in lines. With `maxRows` it is the starting height, and the field grows from it. */
    rows?: number
    /** Grow with the text up to this many lines, then scroll. Without it the height stays `rows` (and the user can drag it). */
    maxRows?: number | undefined
    /** The most characters the field takes. It also draws a count ("12 / 500") at the right of the note line. */
    maxLength?: number | undefined
    disabled?: boolean
    mono?: boolean
    required?: boolean
  }>(),
  { label: '', hint: '', error: '', placeholder: '', rows: 4, maxRows: undefined, maxLength: undefined, disabled: false, mono: false, required: false },
)

const id = useId(undefined, 'roo-textarea')
const control = ref<HTMLTextAreaElement | null>(null)
const length = computed(() => (model.value ?? '').length)
const counted = computed(() => props.maxLength !== undefined)
const nearLimit = computed(() => props.maxLength !== undefined && length.value >= props.maxLength * 0.9)

// Grows from `rows` lines to `maxRows` lines: the line height and the vertical padding and edge come from the computed style,
// so the limit follows the font size and density tokens and never a pixel figure of its own.
function grow(): void {
  const element = control.value
  if (!element || props.maxRows === undefined || typeof getComputedStyle === 'undefined') return
  const style = getComputedStyle(element)
  const lineHeight = Number.parseFloat(style.lineHeight)
  if (!Number.isFinite(lineHeight)) return
  const edges = Number.parseFloat(style.borderTopWidth) + Number.parseFloat(style.borderBottomWidth)
  const chrome = Number.parseFloat(style.paddingTop) + Number.parseFloat(style.paddingBottom) + edges
  element.style.height = 'auto'
  if (element.scrollHeight === 0) return
  const limit = lineHeight * Math.max(props.maxRows, props.rows) + chrome
  const needed = element.scrollHeight + edges
  element.style.height = `${Math.min(needed, limit)}px`
  element.style.overflowY = needed > limit ? 'auto' : 'hidden'
}

onMounted(grow)
watch(model, () => void nextTick(grow))
</script>

<template>
  <div class="roo-field">
    <label v-if="label" class="roo-field-label" :for="id">
      {{ label }}<span v-if="required" class="roo-field-required" aria-hidden="true">*</span>
    </label>
    <textarea
      :id="id"
      ref="control"
      v-model="model"
      class="roo-field-control roo-textarea"
      :class="{ 'is-mono': mono }"
      :rows="rows"
      :maxlength="maxLength"
      :data-grows="maxRows !== undefined ? 'true' : undefined"
      :placeholder="placeholder"
      :disabled="disabled"
      :aria-invalid="error ? 'true' : undefined"
      :aria-required="required ? 'true' : undefined"
      :aria-describedby="error || hint ? `${id}-note` : undefined"
    ></textarea>
    <div v-if="counted" class="roo-field-foot">
      <p
        v-if="error || hint"
        :id="`${id}-note`"
        class="roo-field-note"
        :data-error="error ? 'true' : undefined"
        :role="error ? 'alert' : undefined"
      >
        {{ error || hint }}
      </p>
      <span class="roo-field-count" :data-near-limit="nearLimit ? 'true' : undefined" data-roo-textarea-count>{{ length }} / {{ maxLength }}</span>
    </div>
    <p
      v-else-if="error || hint"
      :id="`${id}-note`"
      class="roo-field-note"
      :data-error="error ? 'true' : undefined"
      :role="error ? 'alert' : undefined"
    >
      {{ error || hint }}
    </p>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-field {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .roo-field-label {
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    font-weight: 500;
    color: var(--roo-muted);
  }

  .roo-field-required {
    margin-left: 2px;
    color: var(--roo-danger-text);
  }

  .roo-field-control {
    width: 100%;
    box-sizing: border-box;
    border: 1px solid var(--roo-field-edge);
    border-radius: var(--roo-p-radius-medium);
    background: var(--roo-surface);
    padding: 8px 12px;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-13);
    line-height: 1.6;
    color: var(--roo-text);
    resize: vertical;
    transition:
      border-color var(--roo-fast) var(--roo-ease),
      box-shadow var(--roo-fast) var(--roo-ease);
  }

  .roo-field-control.is-mono {
    font-family: var(--roo-font-mono);
  }

  .roo-field-control::placeholder {
    color: var(--roo-faint);
  }

  .roo-field-control:hover:not(:disabled) {
    border-color: var(--roo-text);
  }

  /* Focus is the caret plus a brighter fill, never an outline (family rule, Raja 2026-11-13). */
  .roo-field-control:focus {
    outline: none;
    background: var(--roo-raised);
  }

  /* On a popover, menu, palette or dialog surface the plain raised fill is too far from the surface; use the matched step. */
  :is(.roo-popover, .roo-select-popover, .roo-menu, .roo-palette, .roo-dialog) .roo-field-control:focus {
    background: var(--roo-raised-on-raised);
  }

  .roo-field-control:disabled {
    opacity: 0.4;
  }

  .roo-field-control[aria-invalid='true'] {
    border-color: var(--roo-danger);
  }

  .roo-textarea[data-grows='true'] {
    resize: none;
  }

  .roo-textarea {
    min-height: var(--roo-field-h);
  }

  .roo-field-note {
    margin: 0;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    color: var(--roo-faint);
  }

  .roo-field-foot {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: var(--roo-p-space-2);
  }

  .roo-field-foot .roo-field-note {
    min-width: 0;
    flex: 1;
  }

  .roo-field-count {
    flex: none;
    margin-left: auto;
    color: var(--roo-faint);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
  }

  .roo-field-count[data-near-limit='true'] {
    color: var(--roo-danger-text);
  }

  .roo-field-note[data-error='true'] {
    color: var(--roo-danger-text);
  }
}
</style>
