// The arithmetic behind RooChart and RooSparkline. Pure functions, no DOM, so each can be tested alone.

export type ChartValue = number | null

export interface NiceScale {
  min: number
  max: number
  ticks: number[]
}

function niceNumber(range: number, round: boolean): number {
  const exponent = Math.floor(Math.log10(range))
  const fraction = range / 10 ** exponent
  let nice: number
  if (round) nice = fraction < 1.5 ? 1 : fraction < 3 ? 2 : fraction < 7 ? 5 : 10
  else nice = fraction <= 1 ? 1 : fraction <= 2 ? 2 : fraction <= 5 ? 5 : 10
  return nice * 10 ** exponent
}

/** Round axis bounds and evenly spaced ticks that cover [min, max]. A flat range still gets a usable axis. */
export function niceScale(min: number, max: number, targetTicks = 5): NiceScale {
  let low = min
  let high = max
  if (low === high) {
    const pad = low === 0 ? 1 : Math.abs(low) * 0.1
    low -= pad
    high += pad
  }
  const step = niceNumber(niceNumber(high - low, false) / Math.max(targetTicks - 1, 1), true)
  const niceMin = Math.floor(low / step) * step
  const niceMax = Math.ceil(high / step) * step
  const ticks: number[] = []
  for (let value = niceMin; value <= niceMax + step / 2; value += step) ticks.push(Number(value.toPrecision(12)))
  return { min: ticks[0] ?? niceMin, max: ticks[ticks.length - 1] ?? niceMax, ticks }
}

/** Maps a value in [domainStart, domainEnd] to [rangeStart, rangeEnd]. A zero-width domain maps to the range start. */
export function linearScale(domainStart: number, domainEnd: number, rangeStart: number, rangeEnd: number): (value: number) => number {
  const span = domainEnd - domainStart
  if (span === 0) return () => rangeStart
  return (value) => rangeStart + ((value - domainStart) / span) * (rangeEnd - rangeStart)
}

function coordinate(value: number): string {
  return String(Math.round(value * 100) / 100)
}

/** A line path through the points. A null value breaks the line, so a gap in the data is a gap on the chart. */
export function linePath(positions: number[], ys: ChartValue[]): string {
  const commands: string[] = []
  let drawing = false
  for (let index = 0; index < positions.length; index += 1) {
    const y = ys[index]
    if (y === null || y === undefined || Number.isNaN(y)) {
      drawing = false
      continue
    }
    commands.push(`${drawing ? 'L' : 'M'}${coordinate(positions[index] ?? 0)} ${coordinate(y)}`)
    drawing = true
  }
  return commands.join(' ')
}

/** The closed shape between a line and the baseline `baselineY`, one polygon per unbroken run of data, for a light fill under the line. */
export function areaToBaselinePath(positions: number[], ys: ChartValue[], baselineY: number): string {
  const runs: number[][] = []
  let run: number[] = []
  for (let index = 0; index < positions.length; index += 1) {
    const y = ys[index]
    if (y === null || y === undefined || Number.isNaN(y)) {
      if (run.length > 0) runs.push(run)
      run = []
      continue
    }
    run.push(index)
  }
  if (run.length > 0) runs.push(run)
  return runs
    .map((indexes) => {
      const first = indexes[0] ?? 0
      const last = indexes[indexes.length - 1] ?? 0
      const top = indexes.map((index, step) => `${step === 0 ? 'M' : 'L'}${coordinate(positions[index] ?? 0)} ${coordinate(ys[index] ?? 0)}`)
      return `${top.join(' ')} L${coordinate(positions[last] ?? 0)} ${coordinate(baselineY)} L${coordinate(positions[first] ?? 0)} ${coordinate(baselineY)} Z`
    })
    .join(' ')
}

/** The closed shape between an upper and a lower line, one polygon per unbroken run of data. */
export function areaBetweenPath(positions: number[], upperYs: ChartValue[], lowerYs: ChartValue[]): string {
  const runs: number[][] = []
  let run: number[] = []
  for (let index = 0; index < positions.length; index += 1) {
    const upper = upperYs[index]
    const lower = lowerYs[index]
    if (upper === null || upper === undefined || lower === null || lower === undefined) {
      if (run.length > 0) runs.push(run)
      run = []
      continue
    }
    run.push(index)
  }
  if (run.length > 0) runs.push(run)
  return runs
    .map((indexes) => {
      const top = indexes.map((index, step) => `${step === 0 ? 'M' : 'L'}${coordinate(positions[index] ?? 0)} ${coordinate(upperYs[index] ?? 0)}`)
      const bottom = [...indexes].reverse().map((index) => `L${coordinate(positions[index] ?? 0)} ${coordinate(lowerYs[index] ?? 0)}`)
      return `${top.join(' ')} ${bottom.join(' ')} Z`
    })
    .join(' ')
}

export interface StackSegment {
  /** The lower and upper value of this series' slice of the bar. */
  low: number
  high: number
}

/** Stacks the series bottom to top, in series order, one column per bucket. A null or negative value adds nothing and has no segment. Returns one list per series, one entry per bucket. */
export function stackSegments(seriesValues: ChartValue[][], bucketCount: number): Array<Array<StackSegment | null>> {
  const running = new Array<number>(bucketCount).fill(0)
  return seriesValues.map((values) =>
    running.map((low, bucket) => {
      const value = values[bucket]
      if (value === null || value === undefined || Number.isNaN(value) || value <= 0) return null
      running[bucket] = low + value
      return { low, high: low + value }
    }),
  )
}

/** The top of each stack: the sum of the values present in each bucket. */
export function stackTotals(seriesValues: ChartValue[][], bucketCount: number): number[] {
  const totals = new Array<number>(bucketCount).fill(0)
  for (const values of seriesValues) {
    for (let bucket = 0; bucket < bucketCount; bucket += 1) {
      const value = values[bucket]
      if (value !== null && value !== undefined && !Number.isNaN(value) && value > 0) totals[bucket] = (totals[bucket] ?? 0) + value
    }
  }
  return totals
}

/** One equal slot per bucket across [left, right]: the slot centres and the bar width, a share of the slot and never wider than `maximumWidth`. */
export function barSlots(bucketCount: number, left: number, right: number, share = 0.7, maximumWidth = 64): { centres: number[]; barWidth: number } {
  if (bucketCount <= 0) return { centres: [], barWidth: 0 }
  const slot = (right - left) / bucketCount
  const centres = Array.from({ length: bucketCount }, (_, bucket) => left + slot * (bucket + 0.5))
  return { centres, barWidth: Math.max(1, Math.min(slot * share, maximumWidth)) }
}

/** The index whose position is closest to the pointer. Ties go to the earlier point. */
export function nearestIndex(positions: number[], pointer: number): number {
  let best = 0
  let bestDistance = Number.POSITIVE_INFINITY
  for (let index = 0; index < positions.length; index += 1) {
    const distance = Math.abs((positions[index] ?? 0) - pointer)
    if (distance < bestDistance) {
      best = index
      bestDistance = distance
    }
  }
  return best
}

/** Where the crosshair goes for a key: arrows step one point, Home and End jump to the ends. Anything else returns null. */
export function crosshairIndexForKey(key: string, current: number | null, length: number): number | null {
  if (length <= 0) return null
  const last = length - 1
  if (key === 'Home') return 0
  if (key === 'End') return last
  if (key === 'ArrowLeft') return current === null ? last : Math.max(0, current - 1)
  if (key === 'ArrowRight') return current === null ? 0 : Math.min(last, current + 1)
  return null
}

/** Moves labels apart so no two are closer than `minimumGap`, keeping their order, inside [top, bottom]. Returns the new positions in input order. */
export function spreadLabels(positions: number[], minimumGap: number, top: number, bottom: number): number[] {
  const order = positions.map((position, index) => ({ position, index })).sort((first, second) => first.position - second.position || first.index - second.index)
  const placed = order.map((entry) => Math.min(Math.max(entry.position, top), bottom))
  for (let step = 1; step < placed.length; step += 1) {
    placed[step] = Math.max(placed[step] ?? 0, (placed[step - 1] ?? 0) + minimumGap)
  }
  const overflow = (placed[placed.length - 1] ?? 0) - bottom
  if (overflow > 0) {
    placed[placed.length - 1] = bottom
    for (let step = placed.length - 2; step >= 0; step -= 1) {
      placed[step] = Math.min(placed[step] ?? 0, (placed[step + 1] ?? 0) - minimumGap)
    }
  }
  const result = new Array<number>(positions.length)
  order.forEach((entry, step) => {
    result[entry.index] = placed[step] ?? entry.position
  })
  return result
}

export interface SummarySeries {
  label: string
  values: ChartValue[]
}

/** One sentence per series for a screen reader: where it ends and how far it ranges. */
export function chartSummary(
  name: string,
  firstX: string,
  lastX: string,
  pointCount: number,
  series: SummarySeries[],
  formatValue: (value: number) => string,
): string {
  const parts = series.map((entry) => {
    const present = entry.values.filter((value): value is number => value !== null && value !== undefined)
    if (present.length === 0) return `${entry.label} has no data`
    const end = present[present.length - 1] as number
    return `${entry.label} ends at ${formatValue(end)}, from ${formatValue(Math.min(...present))} to ${formatValue(Math.max(...present))}`
  })
  return `${name}. ${series.length} series, ${pointCount} points from ${firstX} to ${lastX}. ${parts.join('. ')}.`
}

/**
 * Which x indexes get an axis label. The ticks step backwards from the last point, so the newest bucket is always labelled
 * and any gap from the even step falls at the old end. `room` is how many labels fit; 1 or less gives only the last one.
 * An index in `required` (the bucket that is still filling) is labelled too, and pushes out any tick closer than one step.
 */
export function axisTickIndexes(length: number, room: number, required?: number): number[] {
  if (length <= 0) return []
  const last = length - 1
  const step = room <= 1 ? Math.max(length, 1) : Math.max(1, Math.ceil(last / (room - 1)))
  let indexes: number[] = []
  for (let index = last; index >= 0; index -= step) indexes.push(index)
  indexes.reverse()
  if (required !== undefined && required >= 0 && required <= last && !indexes.includes(required)) {
    indexes = indexes.filter((index) => Math.abs(index - required) >= step)
    indexes.push(required)
    indexes.sort((first, second) => first - second)
  }
  return indexes
}
