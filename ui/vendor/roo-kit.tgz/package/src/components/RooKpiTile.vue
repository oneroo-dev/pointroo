<script lang="ts">
export type RooKpiDirection = 'up' | 'down' | 'flat'

export interface RooKpiChange {
  direction: RooKpiDirection
  /** What changed, such as `12% vs last week`. The arrow shows the direction. */
  text: string
}

export type RooKpiVerdict = 'better' | 'worse' | 'unchanged'

/** Whether a change is good news. `upIsGood` says which way is better: errors falling is good, signups falling is not. */
export function kpiVerdict(direction: RooKpiDirection, upIsGood: boolean): RooKpiVerdict {
  if (direction === 'flat') return 'unchanged'
  return (direction === 'up') === upIsGood ? 'better' : 'worse'
}
</script>

<script setup lang="ts">
// One headline number: a label, the value in mono, a change line and an optional sparkline. The change line is an arrow
// and words, so the direction never rests on colour; the colour only adds whether that direction is good or bad, and the
// same is spoken for a screen reader. The `value` slot replaces the text inside the value, for a muted prefix such as
// "about" (wrap it in a span with the class `roo-kpi-value-prefix`); the `value` prop stays required as the plain text.
import { computed } from 'vue'
import { useId } from 'reka-ui'
import RooIcon from './RooIcon.vue'
import RooSparkline from './RooSparkline.vue'

const props = withDefaults(
  defineProps<{
    label: string
    value: string
    change?: RooKpiChange | undefined
    /** Whether a rise is good news. Errors and latency set this to false. */
    upIsGood?: boolean
    /** The values for a small line beside the number. */
    sparkline?: Array<number | null> | undefined
    sparklineLabel?: string
  }>(),
  { change: undefined, upIsGood: true, sparkline: undefined, sparklineLabel: '' },
)

const id = useId(undefined, 'roo-kpi')
const verdict = computed(() => (props.change ? kpiVerdict(props.change.direction, props.upIsGood) : 'unchanged'))
const arrow = computed(() => (props.change?.direction === 'up' ? 'arrow-up' : props.change?.direction === 'down' ? 'arrow-down' : 'arrow-right'))
const directionWord = computed(() => (props.change?.direction === 'up' ? 'Up' : props.change?.direction === 'down' ? 'Down' : 'No change'))
</script>

<template>
  <article class="roo-kpi" :aria-labelledby="`${id}-label`">
    <div class="roo-kpi-main">
      <h3 :id="`${id}-label`" class="roo-kpi-label">{{ label }}</h3>
      <p class="roo-kpi-value"><slot name="value">{{ value }}</slot></p>
      <p v-if="change" class="roo-kpi-change" :data-verdict="verdict" :data-direction="change.direction">
        <RooIcon :name="arrow" :size="16" />
        <span class="roo-visually-hidden">{{ directionWord }}, </span>
        <span>{{ change.text }}</span>
        <span class="roo-visually-hidden">, {{ verdict }}</span>
      </p>
    </div>
    <RooSparkline v-if="sparkline && sparkline.length > 1" :values="sparkline" :label="sparklineLabel" :width="96" :height="36" />
  </article>
</template>

<style scoped>
@layer roo-components {
  /* Label, value and change start on the same lines in every tile of a row, with or without a sparkline; the sparkline sits
     beside the value and the change line keeps the full width so "vs last week" never wraps. */
  .roo-kpi {
    display: grid;
    min-width: 0;
    grid-template-columns: minmax(0, 1fr) auto;
    align-content: start;
    column-gap: var(--roo-space-group);
    row-gap: 4px;
    box-sizing: border-box;
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-p-radius-card);
    background: var(--roo-surface);
    padding: 12px 16px;
  }

  .roo-kpi-main {
    display: contents;
  }

  .roo-kpi-label,
  .roo-kpi-value,
  .roo-kpi-change {
    grid-column: 1;
  }

  .roo-kpi-change {
    grid-column: 1 / -1;
    white-space: nowrap;
  }

  .roo-kpi > :deep(.roo-sparkline),
  .roo-kpi > svg {
    grid-column: 2;
    grid-row: 1 / span 2;
    align-self: end;
  }

  .roo-kpi-label {
    margin: 0;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    font-weight: 500;
  }

  .roo-kpi-value {
    margin: 0;
    color: var(--roo-text);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-20);
    font-variant-numeric: tabular-nums;
    font-weight: 600;
    line-height: 1.2;
  }

  /* A small muted word before the number, such as "about". Put it in the value slot: <span class="roo-kpi-value-prefix">about</span> 1,240. */
  .roo-kpi-value :deep(.roo-kpi-value-prefix) {
    color: var(--roo-muted);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    font-weight: 500;
  }

  .roo-kpi-change {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    margin: 0;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }

  .roo-kpi-change[data-verdict='better'] {
    color: var(--roo-ok-text);
  }

  .roo-kpi-change[data-verdict='worse'] {
    color: var(--roo-danger-text);
  }
}
</style>
