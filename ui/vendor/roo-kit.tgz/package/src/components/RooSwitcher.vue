<script lang="ts">
import type { RooEnvironment, RooGuardLevel, RooTag } from '../types/environment'
import type { RooIconName } from '../icons/paths'

export interface RooSwitcherRow {
  id: string
  name: string
  /** The environment tag. Tag grouping puts the row in its tag's group, and a row with a tag and no dot or glyph draws the tag's dot. */
  tag?: RooTag | undefined
  /** The guard level, drawn as its word and icon in the meta position. A `meta` the caller gives replaces it. */
  guard?: RooGuardLevel | undefined
  /**
   * @deprecated Pass `tag`. The old environment word, mapped to a tag with tagForEnvironment. A row with neither falls in
   * the No tag group (the old Unclassified).
   */
  environment?: RooEnvironment | undefined
  health?: 'ok' | 'slow' | 'down' | undefined
  /** A quiet second piece of text in the mono face, such as a latency. */
  detail?: string | undefined
  /** Quiet words at the right in the UI face, such as a platform or "42 items". */
  meta?: string | undefined
  /** A CSS colour for the 8 px project dot. A row with no dot and no glyph gets a faint dot. */
  dot?: string | undefined
  /** An icon in the leading column instead of the dot, such as a platform glyph. */
  glyph?: RooIconName | undefined
  /** A project at its cap: the warning glyph and the pruning word. */
  pruning?: boolean | undefined
  disabled?: boolean | undefined
  /** A row that can be selected but never opened: it never emits `activate`. */
  readonly?: boolean | undefined
}
</script>

<script setup lang="ts">
import { computed, getCurrentInstance, nextTick, onBeforeUnmount, ref, useId, watch } from 'vue'
import { useEscapeLayer } from '../composables/useEscapeLayer'
import { GUARD_ICONS, GUARD_LABELS, ROO_TAGS, TAG_LABELS, tagForEnvironment } from '../environment'
import RooEnvDot from './RooEnvDot.vue'
import RooIcon from './RooIcon.vue'
import RooKbd from './RooKbd.vue'
import RooSwitcherFloating from './RooSwitcherFloating.vue'
import { filterSwitcherRows, splitSwitcherMatch, switcherShortcutIndex } from './RooSwitcherFilter'

const props = withDefaults(
  defineProps<{
    /** Controlled open state. Left out, the switcher is open when it has no trigger and starts closed when it has one. */
    open?: boolean | undefined
    rows: RooSwitcherRow[]
    /** The id of the row that is current. */
    current?: string | undefined
    /** The popover's accessible name. */
    label?: string
    /** @deprecated Use `tagGroupLabel`. The words for a group heading under `grouping="environment"`, given the old environment word. Defaults to that word in sentence case. */
    groupLabel?: ((environment: RooEnvironment) => string) | undefined
    /** The words for a group heading under `grouping="tag"` (and for the tags with no old environment under `grouping="environment"`), given the tag. Defaults to the tag's own words, first letter capital. */
    tagGroupLabel?: ((tag: RooTag) => string) | undefined
    /** The New row's words. */
    newLabel?: string
    emptyHint?: string
    /** Tag groups in the tag order with No tag last, or one flat list. `environment` is the deprecated form: it groups by each row's tag, mapped from its old environment. */
    grouping?: 'tag' | 'environment' | 'none'
    /** Draws a search field that keeps focus while the arrow keys move the active row. */
    search?: boolean
    searchPlaceholder?: string
    /** The words when the text matches nothing. */
    noMatchHint?: (query: string) => string
    /** Ids of recently used rows, newest first. Shown above the list while the search field is empty. */
    recents?: string[]
    recentLabel?: string
    recentLimit?: number
    /** The heading over the full list when recents are shown. */
    allLabel?: string
    /** Cmd or Ctrl 1 to 9 and 0 choose the first ten rows of the list while it is open, and each row shows its key. */
    shortcuts?: boolean
    /** Ticks on every row, an all row on top, and a click on a name chooses only that row. */
    multi?: boolean
    /** The ids ticked in multi mode. */
    selected?: string[]
    /** The words of the trigger when several rows are ticked. */
    multiLabel?: (count: number) => string
    /** Draws the built in breadcrumb trigger (the name and a chevron). The `trigger` slot replaces it. */
    crumb?: boolean
    /** Closes after a choice instead of leaving that to the caller. */
    closeOnSelect?: boolean
    /** The look of the active row: the solid accent fill (default, as kit menus) or a quiet raised fill. A popover row never carries the selection mark (family rule), so neither draws one. */
    highlight?: 'accent' | 'raised'
    /** Words next to a row at its cap. */
    pruningLabel?: string
    /** The word on a hovered or active row in multi mode. */
    onlyLabel?: string
    /** The See all row's words, drawn when the caller listens for `see-all`. */
    seeAllLabel?: string
    /** The line of key hints at the foot. Defaults to on with the search field. */
    hints?: boolean | undefined
  }>(),
  {
    open: undefined,
    current: undefined,
    label: 'Switch context',
    groupLabel: undefined,
    tagGroupLabel: undefined,
    newLabel: 'New connection',
    emptyHint: 'Nothing here yet',
    grouping: 'environment',
    search: false,
    searchPlaceholder: 'Find a project',
    noMatchHint: (query: string) => `Nothing matches “${query}”`,
    recents: () => [],
    recentLabel: 'Recent',
    recentLimit: 3,
    allLabel: 'All projects',
    shortcuts: false,
    multi: false,
    selected: () => [],
    multiLabel: (count: number) => `${count} projects`,
    crumb: false,
    closeOnSelect: false,
    highlight: 'accent',
    pruningLabel: 'pruning',
    onlyLabel: 'Only',
    seeAllLabel: 'See all projects',
    hints: undefined,
  },
)

const emit = defineEmits<{
  'update:open': [open: boolean]
  'update:selected': [ids: string[]]
  select: [row: RooSwitcherRow]
  /** A tick changed in multi mode, from a click on the box or Space. Fires alongside update:selected, never for the All row. */
  toggle: [row: RooSwitcherRow, ticked: boolean]
  /** A row was opened: double click with no modifier key, or Enter. Once per open, never on a single click, never for a disabled or read-only row. In single mode never for the current row; multi mode has no current, so any enabled row can open. */
  activate: [row: RooSwitcherRow]
  'open-in-new-window': [row: RooSwitcherRow]
  new: []
  'see-all': []
}>()

const slots = defineSlots<{
  leading?: (props: { row: RooSwitcherRow }) => unknown
  menu?: (props: { row: RooSwitcherRow }) => unknown
  actions?: () => unknown
  /** Rows that tidy the list, such as "Remove missing projects". Drawn under the list, above the actions. */
  prune?: () => unknown
  trigger?: (props: { open: boolean; summary: string; attrs: Record<string, unknown> }) => unknown
}>()

// The New and See all rows are drawn only when the caller listens. Listeners are read from the vnode on each render.
const instance = getCurrentInstance()
function hasHandler(name: 'onNew' | 'onSeeAll'): boolean {
  return Boolean(instance?.vnode.props?.[name])
}

const anchored = computed(() => props.crumb || Boolean(slots.trigger))
const internalOpen = ref(!anchored.value)
const isOpen = computed(() => props.open ?? internalOpen.value)

function setOpen(open: boolean): void {
  internalOpen.value = open
  emit('update:open', open)
}

useEscapeLayer(() => isOpen.value)

// The old environment word for the tags that have one, so a caller on the old call sees the same headings.
const LEGACY_ENVIRONMENTS: Partial<Record<RooTag, RooEnvironment>> = { local: 'local', staging: 'staging', production: 'prod', none: 'unclassified' }

function capitalised(word: string): string {
  return word.charAt(0).toUpperCase() + word.slice(1)
}

function tagOf(row: RooSwitcherRow): RooTag {
  return row.tag ?? tagForEnvironment(row.environment)
}

/** The text in the search field. Bind it with v-model:query to read or set it. */
const query = defineModel<string>('query', { default: '' })
const searching = computed(() => query.value.trim() !== '')

interface Section {
  key: string
  heading: string | undefined
  environment: RooEnvironment | undefined
  tag: RooTag | undefined
  rows: RooSwitcherRow[]
  numbered: boolean
}

const sections = computed<Section[]>(() => {
  const found = props.search ? filterSwitcherRows(props.rows, query.value) : props.rows
  const result: Section[] = []
  if (props.search && !searching.value && props.recents.length > 0) {
    const byId = new Map(props.rows.map((row) => [row.id, row]))
    const recent = props.recents
      .map((id) => byId.get(id))
      .filter((row): row is RooSwitcherRow => row !== undefined)
      .slice(0, props.recentLimit)
    if (recent.length > 0) result.push({ key: 'recent', heading: props.recentLabel, environment: undefined, tag: undefined, rows: recent, numbered: false })
  }
  if (props.grouping === 'tag' || props.grouping === 'environment') {
    for (const tag of ROO_TAGS) {
      const inGroup = found.filter((row) => tagOf(row) === tag)
      if (inGroup.length === 0) continue
      const environment = props.grouping === 'environment' ? LEGACY_ENVIRONMENTS[tag] : undefined
      let heading: string
      if (environment !== undefined) heading = props.groupLabel ? props.groupLabel(environment) : capitalised(environment)
      else heading = props.tagGroupLabel ? props.tagGroupLabel(tag) : capitalised(TAG_LABELS[tag])
      result.push({ key: environment ?? tag, heading, environment, tag, rows: inGroup, numbered: true })
    }
  } else if (found.length > 0) {
    result.push({ key: 'all', heading: result.length > 0 ? props.allLabel : undefined, environment: undefined, tag: undefined, rows: found, numbered: true })
  }
  return result
})

interface Entry {
  key: string
  sectionKey: string
  /** Undefined for the all row of multi mode. */
  row: RooSwitcherRow | undefined
  shortcut: number | undefined
}

const ALL_KEY = 'all-row'

const entries = computed<Entry[]>(() => {
  const list: Entry[] = []
  if (props.multi && props.search && !searching.value) list.push({ key: ALL_KEY, sectionKey: ALL_KEY, row: undefined, shortcut: undefined })
  let shortcutCount = 0
  for (const section of sections.value) {
    for (const row of section.rows) {
      if (row.disabled) continue
      const shortcut = props.shortcuts && section.numbered && shortcutCount < 10 ? shortcutCount : undefined
      if (section.numbered) shortcutCount += 1
      list.push({ key: `${section.key}:${row.id}`, sectionKey: section.key, row, shortcut })
    }
  }
  return list
})

function entryOf(sectionKey: string, row: RooSwitcherRow): Entry | undefined {
  return entries.value.find((entry) => entry.key === `${sectionKey}:${row.id}`)
}

function shortcutKeys(shortcut: number): string {
  return `Mod+${(shortcut + 1) % 10}`
}

// Health is a glyph and a word; the glyphs differ so colour is never the only signal.
const healthIcons = { ok: 'check', slow: 'gauge', down: 'alert' } as const

const root = ref<HTMLElement | null>(null)
const floating = ref<InstanceType<typeof RooSwitcherFloating> | null>(null)
const field = ref<HTMLInputElement | null>(null)
const baseId = useId()
const activeIndex = ref(0)

const activeEntry = computed(() => entries.value[activeIndex.value])
const activeDescendant = computed(() => (activeEntry.value ? `${baseId}-${activeEntry.value.key}` : undefined))

watch(entries, (list) => {
  activeIndex.value = Math.min(activeIndex.value, Math.max(0, list.length - 1))
})

watch(query, () => {
  activeIndex.value = 0
})

const selectedIds = computed(() => new Set(props.selected))
const everySelected = computed(() => props.rows.length > 0 && props.rows.every((row) => selectedIds.value.has(row.id)))
const someSelected = computed(() => props.rows.some((row) => selectedIds.value.has(row.id)))

const summary = computed(() => {
  if (props.multi && props.selected.length !== 1) return props.multiLabel(props.selected.length)
  const id = props.multi ? props.selected[0] : props.current
  return props.rows.find((row) => row.id === id)?.name ?? ''
})

const triggerAttributes = computed(() => ({
  'aria-haspopup': 'dialog' as const,
  'aria-expanded': isOpen.value,
  onClick: () => setOpen(!isOpen.value),
}))

function isSelected(row: RooSwitcherRow): boolean {
  return props.multi ? selectedIds.value.has(row.id) : row.id === props.current
}

function close(): void {
  setOpen(false)
}

function toggleRow(row: RooSwitcherRow): void {
  const next = new Set(props.selected)
  if (next.has(row.id)) next.delete(row.id)
  else next.add(row.id)
  emit('update:selected', props.rows.filter((candidate) => next.has(candidate.id)).map((candidate) => candidate.id))
  emit('toggle', row, next.has(row.id))
}

function toggleAll(): void {
  emit('update:selected', everySelected.value ? [] : props.rows.map((row) => row.id))
}

function choose(row: RooSwitcherRow, newWindow: boolean): void {
  if (newWindow) {
    emit('open-in-new-window', row)
    return
  }
  if (props.multi) emit('update:selected', [row.id])
  emit('select', row)
  if (props.closeOnSelect) close()
}

function openRow(row: RooSwitcherRow): void {
  if (row.readonly || row.disabled || (!props.multi && row.id === props.current)) return
  emit('activate', row)
}

function onOptionDoubleClick(event: MouseEvent, row: RooSwitcherRow): void {
  if (event.metaKey || event.ctrlKey || event.altKey || event.shiftKey) return
  openRow(row)
}

function onNew(): void {
  emit('new')
  if (props.closeOnSelect) close()
}

function onSeeAll(): void {
  emit('see-all')
  if (props.closeOnSelect) close()
}

function activate(entry: Entry, newWindow = false): void {
  if (!entry.row) toggleAll()
  else if (props.multi && !newWindow) return
  else choose(entry.row, newWindow)
}

function onOptionClick(event: MouseEvent, row: RooSwitcherRow, entry: Entry | undefined): void {
  if (props.multi && event.target instanceof Element && event.target.closest('[data-roo-switcher-box]')) toggleRow(row)
  else choose(row, false)
  if (entry) activeIndex.value = entries.value.indexOf(entry)
  if (props.search) field.value?.focus({ preventScroll: true })
  else if (event.currentTarget instanceof HTMLElement) event.currentTarget.focus({ preventScroll: true })
}

function items(): HTMLElement[] {
  return root.value ? Array.from(root.value.querySelectorAll<HTMLElement>('[data-roo-switcher-item]:not(:disabled)')) : []
}

function focusAt(index: number): void {
  const list = items()
  list[Math.min(Math.max(index, 0), list.length - 1)]?.focus()
}

function moveActive(index: number): void {
  activeIndex.value = Math.min(Math.max(index, 0), entries.value.length - 1)
  void nextTick(() => {
    root.value?.querySelector<HTMLElement>('[data-active="true"]')?.scrollIntoView?.({ block: 'nearest' })
  })
}

function onKeydown(event: KeyboardEvent): void {
  if (event.key === 'Escape') {
    event.preventDefault()
    close()
    return
  }
  if (props.search && event.target === field.value) {
    if (event.key === 'ArrowDown') moveActive(activeIndex.value + 1)
    else if (event.key === 'ArrowUp') moveActive(activeIndex.value - 1)
    else if (event.key === ' ' && props.multi && query.value === '' && activeEntry.value?.row) toggleRow(activeEntry.value.row)
    else if (event.key === 'Enter') {
      const entry = activeEntry.value
      if (entry) {
        activate(entry, event.metaKey || event.ctrlKey)
        if (entry.row && !event.metaKey && !event.ctrlKey && !event.altKey && !event.shiftKey && !event.repeat) openRow(entry.row)
      }
    } else return
    event.preventDefault()
    return
  }
  const list = items()
  const index = list.findIndex((item) => item === document.activeElement)
  if (event.key === 'ArrowDown') focusAt(index + 1)
  else if (event.key === 'ArrowUp') {
    if (index <= 0 && props.search) field.value?.focus()
    else focusAt(index - 1)
  } else if (event.key === 'Home') focusAt(0)
  else if (event.key === 'End') focusAt(list.length - 1)
  else return
  event.preventDefault()
}

function onRowKeyup(event: KeyboardEvent): void {
  if (props.multi && event.key === ' ') event.preventDefault()
}

function onRowKeydown(event: KeyboardEvent, row: RooSwitcherRow): void {
  if (props.multi && event.key === ' ') {
    event.preventDefault()
    toggleRow(row)
    return
  }
  if (event.key !== 'Enter') return
  if (!event.metaKey && !event.ctrlKey && !event.altKey && !event.shiftKey && !event.repeat) openRow(row)
  if (event.metaKey || event.ctrlKey) {
    event.preventDefault()
    emit('open-in-new-window', row)
  } else if (props.multi) {
    event.preventDefault()
  }
}

function onShortcut(event: KeyboardEvent): void {
  if (!props.shortcuts || !(event.metaKey || event.ctrlKey) || event.altKey || event.shiftKey) return
  const shortcut = switcherShortcutIndex(event.key)
  if (shortcut === undefined) return
  const entry = entries.value.find((candidate) => candidate.shortcut === shortcut)
  if (!entry?.row) return
  event.preventDefault()
  choose(entry.row, false)
}

// A pointerdown outside the popover and its anchor (the trigger that opens it) closes it, in the capture phase so nothing
// in the page can swallow it. Without a trigger slot the scope is the element that holds the switcher, so the caller's own
// opener must sit inside that element: its click then toggles instead of closing and reopening.
function onOutside(event: Event): void {
  if (!(event.target instanceof Node)) return
  // The anchored panel is portalled out of the anchor, so the anchor (the trigger) and the panel are two scopes.
  const anchor = floating.value?.anchorElement
  if (anchor) {
    if (!anchor.contains(event.target) && !root.value?.contains(event.target)) close()
    return
  }
  const scope = root.value?.parentElement ?? root.value
  if (scope && !scope.contains(event.target)) close()
}

let previousFocus: HTMLElement | null = null

function listen(on: boolean): void {
  if (typeof document === 'undefined') return
  if (on) {
    document.addEventListener('pointerdown', onOutside, true)
    document.addEventListener('keydown', onShortcut)
  } else {
    document.removeEventListener('pointerdown', onOutside, true)
    document.removeEventListener('keydown', onShortcut)
  }
}

onBeforeUnmount(() => listen(false))

watch(
  isOpen,
  async (open) => {
    listen(open)
    if (!open) {
      query.value = ''
      previousFocus?.focus()
      previousFocus = null
      return
    }
    const active = typeof document === 'undefined' ? null : (document.activeElement as HTMLElement | null)
    previousFocus = active && active !== document.body ? active : null
    await nextTick()
    // A trigger clicked without taking focus leaves the body active, so the trigger is the anchor's first button.
    if (!previousFocus) previousFocus = (floating.value?.anchorElement ?? root.value?.parentElement)?.querySelector<HTMLElement>('button') ?? null
    if (props.search) {
      const currentIndex = entries.value.findIndex((entry) => entry.row?.id === props.current)
      activeIndex.value = Math.max(0, currentIndex)
      field.value?.focus({ preventScroll: true })
      return
    }
    const list = items()
    const currentRow = list.find((item) => item.getAttribute('aria-selected') === 'true')
    ;(currentRow ?? list[0])?.focus({ preventScroll: true })
  },
  { immediate: true },
)

const showHints = computed(() => props.hints ?? props.search)
</script>

<template>
  <RooSwitcherFloating ref="floating" :anchored="anchored" :open="isOpen" @update:open="setOpen">
    <template v-if="anchored" #trigger>
      <slot name="trigger" :open="isOpen" :summary="summary" :attrs="triggerAttributes">
        <button v-if="crumb" class="roo-switcher-crumb" type="button" v-bind="triggerAttributes">
          <span class="roo-switcher-crumb-name">{{ summary }}</span>
          <RooIcon name="chevron-down" :size="12" />
        </button>
      </slot>
    </template>
    <div
      v-if="isOpen"
      ref="root"
      class="roo-switcher"
      role="dialog"
      :aria-label="label"
      :data-search="search ? '' : undefined"
      :data-multi="multi ? '' : undefined"
      :data-highlight="highlight"
      @keydown="onKeydown"
    >
      <div v-if="search" class="roo-switcher-field">
        <RooIcon name="search" :size="14" />
        <input
          ref="field"
          v-model="query"
          class="roo-switcher-input"
          type="text"
          role="combobox"
          aria-expanded="true"
          :aria-label="searchPlaceholder"
          :aria-controls="`${baseId}-list`"
          :aria-activedescendant="activeDescendant"
          :placeholder="searchPlaceholder"
          autocomplete="off"
          spellcheck="false"
        />
      </div>
      <p v-if="rows.length === 0" class="roo-switcher-empty">{{ emptyHint }}</p>
      <p v-else-if="entries.length === 0 && searching" class="roo-switcher-empty" data-roo-switcher-no-match>{{ noMatchHint(query.trim()) }}</p>
      <div
        v-else
        :id="`${baseId}-list`"
        class="roo-switcher-list"
        role="listbox"
        :aria-label="label"
        :aria-multiselectable="multi ? 'true' : undefined"
      >
        <div
          v-if="multi && !searching"
          :id="`${baseId}-${ALL_KEY}`"
          class="roo-switcher-row roo-switcher-all"
          :data-active="search && activeEntry?.key === ALL_KEY ? 'true' : undefined"
        >
          <button
            class="roo-switcher-option"
            type="button"
            role="option"
            data-roo-switcher-item
            :tabindex="search ? -1 : undefined"
            :aria-selected="everySelected"
            @click="toggleAll"
            @mousemove="activeIndex = 0"
          >
            <span class="roo-switcher-box" data-roo-switcher-box :data-state="everySelected ? 'all' : someSelected ? 'some' : 'none'">
              <RooIcon v-if="everySelected" name="check" :size="10" />
              <span v-else-if="someSelected" class="roo-switcher-dash" />
            </span>
            <span class="roo-switcher-leading"><RooIcon name="projects" :size="14" /></span>
            <span class="roo-switcher-name">{{ allLabel }}</span>
            <span class="roo-switcher-detail">{{ rows.length }}</span>
          </button>
        </div>
        <div
          v-for="section in sections"
          :key="section.key"
          class="roo-switcher-group"
          role="group"
          :aria-labelledby="section.heading ? `${baseId}-heading-${section.key}` : undefined"
          :aria-label="section.heading ? undefined : label"
        >
          <p
            v-if="section.heading"
            :id="`${baseId}-heading-${section.key}`"
            class="roo-switcher-group-label"
            :data-env="section.environment"
            :data-tag="section.tag"
          >
            {{ section.heading }}
          </p>
          <div
            v-for="row in section.rows"
            :id="entryOf(section.key, row) ? `${baseId}-${entryOf(section.key, row)!.key}` : undefined"
            :key="row.id"
            class="roo-switcher-row"
            :data-current="row.id === current ? 'true' : undefined"
            :data-active="search && entryOf(section.key, row) && activeEntry?.key === entryOf(section.key, row)!.key ? 'true' : undefined"
          >
            <button
              class="roo-switcher-option"
              type="button"
              role="option"
              data-roo-switcher-item
              :tabindex="search ? -1 : undefined"
              :aria-selected="isSelected(row)"
              :disabled="row.disabled"
              @click="onOptionClick($event, row, entryOf(section.key, row))"
              @dblclick="onOptionDoubleClick($event, row)"
              @keydown="onRowKeydown($event, row)"
              @keyup="onRowKeyup"
              @mousemove="entryOf(section.key, row) && (activeIndex = entries.indexOf(entryOf(section.key, row)!))"
            >
              <span v-if="multi" class="roo-switcher-box" data-roo-switcher-box :data-state="selectedIds.has(row.id) ? 'all' : 'none'">
                <RooIcon v-if="selectedIds.has(row.id)" name="check" :size="10" />
              </span>
              <span v-if="$slots.leading" class="roo-switcher-leading"><slot name="leading" :row="row" /></span>
              <span v-else-if="row.glyph" class="roo-switcher-leading"><RooIcon :name="row.glyph" :size="14" /></span>
              <span v-else-if="row.tag !== undefined && row.dot === undefined" class="roo-switcher-leading"><RooEnvDot :tag="row.tag" aria-hidden="true" /></span>
              <span v-else-if="row.dot !== undefined || search" class="roo-switcher-leading">
                <i class="roo-switcher-dot" :style="row.dot ? { background: row.dot } : undefined" aria-hidden="true" />
              </span>
              <span class="roo-switcher-name">
                <template v-for="(part, partIndex) in splitSwitcherMatch(row.name, search ? query : '')" :key="partIndex">
                  <b v-if="partIndex === 1 && part" class="roo-switcher-match">{{ part }}</b>
                  <template v-else>{{ part }}</template>
                </template>
              </span>
              <span v-if="row.pruning" class="roo-switcher-pruning">
                <RooIcon name="warning" :size="12" />
                <span>{{ pruningLabel }}</span>
              </span>
              <span v-if="row.detail" class="roo-switcher-detail">{{ row.detail }}</span>
              <span v-if="row.meta" class="roo-switcher-meta">{{ row.meta }}</span>
              <span v-else-if="row.guard" class="roo-switcher-meta roo-switcher-guard" :data-guard="row.guard">
                <RooIcon :name="GUARD_ICONS[row.guard]" :size="12" />
                <span>{{ GUARD_LABELS[row.guard] }}</span>
              </span>
              <span v-if="row.health" class="roo-switcher-health" :data-health="row.health">
                <RooIcon :name="healthIcons[row.health]" :size="12" />
                <span>{{ row.health }}</span>
              </span>
              <span v-if="multi" class="roo-switcher-only" aria-hidden="true">{{ onlyLabel }}</span>
              <RooKbd
                v-if="entryOf(section.key, row)?.shortcut !== undefined"
                class="roo-switcher-key"
                :keys="shortcutKeys(entryOf(section.key, row)!.shortcut!)"
              />
            </button>
            <span v-if="$slots.menu" class="roo-switcher-menu"><slot name="menu" :row="row" /></span>
          </div>
        </div>
      </div>
      <div v-if="$slots.prune" class="roo-switcher-prune"><slot name="prune" /></div>
      <div v-if="$slots.actions" class="roo-switcher-actions"><slot name="actions" /></div>
      <p v-if="multi" class="roo-switcher-note">Tick to add a project. Click a name to see only that one.</p>
      <button v-if="hasHandler('onNew')" class="roo-switcher-new" type="button" data-roo-switcher-item @click="onNew">
        <RooIcon name="plus" :size="14" />
        <span>{{ newLabel }}</span>
      </button>
      <button v-if="hasHandler('onSeeAll')" class="roo-switcher-see-all" type="button" data-roo-switcher-item @click="onSeeAll">
        <RooIcon name="projects" :size="14" />
        <span>{{ seeAllLabel }}</span>
      </button>
      <div v-if="showHints" class="roo-switcher-hints" aria-hidden="true">
        <span class="roo-switcher-hint"><RooKbd>↑</RooKbd><RooKbd>↓</RooKbd>move</span>
        <span class="roo-switcher-hint"><RooKbd keys="Enter" />open</span>
        <span class="roo-switcher-hint"><RooKbd keys="Escape" />close</span>
      </div>
    </div>
  </RooSwitcherFloating>
</template>

<style scoped>
@layer roo-components {
  .roo-switcher-crumb {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-1);
    min-height: var(--roo-control-h);
    padding: 0 var(--roo-p-space-2);
    border: 0;
    border-radius: var(--roo-p-radius-medium);
    background: transparent;
    color: var(--roo-text);
    cursor: default;
    font: inherit;
    font-weight: 600;
  }

  .roo-switcher-crumb:hover,
  .roo-switcher-crumb[aria-expanded='true'] {
    background: var(--roo-raised);
  }

  .roo-switcher-crumb:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: -2px;
  }

  .roo-switcher {
    display: flex;
    min-width: 280px;
    max-width: 400px;
    flex-direction: column;
    padding: var(--roo-p-space-1);
    /* One inset for every block (search field, group labels, rows, note, hints, actions), so their content starts on one left edge. */
    --roo-switcher-inset: var(--roo-p-space-2);
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-radius-popover);
    background: var(--roo-raised);
    box-shadow: var(--roo-shadow-popover);
    color: var(--roo-text);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-13);
  }

  .roo-switcher[data-search] {
    width: 340px;
  }

  /* The approved project switcher sits on the surface fill, so the raised-on-raised row reads in light as well as dark. */
  .roo-switcher[data-highlight='raised'] {
    background: var(--roo-surface);
  }

  .roo-switcher-field {
    display: flex;
    flex: none;
    align-items: center;
    gap: var(--roo-p-space-2);
    min-height: var(--roo-control-h);
    margin-bottom: var(--roo-p-space-1);
    /* The field's own 1 px edge is part of the inset, so its icon starts where a row's box and a note's text start. */
    padding: 0 calc(var(--roo-switcher-inset) - 1px);
    border: 1px solid var(--roo-control-edge);
    border-radius: var(--roo-p-radius-medium);
    background: var(--roo-surface);
    color: var(--roo-muted);
  }

  /* Text field focus (Raja, 2026-11-13, every app): the caret and a brighter fill, never an outline or edge colour. The
     switcher is a popover surface, so the step is raised-on-raised, as RooInput uses inside popovers. */
  .roo-switcher-field:focus-within {
    outline: none;
    background: var(--roo-raised-on-raised);
  }

  .roo-switcher-input {
    min-width: 0;
    flex: 1;
    border: 0;
    background: transparent;
    color: var(--roo-text);
    font: inherit;
    outline: none;
  }

  .roo-switcher-input::placeholder {
    color: var(--roo-muted);
  }

  .roo-switcher-list {
    display: flex;
    max-height: 360px;
    flex-direction: column;
    overflow: auto;
  }

  .roo-switcher-group-label {
    margin: 0;
    padding: var(--roo-p-space-2) var(--roo-switcher-inset) var(--roo-p-space-1);
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    font-weight: 600;
    white-space: nowrap;
  }

  .roo-switcher-row {
    position: relative;
    display: flex;
    align-items: center;
    min-height: var(--roo-row-h);
    border-radius: var(--roo-p-radius-medium);
  }

  .roo-switcher-option,
  .roo-switcher-new,
  .roo-switcher-see-all {
    display: flex;
    min-width: 0;
    flex: 1;
    align-items: center;
    gap: var(--roo-p-space-2);
    min-height: var(--roo-row-h);
    padding: 0 var(--roo-switcher-inset);
    border: 0;
    border-radius: var(--roo-p-radius-medium);
    background: transparent;
    color: inherit;
    cursor: default;
    font: inherit;
    text-align: left;
  }

  .roo-switcher:not([data-search]) .roo-switcher-option:hover,
  .roo-switcher-new:hover,
  .roo-switcher-see-all:hover,
  .roo-switcher-option:focus-visible,
  .roo-switcher-new:focus-visible,
  .roo-switcher-see-all:focus-visible,
  .roo-switcher[data-highlight='accent'] [data-active='true'] .roo-switcher-option {
    background: var(--roo-accent);
    color: var(--roo-on-accent);
  }

  .roo-switcher:not([data-search]) .roo-switcher-option:hover .roo-switcher-detail,
  .roo-switcher:not([data-search]) .roo-switcher-option:hover .roo-switcher-meta,
  .roo-switcher:not([data-search]) .roo-switcher-option:hover .roo-switcher-health,
  .roo-switcher-option:focus-visible .roo-switcher-detail,
  .roo-switcher-option:focus-visible .roo-switcher-meta,
  .roo-switcher-option:focus-visible .roo-switcher-health,
  .roo-switcher[data-highlight='accent'] [data-active='true'] .roo-switcher-detail,
  .roo-switcher[data-highlight='accent'] [data-active='true'] .roo-switcher-meta,
  .roo-switcher[data-highlight='accent'] [data-active='true'] .roo-switcher-health,
  .roo-switcher[data-highlight='accent'] [data-active='true'] .roo-switcher-pruning,
  .roo-switcher[data-highlight='accent'] [data-active='true'] .roo-switcher-only,
  .roo-switcher[data-highlight='accent'] [data-active='true'] .roo-switcher-match {
    color: var(--roo-on-accent);
  }

  .roo-switcher[data-highlight='raised'] [data-active='true'] {
    background: var(--roo-raised-on-raised);
  }

  .roo-switcher-option:focus-visible,
  .roo-switcher-new:focus-visible,
  .roo-switcher-see-all:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: -2px;
  }

  .roo-switcher:not([data-multi]) .roo-switcher-option[aria-selected='true'] {
    font-weight: 600;
  }

  .roo-switcher-option:disabled {
    opacity: 0.4;
  }

  .roo-switcher-leading {
    display: inline-flex;
    width: var(--roo-icon);
    flex: none;
    align-items: center;
    justify-content: center;
  }

  .roo-switcher-dot {
    width: 8px;
    height: 8px;
    flex: none;
    border-radius: 50%;
    background: var(--roo-faint);
  }

  .roo-switcher-box {
    display: inline-flex;
    width: 16px;
    height: 16px;
    flex: none;
    align-items: center;
    justify-content: center;
    border: 1px solid var(--roo-control-edge);
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-surface);
    color: var(--roo-on-accent);
  }

  .roo-switcher-box:not([data-state='none']) {
    border-color: var(--roo-accent);
    background: var(--roo-accent);
  }

  .roo-switcher-dash {
    width: 8px;
    height: 2px;
    background: var(--roo-on-accent);
  }

  .roo-switcher-name {
    min-width: 0;
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-switcher-match {
    font-weight: 600;
    color: var(--roo-accent-text);
  }

  .roo-switcher-detail {
    flex: none;
    color: var(--roo-muted);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
  }

  .roo-switcher-meta,
  .roo-switcher-pruning,
  .roo-switcher-only {
    flex: none;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }

  .roo-switcher-guard {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-1);
  }

  .roo-switcher-pruning {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-1);
  }

  .roo-switcher-only {
    display: none;
    color: var(--roo-accent-text);
  }

  .roo-switcher-row:hover .roo-switcher-only,
  .roo-switcher-row[data-active='true'] .roo-switcher-only {
    display: inline;
  }

  .roo-switcher-key {
    flex: none;
  }

  .roo-switcher-health {
    display: inline-flex;
    flex: none;
    align-items: center;
    gap: var(--roo-p-space-1);
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }

  .roo-switcher-menu {
    display: inline-flex;
    flex: none;
    align-items: center;
  }

  .roo-switcher-new,
  .roo-switcher-see-all {
    flex: none;
    color: var(--roo-muted);
  }

  .roo-switcher-new {
    margin-top: var(--roo-p-space-1);
    border-top: 1px solid var(--roo-border);
    border-radius: 0 0 var(--roo-p-radius-medium) var(--roo-p-radius-medium);
  }

  .roo-switcher-see-all {
    border-radius: var(--roo-p-radius-medium);
  }

  .roo-switcher-prune,
  .roo-switcher-actions {
    display: flex;
    flex: none;
    flex-direction: column;
    margin-top: var(--roo-p-space-1);
    border-top: 1px solid var(--roo-border);
  }

  .roo-switcher-note {
    margin: 0;
    padding: var(--roo-p-space-2) var(--roo-switcher-inset) var(--roo-p-space-1);
    border-top: 1px solid var(--roo-border);
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }

  .roo-switcher-hints {
    display: flex;
    flex: none;
    align-items: center;
    gap: var(--roo-p-space-3);
    margin-top: var(--roo-p-space-1);
    padding: var(--roo-p-space-2) var(--roo-switcher-inset) var(--roo-p-space-1);
    border-top: 1px solid var(--roo-border);
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }

  .roo-switcher-hint {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-1);
  }

  .roo-switcher-empty {
    margin: 0;
    padding: var(--roo-p-space-3) var(--roo-switcher-inset);
    color: var(--roo-muted);
  }
}
</style>

<style>
@layer roo-components {
  .roo-switcher-anchor {
    position: relative;
    display: inline-flex;
  }
}
</style>
