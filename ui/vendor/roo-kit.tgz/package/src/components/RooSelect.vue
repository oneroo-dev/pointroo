<script setup lang="ts" generic="T extends string | number | boolean">
// Inside an app that set data-density on <html> this renders a listbox in a popover; everywhere else it is the native
// select it has always been. The choice is made once, at mount, by looking for [data-density] above the select, and
// it is fixed for the component's life. The `listbox` prop forces the listbox branch anywhere. K8 removes the native branch.
// The `leading` slot sits before the value in both branches. Per-option marks (`mark` plus the `option-mark` slot) exist
// only in the listbox branch: a native <option> can hold text and nothing else, so the native branch cannot draw them.
import { computed, nextTick, onBeforeUnmount, onMounted, ref, useSlots, watch } from 'vue'
import { PopoverContent, PopoverPortal, PopoverRoot, PopoverTrigger, useId } from 'reka-ui'
import RooIcon from './RooIcon.vue'
import RooListbox from './RooListbox.vue'
import RooRowTip from './RooRowTip.vue'
import { useEscapeLayer } from '../composables/useEscapeLayer'
import { useCollisionPadding } from '../composables/useWindowControlPadding'

const model = defineModel<T | undefined>()

const $slots = useSlots()

const props = withDefaults(
  defineProps<{
    /** `disabled` rows stay visible but cannot be chosen; `hint` is a short muted note beside the label. */
    options: { value: T; label: string; disabled?: boolean; hint?: string; mark?: string }[]
    label?: string
    hint?: string
    error?: string
    placeholder?: string
    disabled?: boolean
    required?: boolean
    /** Hide the label visually; it stays the accessible name. */
    hideLabel?: boolean
    /** `lg` is the form field height (--roo-control-h-large); `md` is the toolbar control height (--roo-control-h); `sm` is the compact 28px row (--roo-row-h-actions). */
    size?: 'compact' | 'sm' | 'md' | 'lg'
    /** `quiet` drops the edge and draws the field on --roo-x-field-fill, like RooInput variant quiet. */
    variant?: 'default' | 'quiet'
    /** A short leading word (such as "Sort") shown before the value in the muted colour. It joins the accessible name, never the value. */
    prefix?: string
    /** Force the kit listbox even when no ancestor has [data-density]. The default (false) keeps the density rule. */
    listbox?: boolean
  }>(),
  { label: '', hint: '', error: '', placeholder: '', disabled: false, required: false, hideLabel: false, size: 'lg', variant: 'default', prefix: '', listbox: false },
)

defineSlots<{
  /** Decorative content (such as an environment dot) before the selected value. Hidden from assistive tech. */
  leading?: () => unknown
  /** Decorative mark for an option that carries `mark`: before its label in the listbox and before the value when it is selected. Listbox branch only. */
  'option-mark'?: (scope: { option: { value: T; label: string; disabled?: boolean; hint?: string; mark?: string } }) => unknown
}>()

const id = useId(undefined, 'roo-select')
const root = ref<HTMLElement | null>(null)
// The full value in the kit's tooltip when the value is truncated; the native select and the combobox button already expose it to screen readers.
const valueTip = ref<InstanceType<typeof RooRowTip> | null>(null)
const listboxHandle = ref<{ focus: () => void } | null>(null)
const densityListbox = ref(false)
const useListbox = computed(() => props.listbox || densityListbox.value)
const open = ref(false)
const triggerReference = ref<unknown>(null)
const collisionPadding = useCollisionPadding(open, triggerReference)
useEscapeLayer(() => open.value)

// Esc is consumed here and marked handled (preventDefault), so a window-level Esc action knows the popover already took it.
// reka dismisses without preventing the default, and a prevented default would stop its own dismissal, so we close it.
function onEscapeKeyDown(event: KeyboardEvent): void {
  event.preventDefault()
  open.value = false
}

// The native select's start padding clears the prefix and leading content by their measured width; fonts load late, so
// it is re-measured on resize. getBoundingClientRect gives the unrounded width (offsetWidth rounds 25.2 to 25).
const adornmentElement = ref<HTMLElement | null>(null)
const prefixWidth = ref(0)
let prefixObserver: ResizeObserver | undefined

function measurePrefix(): void {
  prefixWidth.value = adornmentElement.value?.getBoundingClientRect().width ?? 0
}

function observePrefix(): void {
  prefixObserver?.disconnect()
  measurePrefix()
  if (adornmentElement.value && typeof ResizeObserver !== 'undefined') {
    prefixObserver = new ResizeObserver(measurePrefix)
    prefixObserver.observe(adornmentElement.value)
  }
}

onMounted(observePrefix)
watch(adornmentElement, observePrefix, { flush: 'post' })

onBeforeUnmount(() => prefixObserver?.disconnect())

onMounted(() => {
  densityListbox.value = root.value?.closest('[data-density]') != null
})

const accessibleName = computed(() => [props.prefix, props.label].filter(Boolean).join(' ') || undefined)
const selectedOption = computed(() => props.options.find((option) => option.value === model.value))
const selectedLabel = computed(() => selectedOption.value?.label)
// Marks reserve their space on every row once any option has one, so labels start at one x. With none, no span renders.
const hasMarks = computed(() => Boolean($slots['option-mark']) && props.options.some((option) => option.mark !== undefined))
const hasAdornment = computed(() => Boolean(props.prefix))

function focusListbox(event: Event): void {
  event.preventDefault()
  void nextTick(() => listboxHandle.value?.focus())
}

function openFromKey(event: KeyboardEvent): void {
  if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return
  event.preventDefault()
  open.value = true
}
</script>

<template>
  <div ref="root" class="roo-field">
    <label v-if="label" class="roo-field-label" :class="{ 'roo-visually-hidden': hideLabel }" :for="id">
      {{ label }}<span v-if="required" class="roo-field-required" aria-hidden="true">*</span>
    </label>
    <div v-if="!useListbox" class="roo-select-wrap" :data-prefixed="hasAdornment || $slots.leading ? 'true' : undefined" :style="{ '--roo-select-prefix-width': `${prefixWidth}px` }">
      <span v-if="hasAdornment || $slots.leading" ref="adornmentElement" class="roo-select-adornment" aria-hidden="true">
        <span v-if="$slots.leading" class="roo-select-leading"><slot name="leading" /></span>
        <span v-if="prefix" class="roo-select-prefix" aria-hidden="true">{{ prefix }}</span>
      </span>
      <select
        :id="id"
        v-model="model"
        class="roo-field-control roo-select"
        :data-size="size"
        :data-variant="variant"
        :disabled="disabled"
        :aria-label="prefix ? accessibleName : undefined"
        :aria-invalid="error ? 'true' : undefined"
        :aria-required="required ? 'true' : undefined"
        :aria-describedby="error || hint ? `${id}-note` : undefined"
        @pointerenter="valueTip?.enter()"
        @pointerleave="valueTip?.leave()"
        @focus="valueTip?.show()"
        @blur="valueTip?.hide()"
      >
        <option v-if="placeholder" disabled :value="undefined">{{ placeholder }}</option>
        <option v-for="option in options" :key="String(option.value)" :value="option.value" :disabled="option.disabled">
          {{ option.hint ? `${option.label} - ${option.hint}` : option.label }}
        </option>
      </select>
      <RooRowTip v-if="selectedLabel" ref="valueTip" :text="selectedLabel" />
      <RooIcon class="roo-select-chevron" name="chevron-down" :size="16" />
    </div>
    <PopoverRoot v-else v-model:open="open">
      <div class="roo-select-wrap">
        <PopoverTrigger ref="triggerReference" as-child>
          <button
            :id="id"
            type="button"
            class="roo-field-control roo-select-trigger"
            :data-size="size"
            :data-variant="variant"
            role="combobox"
            aria-haspopup="listbox"
            :aria-expanded="open"
            :disabled="disabled"
            :aria-label="prefix ? accessibleName : undefined"
            :aria-invalid="error ? 'true' : undefined"
            :aria-required="required ? 'true' : undefined"
            :aria-describedby="error || hint ? `${id}-note` : undefined"
            @keydown="openFromKey"
            @pointerenter="valueTip?.enter()"
            @pointerleave="valueTip?.leave()"
            @focus="valueTip?.show()"
            @blur="valueTip?.hide()"
          >
            <span v-if="$slots.leading" class="roo-select-leading" aria-hidden="true"><slot name="leading" /></span>
            <span v-if="prefix" class="roo-select-prefix" aria-hidden="true">{{ prefix }}</span>
            <span v-if="hasMarks && selectedOption && selectedOption.mark !== undefined" class="roo-select-mark" aria-hidden="true">
              <slot name="option-mark" :option="selectedOption" />
            </span>
            <span class="roo-select-value" :data-placeholder="selectedLabel === undefined ? 'true' : undefined">
              {{ selectedLabel ?? placeholder }}
            </span>
          </button>
        </PopoverTrigger>
        <RooRowTip v-if="selectedLabel" ref="valueTip" :text="selectedLabel" />
        <RooIcon class="roo-select-chevron" name="chevron-down" :size="16" />
      </div>
      <PopoverPortal>
        <PopoverContent class="roo-select-popover" :side-offset="4" align="start" :collision-padding="collisionPadding" @open-auto-focus="focusListbox" @escape-key-down="onEscapeKeyDown">
          <RooListbox ref="listboxHandle" v-model="model" :options="options" :label="label" @select="open = false" @escape="open = false">
            <template v-if="hasMarks" #dot="{ option }">
              <span class="roo-select-mark" aria-hidden="true">
                <slot v-if="(option as { mark?: string }).mark !== undefined" name="option-mark" :option="option as (typeof options)[number]" />
              </span>
            </template>
          </RooListbox>
        </PopoverContent>
      </PopoverPortal>
    </PopoverRoot>
    <p
      v-if="error || hint"
      :id="`${id}-note`"
      class="roo-field-note"
      :data-error="error ? 'true' : undefined"
      :role="error ? 'alert' : undefined"
    >
      {{ error || hint }}
    </p>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-field {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .roo-field-label {
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    font-weight: 500;
    color: var(--roo-muted);
  }

  .roo-field-required {
    margin-left: 2px;
    color: var(--roo-danger-text);
  }

  .roo-select-wrap {
    /* Must equal the control's border width below: the native padding starts after the border. */
    --roo-select-border: 1px;
    /* The chevron sits (field padding less 2) from the edge, is --roo-icon wide and leaves 6 before the value: 10 + 16 + 6 = 32 at comfortable. */
    --roo-select-chevron-right: calc(var(--roo-field-pad-x) - 2px);
    --roo-select-chevron-area: calc(var(--roo-select-chevron-right) + var(--roo-icon) + 6px);
    position: relative;
    /* A select never shrinks below its padding, a readable value and the chevron: at phone width it keeps its value (ellipsis past
       this) instead of collapsing to a bare chevron. There is no kit filter bar; an app lets its own filter row wrap before this floor binds. */
    min-width: calc(var(--roo-field-pad-x) + var(--roo-select-value-min) + var(--roo-select-chevron-area));
  }

  /* Under compact density a whole-pixel line box keeps the value on a whole pixel: (height minus border minus line) is even. */
  :root[data-density='compact'] .roo-field-control {
    line-height: var(--roo-control-line);
  }

  .roo-field-control {
    width: 100%;
    box-sizing: border-box;
    height: var(--roo-field-h);
    appearance: none;
    border: 1px solid var(--roo-field-edge);
    border-radius: var(--roo-radius-control);
    background: var(--roo-surface);
    padding: 0 var(--roo-select-chevron-area) 0 var(--roo-field-pad-x);
    text-overflow: ellipsis;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-ui-size);
    color: var(--roo-text);
    cursor: default;
    transition:
      border-color var(--roo-fast) var(--roo-ease),
      box-shadow var(--roo-fast) var(--roo-ease);
  }

  .roo-field-control[data-size='md'] {
    height: var(--roo-control-h);
  }

  /* Dense filter-row popup: the fixed compact height, the item padding, the small corner and 12px text. */
  .roo-field-control[data-size='compact'] {
    height: var(--roo-compact-control-h);
    padding: 0 24px 0 var(--roo-space-item);
    border-radius: var(--roo-p-radius-small);
    font-size: var(--roo-p-size-12);
  }

  .roo-select-wrap:has(.roo-field-control[data-size='compact']) > .roo-select-chevron {
    right: 6px;
  }

  .roo-field-control[data-variant='quiet'] {
    border-color: transparent;
    background: var(--roo-raised);
  }

  .roo-field-control[data-variant='quiet']:hover:not(:disabled) {
    border-color: transparent;
    background: color-mix(in srgb, var(--roo-raised) 88%, var(--roo-text));
  }

  .roo-field-control[data-size='sm'] {
    height: var(--roo-row-h-actions);
  }

  .roo-field-control:hover:not(:disabled):not([aria-invalid='true']) {
    border-color: var(--roo-border-hover);
  }

  /* Focus turns the border the focus colour and brightens the fill. A select trigger has no caret, so unlike a typed field it also keeps the 2px keyboard ring (Fable review Q2, Raja: apply all). */
  .roo-field-control:focus {
    outline: none;
  }

  .roo-field-control:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: var(--roo-focus-offset);
  }

  .roo-field-control:focus:not(:disabled) {
    background: var(--roo-field-focus-fill);
  }

  .roo-field-control:focus:not(:disabled):not([aria-invalid='true']) {
    border-color: var(--roo-focus);
  }

  .roo-field-control:disabled {
    background: var(--roo-raised);
    border-color: transparent;
    color: var(--roo-faint);
    opacity: 1;
    cursor: default;
  }

  .roo-select-trigger {
    display: flex;
    align-items: center;
    text-align: left;
  }

  .roo-select-prefix {
    flex: none;
    margin-inline-end: 8px;
    color: var(--roo-muted);
    white-space: nowrap;
  }

  .roo-select-leading,
  .roo-select-mark {
    display: inline-flex;
    flex: none;
    align-items: center;
  }

  /* The family's mark is RooEnvDot, whose largest size is a 12px cell (RooEnvDot.vue). An empty mark still holds that
     width, so labels start at the same x on marked and unmarked rows. The cell is a flex row centred on both axes, so the
     mark sits on the label's line with no nudge. */
  .roo-select-mark {
    min-width: 12px;
    justify-content: center;
    align-items: center;
  }

  .roo-select-leading,
  .roo-select-trigger .roo-select-mark {
    margin-inline-end: 8px;
  }

  /* On the native select the prefix and leading content sit over the control's own padding, so the text starts after
     them. The padding starts after the 1px border while the adornment is placed from the wrapper edge, so the border
     is taken off: the gap to the value is then exactly the measured width + 8. */
  .roo-select-wrap[data-prefixed='true'] > .roo-select {
    padding-inline-start: calc(var(--roo-field-pad-x) + var(--roo-select-prefix-width) + 8px - var(--roo-select-border));
  }

  .roo-select-wrap[data-prefixed='true'] > .roo-select-adornment {
    position: absolute;
    top: 50%;
    left: 12px;
    display: inline-flex;
    align-items: center;
    transform: translateY(-50%);
    pointer-events: none;
  }

  .roo-select-adornment > :last-child {
    margin-inline-end: 0;
  }

  /* A value that does not fit ends in an ellipsis on the native select too, never cut mid-word. */
  .roo-select {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-select-value {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-select-value[data-placeholder='true'] {
    color: var(--roo-faint);
  }

  .roo-field-note {
    margin: 0;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    color: var(--roo-faint);
  }

  .roo-field-note[data-error='true'] {
    color: var(--roo-danger-text);
  }

  .roo-field-control[aria-invalid='true'] {
    border-color: var(--roo-danger);
  }

  .roo-select-chevron {
    position: absolute;
    top: 50%;
    right: var(--roo-select-chevron-right);
    width: var(--roo-icon);
    height: var(--roo-icon);
    transform: translateY(-50%);
    pointer-events: none;
    color: var(--roo-faint);
  }
}
</style>

<!-- Not scoped: the popover is portalled into body, outside this component's elements. -->
<style>
@layer roo-components {
  .roo-select-popover {
    z-index: 80;
    min-width: var(--reka-popover-trigger-width);
    box-sizing: border-box;
    border-radius: var(--roo-radius-popover);
    background: var(--roo-surface);
    box-shadow: var(--roo-shadow-popover);
    animation: roo-pop var(--roo-fast) var(--roo-ease) both;
    transform-origin: var(--reka-popover-content-transform-origin, var(--reka-popper-transform-origin, center));
  }

  .roo-select-popover[data-state='closed'] {
    animation: roo-pop-out calc(var(--roo-fast) * 0.625) var(--roo-exit) both;
  }
}
</style>
