<script setup lang="ts">
// A main action plus a chevron that opens related actions, like the macOS pull-down (NSComboButton).
// While the main action is busy the chevron stays usable. Example: Edit connection -> [Save | v] with "Save and connect" in the menu.
// Hold fill: the main half (never the chevron) draws the same rising fill as RooHoldButton, with the same tokens, direction
// and reduced-motion rule. `holdProgress` (0..1; undefined = no fill) drives it, and is also written to the main half as the
// CSS variable `--roo-hold-progress`. `mainAttrs` is v-bound on the main half, so an app can pass the confirm gesture's
// button attrs (`gesture.bindings.value`) and the pointer, key and data-holding handling lands on the main half:
//   <RooSplitButton :main-attrs="gesture.bindings.value" :hold-progress="gesture.progress.value">
// Optional `icon` slot: forwarded to the main button's icon cell. `busyStyle` is passed to the main half: `centred` (the
// default) hides the icon and label in place under one centred loader; `leading` swaps the glyph for the loader. No slot, no change.
// data-holding in mainAttrs alone shows the fill element at 0 until holdProgress arrives.
import { computed } from 'vue'
import RooButton from './RooButton.vue'
import RooIcon from './RooIcon.vue'
import RooMenu from './RooMenu.vue'

const props = withDefaults(
  defineProps<{
    variant?: 'primary' | 'secondary'
    size?: 'sm' | 'md' | 'lg'
    type?: 'button' | 'submit'
    disabled?: boolean
    loading?: boolean
    busy?: boolean
    /** Where the main half's loader sits while busy, as RooButton's `busyStyle`. */
    busyStyle?: 'centred' | 'leading'
    menuLabel?: string
    /** Hold fill progress, 0 to 1. Undefined draws no fill. */
    holdProgress?: number
    /** Attributes bound on the main half, e.g. the confirm gesture's button bindings. */
    mainAttrs?: Record<string, unknown>
  }>(),
  { variant: 'secondary', size: 'md', type: 'button', disabled: false, loading: false, busy: false, busyStyle: 'centred', menuLabel: 'More options' },
)

const emit = defineEmits<{ click: [event: MouseEvent] }>()
const open = defineModel<boolean>('open', { default: false })

const showFill = computed(() => props.holdProgress !== undefined || Boolean(props.mainAttrs?.['data-holding']))
const clampedProgress = computed(() => Math.min(1, Math.max(0, props.holdProgress ?? 0)))
const mainStyle = computed(() => (showFill.value ? { '--roo-hold-progress': String(clampedProgress.value) } : undefined))
</script>

<template>
  <div class="roo-split-button" role="group" :data-variant="variant">
    <RooButton
      class="roo-split-button-main"
      :variant="variant"
      :size="size"
      :type="type"
      :disabled="disabled"
      :loading="loading"
      :busy="busy"
      :busy-style="busyStyle"
      :style="mainStyle"
      v-bind="mainAttrs"
      @click="(event: MouseEvent) => emit('click', event)"
    >
      <template v-if="$slots.icon" #icon><slot name="icon" /></template>
      <span v-if="showFill" class="roo-split-fill" aria-hidden="true"></span>
      <slot />
    </RooButton>
    <RooMenu v-model:open="open" align="end">
      <template #trigger>
        <RooButton
          class="roo-split-button-chevron"
          :variant="variant"
          :size="size"
          :disabled="disabled"
          :aria-label="menuLabel"
        >
          <RooIcon name="chevron-down" :size="16" />
        </RooButton>
      </template>
      <slot name="menu" />
    </RooMenu>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-split-button {
    display: inline-flex;
    flex-shrink: 0;
    align-items: stretch;
  }

  .roo-split-button :deep(.roo-split-button-main) {
    border-top-right-radius: 0;
    border-bottom-right-radius: 0;
  }

  .roo-split-button :deep(.roo-split-button-main) {
    isolation: isolate;
    overflow: hidden;
  }

  /* Same fills as RooHoldButton, per variant. Reduced motion hides the fill, not the hold. */
  .roo-split-fill {
    position: absolute;
    inset: 0;
    z-index: -1;
    background: color-mix(in srgb, var(--roo-text) 12%, transparent);
    transform-origin: left center;
    transform: scaleX(var(--roo-hold-progress, 0));
    transition: transform 150ms var(--roo-exit);
  }

  .roo-split-button[data-variant='primary'] .roo-split-fill {
    background: color-mix(in srgb, var(--roo-p-white) 30%, transparent);
  }

  .roo-split-button :deep(.roo-split-button-main[data-holding='true']) .roo-split-fill {
    transition: none;
  }

  .roo-force-reduced .roo-split-fill,
  [data-motion='still'] .roo-split-fill {
    display: none;
  }

  @media (prefers-reduced-motion: reduce) {
    .roo-split-fill {
      display: none;
    }
  }

  .roo-split-button :deep(.roo-split-button-chevron) {
    margin-left: 1px;
    padding-left: var(--roo-control-pad-chevron);
    padding-right: var(--roo-control-pad-chevron);
    border-top-left-radius: 0;
    border-bottom-left-radius: 0;
  }

  .roo-split-button[data-variant='secondary'] :deep(.roo-split-button-chevron) {
    margin-left: -1px;
  }

  /* Filled halves meet with no gap: a 1 px line in black at 15 percent, as in macOS split buttons (Raja 2026-11-17). */
  .roo-split-button[data-variant='primary'] :deep(.roo-split-button-chevron),
  .roo-split-button[data-variant='prod'] :deep(.roo-split-button-chevron) {
    margin-left: 0;
    box-shadow: inset 1px 0 0 rgb(0 0 0 / 15%);
  }

  /* The focused half rides above the other so its ring is not painted over where the halves meet. */
  .roo-split-button :deep(.roo-split-button-main),
  .roo-split-button :deep(.roo-split-button-chevron) {
    position: relative;
  }

  .roo-split-button :deep(.roo-split-button-main:focus-visible),
  .roo-split-button :deep(.roo-split-button-chevron:focus-visible) {
    z-index: 1;
  }

  /* Outlined halves keep a quiet divider line, not black on a near-black button. */
  .roo-split-button[data-variant='secondary'] :deep(.roo-split-button-chevron) {
    box-shadow: inset 1px 0 0 var(--roo-border-floating);
  }
}
</style>
