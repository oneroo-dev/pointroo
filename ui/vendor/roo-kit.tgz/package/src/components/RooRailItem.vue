<script setup lang="ts">
// One rail button: a glyph (an icon or an app tile), an 11 px label, an optional badge and an environment dot shaped
// by environment. In a `contexts` rail it is 48 wide and carries a meta line: the full environment word for prod and
// unclassified (lowercase here, capitals from CSS, never shortened) and an optional health word. Selected is the
// selection fill plus semibold, no ring; `aria-current="page"` carries it for assistive technology. A `menu` slot opens
// a menu at the pointer on right click. `size="card"` is the A2 card (Raja approved 2026-11-14): 96 x 84, a database icon
// over a label that holds two lines at most (the label, then an optional ": schema"), inside a RooRail of size card. The
// selected card joins the panel beside the rail. `size="card-narrow"` is the icon-only card, 52 x 52 in a 64 rail: the label is its accessible name (aria-label) and its RooTooltip, which needs the RooTooltipProvider every app mounts, and it joins the panel like the A2 card. The card's `label-prefix` slot puts a mark (a status dot) before line one; the pair is centred as a group on the label's centre line. `lost` adds the amber lost-connection dot; `environment` colours the icon.
import { computed, inject, ref, useAttrs, type ComputedRef, type FunctionalComponent } from 'vue'
import RooAnchoredMenu from './RooAnchoredMenu.vue'
import RooEnvDot from './RooEnvDot.vue'
import RooIcon from './RooIcon.vue'
import RooTooltip from './RooTooltip.vue'
import type { RooIconName } from '../icons/paths'
import type { RooEnvironmentWord } from '../types/environment'

defineOptions({ inheritAttrs: false })

const props = defineProps<{
  label: string
  icon?: RooIconName
  /** Text for an app tile (a letter or two), shown in place of the icon. */
  tile?: string
  selected?: boolean
  badge?: number | string
  environment?: RooEnvironmentWord
  /** A tag for the meta line of a contexts item. Defaults to the environment word for prod and unclassified. */
  tag?: string
  health?: 'ok' | 'warn' | 'down'
  size?: 'default' | 'card' | 'card-narrow'
  /** Card only: the second label line, drawn as ": schema". */
  schema?: string
  /** Card only: the connection is lost, so the amber dot shows on the icon. */
  lost?: boolean
}>()
const emit = defineEmits<{ select: [] }>()

const isNarrow = computed(() => props.size === 'card-narrow')
const isCard = computed(() => props.size === 'card' || isNarrow.value)
const attrs = useAttrs()
const narrowName = computed(() => (props.schema ? `${props.label}: ${props.schema}` : props.label))
// Only the narrow card wraps itself in a tooltip; every other item renders its button bare, so it needs no provider.
const passThrough: FunctionalComponent = (_props, { slots }) => slots['default']?.()
// The app's own aria-label wins on every size; only the narrow card, which shows no words, falls back to its visible name.
const accessibleName = computed(() => (typeof attrs['aria-label'] === 'string' ? attrs['aria-label'] : isNarrow.value ? narrowName.value : undefined))
const wrapper = computed(() => (isNarrow.value ? RooTooltip : passThrough))
const wrapperProps = computed(() => (isNarrow.value ? { text: narrowName.value, side: 'right' as const } : {}))
const kind = inject<ComputedRef<'navigation' | 'contexts'>>('roo-rail-kind', computed(() => 'navigation'))
const metaTag = computed(() => props.tag ?? (props.environment === 'prod' || props.environment === 'unclassified' ? props.environment : ''))

const menuOpen = ref(false)
const menuX = ref(0)
const menuY = ref(0)

function onContextMenu(event: MouseEvent): void {
  event.preventDefault()
  menuX.value = event.clientX
  menuY.value = event.clientY
  menuOpen.value = true
}
</script>

<template>
  <component :is="wrapper" v-bind="wrapperProps">
    <button
      v-bind="$attrs"
      type="button"
      class="roo-rail-item"
      data-roving-item
      :data-kind="kind"
      :data-tiled="tile ? '' : undefined"
      :data-size="isCard ? size : undefined"
      :data-environment="isCard ? environment : undefined"
      :aria-label="accessibleName"
      :aria-current="selected ? 'page' : undefined"
      @click="emit('select')"
      @contextmenu="$slots.menu ? onContextMenu($event) : undefined"
    >
      <span class="roo-rail-item-glyph">
        <span v-if="tile" class="roo-rail-item-tile" aria-hidden="true">{{ tile }}</span>
        <RooIcon v-else-if="icon" :name="icon" :size="isCard ? 28 : 20" />
        <RooEnvDot v-if="environment && !isCard" class="roo-rail-item-env" :environment="environment" />
        <span v-if="isCard && lost" class="roo-rail-item-lost" aria-hidden="true" />
        <span v-if="badge !== undefined" class="roo-rail-item-badge">{{ badge }}</span>
      </span>
      <span v-if="!isNarrow" class="roo-rail-item-label">
        <span v-if="isCard && $slots['label-prefix']" class="roo-rail-item-label-line">
          <span class="roo-rail-item-prefix"><slot name="label-prefix" /></span>
          <span class="roo-rail-item-label-text">{{ label }}</span>
        </span>
        <template v-else>{{ label }}</template>
      </span>
      <span v-if="isCard && !isNarrow && schema" class="roo-rail-item-schema">: {{ schema }}</span>
      <span v-if="kind === 'contexts' && !isCard" class="roo-rail-item-meta">
        <span v-if="metaTag" class="roo-rail-item-tag">{{ metaTag }}</span>
        <span v-if="health" class="roo-rail-item-health" :data-health="health"><span class="roo-visually-hidden">{{ health }}</span></span>
      </span>
    </button>
  </component>
  <RooAnchoredMenu v-if="$slots.menu" v-model:open="menuOpen" :x="menuX" :y="menuY"><slot name="menu" /></RooAnchoredMenu>
</template>

<style scoped>
@layer roo-components {
  .roo-rail-item {
    display: flex;
    width: calc(var(--roo-rail-w) - 16px);
    flex: none;
    flex-direction: column;
    align-items: center;
    gap: 2px;
    box-sizing: border-box;
    border: 0;
    border-radius: var(--roo-p-radius-medium);
    background: transparent;
    padding: 4px 0;
    color: var(--roo-muted);
    font-family: var(--roo-font-ui);
    cursor: default;
    transition: color var(--roo-fast) var(--roo-ease), background-color var(--roo-fast) var(--roo-ease);
  }

  .roo-rail-item[data-kind='contexts'],
  .roo-rail-item[data-tiled] {
    width: calc(var(--roo-rail-w) - 8px);
  }

  .roo-rail-item[data-tiled] .roo-rail-item-label {
    font-size: var(--roo-p-size-11);
  }

  .roo-rail-item:hover {
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  .roo-rail-item:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 1px;
  }

  /* Selected: the selection fill and semibold, never a ring or an edge bar. */
  .roo-rail-item[aria-current='page'] {
    background: var(--roo-select);
    font-weight: 600;
    color: var(--roo-text);
  }

  .roo-rail-item-glyph {
    position: relative;
    display: grid;
    width: calc(var(--roo-icon) + 8px);
    height: calc(var(--roo-icon) + 8px);
    place-items: center;
  }

  .roo-rail-item-tile {
    display: grid;
    width: calc(var(--roo-icon) + 8px);
    height: calc(var(--roo-icon) + 8px);
    place-items: center;
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-raised);
    color: var(--roo-text);
    font-size: var(--roo-p-size-12);
    font-weight: 600;
  }

  .roo-rail-item-env {
    position: absolute;
    inset-block-end: -2px;
    inset-inline-end: -4px;
  }

  .roo-rail-item-badge {
    position: absolute;
    inset-block-start: -4px;
    inset-inline-end: -8px;
    box-sizing: border-box;
    min-width: var(--roo-icon);
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-text);
    padding-inline: 4px;
    color: var(--roo-bg);
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
    line-height: var(--roo-icon);
    text-align: center;
    white-space: nowrap;
  }

  .roo-rail-item-label {
    max-width: 100%;
    overflow: hidden;
    font-size: var(--roo-p-size-12);
    line-height: 1.2;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-rail-item[data-kind='contexts'][aria-current='page'] .roo-rail-item-label {
    font-weight: 600;
  }

  .roo-rail-item-meta {
    display: flex;
    max-width: 100%;
    align-items: center;
    gap: 4px;
    font-size: var(--roo-p-size-12);
    line-height: 1.2;
  }

  .roo-rail-item-tag {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    color: var(--roo-muted);
  }

  .roo-rail-item-health {
    width: 8px;
    height: 8px;
    flex: none;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-muted);
  }

  .roo-rail-item-health[data-health='ok'] {
    background: var(--roo-ok);
  }

  .roo-rail-item-health[data-health='warn'] {
    background: var(--roo-warn);
  }

  .roo-rail-item-health[data-health='down'] {
    background: var(--roo-danger);
  }

  /* The A2 card. Every measure is an anatomy token; the glyph box is the density icon tile. */
  .roo-rail-item[data-size='card'] {
    width: var(--roo-rail-card-w);
    height: var(--roo-rail-card-h);
    justify-content: center;
    gap: var(--roo-space-item);
    padding: var(--roo-space-item) var(--roo-p-space-1);
    border-radius: var(--roo-p-radius-card);
  }

  .roo-rail-item[data-size='card'] .roo-rail-item-glyph {
    width: var(--roo-icon-tile);
    height: var(--roo-icon-tile);
  }

  .roo-rail-item[data-size='card'][data-environment='local'] .roo-rail-item-glyph {
    color: var(--roo-env-local);
  }

  .roo-rail-item[data-size='card'][data-environment='testing'] .roo-rail-item-glyph {
    color: var(--roo-env-testing);
  }

  .roo-rail-item[data-size='card'][data-environment='development'] .roo-rail-item-glyph {
    color: var(--roo-env-development);
  }

  .roo-rail-item[data-size='card'][data-environment='staging'] .roo-rail-item-glyph {
    color: var(--roo-env-staging);
  }

  .roo-rail-item[data-size='card'][data-environment='prod'] .roo-rail-item-glyph {
    color: var(--roo-env-prod);
  }

  /* Line one is the label and never splits; line two is ": schema". Each is its own block and ends in an ellipsis. */
  .roo-rail-item[data-size='card'] .roo-rail-item-label,
  .roo-rail-item[data-size='card'] .roo-rail-item-schema {
    display: block;
    width: var(--roo-rail-card-label-w);
    overflow: hidden;
    font-size: var(--roo-p-size-12);
    line-height: 1.25;
    text-align: center;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  /* The prefix mark and the label text are one centred group: the line is a flex row on the centre line, the text clips with an ellipsis. */
  .roo-rail-item-label-line {
    display: flex;
    min-width: 0;
    align-items: center;
    justify-content: center;
    gap: var(--roo-p-space-1);
  }

  .roo-rail-item-prefix {
    display: inline-flex;
    flex: none;
    align-items: center;
  }

  .roo-rail-item-label-text {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  /* The narrow card: a 52 square holding the icon only, centred. */
  .roo-rail-item[data-size='card-narrow'] {
    width: var(--roo-rail-card-narrow-w);
    height: var(--roo-rail-card-narrow-h);
    justify-content: center;
    padding: 0;
    border-radius: var(--roo-p-radius-card);
  }

  .roo-rail-item[data-size='card-narrow'] .roo-rail-item-glyph {
    width: var(--roo-icon-tile);
    height: var(--roo-icon-tile);
  }

  .roo-rail-item[data-size='card-narrow'][data-environment='local'] .roo-rail-item-glyph {
    color: var(--roo-env-local);
  }

  .roo-rail-item[data-size='card-narrow'][data-environment='testing'] .roo-rail-item-glyph {
    color: var(--roo-env-testing);
  }

  .roo-rail-item[data-size='card-narrow'][data-environment='development'] .roo-rail-item-glyph {
    color: var(--roo-env-development);
  }

  .roo-rail-item[data-size='card-narrow'][data-environment='staging'] .roo-rail-item-glyph {
    color: var(--roo-env-staging);
  }

  .roo-rail-item[data-size='card-narrow'][data-environment='prod'] .roo-rail-item-glyph {
    color: var(--roo-env-prod);
  }

  .roo-rail-item[data-size='card-narrow']:hover:not([aria-current='page']) {
    background: var(--roo-raised-hover);
    color: var(--roo-text);
  }

  /* Selected: joined to the panel exactly like the A2 card, over the 64 rail. */
  .roo-rail-item[data-size='card-narrow'][aria-current='page'] {
    width: var(--roo-rail-card-narrow-rail-w);
    margin-inline: calc(-1 * (var(--roo-rail-card-narrow-rail-w) - var(--roo-rail-card-narrow-w)) / 2);
    border-radius: 0;
    background: var(--roo-x-side);
    font-weight: 400;
    color: var(--roo-text);
  }

  /* Hover on the raised rail: raised itself would show nothing, so the matched step. */
  .roo-rail-item[data-size='card']:hover:not([aria-current='page']) {
    background: var(--roo-raised-hover);
    color: var(--roo-text);
  }

  /* Selected: joined to the panel on the rail's right. The panel fill, the whole rail width (over the edge line and flush to
     the window edge), square corners. The margin takes back the gap each side of a resting card, so the card stays centred. */
  .roo-rail-item[data-size='card'][aria-current='page'] {
    width: var(--roo-rail-card-rail-w);
    margin-inline: calc(-1 * (var(--roo-rail-card-rail-w) - var(--roo-rail-card-w)) / 2);
    border-radius: 0;
    background: var(--roo-x-side);
    font-weight: 400;
    color: var(--roo-text);
  }

  /* The lost dot: the amber fill token with a 2px ring in the rail's colour (the panel's, on the joined card). */
  .roo-rail-item-lost {
    position: absolute;
    inset-block-start: calc(-1 * var(--roo-p-space-1));
    inset-inline-end: calc(-1 * var(--roo-p-space-1));
    z-index: 1;
    box-sizing: border-box;
    width: var(--roo-p-space-3);
    height: var(--roo-p-space-3);
    border: 2px solid var(--roo-raised);
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-status-orange-fill);
  }

  .roo-rail-item[aria-current='page'] .roo-rail-item-lost {
    border-color: var(--roo-x-side);
  }
}
</style>
