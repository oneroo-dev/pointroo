<script lang="ts">
export interface RooRuleOption {
  value: string
  label: string
}

export interface RooRuleRowValue {
  /** A stable key for the row, so a list keeps focus and state when rows are added or removed. */
  key: string | number
  /** The condition: which field the rule tests. */
  field: string
  /** The operator, such as `is` or `contains`. */
  operator: string
  /** The value the field is tested against. */
  value: string
}
</script>

<script setup lang="ts">
// One row of a rule builder: condition, operator, value, remove. The row is a container, so it folds to two lines (value full width below) when the
// row itself is narrow (field and operator on the first line with the remove button at the end, the value below), whatever the window width. Every control
// has its own accessible name; the lead word ("When", "and") is read as part of the group name.
import { computed } from 'vue'
import RooIconButton from './RooIconButton.vue'
import RooInput from './RooInput.vue'
import RooSelect from './RooSelect.vue'

const model = defineModel<RooRuleRowValue>({ required: true })

const props = withDefaults(
  defineProps<{
    /** The conditions to pick from. */
    fieldOptions: RooRuleOption[]
    /** The operators to pick from. */
    operatorOptions: RooRuleOption[]
    /** The values to pick from, per field. A field with no entry takes free text. */
    valueOptions?: Record<string, RooRuleOption[]>
    /** The small word before the row, such as `When`, `and` or `or`. */
    lead?: string
    /** Accessible names for the four controls. */
    fieldLabel?: string
    operatorLabel?: string
    valueLabel?: string
    removeLabel?: string
    valuePlaceholder?: string
    /** The remove button is disabled (for the last row a rule must keep). */
    removeDisabled?: boolean
    disabled?: boolean
    /** `select` draws the operator as a select; `words` shows the chosen operator's label as plain words, such as "is". */
    operatorDisplay?: 'select' | 'words'
  }>(),
  {
    valueOptions: () => ({}),
    lead: '',
    fieldLabel: 'Condition',
    operatorLabel: 'Operator',
    valueLabel: 'Value',
    removeLabel: 'Remove condition',
    valuePlaceholder: '',
    removeDisabled: false,
    disabled: false,
    operatorDisplay: 'select',
  },
)

const emit = defineEmits<{ remove: [key: string | number] }>()

const choicesForField = computed(() => props.valueOptions[model.value.field])
const operatorWords = computed(() => props.operatorOptions.find((option) => option.value === model.value.operator)?.label ?? model.value.operator)

function changeField(field: string | undefined): void {
  if (field === undefined || field === model.value.field) return
  model.value = { ...model.value, field, value: '' }
}

function changeOperator(operator: string | undefined): void {
  if (operator === undefined) return
  model.value = { ...model.value, operator }
}

function changeValue(value: string | number | undefined): void {
  model.value = { ...model.value, value: value === undefined ? '' : String(value) }
}
</script>

<template>
  <div class="roo-rule-row" role="group" :aria-label="lead ? `${lead} ${fieldLabel}` : fieldLabel" :data-disabled="disabled ? '' : undefined">
    <div class="roo-rule-row-body" :data-lead="lead ? '' : undefined" :data-operator="operatorDisplay">
    <span v-if="lead" class="roo-rule-row-lead" aria-hidden="true">{{ lead }}</span>
    <RooSelect
      class="roo-rule-row-field"
      :model-value="model.field"
      :label="fieldLabel"
      hide-label
      size="md"
      :disabled="disabled"
      :options="fieldOptions"
      @update:model-value="changeField"
    />
    <span v-if="operatorDisplay === 'words'" class="roo-rule-row-operator-words">{{ operatorWords }}</span>
    <RooSelect
      v-else
      class="roo-rule-row-operator"
      :model-value="model.operator"
      :label="operatorLabel"
      hide-label
      size="md"
      :disabled="disabled"
      :options="operatorOptions"
      @update:model-value="changeOperator"
    />
    <RooSelect
      v-if="choicesForField"
      class="roo-rule-row-value"
      :model-value="model.value"
      :label="valueLabel"
      hide-label
      size="md"
      :placeholder="valuePlaceholder"
      :disabled="disabled"
      :options="choicesForField"
      @update:model-value="changeValue"
    />
    <RooInput
      v-else
      class="roo-rule-row-value"
      :model-value="model.value"
      :aria-label="valueLabel"
      size="md"
      :placeholder="valuePlaceholder"
      :disabled="disabled"
      @update:model-value="changeValue"
    />
    <RooIconButton
      class="roo-rule-row-remove"
      icon="x"
      size="md"
      :label="removeLabel"
      :disabled="disabled || removeDisabled"
      @click="emit('remove', model.key)"
    />
    </div>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-rule-row {
    container-type: inline-size;
    font-family: var(--roo-font-ui);
  }

  .roo-rule-row-body {
    --roo-rule-operator-track: minmax(0, 1fr);
    display: grid;
    grid-template-columns: minmax(0, 1fr) var(--roo-rule-operator-track) minmax(0, 1fr) auto;
    align-items: center;
    gap: var(--roo-p-space-2);
  }

  .roo-rule-row-body[data-lead] {
    grid-template-columns: auto minmax(0, 1fr) var(--roo-rule-operator-track) minmax(0, 1fr) auto;
  }

  .roo-rule-row-body[data-operator='words'] {
    --roo-rule-operator-track: auto;
  }

  .roo-rule-row-lead {
    /* One shared lead column: every row holds the same width (sized for the longest lead word, such as a translated "When"), so the first select starts at one x. */
    min-width: 4.5em;
    font-size: var(--roo-p-size-12);
    font-weight: 600;
    color: var(--roo-muted);
  }

  .roo-rule-row-operator-words {
    font-size: var(--roo-p-size-13);
    color: var(--roo-muted);
    white-space: nowrap;
  }

  .roo-rule-row[data-disabled] .roo-rule-row-lead {
    color: var(--roo-faint);
    opacity: 1;
  }

  .roo-rule-row-remove {
    justify-self: end;
  }

  /* Fold: below 28rem of row width (one-line minimum: 3 selects at about 108px + remove 36px + 3 gaps of 8px, plus the lead, is about 28rem)
     the field and operator share the first line with the remove button at its end, and the value takes the full line below. */
  @container (max-width: 28rem) {
    .roo-rule-row-body {
      grid-template-columns: minmax(0, 1fr) var(--roo-rule-operator-track) auto;
    }

    .roo-rule-row-body[data-lead] {
      grid-template-columns: auto minmax(0, 1fr) var(--roo-rule-operator-track) auto;
    }

    .roo-rule-row-field {
      grid-row: 1;
    }

    .roo-rule-row-operator,
    .roo-rule-row-operator-words {
      grid-row: 1;
    }

    .roo-rule-row-remove {
      grid-row: 1;
      grid-column: -2;
    }

    .roo-rule-row-value {
      grid-row: 2;
      grid-column: 1 / -1;
      justify-self: stretch;
      width: 100%;
      min-width: 0;
      margin: 0;
    }

    .roo-rule-row-body[data-lead] .roo-rule-row-lead {
      grid-row: 1;
    }

  }
}
</style>
