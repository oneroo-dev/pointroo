<script setup lang="ts">
import { computed } from 'vue'
import RooAvatar from './RooAvatar.vue'
import RooIcon from './RooIcon.vue'

// A plain chip: a short label with an optional leading dot or icon. Sizes and colours are kit tokens only. `interactive`
// makes it a real button (the "+N" of a RooChipGroup is one); without it the chip is a plain status.
// `shape="tag"` (the default) is the 18px chip with the tag corner; `shape="pill"` is the 22px fully rounded chip, on request. `mono` is the go-to-line chip
// ("L12"): a tag-shaped, bordered, mono chip. Make it `interactive` and it is a button with the standard control hover
// (raised fill, full-strength text) and the kit focus ring. `tone="outline"` is a transparent pill with a 1px border.
// `size="small"` is the 8px-inset small-type chip (20 tall, clickable or not, so a row stays one height). `removable` adds a
// trailing x button named "Remove <label>"; it emits `remove`, as do Backspace and Delete on the focused chip.
const props = withDefaults(
  defineProps<{
    label?: string
    tone?: 'neutral' | 'accent' | 'ok' | 'warn' | 'danger' | 'outline'
    /** A small dot in the tone's colour before the label. The `leading` slot takes an icon instead. */
    dot?: boolean
    /** A status chip shows a 6px dot inside its pale pill, in light and dark. Neutral and outline get a muted grey dot; accent, ok, warn and danger get a dot in the ink colour. Off by default. No effect when `dot` is set. */
    statusDot?: boolean
    interactive?: boolean
    /** `tag` is the default: the 18px chip with the tag corner (Raja 2026-11-22: "the middle one, not the fully rounded version"). `pill` is the 22px fully rounded chip, on request. */
    shape?: 'pill' | 'tag'
    /** The mono go-to-line chip: tag shape, border, mono font. Ignores `tone` colours. */
    mono?: boolean
    /** `small` is the 8px-inset chip in the small type size. */
    size?: 'default' | 'small'
    /** A trailing x button that emits `remove`. */
    removable?: boolean
    /** A teammate: the person's name. Shows a round initials badge before the label (the label is the name unless you give one). */
    person?: string
  }>(),
  { label: '', tone: 'neutral', dot: false, statusDot: false, interactive: false, shape: 'tag', mono: false, size: 'default', removable: false, person: '' },
)

const emit = defineEmits<{ remove: [] }>()

const removeName = computed(() => `Remove ${props.label}`.trim())

function onKeydown(event: KeyboardEvent) {
  if (!props.removable || (event.key !== 'Backspace' && event.key !== 'Delete')) return
  event.preventDefault()
  emit('remove')
}
</script>

<template>
  <component :is="interactive ? 'button' : 'span'" class="roo-chip" :type="interactive ? 'button' : undefined" :data-tone="tone" :data-interactive="interactive" :data-shape="mono ? 'tag' : shape" :data-mono="mono || undefined" :data-size="size" :data-status-dot="statusDot || undefined" :data-removable="removable || undefined" :tabindex="removable && !interactive ? 0 : undefined" @keydown="onKeydown">
    <span v-if="dot" class="roo-chip-dot" aria-hidden="true" />
    <span v-if="person" class="roo-chip-person" aria-hidden="true"><RooAvatar :name="person" :size="16" single /></span>
    <span v-if="$slots.leading" class="roo-chip-leading"><slot name="leading" /></span>
    <span class="roo-chip-label"><slot>{{ label || person }}</slot></span>
    <button v-if="removable" class="roo-chip-remove" type="button" :aria-label="removeName" tabindex="-1" @click.stop="emit('remove')"><RooIcon name="x" :size="12" /></button>
  </component>
</template>

<style scoped>
@layer roo-components {
  .roo-chip {
    --roo-chip-fill: var(--roo-raised);
    --roo-chip-text: var(--roo-text);
    display: inline-flex;
    align-items: center;
    flex: none;
    gap: var(--roo-p-space-2);
    box-sizing: border-box;
    height: var(--roo-pill-h);
    padding: 0 var(--roo-p-space-3);
    border: 0;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-chip-fill);
    color: var(--roo-chip-text);
    font: inherit;
    font-size: var(--roo-p-size-12);
    font-weight: 500;
    white-space: nowrap;
    cursor: default;
  }

  .roo-chip-person {
    display: inline-flex;
    margin-inline-start: -2px;
  }

  .roo-chip-person :deep(.roo-avatar) {
    background: var(--roo-surface);
    border: 1px solid var(--roo-border);
  }

  .roo-chip[data-tone='accent'] {
    --roo-chip-fill: var(--roo-accent-bg);
    --roo-chip-text: var(--roo-accent-text);
  }

  .roo-chip[data-tone='ok'] {
    --roo-chip-fill: var(--roo-ok-bg);
    --roo-chip-text: var(--roo-ok-text);
  }

  .roo-chip[data-tone='warn'] {
    --roo-chip-fill: var(--roo-warn-bg);
    --roo-chip-text: var(--roo-warn);
  }

  .roo-chip[data-tone='danger'] {
    --roo-chip-fill: var(--roo-danger-bg);
    --roo-chip-text: var(--roo-danger-text);
  }

  /* The outline chip: transparent, a 1px edge inside the height, normal ink. Hover is the raised hover fill. */
  .roo-chip[data-tone='outline'] {
    --roo-chip-fill: transparent;
    border: 1px solid var(--roo-border);
    transition: background-color var(--roo-fast) var(--roo-ease);
  }

  .roo-chip[data-tone='outline'][data-interactive='true']:hover,
  .roo-chip[data-tone='outline'][data-removable]:hover {
    background: var(--roo-raised-hover);
  }

  .roo-chip[data-tone='accent'] {
    --roo-chip-dot: var(--roo-accent);
  }

  .roo-chip[data-tone='ok'] {
    --roo-chip-dot: var(--roo-ok);
  }

  .roo-chip[data-tone='warn'] {
    --roo-chip-dot: var(--roo-status-orange);
  }

  .roo-chip[data-tone='danger'] {
    --roo-chip-dot: var(--roo-danger);
  }

  /* Status chips (a RooChip used as a readout) are pale pills (Raja 2026-11-22: "Do you want C's pale-fill pills back - yes", then "the
     middle one, not the fully rounded version", so the tag shape is the default): a tinted fill, darker ink at weight 600, no border, no dot.
     Neutral is the 7% text-colour grey; outline stays transparent with its 1px edge. Dark uses the same idea on the dark tone tokens
     (a low-alpha tint, light ink). `statusDot` adds the 6px dot below. Interactive, removable and mono chips are controls and follow. */
  .roo-chip.roo-chip[data-tone]:not([data-mono], [data-interactive='true'], [data-removable]) {
    font-weight: 600;
  }

  .roo-chip.roo-chip[data-tone='neutral']:not([data-mono], [data-interactive='true'], [data-removable]) {
    --roo-chip-fill: color-mix(in srgb, var(--roo-text) 7%, transparent);
    --roo-chip-text: var(--roo-text);
  }

  .roo-chip.roo-chip[data-tone='outline']:not([data-mono], [data-interactive='true'], [data-removable]) {
    --roo-chip-text: var(--roo-text);
  }

  .roo-chip.roo-chip[data-tone='danger']:not([data-mono], [data-interactive='true'], [data-removable]):is(:root[data-appearance='dark'] *, .dark *) {
    --roo-chip-fill: var(--roo-danger-fill);
  }

  /* Light tones, C's recipe from docs/design/kit-light-options-2026-11-21 (text on fill: accent 6.6, ok 7.0, warn 7.1, danger 6.7). */
  .roo-chip.roo-chip[data-tone='accent']:not([data-mono], [data-interactive='true'], [data-removable]):not(:root[data-appearance='dark'] *, .dark *) {
    --roo-chip-fill: rgba(240, 87, 53, 0.13);
    --roo-chip-text: #9a2a12;
  }

  .roo-chip.roo-chip[data-tone='ok']:not([data-mono], [data-interactive='true'], [data-removable]):not(:root[data-appearance='dark'] *, .dark *) {
    --roo-chip-fill: rgba(21, 148, 131, 0.13);
    --roo-chip-text: #0a5a50;
  }

  .roo-chip.roo-chip[data-tone='warn']:not([data-mono], [data-interactive='true'], [data-removable]):not(:root[data-appearance='dark'] *, .dark *) {
    --roo-chip-fill: rgba(196, 134, 0, 0.16);
    --roo-chip-text: #6b4700;
  }

  .roo-chip.roo-chip[data-tone='danger']:not([data-mono], [data-interactive='true'], [data-removable]):not(:root[data-appearance='dark'] *, .dark *) {
    --roo-chip-fill: rgba(225, 29, 72, 0.1);
    --roo-chip-text: #a30f31;
  }

  /* Interactive and removable chips are controls: a pale grey pill in both themes (the neutral recipe), weight 500. A tone shows only as
     the 6px dot inside the grey. */
  .roo-chip.roo-chip:where([data-interactive='true'], [data-removable]):not([data-mono], [data-tone='outline']) {
    --roo-chip-fill: color-mix(in srgb, var(--roo-text) 7%, transparent);
    --roo-chip-text: var(--roo-text);
  }

  .roo-chip.roo-chip:where([data-interactive='true'], [data-removable]):where([data-tone='accent'], [data-tone='ok'], [data-tone='warn'], [data-tone='danger']):not([data-mono], :has(.roo-chip-dot))::before {
    content: '';
    flex: none;
    width: var(--roo-p-chip-dot);
    height: var(--roo-p-chip-dot);
    margin-right: -2px;
    border-radius: 50%;
    background: var(--roo-chip-dot);
  }

  /* statusDot on a status chip: a 6px dot inside the pill. Tone chips draw it in the ink colour (the tone colour measures only about 3:1 or
     less on its own tint, ink measures 6:1 or more and still pairs with the label); neutral and outline get a muted grey dot. */
  .roo-chip[data-status-dot]:where([data-tone='neutral'], [data-tone='outline']):not(:has(.roo-chip-dot))::before {
    content: '';
    flex: none;
    width: var(--roo-p-chip-dot);
    height: var(--roo-p-chip-dot);
    margin-right: -2px;
    border-radius: 50%;
    background: var(--roo-muted);
  }

  .roo-chip[data-status-dot]:where([data-tone='accent'], [data-tone='ok'], [data-tone='warn'], [data-tone='danger']):not([data-interactive='true'], [data-removable], :has(.roo-chip-dot))::before {
    content: '';
    flex: none;
    width: var(--roo-p-chip-dot);
    height: var(--roo-p-chip-dot);
    margin-right: -2px;
    border-radius: 50%;
    background: currentColor;
  }

  .roo-chip[data-removable]:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: var(--roo-focus-offset);
  }

  .roo-chip[data-shape='tag'] {
    height: var(--roo-tag-h);
    padding: 0 var(--roo-tag-pad-inline);
    border-radius: var(--roo-tag-radius);
  }

  .roo-chip[data-size='small'] {
    height: var(--roo-tag-h);
    padding: 0 var(--roo-tag-pad-inline);
    font-size: var(--roo-p-size-12);
  }

  /* The mono chip: a bordered tag on the page fill, muted text. Its hover is the standard control hover. */
  .roo-chip[data-mono] {
    border: 1px solid var(--roo-border);
    background: transparent;
    color: var(--roo-muted);
    font-family: var(--roo-font-mono);
    font-weight: 400;
    transition:
      background-color var(--roo-fast) var(--roo-ease),
      color var(--roo-fast) var(--roo-ease);
  }

  .roo-chip[data-mono][data-interactive='true']:hover {
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  .roo-chip[data-interactive='true']:active {
    background: color-mix(in srgb, var(--roo-raised) 90%, var(--roo-text));
    color: var(--roo-text);
  }

  .roo-chip[data-interactive='true']:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: var(--roo-focus-offset);
  }

  .roo-chip[data-interactive='true']:not([data-mono]):not([data-tone='outline']):hover {
    background: color-mix(in srgb, var(--roo-chip-fill) 90%, var(--roo-text));
  }

  .roo-chip-remove {
    position: relative;
    display: inline-grid;
    flex: none;
    place-items: center;
    margin: 0 calc(var(--roo-p-space-1) * -1) 0 0;
    border: 0;
    padding: 0;
    background: transparent;
    color: inherit;
    cursor: default;
  }

  /* The 44 tap area sits outside the layout, like the info tip's close. */
  .roo-chip-remove::after {
    content: '';
    position: absolute;
    inset: 50% auto auto 50%;
    width: var(--roo-tap-target);
    height: var(--roo-tap-target);
    transform: translate(-50%, -50%);
  }

  .roo-chip-remove:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: var(--roo-focus-offset);
  }

  .roo-chip-dot {
    width: var(--roo-p-space-2);
    height: var(--roo-p-space-2);
    flex: none;
    border-radius: 50%;
    background: currentColor;
  }

  .roo-chip-leading {
    display: inline-flex;
    flex: none;
  }

  .roo-chip-label {
    min-width: 0;
  }
}
</style>
