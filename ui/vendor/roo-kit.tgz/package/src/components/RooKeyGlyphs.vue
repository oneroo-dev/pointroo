<script setup lang="ts">
// The glyphs of one keycap, drawn at one visual height. The system font draws the arrow characters (↑ ↓ ← →) clearly
// smaller than a letter, so each arrow is an inline icon sized to the letter cap height, and the character stays in the DOM
// as hidden text (copy, screen readers, tests). Everything else (⌘ ⇧ ⌥ ⏎ letters) stays text in the system font, where it
// already matches the cap height. Raja, 2026-11-17: arrow visibly shorter than the D in "Open ⌘↓", "Download ⌘D".
import { computed } from 'vue'
import type { RooIconName } from '../icons/paths'
import RooIcon from './RooIcon.vue'

const props = defineProps<{ text: string }>()

const ARROW_ICONS: Record<string, RooIconName> = { '↑': 'arrow-up', '↓': 'arrow-down', '←': 'arrow-left', '→': 'arrow-right' }

type Piece = { kind: 'text'; text: string } | { kind: 'arrow'; text: string; icon: RooIconName }

const pieces = computed<Piece[]>(() =>
  props.text
    .split(/([↑↓←→])/)
    .filter((part) => part !== '')
    .map((part) => {
      const icon = ARROW_ICONS[part]
      // In the system font the ↵ sits high and short. ⏎ is the same height as the letter D.
      return icon ? { kind: 'arrow', text: part, icon } : { kind: 'text', text: part.replaceAll('↵', '⏎') }
    }),
)
</script>

<template>
  <span class="roo-key-glyphs">
    <template v-for="(piece, index) in pieces" :key="index">
      <span v-if="piece.kind === 'arrow'" class="roo-key-glyph roo-key-glyph-arrow" data-glyph="arrow">
        <span class="roo-visually-hidden">{{ piece.text }}</span>
        <RooIcon :name="piece.icon" :size="13" />
      </span>
      <span v-else class="roo-key-glyph" data-glyph="text" :data-symbol="/^[⌘⇧⌥⌃⏎]+$/.test(piece.text) ? '' : undefined">{{ piece.text }}</span>
    </template>
  </span>
</template>

<style scoped>
@layer roo-components {
  .roo-key-glyphs {
    display: inline-flex;
    align-items: center;
  }

  .roo-key-glyph {
    display: inline-flex;
    align-items: center;
    line-height: 1;
  }

  /* Optical centring: the line box of a system face is not symmetric around the capitals (the letters sit about 1 px low in a
     line-height 1 box), so the text is trimmed to its cap height and the cap centres the ink. Where text-box is not supported the
     same shift is a fixed 2 px of bottom padding. */
  /* The key symbols stay in the system face when a cap sets another (the mono cap of the Jump trigger): Geist Mono has no command
     sign and the fallback draws it small (Raja, 2026-11-16: "uneven icon heights"). */
  .roo-key-glyph[data-symbol] {
    font-family: -apple-system, system-ui, var(--roo-font-ui);
  }

  .roo-key-glyph[data-glyph='text'] {
    display: block;
    padding-bottom: 2px;
  }

  @supports (text-box: trim-both cap alphabetic) {
    .roo-key-glyph[data-glyph='text'] {
      padding-bottom: 0;
      text-box: trim-both cap alphabetic;
    }
  }

  /* Lucide arrows ink 14 of 24 units, so a box of 1.2em inks 0.7em, the cap height of the system face (0.705em). The box
     follows the font size, so the arrow matches the letter in an 11px keycap and in a 12px menu row alike. */
  .roo-key-glyph-arrow {
    width: 1.2em;
    height: 1.2em;
    justify-content: center;
  }

  .roo-key-glyph-arrow :deep(svg) {
    width: 100%;
    height: 100%;
  }
}
</style>
