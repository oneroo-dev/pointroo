<script lang="ts">
export const DIVIDER_KEY_STEP = 8

export type DividerLimit = 'min' | 'max' | 'none'

export interface DividerBounds {
  min: number
  max: number
  /** Dragging below this size collapses the region to 0 (it emits `collapse`). 0 turns it off. */
  collapseAt?: number
  /** Sizes the divider snaps to when released within `detentRange` of one. */
  detent?: number[]
}

export const DIVIDER_DETENT_RANGE = 8

/** Keeps a size between the bounds. */
export function clampSize(size: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, size))
}

/** The nearest detent within range, or the size itself. */
export function snapToDetent(size: number, detent: number[] = [], range = DIVIDER_DETENT_RANGE): number {
  let best = size
  let bestDistance = range + 1
  for (const candidate of detent) {
    const distance = Math.abs(candidate - size)
    if (distance <= range && distance < bestDistance) {
      best = candidate
      bestDistance = distance
    }
  }
  return best
}

/** Which limit the size sits on, for the one-way cursor. */
export function limitOf(size: number, min: number, max: number): DividerLimit {
  if (size <= min) return 'min'
  if (size >= max) return 'max'
  return 'none'
}

/** The size a key press asks for, or null for a key the divider ignores. `growKey` is the key that enlarges the region. */
export function sizeForKey(key: string, size: number, bounds: DividerBounds, growKey: string, shrinkKey: string): number | null {
  if (key === growKey) return clampSize(size + DIVIDER_KEY_STEP, bounds.min, bounds.max)
  if (key === shrinkKey) return clampSize(size - DIVIDER_KEY_STEP, bounds.min, bounds.max)
  if (key === 'Home') return bounds.min
  if (key === 'End') return bounds.max
  return null
}
</script>

<script setup lang="ts">
// The draggable edge between two regions of the window. It is a separator that takes focus, so the size is
// reachable by keyboard (8 px a press, Home, End) and announced through aria-valuenow; a double click asks the
// owner to `reset` it. The hit area is wider than the drawn line (--roo-divider-hit). At a limit the cursor points
// only the way the edge can still move.
import { computed, ref } from 'vue'

const props = withDefaults(
  defineProps<{
    /** `vertical` is a vertical line between side-by-side regions (it changes a width); `horizontal` changes a height. */
    orientation?: 'vertical' | 'horizontal'
    min: number
    max: number
    label: string
    /** Dragging below this size collapses the region to 0. 0 turns it off. */
    collapseAt?: number
    detent?: number[]
    /** The region sits after the divider (a pane on the end side), so dragging toward the start grows it. */
    invert?: boolean
    /** At most one `drag` update every this many ms. 0 sends every move. */
    throttle?: number
    /** The region is collapsed to its summary. */
    collapsed?: boolean
  }>(),
  { orientation: 'vertical', collapseAt: 0, detent: () => [], invert: false, throttle: 0, collapsed: false },
)

const size = defineModel<number>({ required: true })
const emit = defineEmits<{ reset: []; collapse: []; drag: [size: number]; 'drag-end': [size: number] }>()

const dragging = ref(false)
const readout = ref(size.value)
let startPointer = 0
let startSize = 0
let lastEmit = Number.NEGATIVE_INFINITY

const vertical = computed(() => props.orientation === 'vertical')
const bounds = computed<DividerBounds>(() => ({ min: props.min, max: props.max, collapseAt: props.collapseAt, detent: props.detent }))
const limit = computed(() => (props.collapsed ? 'min' : limitOf(size.value, props.min, props.max)))
const keys = computed(() => {
  const grow = vertical.value ? (props.invert ? 'ArrowLeft' : 'ArrowRight') : props.invert ? 'ArrowUp' : 'ArrowDown'
  const shrink = vertical.value ? (props.invert ? 'ArrowRight' : 'ArrowLeft') : props.invert ? 'ArrowDown' : 'ArrowUp'
  return { grow, shrink }
})

function pointerPosition(event: PointerEvent): number {
  return vertical.value ? event.clientX : event.clientY
}

function setSize(next: number): void {
  if (next === size.value) return
  size.value = next
}

function onPointerDown(event: PointerEvent): void {
  if (event.button !== 0) return
  dragging.value = true
  startPointer = pointerPosition(event)
  startSize = props.collapsed ? 0 : size.value
  lastEmit = Number.NEGATIVE_INFINITY
  readout.value = size.value
  ;(event.currentTarget as HTMLElement).setPointerCapture?.(event.pointerId)
}

function onPointerMove(event: PointerEvent): void {
  if (!dragging.value) return
  const delta = (pointerPosition(event) - startPointer) * (props.invert ? -1 : 1)
  const raw = startSize + delta
  const collapsing = props.collapseAt > 0 && raw < props.collapseAt
  const next = collapsing ? props.min : clampSize(raw, props.min, props.max)
  readout.value = collapsing ? 0 : next
  const now = event.timeStamp
  if (props.throttle > 0 && now - lastEmit < props.throttle) return
  lastEmit = now
  setSize(next)
  emit('drag', readout.value)
}

function onPointerUp(event: PointerEvent): void {
  if (!dragging.value) return
  dragging.value = false
  const delta = (pointerPosition(event) - startPointer) * (props.invert ? -1 : 1)
  const raw = startSize + delta
  if (props.collapseAt > 0 && raw < props.collapseAt) {
    setSize(props.min)
    emit('collapse')
    emit('drag-end', 0)
    return
  }
  const settled = snapToDetent(clampSize(raw, props.min, props.max), props.detent)
  const finalSize = clampSize(settled, props.min, props.max)
  setSize(finalSize)
  emit('drag-end', finalSize)
}

function onKeyDown(event: KeyboardEvent): void {
  const next = sizeForKey(event.key, size.value, bounds.value, keys.value.grow, keys.value.shrink)
  if (next === null) return
  event.preventDefault()
  setSize(next)
}
</script>

<template>
  <div
    class="roo-divider"
    role="separator"
    tabindex="0"
    :aria-label="label"
    :aria-orientation="vertical ? 'vertical' : 'horizontal'"
    :aria-valuemin="min"
    :aria-valuemax="max"
    :aria-valuenow="collapsed ? 0 : size"
    :data-orientation="orientation"
    :data-limit="limit"
    :data-dragging="dragging"
    @pointerdown="onPointerDown"
    @pointermove="onPointerMove"
    @pointerup="onPointerUp"
    @pointercancel="onPointerUp"
    @keydown="onKeyDown"
    @dblclick="emit('reset')"
  >
    <span class="roo-divider-line" aria-hidden="true" />
    <span v-if="dragging && $slots.readout" class="roo-divider-readout" aria-hidden="true">
      <slot name="readout" :size="readout">{{ readout }}</slot>
    </span>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-divider {
    position: relative;
    z-index: 2;
    flex: none;
    touch-action: none;
    cursor: default;
  }

  /* The hit area is --roo-divider-hit wide (10 inside the suite), centred on the drawn line, and takes no layout room. */
  .roo-divider[data-orientation='vertical'] {
    width: 0;
    height: 100%;
  }

  .roo-divider[data-orientation='horizontal'] {
    width: 100%;
    height: 0;
  }

  .roo-divider::before {
    content: '';
    position: absolute;
  }

  .roo-divider[data-orientation='vertical']::before {
    inset-block: 0;
    inset-inline: calc(var(--roo-divider-hit) / -2);
  }

  .roo-divider[data-orientation='horizontal']::before {
    inset-inline: 0;
    inset-block: calc(var(--roo-divider-hit) / -2);
  }

  .roo-divider[data-orientation='vertical'][data-limit='none'],
  .roo-divider[data-orientation='vertical'][data-dragging='true'] {
    cursor: col-resize;
  }

  .roo-divider[data-orientation='horizontal'][data-limit='none'],
  .roo-divider[data-orientation='horizontal'][data-dragging='true'] {
    cursor: row-resize;
  }

  /* At a limit the edge can move one way only, so the cursor points that way. */
  .roo-divider[data-orientation='vertical'][data-limit='min'] {
    cursor: e-resize;
  }

  .roo-divider[data-orientation='vertical'][data-limit='max'] {
    cursor: w-resize;
  }

  .roo-divider[data-orientation='horizontal'][data-limit='min'] {
    cursor: s-resize;
  }

  .roo-divider[data-orientation='horizontal'][data-limit='max'] {
    cursor: n-resize;
  }

  .roo-divider-line {
    position: absolute;
    background: var(--roo-border);
    transition: background-color var(--roo-fast) var(--roo-ease);
  }

  .roo-divider[data-orientation='vertical'] .roo-divider-line {
    inset-block: 0;
    inset-inline-start: 0;
    width: 1px;
  }

  .roo-divider[data-orientation='horizontal'] .roo-divider-line {
    inset-inline: 0;
    inset-block-start: 0;
    height: 1px;
  }

  .roo-divider:hover .roo-divider-line,
  .roo-divider[data-dragging='true'] .roo-divider-line {
    background: var(--roo-control-edge);
  }

  .roo-divider:focus-visible {
    outline: none;
  }

  .roo-divider:focus-visible .roo-divider-line {
    background: var(--roo-focus);
    box-shadow: 0 0 0 1px var(--roo-focus);
  }

  .roo-divider-readout {
    position: absolute;
    inset-block-start: 8px;
    inset-inline-start: 8px;
    white-space: nowrap;
    border: 1px solid var(--roo-control-edge);
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-surface);
    padding: 0 8px;
    color: var(--roo-text);
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
  }
}
</style>
