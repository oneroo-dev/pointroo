<script setup lang="ts">
// A group in a RooSettingsLayout pane: a heading, then a rounded card of RooSettingRow separated by hairlines (the TablePlus and
// Tinkeroo settings card). Each row keeps the kit's two columns, the name and help on the left and the control on the right, in a
// row at least 44 tall; the card gives the side room, so the heading and the row text share one left edge, 16 inside the card.
import { useId } from 'vue'

withDefaults(
  defineProps<{
    /** The group's name, shown above the card. Leave it out for a lone card at the top of a page. */
    title?: string
    /** One quiet line under the heading. */
    description?: string
  }>(),
  { title: '', description: '' },
)

const titleId = useId()
</script>

<template>
  <section class="roo-settings-group" :aria-labelledby="title ? titleId : undefined">
    <h4 v-if="title" :id="titleId" class="roo-settings-group-title">{{ title }}</h4>
    <p v-if="description" class="roo-settings-group-description">{{ description }}</p>
    <div class="roo-settings-group-card"><slot /></div>
  </section>
</template>

<style scoped>
@layer roo-components {
  .roo-settings-group {
    font-family: var(--roo-font-ui);
    color: var(--roo-text);
  }

  .roo-settings-group-title {
    margin: 0 0 var(--roo-p-space-2);
    font-size: var(--roo-p-size-13);
    font-weight: 600;
  }

  .roo-settings-group-description {
    margin: calc(var(--roo-p-space-1) * -1) 0 var(--roo-p-space-2);
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-settings-group-card {
    overflow: hidden;
    border-radius: var(--roo-p-radius-large);
    background: var(--roo-surface);
    box-shadow: var(--roo-shadow-card);
  }

  .roo-settings-group-card > :deep(.roo-setting-row) {
    box-sizing: border-box;
    display: grid;
    align-content: center;
    min-height: calc(var(--roo-control-h) + var(--roo-p-space-3));
    padding-block: var(--roo-p-space-2);
    padding-inline: var(--roo-p-space-4);
  }

  .roo-settings-group-card > :deep(.roo-setting-row + .roo-setting-row) {
    border-top: 1px solid var(--roo-line);
  }
}
</style>
