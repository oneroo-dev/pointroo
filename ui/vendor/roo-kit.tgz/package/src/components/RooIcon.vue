<script setup lang="ts">
import { computed } from 'vue'
import { LUCIDE_NODES } from '../icons/lucide'
import { ROO_PANEL_NODES } from '../icons/panels'
import {
  ROO_FILLED_ICONS,
  ROO_ICON_PATHS,
  ROO_ICON_STILL_PATHS,
  ROO_LUCIDE_ALIASES,
  ROO_TURNING_ICONS,
  rooIconStrokeWidth,
  type RooIconName,
} from '../icons/paths'

// `size` is a pixel number (default 20), or 'token' to draw at var(--roo-icon) so the glyph follows the density (12 compact, 16 comfortable and roomy).
// A token-sized glyph takes the small-size stroke (1.75), the stroke the numeric sizes up to 16 get, because the token never exceeds 16 at the base type scale.
const props = withDefaults(defineProps<{ name: RooIconName; size?: number | 'token'; label?: string }>(), {
  size: 20,
  label: '',
})

const tokenSized = computed(() => props.size === 'token')

const strokeWidth = computed(() => rooIconStrokeWidth(props.size === 'token' ? 16 : props.size))

const filled = computed(() => ROO_FILLED_ICONS.has(props.name))

const turning = computed(() => ROO_TURNING_ICONS.has(props.name))

// Lucide's nodes carry their own key attribute; the svg root sets the stroke, so only geometry is kept.
const parts = computed(() => {
  const aliased = ROO_LUCIDE_ALIASES[props.name]
  if (aliased) {
    return (ROO_PANEL_NODES[aliased] ?? LUCIDE_NODES[aliased] ?? []).map(([tag, attributes]) => {
      const { key: _key, ...geometry } = attributes
      return { tag, attributes: geometry }
    })
  }
  return (ROO_ICON_PATHS[props.name] ?? []).map((path) => ({ tag: 'path', attributes: { d: path } }))
})

const stillPaths = computed(() => ROO_ICON_STILL_PATHS[props.name] ?? [])
</script>

<template>
  <svg
    class="roo-icon"
    :class="{ 'roo-icon-turning': turning, 'roo-icon-token': tokenSized }"
    :width="tokenSized ? undefined : size"
    :height="tokenSized ? undefined : size"
    viewBox="0 0 24 24"
    :fill="filled ? 'currentColor' : 'none'"
    stroke="currentColor"
    :stroke-width="filled ? 2 : strokeWidth"
    stroke-linecap="round"
    stroke-linejoin="round"
    :role="label ? 'img' : undefined"
    :aria-label="label || undefined"
    :aria-hidden="label ? undefined : 'true'"
  >
    <template v-if="stillPaths.length > 0">
      <g class="roo-icon-turn-form">
        <component :is="part.tag" v-for="(part, index) in parts" :key="index" v-bind="part.attributes" />
      </g>
      <g class="roo-icon-still">
        <path v-for="(path, index) in stillPaths" :key="index" :d="path" />
      </g>
    </template>
    <template v-else>
      <component :is="part.tag" v-for="(part, index) in parts" :key="index" v-bind="part.attributes" />
    </template>
  </svg>
</template>

<style scoped>
@layer roo-components {
  .roo-icon {
    flex-shrink: 0;
  }

  .roo-icon-token {
    width: var(--roo-icon);
    height: var(--roo-icon);
  }

  .roo-icon-turning {
    animation: roo-icon-turn 900ms linear infinite;
  }

  .roo-icon-still { display: none; }

  @media (prefers-reduced-motion: reduce) {
    .roo-icon-turning { animation: none; }
    .roo-icon-turn-form { display: none; }
    .roo-icon-still { display: inline; }
  }

  /* The kit's own still switches (V1 sets both) give the same still form as the system setting. */
  :where(.roo-force-reduced, [data-motion='still']) .roo-icon-turning { animation: none; }
  :where(.roo-force-reduced, [data-motion='still']) .roo-icon-turn-form { display: none; }
  :where(.roo-force-reduced, [data-motion='still']) .roo-icon-still { display: inline; }

  @keyframes roo-icon-turn {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
  }
}
</style>
