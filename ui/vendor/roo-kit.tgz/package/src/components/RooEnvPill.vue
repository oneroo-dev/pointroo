<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import RooEnvDot from './RooEnvDot.vue'
import RooIcon from './RooIcon.vue'
import type { RooContextKind } from '../types/context'
import { GUARD_ICONS, GUARD_LABELS, TAG_LABELS, tagForEnvironment } from '../environment'
import type { RooContextState, RooEnvironmentWord, RooGuardLevel, RooTag } from '../types/environment'

const props = withDefaults(
  defineProps<{
    /** The environment tag: colour and label only. It turns no guard on or off. */
    tag?: RooTag | undefined
    /** The guard level, drawn as its own small word beside the tag word. Left out, no guard word is drawn. */
    guard?: RooGuardLevel | undefined
    /**
     * @deprecated Pass `tag` (and `guard`). The old environment word, kept so apps on the old call keep working.
     * Optional: the workspace pill in the title bar passes none, and then no environment word, dot or gap is drawn.
     */
    environment?: RooEnvironmentWord | undefined
    serverName?: string
    /** The prod guard is switched off for this connection. Shown in words, not just colour. */
    guardsOff?: boolean
    /** A real button that opens a connection switcher (Tableroo toolbar env tag). */
    interactive?: boolean
    /** Interactive only: whether the switcher it controls is open. */
    expanded?: boolean
    /** Interactive only: what kind of popup the button opens, for aria-haspopup. */
    popup?: 'dialog' | 'menu'
    /** Where the context stands. Anything but connected draws the dashed outline and appends the word. */
    state?: RooContextState | undefined
    /** A free word for a state the named ones do not cover. It draws the same dashed form. */
    stateWord?: string | undefined
    /** A glyph for the kind of thing this is, before the environment word. */
    kind?: RooContextKind | undefined
    /** Small is for lists and cards, never inside the Bar. Bar is the title bar control: the control height and radius. */
    size?: 'small' | 'bar' | undefined
    /** Size to content: the pill grows with its text and the server name truncates only beyond `maxWidth`. */
    sizeToContent?: boolean
    /** The widest a size-to-content pill grows (a number is px). Default 260 px. */
    maxWidth?: number | string | undefined
  }>(),
  {
    tag: undefined,
    guard: undefined,
    environment: undefined,
    serverName: '',
    guardsOff: false,
    interactive: false,
    expanded: false,
    popup: 'dialog',
    state: undefined,
    stateWord: undefined,
    kind: undefined,
    size: undefined,
    sizeToContent: false,
    maxWidth: undefined,
  },
)

const emit = defineEmits<{ open: [] }>()

// The cap is written as a custom property with the CSSOM, never as a style attribute in the template.
const pillElement = ref<{ $el?: HTMLElement } | HTMLElement | null>(null)
function applyMaxWidth(): void {
  const raw = pillElement.value
  const element = raw instanceof HTMLElement ? raw : raw?.$el
  if (!element?.style) return
  const width = props.maxWidth
  if (!props.sizeToContent || width === undefined || width === '') element.style.removeProperty('--roo-env-pill-max-width')
  else element.style.setProperty('--roo-env-pill-max-width', typeof width === 'number' ? `${width}px` : width)
}
onMounted(applyMaxWidth)
watch(() => [props.sizeToContent, props.maxWidth], applyMaxWidth, { flush: 'post' })

// The two tags that also arrive as an environment word draw through the tag styles; neither is prod-like.
const shownTag = computed<RooTag | undefined>(() => props.tag ?? (props.environment === 'testing' || props.environment === 'development' ? props.environment : undefined))

const prodLike = computed(() => (props.tag !== undefined ? props.tag === 'production' : tagForEnvironment(props.environment) === 'production'))
const wordText = computed(() => (props.tag !== undefined ? TAG_LABELS[props.tag] : props.environment))
const hasWord = computed(() => props.tag !== undefined || props.environment !== undefined)

const stateWordText = computed(() => {
  if (props.stateWord) return props.stateWord
  if (props.state && props.state !== 'connected') return props.state.replace('-', ' ')
  return ''
})

const stateName = computed(() => {
  if (props.stateWord) return 'custom'
  return props.state && props.state !== 'connected' ? props.state : undefined
})

const showDot = computed(
  () => hasWord.value && (!prodLike.value || props.environment === 'unclassified' || props.state === 'connecting'),
)
</script>

<template>
  <component
    :is="interactive ? 'button' : 'span'"
    ref="pillElement"
    class="roo-env-pill"
    :data-fit="sizeToContent ? 'true' : undefined"
    :type="interactive ? 'button' : undefined"
    :aria-haspopup="interactive ? popup : undefined"
    :aria-expanded="interactive ? expanded : undefined"
    :data-env="shownTag === undefined ? environment : undefined"
    :data-tag="shownTag"
    :data-prod-like="prodLike"
    :data-guards-off="guardsOff"
    :data-interactive="interactive"
    :data-state="stateName"
    :data-size="size"
    :data-leading="$slots.leading ? 'true' : undefined"
    @click="interactive && emit('open')"
  >
    <span v-if="$slots.leading" class="roo-env-pill-leading" aria-hidden="true"><slot name="leading" /></span>
    <RooEnvDot v-if="showDot && tag !== undefined" :tag="tag" :state="stateName" aria-hidden="true" />
    <RooEnvDot v-else-if="showDot && environment" :environment="environment" :state="stateName" aria-hidden="true" />
    <RooIcon v-if="kind" class="roo-env-pill-kind" :name="kind" :size="size === 'small' ? 12 : size === 'bar' ? 16 : 14" />
    <span v-if="hasWord" class="roo-env-pill-label">{{ wordText }}</span>
    <span v-if="guard" class="roo-env-pill-guard" :data-guard="guard">
      <RooIcon :name="GUARD_ICONS[guard]" :size="12" />
      <span>{{ GUARD_LABELS[guard] }}</span>
    </span>
    <span v-if="serverName" class="roo-env-pill-server">{{ environment === 'unclassified' ? '· ' : '' }}{{ serverName }}</span>
    <span v-if="stateWordText" class="roo-env-pill-state">{{ stateWordText }}</span>
    <span v-if="guardsOff" class="roo-env-pill-guards">guards off</span>
    <svg v-if="interactive" class="roo-env-pill-chevron" viewBox="0 0 12 12" aria-hidden="true">
      <path d="M3 4.5 6 7.5 9 4.5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />
    </svg>
  </component>
</template>

<style scoped>
@layer roo-components {
  .roo-env-pill {
    display: inline-flex;
    box-sizing: border-box;
    align-items: center;
    gap: 6px;
    height: var(--roo-pill-h);
    padding: 0 10px 0 8px;
    border-radius: var(--roo-p-radius-pill);
    border: 1px solid var(--roo-bar-edge);
    background: var(--roo-surface);
    color: var(--roo-text);
    font: inherit;
    font-size: var(--roo-p-size-12);
    font-weight: 600;
    white-space: nowrap;
    transition: background-color var(--roo-base) var(--roo-ease), color var(--roo-base) var(--roo-ease),
      border-color var(--roo-base) var(--roo-ease), transform var(--roo-fast) var(--roo-spring);
  }

  .roo-env-pill[data-size='small'] {
    height: calc(var(--roo-pill-h) - 4px);
    gap: var(--roo-p-space-1);
    padding: 0 var(--roo-p-space-2) 0 var(--roo-p-space-1);
  }

  /* A title bar control (family rule, Raja 2026-11-17: one height per bar, rounder corners): the control height and the
     control radius, not a pill. Inner corners stay under 8. */
  .roo-env-pill[data-size='bar'] {
    height: var(--roo-control-h);
    border-radius: var(--roo-p-radius-medium);
    padding: 0 var(--roo-p-space-3) 0 10px;
  }

  .roo-env-pill[data-size='bar'][data-interactive='true'] {
    padding-right: var(--roo-p-space-2);
  }

  /* A leading mark (the workspace letter tile): 8 in from the left edge and 8 before the next part. */
  .roo-env-pill[data-leading='true'] {
    gap: var(--roo-p-space-2);
    padding-left: var(--roo-p-space-2);
  }

  .roo-env-pill-leading {
    display: inline-flex;
    flex: none;
    align-items: center;
  }

  .roo-env-pill[data-size='bar'] .roo-env-pill-guards {
    border-radius: var(--roo-p-radius-mark);
  }

  /* Size to content: the pill is exactly as wide as its text, up to the cap; only the server name gives way beyond it. */
  .roo-env-pill[data-fit='true'] {
    width: max-content;
    max-width: min(100%, var(--roo-env-pill-max-width, 260px));
  }

  .roo-env-pill[data-env='local'] {
    --roo-env-pill-ink: var(--roo-env-local);
  }

  .roo-env-pill[data-env='staging'] {
    --roo-env-pill-ink: var(--roo-env-staging);
  }

  .roo-env-pill[data-env='unclassified'] {
    --roo-env-pill-ink: var(--roo-env-none);
  }

  .roo-env-pill[data-tag='testing'] {
    --roo-env-pill-ink: var(--roo-env-testing);
  }

  .roo-env-pill[data-tag='development'] {
    --roo-env-pill-ink: var(--roo-env-development);
  }

  .roo-env-pill[data-tag='none'] {
    --roo-env-pill-ink: var(--roo-env-none);
  }

  .roo-env-pill[data-prod-like='true'] {
    --roo-env-pill-ink: var(--roo-prod-text);
  }

  /* Source words are lowercase and stay lowercase: sentence case, no capitals. */
  .roo-env-pill-label {
    flex: none;
  }

  .roo-env-pill-kind {
    flex: none;
  }

  .roo-env-pill-server {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: var(--roo-font-mono);
    font-weight: 500;
  }

  .roo-env-pill-state {
    flex: none;
    font-weight: 500;
  }

  .roo-env-pill[data-prod-like='true'] {
    padding-left: 10px;
    border-color: transparent;
  }

  /* Only the production tag (old 'prod') takes the solid crimson fill and the on-crimson text. Unclassified maps to no tag:
     it keeps its own shape glyph (the hollow ring dot) and its "unclassified" word, in the no-tag colour. */
  .roo-env-pill[data-prod-like='true']:not([data-state]) {
    background: var(--roo-prod-pill);
    color: var(--roo-on-prod);
    animation: roo-pop var(--roo-base) var(--roo-spring) both;
  }

  /* Every state but connected is a 1 px dashed outline and the word, in the environment's text colour. */
  .roo-env-pill[data-state] {
    background: transparent;
    border-style: dashed;
    border-width: 1px;
    border-color: var(--roo-env-pill-ink);
    color: var(--roo-env-pill-ink);
  }

  /* The guard level is its own word, set apart from the tag word: the tag only colours, the guard is what asks. */
  .roo-env-pill-guard {
    display: inline-flex;
    flex: none;
    align-items: center;
    gap: var(--roo-p-space-1);
    padding-left: var(--roo-p-space-2);
    border-left: 1px solid currentColor;
    font-weight: 500;
  }

  .roo-env-pill-guards {
    padding: 1px 6px;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-on-prod);
    color: var(--roo-prod-pill);
    font-size: var(--roo-p-size-12);
    font-weight: 700;
  }

  .roo-env-pill[data-prod-like='true'][data-guards-off='true']:not([data-state]) {
    background-image: repeating-linear-gradient(
      -45deg,
      transparent 0 6px,
      color-mix(in srgb, var(--roo-on-prod) 14%, transparent) 6px 12px
    );
  }

  .roo-env-pill[data-interactive='true'] {
    cursor: default;
    padding-right: 6px;
  }

  /* Hover mixes 10% of the text colour into the pill's own fill, the rule RooBarChip uses, so it reads on every
     environment colour in both themes (a brightness filter is nearly invisible on a light fill). One rule per fill the
     pill can have: the raised surface, the production crimson (text is the on-crimson colour) and the transparent fill of
     a dashed state (text is the environment ink). */
  .roo-env-pill[data-interactive='true']:hover {
    background-color: color-mix(in srgb, var(--roo-surface) 90%, var(--roo-text));
  }

  .roo-env-pill[data-interactive='true'][data-prod-like='true']:not([data-state]):hover {
    background-color: color-mix(in srgb, var(--roo-prod-pill) 90%, var(--roo-on-prod));
  }

  .roo-env-pill[data-interactive='true'][data-state]:hover {
    background-color: color-mix(in srgb, transparent 90%, var(--roo-env-pill-ink));
  }

  .roo-env-pill[data-interactive='true']:active {
    transform: scale(0.97);
  }

  .roo-env-pill[data-interactive='true']:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  .roo-env-pill-chevron {
    flex: none;
    width: 12px;
    height: 12px;
    transition: transform var(--roo-base) var(--roo-spring);
  }

  .roo-env-pill[aria-expanded='true'] .roo-env-pill-chevron {
    transform: rotate(180deg);
  }
}
</style>
