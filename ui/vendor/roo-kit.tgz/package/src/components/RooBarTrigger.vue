<script setup lang="ts">
import RooIcon from './RooIcon.vue'

// The button that opens a dropdown from a bar: a workspace picker, a project picker. Slots run in a fixed order:
// leading (icon or colour tile), the label, trailing-extra (a branch name), then the chevron. Attrs such as aria-label,
// data-* and click land on the button.
withDefaults(
  defineProps<{
    /** The menu it opens is showing: the raised fill stays and aria-expanded is true. */
    open?: boolean
    /** Take the room of the bar (flex 1) and let the label grow. Without it the button stops at 260px. */
    fill?: boolean
    /** The empty "choose" state: the label is medium weight and muted. */
    muted?: boolean
  }>(),
  { open: false, fill: false, muted: false },
)
</script>

<template>
  <button
    type="button"
    class="roo-bar-trigger"
    :data-open="open"
    :data-fill="fill"
    :data-muted="muted"
    :aria-expanded="open ? 'true' : undefined"
  >
    <slot name="leading" />
    <span class="roo-bar-trigger-label"><slot /></span>
    <slot name="trailing-extra" />
    <!-- The negative margins cancel the icon's own blank space, uneven on its two sides (3.5px and 3px), so the
         tile and the chevron's ink sit 7px from the left and right edges -->
    <RooIcon class="roo-bar-trigger-chevron" name="chevron-down" :size="14" />
  </button>
</template>

<style scoped>
@layer roo-components {
  .roo-bar-trigger {
    display: flex;
    align-items: center;
    gap: var(--roo-p-space-2);
    min-width: 0;
    max-width: 260px;
    /* Off the 4px grid on purpose: the workspace picker look the owner chose. The chevron's blank space is 3.5px and 3px. */
    --roo-bar-trigger-pad: 6px;
    --roo-bar-trigger-chevron-start: -3.5px;
    --roo-bar-trigger-chevron-end: -3px;
    height: var(--roo-bar-control-h);
    padding: 0 var(--roo-bar-trigger-pad);
    border-radius: var(--roo-bar-control-radius);
    border: 1px solid var(--roo-bar-edge);
    background: var(--roo-surface);
    color: var(--roo-text);
    font: inherit;
    font-size: var(--roo-p-size-13);
    font-weight: var(--roo-p-weight-semibold);
    cursor: default;
    -webkit-app-region: no-drag;
    app-region: no-drag;
    transition: background-color var(--roo-fast) var(--roo-ease);
  }

  /* data-state='open' is what a menu trigger (RooMenu, reka as-child) sets, so an uncontrolled menu needs no open prop */
  .roo-bar-trigger:hover,
  .roo-bar-trigger[data-open='true'],
  .roo-bar-trigger[data-state='open'] {
    background: var(--roo-raised);
  }

  .roo-bar-trigger:active {
    background: color-mix(in srgb, var(--roo-raised) 90%, var(--roo-text));
  }

  .roo-bar-trigger:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: var(--roo-focus-offset);
  }

  .roo-bar-trigger[data-fill='true'] {
    flex: 1;
    max-width: none;
  }

  .roo-bar-trigger-label {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-bar-trigger[data-fill='true'] .roo-bar-trigger-label {
    flex: 1;
    text-align: left;
  }

  .roo-bar-trigger[data-muted='true'] .roo-bar-trigger-label {
    font-weight: var(--roo-p-weight-medium);
    color: var(--roo-muted);
  }

  .roo-bar-trigger-chevron {
    flex: none;
    margin-left: var(--roo-bar-trigger-chevron-start);
    margin-right: var(--roo-bar-trigger-chevron-end);
    opacity: 0.7;
  }

  @media (prefers-reduced-motion: reduce) {
    .roo-bar-trigger {
      transition: none;
    }
  }
}
</style>
