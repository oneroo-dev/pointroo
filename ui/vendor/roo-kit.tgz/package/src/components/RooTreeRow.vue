<script lang="ts">
// Type-ahead letters are shared by every row, so the typing carries on as focus moves from row to row.
const typeAhead = { letters: '', at: 0 }
</script>

<script setup lang="ts">
// A row of the sidebar tree. `expanded` is undefined for a leaf. Left and Right follow the tree pattern: Right opens a
// closed row, or steps into the first child of an open one; Left closes an open row, or steps out to the parent.
// A single click only selects. A double click with no modifier selects then emits `open`, and so does Enter; the app owns what open means.
// `activation="single"` is the press-to-open mode: a click selects and emits `open` (a double click then does nothing more), a click
// with Command (macOS) or Ctrl (elsewhere) emits `open-in-new-tab` instead, typing letters moves focus to the next row whose label
// starts with them, and a right click, the Menu key or Shift+F10 emits `contextmenu` with the row and a point to anchor the menu at.
// Enter opens in both modes; in the press-to-open mode Command+Enter (macOS) or Ctrl+Enter (elsewhere) emits `open-in-new-tab`, as the same click does. Selecting reports whether Ctrl or Command (additive) or Shift (range) was held, and the app owns the selection.
// `reorderable` rows drag, and Alt with Up or Down asks for a move. Actions show on hover, focus and selection.
// A label cut short by the row's width shows in full in a RooTooltip on hover or keyboard focus (it needs a RooTooltipProvider
// above it; without one the row just renders). It is measured when the pointer or focus arrives, never on a render.
// A row with `expanded` draws a chevron; clicking it toggles. A child steps in by one chevron plus one gap, so its leading
// column starts under the parent's label. Thin guides at each ancestor's chevron run down the children.
// States: rest, hover, selected, focus-visible, disabled (skipped by the arrows, never activates) and invalid (muted text and an
// icon, still focusable and selectable). `dropPosition` draws a 2px accent line before or after the row, or an into-folder
// highlight; the app drives it from its own drag handlers. `renaming` swaps the label for a text field: Enter and blur commit
// (`rename`), Escape cancels (`rename-cancel`), F2 asks to start (`rename-start`). The field passes Ctrl and Command chords up.
import { computed, inject, nextTick, ref, watch, type ComputedRef } from 'vue'
import type { RooEnvironment } from '../types/environment'
import RooIcon from './RooIcon.vue'
import RooRowTip from './RooRowTip.vue'

const props = withDefaults(
  defineProps<{
    label: string
    level?: number
    selected?: boolean
    expanded?: boolean | undefined
    environment?: RooEnvironment
    readonly?: boolean | undefined
    reorderable?: boolean
    dropTarget?: boolean
    /** Unsaved changes: draws a small accent dot after the label. */
    dirty?: boolean
    /** The row's accessible name when the visible label is not enough (an icon-only tile, a method badge). Defaults to the label. */
    ariaLabel?: string | undefined
    /** The row's thing is already open: a double click or Enter then emits no `open` (the click still selects). */
    open?: boolean
    /** Where a dragged item would land: a line before or after this row, or into it (a folder row). The app drives it. */
    dropPosition?: 'before' | 'after' | 'into' | undefined
    /** The label is a text field. The app sets it (usually on `rename-start`) and clears it on `rename` or `rename-cancel`. */
    renaming?: boolean
    /** Label weight by row kind: folders and collections can be semibold. */
    labelWeight?: 'regular' | 'semibold'
    /** The row's thing is broken: muted text and the `invalid` slot's icon (a warning glyph by default). Still focusable and selectable. */
    invalid?: boolean
    /** Greyed and inert: no select, open, expand or rename; the arrow keys skip it. */
    disabled?: boolean
    /** `double` (default): click selects, double click opens. `single`: click opens, Command or Ctrl click opens in a new tab, type-ahead and the context menu event are on. */
    activation?: 'double' | 'single'
  }>(),
  {
    level: 1,
    selected: false,
    expanded: undefined,
    readonly: undefined,
    reorderable: false,
    dropTarget: false,
    dirty: false,
    ariaLabel: undefined,
    open: false,
    dropPosition: undefined,
    renaming: false,
    labelWeight: 'regular',
    invalid: false,
    disabled: false,
    activation: 'double',
  },
)
const emit = defineEmits<{
  select: [selection: { additive: boolean; range: boolean }]
  open: []
  'open-in-new-tab': []
  contextmenu: [request: { row: HTMLElement; event: MouseEvent | KeyboardEvent; x: number; y: number }]
  'update:expanded': [expanded: boolean]
  reorder: [move: { direction: 'up' | 'down' }]
  'drag-start': [event: DragEvent]
  'drag-over': [event: DragEvent]
  drop: [event: DragEvent]
  'rename-start': []
  rename: [name: string]
  'rename-cancel': []
}>()

const treeReadonly = inject<ComputedRef<boolean>>('roo-sidebar-readonly', computed(() => false))
const locked = computed(() => props.readonly ?? treeReadonly.value)
const canDrag = computed(() => props.reorderable && !locked.value && !props.renaming && !props.disabled)

const dropMode = computed(() => props.dropPosition ?? (props.dropTarget ? 'into' : undefined))

function select(event: MouseEvent | KeyboardEvent): void {
  if (locked.value || props.disabled) return
  const additive = event.ctrlKey || event.metaKey
  emit('select', { additive, range: event.shiftKey && !additive })
}

function requestOpen(): void {
  if (locked.value || props.disabled || props.open) return
  emit('open')
}

const pressToOpen = computed(() => props.activation === 'single')
function onMacintosh(): boolean {
  return typeof navigator !== 'undefined' && /Mac|iPhone|iPad/.test(navigator.platform)
}

function onClick(event: MouseEvent): void {
  if (!pressToOpen.value) {
    select(event)
    return
  }
  if (locked.value || props.disabled) return
  if (onMacintosh() ? event.metaKey : event.ctrlKey) {
    emit('open-in-new-tab')
    return
  }
  select(event)
  if (!event.shiftKey && !event.ctrlKey && !event.metaKey && !event.altKey) requestOpen()
}

function onContextMenu(event: MouseEvent): void {
  if (!pressToOpen.value || props.disabled) return
  event.preventDefault()
  emit('contextmenu', { row: event.currentTarget as HTMLElement, event, x: event.clientX, y: event.clientY })
}

function typeAheadFocus(row: HTMLElement, character: string): void {
  const now = Date.now()
  typeAhead.letters = now - typeAhead.at > 700 ? character : typeAhead.letters + character
  typeAhead.at = now
  const items = treeItems(row)
  const start = items.indexOf(row)
  const repeated = typeAhead.letters.split('').every((letter) => letter === typeAhead.letters[0])
  const prefix = (repeated ? typeAhead.letters[0]! : typeAhead.letters).toLowerCase()
  for (let step = repeated ? 1 : 0; step <= items.length; step += 1) {
    const item = items[(start + step) % items.length]!
    if (item.getAttribute('aria-disabled') === 'true') continue
    const text = item.querySelector('.roo-tree-row-label')?.textContent ?? item.getAttribute('aria-label') ?? ''
    if (text.toLowerCase().startsWith(prefix)) {
      item.focus()
      return
    }
  }
}

function onDoubleClick(event: MouseEvent): void {
  if (pressToOpen.value) return
  if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return
  if (locked.value || props.disabled) return
  select(event)
  requestOpen()
}

function treeItems(row: HTMLElement): HTMLElement[] {
  return Array.from(row.closest('[role=tree]')?.querySelectorAll<HTMLElement>('[role=treeitem]') ?? [])
}

function stepToChild(row: HTMLElement): void {
  const items = treeItems(row)
  const next = items[items.indexOf(row) + 1]
  if (next && Number(next.getAttribute('aria-level')) > props.level) next.focus()
}

function stepToParent(row: HTMLElement): void {
  const items = treeItems(row)
  for (let index = items.indexOf(row) - 1; index >= 0; index -= 1) {
    if (Number(items[index]!.getAttribute('aria-level')) < props.level) {
      items[index]!.focus()
      return
    }
  }
}

function setExpanded(expanded: boolean): void {
  if (props.disabled) return
  emit('update:expanded', expanded)
}

function onKeydown(event: KeyboardEvent): void {
  const row = event.currentTarget as HTMLElement
  if (event.altKey && (event.key === 'ArrowUp' || event.key === 'ArrowDown')) {
    if (!canDrag.value) return
    event.preventDefault()
    emit('reorder', { direction: event.key === 'ArrowUp' ? 'up' : 'down' })
    return
  }
  if (pressToOpen.value && !props.disabled && (event.key === 'ContextMenu' || (event.key === 'F10' && event.shiftKey))) {
    event.preventDefault()
    const box = row.getBoundingClientRect()
    emit('contextmenu', { row, event, x: box.left, y: box.bottom })
    return
  }
  if (pressToOpen.value && event.key === 'Enter' && !event.altKey && !event.shiftKey && (onMacintosh() ? event.metaKey && !event.ctrlKey : event.ctrlKey && !event.metaKey)) {
    event.preventDefault()
    if (!locked.value && !props.disabled) emit('open-in-new-tab')
    return
  }
  if (event.ctrlKey || event.metaKey || event.altKey) return
  if (pressToOpen.value && !props.renaming && !props.disabled && event.key.length === 1 && event.key !== ' ') {
    event.preventDefault()
    typeAheadFocus(row, event.key)
    return
  }
  if (event.key === 'F2') {
    if (locked.value || props.disabled || event.shiftKey) return
    event.preventDefault()
    emit('rename-start')
  } else if (event.key === 'Enter' || event.key === ' ') {
    event.preventDefault()
    select(event)
    if (event.key === 'Enter') requestOpen()
  } else if (event.key === 'ArrowRight') {
    if (props.expanded === false) setExpanded(true)
    else if (props.expanded === true) stepToChild(row)
    else return
    event.preventDefault()
  } else if (event.key === 'ArrowLeft') {
    if (props.expanded === true) setExpanded(false)
    else stepToParent(row)
    event.preventDefault()
  }
}

const labelElement = ref<HTMLElement | null>(null)
const labelTip = ref<InstanceType<typeof RooRowTip> | null>(null)
let pointerIsDown = false

function labelIsCut(): boolean {
  const element = labelElement.value
  return element !== null && element.scrollWidth > element.clientWidth
}

function onPointerEnter(): void {
  if (labelIsCut()) labelTip.value?.enter()
}

function onPointerDown(): void {
  pointerIsDown = true
  labelTip.value?.hide()
  document.addEventListener('pointerup', () => setTimeout(() => (pointerIsDown = false), 1), { once: true })
}

function onFocus(): void {
  if (!pointerIsDown && labelIsCut()) labelTip.value?.show()
}

const rowElement = ref<HTMLElement | null>(null)
const renameField = ref<HTMLInputElement | null>(null)
const draft = ref('')
let renameFinished = false

watch(
  () => props.renaming,
  async (renaming) => {
    if (!renaming) return
    draft.value = props.label
    renameFinished = false
    labelTip.value?.hide()
    await nextTick()
    renameField.value?.focus()
    renameField.value?.select()
  },
  { immediate: true, flush: 'post' },
)

function finishRename(commit: boolean, refocusRow: boolean): void {
  if (renameFinished) return
  renameFinished = true
  const name = draft.value.trim()
  if (commit && name !== '' && name !== props.label) emit('rename', name)
  else emit('rename-cancel')
  if (refocusRow) rowElement.value?.focus()
}

// Plain keys stay in the field (arrows move the caret, Space types). Ctrl and Command chords carry on up, so app shortcuts still work.
function onRenameKeydown(event: KeyboardEvent): void {
  if (event.ctrlKey || event.metaKey) return
  event.stopPropagation()
  if (event.isComposing) return
  if (event.key === 'Enter') {
    event.preventDefault()
    finishRename(true, true)
  } else if (event.key === 'Escape') {
    event.preventDefault()
    finishRename(false, true)
  }
}

function onChevronClick(): void {
  if (props.expanded !== undefined) setExpanded(!props.expanded)
}

function onDragStart(event: DragEvent): void {
  if (event.dataTransfer) event.dataTransfer.effectAllowed = 'move'
  emit('drag-start', event)
}
</script>

<template>
  <div
    ref="rowElement"
    class="roo-tree-row"
    :class="{ 'roo-selected-row': selected }"
    role="treeitem"
    data-roving-item
    :aria-level="level"
    :aria-label="ariaLabel"
    :aria-selected="selected ? 'true' : 'false'"
    :aria-expanded="expanded === undefined ? undefined : expanded ? 'true' : 'false'"
    :aria-readonly="locked ? 'true' : undefined"
    :aria-disabled="disabled ? 'true' : undefined"
    :aria-invalid="invalid ? 'true' : undefined"
    :data-invalid="invalid ? 'true' : undefined"
    :data-weight="labelWeight"
    :data-renaming="renaming ? 'true' : undefined"
    :data-drop-target="dropMode === 'into' ? 'true' : undefined"
    :data-drop="dropMode"
    :draggable="canDrag ? 'true' : undefined"
    :style="{ '--roo-tree-level': String(level) }"
    @pointerenter="onPointerEnter"
    @pointerleave="labelTip?.leave()"
    @pointerdown="onPointerDown"
    @focus="onFocus"
    @blur="labelTip?.hide()"
    @click="onClick"
    @dblclick="onDoubleClick"
    @contextmenu="onContextMenu"
    @keydown="onKeydown"
    @dragstart="canDrag && onDragStart($event)"
    @dragover="canDrag && emit('drag-over', $event)"
    @drop="canDrag && emit('drop', $event)"
  >
    <span v-if="expanded !== undefined" class="roo-tree-row-chevron" :data-open="expanded ? 'true' : 'false'" aria-hidden="true" @click.stop="onChevronClick" @dblclick.stop>
      <RooIcon name="chevron" :size="12" />
    </span>
    <span v-if="$slots.tile" class="roo-tree-row-tile"><slot name="tile" /></span>
    <input
      v-if="renaming"
      ref="renameField"
      v-model="draft"
      class="roo-tree-row-rename"
      type="text"
      spellcheck="false"
      autocomplete="off"
      :aria-label="`Rename ${label}`"
      @keydown="onRenameKeydown"
      @keyup.stop
      @blur="finishRename(true, false)"
      @click.stop
      @dblclick.stop
      @pointerdown.stop
      @dragstart.stop.prevent
    />
    <span v-else ref="labelElement" class="roo-tree-row-label">{{ label }}</span>
    <RooRowTip ref="labelTip" :text="label" />
    <span v-if="invalid" class="roo-tree-row-invalid"><slot name="invalid"><RooIcon name="warning" :size="14" /></slot></span>
    <span v-if="dirty" class="roo-tree-row-dirty"><span class="roo-visually-hidden">Unsaved changes</span></span>
    <span v-if="environment" class="roo-tree-row-env" :data-env="environment">{{ environment }}</span>
    <span v-if="$slots.actions && !locked" class="roo-tree-row-actions"><slot name="actions" /></span>
    <span v-if="$slots.meta" class="roo-tree-row-meta"><slot name="meta" /></span>
    <span v-if="dropMode === 'before' || dropMode === 'after'" class="roo-tree-row-drop-line" :data-edge="dropMode" aria-hidden="true" />
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-tree-row {
    /* One step in per level is the chevron cell plus the gap, so a child's leading column starts at its parent's label. The
       cell is the indent minus the gap, so the sum holds at every density (the icon is --roo-tree-chevron wide, centred in it). */
    /* --roo-tree-chevron-gap is the gap after the chevron: the row gap at each density, and --roo-sidebar-chevron-gap under the sidebar
       placement of RooTree and RooSidebarGroup. */
    --roo-tree-step-gap: var(--roo-tree-chevron-gap);
    --roo-tree-cell: calc(var(--roo-tree-indent) - var(--roo-tree-step-gap));
    /* The tree insets its rows --roo-tree-inset; the row's own start padding takes the text line up to --roo-tree-text-line,
       so the selection pill (centred in the padding) has clear room each side and the text sits on the sidebar's shared line. */
    --roo-row-pad-inline: calc(var(--roo-tree-text-line) - var(--roo-tree-inset));
    position: relative;
    display: flex;
    height: var(--roo-tree-row-h);
    box-sizing: border-box;
    align-items: center;
    gap: var(--roo-gap);
    border-radius: var(--roo-tree-radius);
    margin-inline-start: calc((var(--roo-tree-level) - 1) * var(--roo-tree-indent));
    padding-inline: var(--roo-row-pad-inline) var(--roo-gap);
    color: var(--roo-text);
    font-size: var(--roo-ui-size);
    cursor: default;
  }

  /* Indent guides: one 1px line in the border colour under each ancestor's chevron, drawn by the row itself so the lines
     join across rows. The strip reaches left over the margin to the first level's start; the repeat is one indent. */
  .roo-tree-row[aria-level]:not([aria-level='1'])::after {
    --roo-guide-x: calc(var(--roo-row-pad-inline) + var(--roo-tree-cell) / 2 - 0.5px);
    content: '';
    position: absolute;
    top: 0;
    bottom: 0;
    right: 100%;
    width: calc((var(--roo-tree-level) - 1) * var(--roo-tree-indent));
    background: repeating-linear-gradient(
      to right,
      transparent 0 var(--roo-guide-x),
      var(--roo-border) var(--roo-guide-x) calc(var(--roo-guide-x) + 1px),
      transparent calc(var(--roo-guide-x) + 1px) var(--roo-tree-indent)
    );
    pointer-events: none;
  }

  .roo-tree-row:hover {
    background: var(--roo-row-hover);
  }

  .roo-tree-row:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: -2px;
  }

  .roo-tree-row[aria-disabled='true']:hover:not([aria-selected='true']) {
    background: transparent;
  }

  /* Selected: the selection fill (and the shared pill from .roo-selected-row) at normal weight (the text never moves), never a ring or an edge bar. A
     nested row is indented by its own margin, so its fill and its pill start at its own left edge, not the list's. */
  .roo-tree-row[aria-selected='true'] {
    background: var(--roo-select);
  }

  .roo-tree-row[aria-selected='true']:hover {
    background: var(--roo-select-hover);
  }

  .roo-tree-row[data-invalid='true'] {
    color: var(--roo-muted);
  }

  .roo-tree-row[aria-disabled='true'] {
    color: var(--roo-faint);
  }

  .roo-tree-row[data-drop-target='true'] {
    background: color-mix(in srgb, var(--roo-accent) 16%, transparent);
    outline: 1px dashed var(--roo-select-outline);
    outline-offset: -1px;
  }

  /* A 2px accent line on the row's top or bottom edge, from the row's own start (so it follows the indent) to its end. */
  .roo-tree-row-drop-line {
    position: absolute;
    inset-inline: 0;
    z-index: 1;
    height: 2px;
    border-radius: var(--roo-p-radius-hair);
    background: var(--roo-accent);
    pointer-events: none;
  }

  .roo-tree-row-drop-line[data-edge='before'] {
    top: -1px;
  }

  .roo-tree-row-drop-line[data-edge='after'] {
    bottom: -1px;
  }

  .roo-tree-row-chevron {
    display: inline-flex;
    width: var(--roo-tree-cell);
    flex: none;
    align-items: center;
    justify-content: center;
    /* The flex gap follows the chevron cell; where the placement sets a tighter chevron gap, pull the next item in by the difference. */
    margin-inline-end: calc(var(--roo-tree-step-gap) - var(--roo-gap));
    color: var(--roo-muted);
  }

  .roo-tree-row-chevron :deep(svg) {
    width: var(--roo-tree-chevron);
    height: var(--roo-tree-chevron);
    transition: transform var(--roo-fast) var(--roo-ease);
  }

  .roo-tree-row-chevron[data-open='true'] :deep(svg) {
    transform: rotate(90deg);
  }

  .roo-tree-row:hover .roo-tree-row-chevron {
    color: var(--roo-text);
  }

  .roo-tree-row-tile {
    display: inline-flex;
    flex: none;
    align-items: center;
    color: var(--roo-muted);
  }

  .roo-tree-row:hover .roo-tree-row-tile,
  .roo-tree-row[aria-selected='true'] .roo-tree-row-tile {
    color: var(--roo-text);
  }

  .roo-tree-row-label {
    min-width: 0;
    flex: 1 1 auto;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-tree-row[data-weight='semibold'] .roo-tree-row-label {
    font-weight: 600;
  }

  .roo-tree-row-rename {
    min-width: 0;
    height: calc(var(--roo-tree-row-h) - 6px);
    flex: 1 1 auto;
    box-sizing: border-box;
    border: 1px solid var(--roo-focus);
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-bg);
    padding: 0 4px;
    color: var(--roo-text);
    font: inherit;
    outline: none;
  }

  .roo-tree-row-invalid {
    display: inline-flex;
    flex: none;
    align-items: center;
    color: var(--roo-muted);
  }

  .roo-tree-row-env {
    flex: none;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    white-space: nowrap;
  }

  .roo-tree-row-dirty {
    width: 8px;
    height: 8px;
    flex: none;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-accent);
  }

  .roo-tree-row-meta {
    display: inline-flex;
    flex: none;
    align-items: center;
    color: var(--roo-muted);
  }

  /* Hidden actions take no width, so a label is only shortened while the actions show (hover, focus within, selected). */
  .roo-tree-row-actions {
    display: none;
    flex: none;
    align-items: center;
  }

  .roo-tree-row:hover .roo-tree-row-actions,
  .roo-tree-row:focus-within .roo-tree-row-actions,
  .roo-tree-row[aria-selected='true'] .roo-tree-row-actions {
    display: inline-flex;
  }
}
</style>
