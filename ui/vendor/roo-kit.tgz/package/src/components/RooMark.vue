<script lang="ts">
// Keys that have already drawn in this launch. Module scope, so a second mount of the same key stays still.
const drawnKeys = new Set<string>()
</script>

<script setup lang="ts">
import { computed, useSlots } from 'vue'

// A slot only: the app supplies its own artwork as svg children. The kit ships no roo artwork (Raja's D3 is open).
const props = withDefaults(defineProps<{ size?: 14 | 48 | 64; draw?: boolean; drawKey?: string }>(), {
  size: 48,
  draw: false,
  drawKey: 'default',
})

const slots = useSlots()

const drawsNow = computed(() => {
  if (!props.draw || drawnKeys.has(props.drawKey)) return false
  drawnKeys.add(props.drawKey)
  return true
})
</script>

<template>
  <svg
    v-if="slots.default"
    class="roo-mark"
    :class="{ 'roo-mark-draw': drawsNow }"
    :width="size"
    :height="size"
    viewBox="0 0 24 24"
    fill="currentColor"
    aria-hidden="true"
    focusable="false"
  >
    <slot />
  </svg>
</template>

<style scoped>
@layer roo-components {
  .roo-mark {
    flex-shrink: 0;
  }

  .roo-mark-draw {
    animation: roo-tick var(--roo-tick) var(--roo-ease) both;
  }
}
</style>
