<script setup lang="ts">
// The Pill as a context control: the environment word, the name, the state, and a hover card. It does not own the
// switcher; the app listens for `open` and shows RooSwitcher beside it.
import { injectTooltipProviderContext } from 'reka-ui'
import { computed, h, nextTick, onBeforeUnmount, onMounted, ref, useId, useSlots, watch } from 'vue'
import { useEscapeLayer } from '../composables/useEscapeLayer'
import RooEnvPill from './RooEnvPill.vue'
import RooTooltip from './RooTooltip.vue'
import type { VNodeChild } from 'vue'
import type { RooContextKind } from '../types/context'
import type { RooContextState, RooEnvironment } from '../types/environment'

const HOVER_CARD_DELAY_MS = 500

const props = withDefaults(
  defineProps<{
    /** Optional: the title bar's workspace pill shows no environment word. */
    environment?: RooEnvironment | undefined
    name: string
    kind?: RooContextKind | undefined
    state?: RooContextState | undefined
    /** A free word for a state the named ones do not cover. */
    stateWord?: string | undefined
    guardsOff?: boolean
    /** A fixed context (the sample project): no chevron, no switcher. */
    static?: boolean
    maxWidth?: number | string | undefined
    /** Whether the switcher this pill opens is showing. */
    expanded?: boolean
    /** `bar` (default) is the title bar control at the control height. `status` is the slim pill for a status line. */
    size?: 'bar' | 'status'
  }>(),
  { environment: undefined, kind: undefined, state: undefined, stateWord: undefined, guardsOff: false, static: false, maxWidth: undefined, expanded: false, size: 'bar' },
)

const emit = defineEmits<{ open: []; 'card-open': [open: boolean] }>()

const widthLimit = computed(() => {
  if (props.maxWidth === undefined) return undefined
  return { maxWidth: typeof props.maxWidth === 'number' ? `${props.maxWidth}px` : props.maxWidth }
})

const slots = useSlots()
// Not a computed: `slots` is not reactive, so a computed would freeze the answer from the first render. Every caller
// runs in a render or an event handler, where the slot is read fresh.
function hasCard(): boolean {
  return Boolean(slots.card)
}
const cardOpen = ref(false)
useEscapeLayer(
  () => cardOpen.value && hasCard(),
  () => setCard(false),
)
const cardId = useId()
let hoverTimer: ReturnType<typeof setTimeout> | undefined

function setCard(open: boolean): void {
  clearTimeout(hoverTimer)
  if (cardOpen.value === open) return
  cardOpen.value = open
  emit('card-open', open)
}

function onEnter(): void {
  if (!hasCard()) return
  clearTimeout(hoverTimer)
  hoverTimer = setTimeout(() => setCard(true), HOVER_CARD_DELAY_MS)
}

function onLeave(): void {
  setCard(false)
}

// Space opens the card as a popover. The click that follows a Space press is held back, so it does not open the switcher.
function onKeydown(event: KeyboardEvent): void {
  if (event.key === 'Escape' && cardOpen.value) {
    event.preventDefault()
    event.stopPropagation()
    setCard(false)
    return
  }
  if (event.key === ' ' && hasCard()) {
    event.preventDefault()
    setCard(!cardOpen.value)
  }
}

function onKeyup(event: KeyboardEvent): void {
  if (event.key === ' ' && hasCard()) event.preventDefault()
}

function onOpen(): void {
  setCard(false)
  emit('open')
}

const root = ref<HTMLElement | null>(null)

// A screen reader gets the parts as separate phrases. The words stay lowercase.
const accessibleName = computed(() => {
  const kindWord = props.kind ? props.kind.charAt(0).toUpperCase() + props.kind.slice(1) : 'Connection'
  const stateWord = props.stateWord || (props.state && props.state !== 'connected' ? props.state.replace('-', ' ') : '')
  return [kindWord, props.environment ?? '', props.name, stateWord, props.guardsOff ? 'guards off' : '']
    .filter((part) => part !== '')
    .join(', ')
})

// When the name is cut short by the width cap, the whole name shows in a RooTooltip (which needs a RooTooltipProvider above).
const truncated = ref(false)
let resizeObserver: ResizeObserver | undefined

function measure(): void {
  const label = root.value?.querySelector<HTMLElement>('.roo-env-pill-server')
  truncated.value = Boolean(label) && (label as HTMLElement).scrollWidth > (label as HTMLElement).clientWidth
}

// The tooltip trigger wraps the pill when truncated, which remounts it, so the new element is measured again too.
type PassedSlots = { slots: { default?: () => VNodeChild } }
const PassThrough = (_: unknown, { slots: passed }: PassedSlots): VNodeChild => passed.default?.()
// The span is always there when a provider is, and is `display: contents`, so the pill keeps its layout and its focus
// when the tooltip switches on or off. `disabled` falls through RooTooltip onto reka's TooltipRoot.
const NameTip = (properties: { text?: string; disabled?: boolean }, { slots: passed }: PassedSlots): VNodeChild =>
  h(RooTooltip, { text: properties.text ?? '', disabled: properties.disabled === true }, () =>
    h('span', { class: 'roo-context-pill-tip', style: 'display: contents' }, [passed.default?.()]),
  )

// Found by injection, never by catching: without a RooTooltipProvider the pill renders with no tooltip.
const hasTooltipProvider = injectTooltipProviderContext(null as never) !== null
// One popup at a time: a card slot shows the full name at its top instead of a tooltip.
function tooltipOn(): boolean {
  return truncated.value && !hasCard()
}

watch(
  () => truncated.value && !hasTooltipProvider,
  (missing) => {
    if (missing) {
      console.warn('[RooContextPill] the name is truncated but there is no RooTooltipProvider above it, so no tooltip shows.')
    }
  },
  { immediate: true },
)

onMounted(() => {
  measure()
  if (typeof ResizeObserver !== 'undefined' && root.value) {
    resizeObserver = new ResizeObserver(measure)
    resizeObserver.observe(root.value)
  }
})

watch(
  () => [props.name, props.maxWidth, props.environment, props.state, props.stateWord, props.guardsOff, props.kind],
  async () => {
    await nextTick()
    measure()
  },
)

function onOutside(event: Event): void {
  if (root.value && event.target instanceof Node && !root.value.contains(event.target)) setCard(false)
}

watch(cardOpen, (open) => {
  if (typeof document === 'undefined') return
  if (open) document.addEventListener('pointerdown', onOutside, true)
  else document.removeEventListener('pointerdown', onOutside, true)
})

onBeforeUnmount(() => {
  clearTimeout(hoverTimer)
  resizeObserver?.disconnect()
  if (typeof document !== 'undefined') document.removeEventListener('pointerdown', onOutside, true)
})
</script>

<template>
  <span
    ref="root"
    class="roo-context-pill"
    :data-size="props.size"
    :tabindex="props.static && hasCard() ? 0 : undefined"
    :aria-haspopup="props.static && hasCard() ? 'dialog' : undefined"
    :aria-expanded="props.static && hasCard() ? cardOpen : undefined"
    :aria-controls="props.static && cardOpen ? cardId : undefined"
    :aria-label="props.static && hasCard() ? accessibleName : undefined"
    :style="widthLimit"
    @mouseenter="onEnter"
    @mouseleave="onLeave"
    @keydown="onKeydown"
    @keyup="onKeyup"
  >
    <component :is="hasTooltipProvider ? NameTip : PassThrough" v-bind="hasTooltipProvider ? { text: name, disabled: !tooltipOn() } : {}">
      <RooEnvPill
        :environment="environment"
        :server-name="name"
        :interactive="!props.static"
        :expanded="expanded"
        :guards-off="guardsOff"
        :state="state"
        :state-word="stateWord"
        :kind="kind"
        :size="props.size === 'bar' ? 'bar' : undefined"
        size-to-content
        :max-width="maxWidth"
        :aria-label="props.static ? undefined : accessibleName"
        :aria-controls="!props.static && cardOpen ? cardId : undefined"
        @open="onOpen"
      >
        <template v-if="$slots.leading" #leading><slot name="leading" /></template>
      </RooEnvPill>
    </component>
    <div v-if="cardOpen && hasCard()" :id="cardId" class="roo-context-card" role="dialog" :aria-label="`${name} details`">
      <p v-if="truncated" class="roo-context-card-name">{{ name }}</p>
      <slot name="card" />
    </div>
  </span>
</template>

<style scoped>
@layer roo-components {
  .roo-context-pill {
    position: relative;
    display: inline-flex;
    max-width: 100%;
  }

  /* The Pill sizes to its content up to the cap (260 px unless `maxWidth` says otherwise): the name gives way (ellipsis)
     and the environment word never does. */
  .roo-context-pill .roo-env-pill {
    min-width: 0;
  }

  .roo-context-pill:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
    border-radius: var(--roo-p-radius-medium);
  }

  .roo-context-pill[data-size='status']:focus-visible {
    border-radius: var(--roo-p-radius-pill);
  }

  .roo-context-card-name {
    margin: 0 0 var(--roo-p-space-2);
    font-family: var(--roo-font-mono);
    font-weight: 600;
    overflow-wrap: anywhere;
  }

  .roo-context-card {
    position: absolute;
    top: 100%;
    left: 0;
    z-index: 50;
    min-width: 240px;
    margin-top: var(--roo-p-space-1);
    padding: var(--roo-p-space-3);
    border: 1px solid transparent;
    border-radius: var(--roo-radius-popover);
    background: var(--roo-raised);
    box-shadow: var(--roo-shadow-popover);
    color: var(--roo-text);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
  }
}
</style>
