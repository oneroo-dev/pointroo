<script setup lang="ts">
// A toolbar that never wraps or clips. The controls (RooOverflowItem, each with a priority) sit in one line; when the width
// runs out, the lowest priority folds first into a trailing "More" menu, in the original visual order. Pinned controls never
// fold. The arithmetic is in RooOverflowBarFit.ts, as RooChipGroup's is in RooChipGroupFit.ts.
import { computed, nextTick, onBeforeUnmount, onMounted, provide, ref, shallowRef } from 'vue'
import { ROO_OVERFLOW_BAR, type OverflowItemEntry } from '../composables/overflowBar'
import RooIconButton from './RooIconButton.vue'
import RooMenu from './RooMenu.vue'
import RooMenuItem from './RooMenuItem.vue'
import { visibleItems } from './RooOverflowBarFit'

const props = withDefaults(defineProps<{ moreLabel?: string }>(), { moreLabel: 'More' })

const root = ref<HTMLElement | null>(null)
const probe = ref<HTMLElement | null>(null)
const entries = shallowRef<OverflowItemEntry[]>([])
const foldedIdentifiers = ref<number[]>([])
let counter = 0

const foldedEntries = computed(() => entries.value.filter((entry) => foldedIdentifiers.value.includes(entry.identifier)))

function sortByPosition(list: OverflowItemEntry[]): OverflowItemEntry[] {
  return [...list].sort((left, right) => {
    if (!left.element || !right.element) return 0
    return left.element.compareDocumentPosition(right.element) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1
  })
}

function measure(): void {
  const row = root.value
  if (!row) return
  const ordered = sortByPosition(entries.value)
  if (ordered.some((entry, index) => entry !== entries.value[index])) entries.value = ordered
  const elements = ordered.map((entry) => entry.element)
  if (elements.length === 0 || elements.some((element) => element === null)) return
  const itemElements = elements as HTMLElement[]
  // Every control is shown, measured, and hidden again as the arithmetic says, in one go, so nothing paints between.
  itemElements.forEach((element) => {
    element.hidden = false
  })
  const gap = Number.parseFloat(getComputedStyle(row).columnGap) || 0
  const widths = itemElements.map((element) => element.getBoundingClientRect().width)
  const moreWidth = probe.value?.getBoundingClientRect().width ?? 0
  const visible = visibleItems({
    items: ordered.map((entry, index) => ({ width: widths[index] ?? 0, priority: entry.priority, pinned: entry.pinned })),
    containerWidth: row.clientWidth,
    gap,
    moreWidth,
  })
  itemElements.forEach((element, index) => {
    element.hidden = !visible[index]
  })
  // Only a changed answer is stored, so a measure that finds the same fold renders nothing and cannot loop.
  const folded = ordered.filter((_, index) => !visible[index]).map((entry) => entry.identifier)
  if (folded.join() !== foldedIdentifiers.value.join()) foldedIdentifiers.value = folded
}

let observer: ResizeObserver | undefined
let frame = 0
function schedule(): void {
  if (typeof requestAnimationFrame === 'undefined') {
    measure()
    return
  }
  cancelAnimationFrame(frame)
  frame = requestAnimationFrame(measure)
}

provide(ROO_OVERFLOW_BAR, {
  nextIdentifier: () => ++counter,
  register(entry) {
    entries.value = [...entries.value, entry]
    void nextTick(schedule)
  },
  unregister(identifier) {
    entries.value = entries.value.filter((entry) => entry.identifier !== identifier)
    foldedIdentifiers.value = foldedIdentifiers.value.filter((folded) => folded !== identifier)
    void nextTick(schedule)
  },
  invalidate: schedule,
  isFolded: (identifier) => foldedIdentifiers.value.includes(identifier),
})

onMounted(() => {
  measure()
  if (root.value && typeof ResizeObserver !== 'undefined') {
    observer = new ResizeObserver(schedule)
    observer.observe(root.value)
  }
})

onBeforeUnmount(() => {
  observer?.disconnect()
  if (typeof cancelAnimationFrame !== 'undefined') cancelAnimationFrame(frame)
})
</script>

<template>
  <div ref="root" class="roo-overflow-bar">
    <slot />
    <RooMenu v-if="foldedEntries.length > 0" align="end">
      <template #trigger>
        <RooIconButton class="roo-overflow-more" icon="more" :label="props.moreLabel" />
      </template>
      <RooMenuItem v-for="entry in foldedEntries" :key="entry.identifier" :icon="entry.icon" :disabled="entry.disabled" @select="entry.run()">
        {{ entry.label }}
      </RooMenuItem>
    </RooMenu>
    <span ref="probe" class="roo-overflow-probe" aria-hidden="true" />
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-overflow-bar {
    position: relative;
    display: flex;
    flex-wrap: nowrap;
    align-items: center;
    gap: var(--roo-p-space-2);
    min-width: 0;
    overflow: clip;
    overflow-clip-margin: var(--roo-p-space-1);
  }

  /* Never seen: it is the More button's box, measured before the button is shown. */
  .roo-overflow-probe {
    position: absolute;
    visibility: hidden;
    pointer-events: none;
    width: var(--roo-control-h);
    height: var(--roo-control-h);
  }
}
</style>
