<script lang="ts">
/** The final action in the list. It stays visible but disabled until custom tags exist, so it cannot be chosen and `manage` is not emitted. */
export const MANAGE_TAGS_LABEL = 'Add or remove tags...'
export const MANAGE_TAGS_HINT = 'Coming later'
const MANAGE_VALUE = '__manage__'
</script>

<script setup lang="ts">
import { computed } from 'vue'
import { ROO_TAGS, TAG_LABELS } from '../environment'
import type { RooTag } from '../types/environment'
import RooSelect from './RooSelect.vue'

const model = defineModel<RooTag>()

withDefaults(defineProps<{ label?: string; disabled?: boolean; size?: 'sm' | 'md' | 'lg'; hideLabel?: boolean }>(), { label: 'Tag', disabled: false, size: 'lg', hideLabel: false })

// Kept for when custom tags exist; not fired while the item is disabled.
defineEmits<{ manage: [] }>()

const options = computed(() => [
  ...ROO_TAGS.map((tag) => ({ value: tag as string, label: TAG_LABELS[tag] })),
  { value: MANAGE_VALUE, label: MANAGE_TAGS_LABEL, disabled: true, hint: MANAGE_TAGS_HINT },
])

// The tag only colours and labels; it never touches the guard. The guard follows it only through `changeTag`.
const selected = computed({
  get: () => model.value as string | undefined,
  set: (value) => {
    if (value === MANAGE_VALUE) return
    if (value !== undefined) model.value = value as RooTag
  },
})
</script>

<template>
  <RooSelect v-model="selected" :options="options" :label="label" :disabled="disabled" :size="size" :hide-label="hideLabel" />
</template>
