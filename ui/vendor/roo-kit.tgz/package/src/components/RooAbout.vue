<script setup lang="ts">
import { computed, onBeforeUnmount, ref } from 'vue'
import RooButton from './RooButton.vue'
import RooIcon from './RooIcon.vue'
import { ROO_FAMILY_URL, ROO_OWNER_NAME } from './about-constants'

export interface RooAboutLinks {
  website?: string
  releaseNotes?: string
  licence: { name: string; url: string }
  source?: string
  thirdPartyNotices?: string
  privacy?: { summary: string; url?: string }
}

export interface RooAboutRow {
  key: string
  label: string
  value?: string
  url?: string | undefined
}

interface AboutRow extends RooAboutRow {
  /** True for the third-party notices row an app opens itself instead of through a link. */
  internal?: boolean
}

const props = withDefaults(
  defineProps<{
    appName: string
    tagline: string
    version: string
    build?: string | undefined
    links: RooAboutLinks
    firstYear?: number
    canCheckForUpdates?: boolean
    /** Rows an app adds after the built-in ones. */
    extraRows?: RooAboutRow[]
    /** Opens the bundled third-party notices in the app; the row then shows without a link. */
    thirdPartyNoticesHandler?: (() => void) | undefined
  }>(),
  { build: undefined, firstYear: 2026, canCheckForUpdates: false, extraRows: () => [], thirdPartyNoticesHandler: undefined },
)

const emit = defineEmits<{ 'open-link': [url: string]; 'check-for-updates': [] }>()

const COPIED_RESET_MS = 2000
const EXTERNAL_HINT = ', opens in the browser'

function activate(row: AboutRow): void {
  if (row.internal) props.thirdPartyNoticesHandler?.()
  else if (row.url) emit('open-link', row.url)
}

const versionLine = computed(() => (props.build ? `Version ${props.version} (build ${props.build})` : `Version ${props.version}`))
const copyText = computed(() => (props.build ? `${props.appName} ${props.version} (${props.build})` : `${props.appName} ${props.version}`))

const rows = computed<AboutRow[]>(() => {
  const links = props.links
  const list: AboutRow[] = []
  if (links.website) list.push({ key: 'website', label: 'Website', url: links.website })
  if (links.releaseNotes) list.push({ key: 'release-notes', label: 'Release notes', url: links.releaseNotes })
  list.push({ key: 'licence', label: 'Licence', value: links.licence.name, url: links.licence.url })
  if (links.source) list.push({ key: 'source', label: 'Source code', url: links.source })
  if (props.thirdPartyNoticesHandler) list.push({ key: 'notices', label: 'Third-party notices', internal: true })
  else if (links.thirdPartyNotices) list.push({ key: 'notices', label: 'Third-party notices', url: links.thirdPartyNotices })
  if (links.privacy) list.push({ key: 'privacy', label: 'Privacy', value: links.privacy.summary, url: links.privacy.url })
  list.push(...props.extraRows)
  return list
})

const footer = computed(() => {
  const currentYear = new Date().getFullYear()
  const years = currentYear > props.firstYear ? `${props.firstYear}-${currentYear}` : `${props.firstYear}`
  return `© ${years} ${ROO_OWNER_NAME}`
})

const copied = ref(false)
let resetTimer: ReturnType<typeof setTimeout> | undefined

async function copyVersion(): Promise<void> {
  try {
    await navigator.clipboard.writeText(copyText.value)
  } catch {
    return
  }
  copied.value = true
  clearTimeout(resetTimer)
  resetTimer = setTimeout(() => {
    copied.value = false
  }, COPIED_RESET_MS)
}

onBeforeUnmount(() => clearTimeout(resetTimer))
</script>

<template>
  <div class="roo-about">
    <section class="roo-about-card roo-about-header">
      <div v-if="$slots.icon" class="roo-about-icon"><slot name="icon" /></div>
      <div class="roo-about-identity">
        <h2 class="roo-about-name">{{ appName }}</h2>
        <p class="roo-about-tagline">{{ tagline }}</p>
        <div class="roo-about-version-line">
          <span class="roo-about-version">{{ versionLine }}</span>
          <button type="button" class="roo-about-copy" aria-label="Copy version" @click="copyVersion">
            <RooIcon :name="copied ? 'check' : 'copy'" :size="14" />
            <span>{{ copied ? 'Copied' : 'Copy' }}</span>
          </button>
          <span class="roo-about-status" role="status" aria-live="polite">{{ copied ? 'Copied' : '' }}</span>
        </div>
      </div>
    </section>

    <button type="button" class="roo-about-card roo-about-row roo-about-family" @click="emit('open-link', ROO_FAMILY_URL)">
      <span class="roo-about-family-label">Part of the {{ ROO_OWNER_NAME }} family</span>
      <span class="roo-visually-hidden">{{ EXTERNAL_HINT }}</span>
      <RooIcon name="pop-out" :size="14" />
    </button>

    <ul class="roo-about-list">
      <li v-for="row in rows" :key="row.key">
        <button v-if="row.url || row.internal" type="button" class="roo-about-row" @click="activate(row)">
          <span class="roo-about-row-label">{{ row.label }}</span>
          <span v-if="row.value" class="roo-about-row-value">{{ row.value }}</span>
          <template v-if="!row.internal">
            <span class="roo-visually-hidden">{{ EXTERNAL_HINT }}</span>
            <RooIcon name="pop-out" :size="14" />
          </template>
        </button>
        <div v-else class="roo-about-row roo-about-row-static">
          <span class="roo-about-row-label">{{ row.label }}</span>
          <span v-if="row.value" class="roo-about-row-value">{{ row.value }}</span>
        </div>
      </li>
    </ul>

    <div v-if="$slots.details" class="roo-about-details"><slot name="details" /></div>

    <div v-if="canCheckForUpdates || $slots.updates" class="roo-about-actions">
      <slot name="updates">
        <RooButton @click="emit('check-for-updates')">Check for updates</RooButton>
      </slot>
    </div>

    <p class="roo-about-footer">{{ footer }}</p>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-about {
    display: flex;
    flex-direction: column;
    gap: var(--roo-p-space-3);
    max-width: 480px;
    margin: 0 auto;
    font-family: var(--roo-font-ui);
    color: var(--roo-text);
  }

  .roo-about-card {
    border: 1px solid transparent;
    border-radius: var(--roo-p-radius-card);
    background: var(--roo-surface);
    box-shadow: var(--roo-shadow-card);
  }

  .roo-about-header {
    display: flex;
    align-items: flex-start;
    gap: var(--roo-space-group);
    padding: var(--roo-space-card);
  }

  .roo-about-icon {
    display: flex;
    flex-shrink: 0;
    width: 48px;
    height: 48px;
    align-items: center;
    justify-content: center;
  }

  .roo-about-identity {
    display: flex;
    min-width: 0;
    flex-direction: column;
    gap: var(--roo-p-space-1);
  }

  .roo-about-name {
    margin: 0;
    font-size: var(--roo-p-size-20);
    font-weight: 600;
  }

  .roo-about-tagline {
    margin: 0;
    font-size: var(--roo-p-size-13);
    color: var(--roo-muted);
  }

  .roo-about-version-line {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--roo-p-space-2);
    margin-top: var(--roo-p-space-1);
  }

  .roo-about-version {
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-about-copy {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-1);
    padding: 2px 8px;
    border: 1px solid transparent;
    border-radius: var(--roo-p-radius-medium);
    background: transparent;
    font-family: inherit;
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
    cursor: default;
    transition:
      background-color var(--roo-fast) var(--roo-ease),
      color var(--roo-fast) var(--roo-ease);
  }

  .roo-about-copy:hover {
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  .roo-about-copy:focus-visible,
  .roo-about-row:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  .roo-about-status {
    position: absolute;
    width: 1px;
    height: 1px;
    margin: -1px;
    padding: 0;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
    border: 0;
  }

  /* One grouped card for the links, rows split by a hairline, like a native settings list. */
  .roo-about-list {
    display: flex;
    flex-direction: column;
    margin: 0;
    padding: 0;
    overflow: hidden;
    list-style: none;
    border: 1px solid transparent;
    border-radius: var(--roo-p-radius-card);
    background: var(--roo-surface);
    box-shadow: var(--roo-shadow-card);
  }

  .roo-about-list li + li {
    border-top: 1px solid var(--roo-line);
  }

  .roo-about-list .roo-about-row {
    border: 0;
    border-radius: 0;
    background: transparent;
  }

  .roo-about-list .roo-about-row:focus-visible {
    outline-offset: -2px;
  }

  .roo-about-row {
    box-sizing: border-box;
    display: flex;
    width: 100%;
    align-items: center;
    gap: var(--roo-p-space-3);
    padding: var(--roo-p-space-3) var(--roo-p-space-4);
    font-family: inherit;
    font-size: var(--roo-p-size-13);
    color: var(--roo-text);
    text-align: left;
  }

  button.roo-about-row {
    cursor: default;
    transition: background-color var(--roo-fast) var(--roo-ease);
  }

  button.roo-about-row:hover {
    background: var(--roo-raised);
  }

  .roo-about-row-label,
  .roo-about-family-label {
    flex: 1;
  }

  .roo-about-row-value {
    min-width: 0;
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
    text-align: right;
  }

  .roo-about-row :deep(svg) {
    flex-shrink: 0;
    color: var(--roo-faint);
  }

  .roo-about-actions {
    display: flex;
    justify-content: center;
  }

  .roo-about-details {
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
    text-align: center;
  }

  /* Opt-in only (K1c, X12): an app that has set data-density gets the arrow, muted glyphs and the stacked row. */
  :where([data-density]) .roo-about {
    container-type: inline-size;
  }

  :where([data-density]) button.roo-about-row {
    cursor: default;
  }

  :where([data-density]) .roo-about-row :deep(svg) {
    color: var(--roo-muted);
  }

  :where([data-density]) .roo-about-row-label {
    white-space: nowrap;
  }

  @container (max-width: 439px) {
    :where([data-density]) .roo-about-row {
      display: grid;
      grid-template-columns: 1fr auto;
      align-items: center;
      row-gap: var(--roo-p-space-1);
    }

    :where([data-density]) .roo-about-row-value {
      grid-column: 1 / -1;
      grid-row: 2;
      text-align: left;
    }
  }

  .roo-about-footer {
    margin: var(--roo-p-space-2) 0 0;
    text-align: center;
    font-size: var(--roo-p-size-12);
    color: var(--roo-faint);
  }

  /* An invisible tap area of at least --roo-touch-target on a coarse pointer (family rule F6, Fable review). The drawn size never changes. */
  @media (pointer: coarse) {
    .roo-about-copy {
      position: relative;
    }

    .roo-about-copy::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2));
    }
  }
}
</style>
