<script lang="ts">
/** A row's share of the whole, as a whole-number percent from 0 to 100. A total of 0 or less is 0%. */
export function rankedShare(amount: number, total: number): number {
  if (!(total > 0) || !(amount > 0)) return 0
  return Math.min(100, Math.round((amount / total) * 100))
}
</script>

<script setup lang="ts">
// One row of a ranked list: a label with an optional project swatch and secondary text, a value at the right, and a
// thin bar under the row for its share of the total. The bar is a meter with words for its value, so the share is never
// only a length.
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    label: string
    /** The value as text, such as `4h 12m`. */
    value: string
    /** The row's number and the whole it is part of, in the same unit. */
    amount: number
    total: number
    secondary?: string
    /** A colour for the project, such as `var(--roo-x-project-1)`. Drawn as a small square before the label. */
    swatch?: string
    /** What the share is a share of, spoken after the percent: `18% of time spent`. */
    shareOf?: string
    /** `dense` is the 38px two-line row (--roo-list-row-2-dense-h, the TablePlus measure) with 12px title and subtitle; without it the row is --roo-list-row-2-h (44 or 52). */
    size?: 'dense'
  }>(),
  { secondary: '', swatch: '', shareOf: 'of the total' },
)

const share = computed(() => rankedShare(props.amount, props.total))
const valueText = computed(() => `${share.value}% ${props.shareOf}`)
</script>

<template>
  <div class="roo-ranked-row" :data-size="size">
    <span v-if="swatch" class="roo-ranked-swatch" aria-hidden="true" :style="{ background: swatch }" />
    <span class="roo-ranked-text">
      <span class="roo-ranked-label">{{ label }}</span>
      <span v-if="secondary" class="roo-ranked-secondary">{{ secondary }}</span>
    </span>
    <span class="roo-ranked-value">{{ value }}</span>
    <span class="roo-ranked-track" role="meter" :aria-label="label" aria-valuemin="0" aria-valuemax="100" :aria-valuenow="share" :aria-valuetext="valueText">
      <span class="roo-ranked-bar" :style="{ width: `${share}%` }" />
    </span>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-ranked-row {
    position: relative;
    display: flex;
    min-height: var(--roo-list-row-2-h);
    box-sizing: border-box;
    align-items: center;
    gap: 8px;
    padding: 6px var(--roo-row-pad-inline) 10px;
    font-size: var(--roo-p-size-13);
  }

  /* Dense: 38px, 12px title and subtitle on 14px lines (28), 3px above and 7px below, with the 4px share track on the bottom edge, 3px under the text. */
  .roo-ranked-row[data-size='dense'] {
    min-height: var(--roo-list-row-2-dense-h);
    padding: 3px var(--roo-row-pad-inline) 7px;
    font-size: var(--roo-p-size-12);
  }

  .roo-ranked-row[data-size='dense'] .roo-ranked-label,
  .roo-ranked-row[data-size='dense'] .roo-ranked-secondary {
    line-height: 14px;
  }

  .roo-ranked-row[data-size='dense'] .roo-ranked-track {
    bottom: 0;
  }

  .roo-ranked-swatch {
    width: 12px;
    height: 12px;
    flex: none;
    border-radius: var(--roo-p-radius-mark);
  }

  .roo-ranked-text {
    display: flex;
    min-width: 0;
    flex: 1;
    flex-direction: column;
  }

  .roo-ranked-label {
    overflow: hidden;
    color: var(--roo-text);
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-ranked-secondary {
    overflow: hidden;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-ranked-value {
    flex: none;
    color: var(--roo-text);
    font-family: var(--roo-font-mono);
    font-variant-numeric: tabular-nums;
  }

  .roo-ranked-track {
    position: absolute;
    right: var(--roo-row-pad-inline);
    bottom: 4px;
    left: var(--roo-row-pad-inline);
    height: 4px;
    overflow: hidden;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-raised);
  }

  .roo-ranked-bar {
    display: block;
    height: 100%;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-muted);
    transition: width var(--roo-base) var(--roo-ease);
  }
}
</style>
