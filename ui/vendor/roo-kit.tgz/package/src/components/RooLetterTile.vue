<script setup lang="ts">
// The workspace letter tile in the title bar pill (Raja, 2026-11-17): the first letter of the name, white on a fill the
// caller picks. The pill says the name, so the tile is hidden from assistive technology.
import { computed } from 'vue'
import { firstLetter } from '../composables/firstLetter'

const props = withDefaults(
  defineProps<{
    name: string
    /** Any CSS colour. Left out, the tile takes the neutral fill. */
    color?: string | undefined
    /** Pixels: 18 (the bar tile, default), 22 (connection tiles), 28 (workspace rows) or 30 (the closed rail, with the 9px bar corner). The radius and letter follow. */
    size?: 18 | 22 | 28 | 30
  }>(),
  { color: undefined, size: 18 },
)

const letter = computed(() => firstLetter(props.name))

// The caller's colour reaches the rule as one custom property, so the stylesheet keeps the neutral default.
const fill = computed(() => (props.color ? { '--roo-letter-tile-fill': props.color } : undefined))
</script>

<template>
  <span class="roo-letter-tile" aria-hidden="true" :data-size="size" :style="fill">{{ letter }}</span>
</template>

<style scoped>
@layer roo-components {
  .roo-letter-tile {
    display: inline-grid;
    flex: none;
    place-items: center;
    box-sizing: border-box;
    width: var(--roo-bar-tile);
    height: var(--roo-bar-tile);
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-letter-tile-fill, var(--roo-x-tile));
    color: var(--roo-p-white);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    font-weight: 700;
    line-height: 1;
    user-select: none;
  }

  .roo-letter-tile[data-size='22'] {
    width: var(--roo-tile-md);
    height: var(--roo-tile-md);
  }

  .roo-letter-tile[data-size='28'] {
    width: var(--roo-tile-lg);
    height: var(--roo-tile-lg);
    border-radius: var(--roo-p-radius-medium);
    font-size: var(--roo-p-size-13);
  }

  .roo-letter-tile[data-size='30'] {
    width: var(--roo-tile-xl);
    height: var(--roo-tile-xl);
    border-radius: var(--roo-bar-radius);
  }
}
</style>
