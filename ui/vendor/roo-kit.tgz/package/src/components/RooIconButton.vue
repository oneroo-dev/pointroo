<script setup lang="ts">
// An icon-only button. `loading` swaps the glyph for the kit spinner, sets aria-busy and blocks clicks. The spinner takes the
// glyph's exact box, centred, and the button stays up in the depth look (data-busy-style="centred", as a centred RooButton), so
// busy changes nothing but the glyph. `tooltip` (and `shortcut`) wrap it in a RooTooltip, which needs one RooTooltipProvider above it. Primary and
// danger are drawn like RooButton's, so a Send or Delete icon matches the text buttons beside it. On a coarse pointer the button has an
// invisible hit area of at least --roo-touch-target (44 px), `data-touch-target="44"`; a hold-to-confirm button clips its fill with
// overflow, which clips the area too, so it says `clipped` and the tap-target probe reports it.
import { computed, mergeProps, useAttrs } from 'vue'
import type { ConfirmGesture } from '../composables/useConfirmGesture'
import RooIcon from './RooIcon.vue'
import RooTooltip from './RooTooltip.vue'
import type { RooIconName } from '../icons/paths'

defineOptions({ inheritAttrs: false })

const props = withDefaults(
  defineProps<{
    icon: RooIconName
    label: string
    variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'quiet'
    /** `sm` and `md` are the bar height (--roo-control-h). `xs` is the smaller in-row action (--roo-icon-button). `xxs` is the dense in-row action: a 20px box with a 14px glyph. `xxxs` is the A2 card close: an 18px box with a 12px glyph. `compact` is a square of --roo-compact-control-h, the height of a dense filter row, with a 14px glyph. `capsule` is the toolbar action: a square of --roo-control-h with no ring and no fill at rest and a soft fill on hover; inside a RooCapsuleGroup of two or more buttons the group draws the one 1px hairline and the button sits 1px in. */
    size?: 'capsule' | 'compact' | 'xxxs' | 'xxs' | 'xs' | 'sm' | 'md'
    /** `round` is a circle (the full radius, --roo-p-radius-pill), for the dense close button on a card. Square is the default. */
    shape?: 'square' | 'round'
    pressed?: boolean | undefined
    disabled?: boolean
    /** Shows the spinner in place of the glyph, sets aria-busy and ignores clicks. */
    loading?: boolean
    /** Tooltip text. Left out, there is no tooltip. */
    tooltip?: string
    /** Shortcut shown beside the tooltip text. Only used with `tooltip`. */
    shortcut?: string
    tooltipSide?: 'top' | 'bottom' | 'left' | 'right'
    /** A confirm gesture (useConfirmGesture): the button then holds or presses twice before the action runs, exactly as RooHoldButton does, with a fill rising from the bottom edge. The action lives in the gesture, so `click` is not emitted. */
    gesture?: ConfirmGesture
    /** What the button does ("delete"): while armed the accessible name reads "Press again to <verb>". Only used with `gesture`. */
    verb?: string
  }>(),
  { variant: 'ghost', size: 'md', shape: 'square', pressed: undefined, disabled: false, loading: false, tooltip: '', shortcut: '', tooltipSide: 'bottom', verb: 'continue' },
)

const emit = defineEmits<{ click: [event: MouseEvent] }>()

if (!props.label.trim()) {
  console.warn('[RooIconButton] label is empty. An icon button needs a label for its accessible name.')
}

const glyphSize = computed(() => (props.size === 'xxxs' ? 12 : props.size === 'xxs' || props.size === 'compact' ? 14 : 16))
const spinnerStyle = computed(() => ({ width: `${glyphSize.value}px`, height: `${glyphSize.value}px` }))

const attributes = useAttrs()
// The gesture's bindings minus its click: the click goes through onClick, so a busy button blocks it first.
const holdBindings = computed(() => {
  if (!props.gesture) return {}
  const { onClick: _gestureClick, ...bindings } = props.gesture.bindings.value
  return bindings
})
const mergedAttributes = computed(() => mergeProps(attributes, holdBindings.value))
const shownLabel = computed(() => (props.gesture?.armed.value ? `Press again to ${props.verb}` : props.label))
const fillStyle = computed(() => ({ transform: `scaleY(${props.gesture?.progress.value ?? 0})` }))

function onClick(event: MouseEvent): void {
  if (props.loading) {
    event.preventDefault()
    return
  }
  if (props.gesture) {
    props.gesture.onClick(event)
    return
  }
  emit('click', event)
}
</script>

<template>
  <RooTooltip v-if="tooltip" :text="tooltip" :shortcut="shortcut" :side="tooltipSide">
    <button
      v-bind="mergedAttributes"
      class="roo-icon-button"
      type="button"
      :data-variant="variant"
      :data-size="size"
      :data-shape="shape === 'round' ? 'round' : undefined"
      :data-touch-target="gesture ? 'clipped' : '44'"
      :data-pressed="pressed || undefined"
      :data-hold="gesture ? 'true' : undefined"
      :aria-label="shownLabel"
      :aria-pressed="pressed"
      :aria-busy="loading || undefined"
      :data-busy-style="loading ? 'centred' : undefined"
      :disabled="disabled"
      @click="onClick"
    >
      <span v-if="gesture" class="roo-icon-button-fill" :style="fillStyle" aria-hidden="true"></span>
      <span v-if="loading" class="roo-icon-button-spinner" :style="spinnerStyle" aria-hidden="true"></span>
      <RooIcon v-else :name="icon" :size="glyphSize" />
    </button>
  </RooTooltip>
  <button
    v-else
    v-bind="mergedAttributes"
    class="roo-icon-button"
    type="button"
    :data-variant="variant"
    :data-size="size"
    :data-shape="shape === 'round' ? 'round' : undefined"
    :data-touch-target="gesture ? 'clipped' : '44'"
    :data-pressed="pressed || undefined"
    :data-hold="gesture ? 'true' : undefined"
    :aria-label="shownLabel"
    :aria-pressed="pressed"
    :aria-busy="loading || undefined"
    :data-busy-style="loading ? 'centred' : undefined"
    :disabled="disabled"
    @click="onClick"
  >
    <span v-if="gesture" class="roo-icon-button-fill" :style="fillStyle" aria-hidden="true"></span>
    <span v-if="loading" class="roo-icon-button-spinner" :style="spinnerStyle" aria-hidden="true"></span>
    <RooIcon v-else :name="icon" :size="glyphSize" />
  </button>
</template>

<style scoped>
@layer roo-components {
  .roo-icon-button {
    box-sizing: border-box;
    display: inline-flex;
    flex-shrink: 0;
    align-items: center;
    justify-content: center;
    border: 1px solid transparent;
    border-radius: var(--roo-radius-control);
    padding: 0;
    cursor: default;
    user-select: none;
    transition:
      background-color var(--roo-fast) var(--roo-ease),
      color var(--roo-fast) var(--roo-ease),
      border-color var(--roo-fast) var(--roo-ease),
      filter var(--roo-fast) var(--roo-ease);
  }

  /* An invisible tap area of at least --roo-touch-target on a coarse pointer; the visible box and the layout do not change. */
  @media (pointer: coarse) {
    .roo-icon-button {
      position: relative;
    }

    .roo-icon-button::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2));
    }
  }

  .roo-icon-button[data-size='sm'] {
    width: var(--roo-control-h);
    height: var(--roo-control-h);
  }

  .roo-icon-button[data-size='md'] {
    width: var(--roo-control-h);
    height: var(--roo-control-h);
  }

  /* In the title bar the 32px buttons take the bar control corner (Raja 2026-11-18), like the app mark and the workspace dropdown. Outside the bar the corner is unchanged. */
  :where([data-roo-region='bar']) .roo-icon-button:not([data-size='xs']) {
    border-radius: var(--roo-bar-control-radius);
  }

  .roo-icon-button[data-size='xs'] {
    width: var(--roo-icon-button);
    height: var(--roo-icon-button);
  }

  /* The dense in-row action (Copy, Copy as): a 20px box and a 14px glyph. It keeps the medium corner in the bar too. */
  .roo-icon-button[data-size='xxs'] {
    width: var(--roo-icon-button-xxs);
    height: var(--roo-icon-button-xxs);
    border-radius: var(--roo-p-radius-small);
  }

  /* The A2 card close: an 18px box and a 12px glyph, the medium corner in the bar too (shape round still wins). */
  .roo-icon-button[data-size='xxxs'] {
    width: var(--roo-icon-button-xxxs);
    height: var(--roo-icon-button-xxxs);
    border-radius: var(--roo-tag-radius);
  }

  /* The dense filter-row action (minus, plus): a square as tall as the row's other controls, the small corner in the bar too. */
  .roo-icon-button[data-size='compact'] {
    width: var(--roo-compact-control-h);
    height: var(--roo-compact-control-h);
    border-radius: var(--roo-p-radius-small);
  }

  /* The toolbar action (Raja 2026-11-22, option 1 "quiet" picked): a square at the control height (--roo-control-h) in a 1px transparent edge. No ring, no fill at rest, the soft fill on hover and when pressed; secondary and quiet look the same at this size. Inside a RooCapsuleGroup of two or more buttons the group draws the one hairline. */
  .roo-icon-button[data-size='capsule'] {
    width: var(--roo-control-h);
    height: var(--roo-control-h);
    border-radius: var(--roo-radius-control);
  }

  .roo-icon-button[data-size='capsule']:is([data-variant='ghost'], [data-variant='secondary'], [data-variant='quiet']):not(:disabled) {
    border-color: transparent;
    background: transparent;
    color: var(--roo-muted);
  }

  .roo-icon-button[data-size='capsule'] :deep(svg) {
    width: var(--roo-icon);
    height: var(--roo-icon);
  }

  .roo-icon-button[data-size='capsule']:is([data-variant='ghost'], [data-variant='secondary'], [data-variant='quiet']):not(:disabled):is(:hover, [data-pressed]) {
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  [data-on-raised='true'] .roo-icon-button[data-size='capsule']:is([data-variant='ghost'], [data-variant='secondary'], [data-variant='quiet']):not(:disabled):is(:hover, [data-pressed]) {
    background: var(--roo-raised-hover);
  }

  /* Round: the full corner (a circle), after every other corner rule and equal to the bar rule in specificity, so it wins at xxs and in the bar. */
  .roo-icon-button[data-shape='round'] {
    border-radius: var(--roo-icon-button-round-radius);
  }

  /* The glyph of the three density steps follows the density's icon size (16 comfortable, 12 compact). */
  .roo-icon-button[data-size='sm'] :deep(svg),
  .roo-icon-button[data-size='md'] :deep(svg),
  .roo-icon-button[data-size='xs'] :deep(svg) {
    width: var(--roo-icon);
    height: var(--roo-icon);
  }

  .roo-icon-button[data-size='xxs'] :deep(svg),
  .roo-icon-button[data-size='compact'] :deep(svg) {
    width: var(--roo-icon-button-xxs-glyph);
    height: var(--roo-icon-button-xxs-glyph);
  }

  .roo-icon-button[data-size='xxxs'] :deep(svg) {
    width: var(--roo-icon-button-xxxs-glyph);
    height: var(--roo-icon-button-xxxs-glyph);
  }

  /* Hold to confirm (a gesture is bound): the same fill as RooHoldButton, risen from the bottom edge because the box is square. */
  .roo-icon-button[data-hold='true'] {
    position: relative;
    overflow: hidden;
    isolation: isolate;
    touch-action: none;
  }

  .roo-icon-button-fill {
    position: absolute;
    inset: 0;
    z-index: -1;
    background: color-mix(in srgb, var(--roo-text) 12%, transparent);
    transform-origin: center bottom;
    transform: scaleY(0);
    transition: transform 150ms var(--roo-exit);
  }

  .roo-icon-button[data-variant='primary'] .roo-icon-button-fill {
    background: color-mix(in srgb, var(--roo-p-white) 30%, transparent);
  }

  .roo-icon-button[data-variant='danger'] .roo-icon-button-fill {
    background: color-mix(in srgb, currentColor 14%, transparent);
  }

  .roo-icon-button[data-holding='true'] .roo-icon-button-fill {
    transition: none;
  }

  /* Reduced motion skips the fill animation, not the hold. */
  :global(.roo-force-reduced .roo-icon-button-fill),
  :global([data-motion='still'] .roo-icon-button-fill) {
    display: none;
  }

  @media (prefers-reduced-motion: reduce) {
    .roo-icon-button-fill {
      display: none;
    }
  }

  /* Armed: the press-twice second step inverts to the text colour, like RooHoldButton. */
  .roo-icon-button[data-hold='true'][data-armed='true']:not(:disabled) {
    border-color: var(--roo-text);
    background: var(--roo-text);
    color: var(--roo-surface);
  }

  .roo-icon-button[data-hold='true'][data-variant='danger'][data-armed='true']:not(:disabled) {
    border-color: var(--roo-danger-text);
    background: var(--roo-danger-text);
    color: var(--roo-surface);
  }

  /* The glyph's own box (width and height set from the glyph size), so swapping the glyph for the spinner moves nothing. */
  .roo-icon-button-spinner {
    box-sizing: border-box;
    flex-shrink: 0;
    border: 2px solid currentColor;
    border-right-color: transparent;
    border-radius: 50%;
    animation: roo-icon-button-spin 700ms linear infinite;
  }

  /* The solid accent is the deeper fill with white on it (Raja, 2026-11-17). Hover and press darken the fill itself. */
  .roo-icon-button[data-variant='primary'] {
    background: var(--roo-accent-fill);
    color: var(--roo-on-accent-fill);
  }

  .roo-icon-button[data-variant='primary']:hover:not(:disabled) {
    background: color-mix(in srgb, var(--roo-accent-fill) 90%, black);
  }

  .roo-icon-button[data-variant='primary']:active:not(:disabled) {
    background: color-mix(in srgb, var(--roo-accent-fill) 80%, black);
  }

  .roo-icon-button[data-variant='secondary'] {
    border-color: var(--roo-border-floating);
    background: var(--roo-surface);
    color: var(--roo-text);
  }

  .roo-icon-button[data-variant='quiet'] {
    border-color: var(--roo-border);
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  .roo-icon-button[data-variant='quiet']:hover:not(:disabled) {
    border-color: var(--roo-border-floating);
    background: color-mix(in srgb, var(--roo-raised) 88%, var(--roo-text));
  }

  /* Pressed is a colour and ring step, never a movement: the fill takes more of the text colour and the hairline steps up. */
  .roo-icon-button[data-variant='quiet']:active:not(:disabled) {
    border-color: var(--roo-border-floating);
    background: color-mix(in srgb, var(--roo-raised) 90%, var(--roo-text));
  }

  .roo-icon-button[data-variant='ghost'] {
    background: transparent;
    color: var(--roo-muted);
  }

  .roo-icon-button[data-variant='ghost']:hover {
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  .roo-icon-button[data-variant='ghost']:active:not(:disabled) {
    background: color-mix(in srgb, var(--roo-raised) 92%, var(--roo-text));
    color: var(--roo-text);
  }

  /* Danger has no tint (Raja's ruling 3): the secondary surface and edge in every state, a crimson glyph, and only the
     colour deepens on hover and press. */
  .roo-icon-button[data-variant='danger'] {
    border-color: var(--roo-border-floating);
    background: var(--roo-surface);
    color: var(--roo-danger-text);
  }

  .roo-icon-button[data-variant='secondary']:hover,
  .roo-icon-button[data-variant='danger']:hover {
    border-color: var(--roo-border-hover);
    background: var(--roo-raised);
  }

  .roo-icon-button[data-variant='secondary']:active:not(:disabled),
  .roo-icon-button[data-variant='danger']:active:not(:disabled) {
    border-color: var(--roo-border-hover);
    background: color-mix(in srgb, var(--roo-raised) 90%, var(--roo-text));
  }

  .roo-icon-button[data-variant='danger']:hover {
    color: color-mix(in srgb, var(--roo-danger-text) 80%, var(--roo-text));
  }

  .roo-icon-button[data-variant='danger']:active:not(:disabled) {
    color: color-mix(in srgb, var(--roo-danger-text) 60%, var(--roo-text));
  }

  .roo-icon-button[data-pressed]:not([data-variant='primary']):not([data-variant='danger']) {
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  .roo-icon-button[data-pressed]:hover:not(:disabled):not([data-variant='primary']):not([data-variant='danger']) {
    background: color-mix(in srgb, var(--roo-raised) 92%, var(--roo-text));
  }

  .roo-icon-button:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  /* Every disabled control is neutral grey: it should never compete or look like its live colour. */
  .roo-icon-button:disabled {
    background: var(--roo-raised);
    color: var(--roo-faint);
    border-color: transparent;
    box-shadow: none;
    pointer-events: none;
  }

  /* A ghost button has no fill when live, so disabled keeps none: the faint glyph alone marks it. Other variants keep the grey fill. */
  .roo-icon-button[data-variant='ghost']:disabled {
    background: transparent;
  }
}

@keyframes roo-icon-button-spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
