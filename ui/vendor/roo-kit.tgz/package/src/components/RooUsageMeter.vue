<script lang="ts">
export type RooUsageMeterState = 'normal' | 'warning' | 'limit'

export interface RooUsageMeterSegment {
  /** What this part is, such as `Included` or `Paid`. It is shown in the legend, so the part never relies on colour. */
  label: string
  value: number
  /** `free` keeps its own colour at every state; `paid` follows the meter's state. */
  kind?: 'free' | 'paid'
}

/** A meter turns to its warning at this share of the limit. */
export const USAGE_METER_WARN_AT = 0.8

/** The state of a meter: normal, warning from 80% of the limit, at the limit from 100%. A limit of 0 or less never warns. */
export function usageMeterState(used: number, limit: number | null | undefined): RooUsageMeterState {
  if (limit === null || limit === undefined || !Number.isFinite(limit) || limit <= 0) return 'normal'
  const share = used / limit
  if (share >= 1) return 'limit'
  if (share >= USAGE_METER_WARN_AT) return 'warning'
  return 'normal'
}
</script>

<script setup lang="ts">
import { computed } from 'vue'
import RooIcon from './RooIcon.vue'
import { useId } from 'reka-ui'

const props = withDefaults(
  defineProps<{
    /** The visible name of what is measured, such as `Events`. It is also the accessible name. */
    label: string
    /** Used so far. Ignored when `segments` are given: the segments add up to it. */
    used?: number
    /** The most there is. Null, undefined or Infinity means unlimited: the readout shows only the used amount. */
    limit?: number | null
    /** The used amount in parts, such as the free part and the paid part. Drawn in order, left to right. */
    segments?: RooUsageMeterSegment[]
    /** Turns a number into text, such as `1.2M`. Used for the readout and for the screen reader. */
    formatValue?: ((value: number) => string) | undefined
    /** The words shown beside the icon at 80% and at 100%. */
    warningText?: string
    limitText?: string
    /** `inline` puts the label, the track and the readout on one line. `stacked` (default) draws the label and readout above the track. */
    layout?: 'stacked' | 'inline'
    /** Hides the label from sight and keeps it for screen readers (the readout and track still show). */
    hideLabel?: boolean
    /** Hides the readout above the track. It is also hidden when the `figure` slot is filled, so the figure shows once. The meter keeps its spoken value text either way. */
    hideReadout?: boolean
    /** A table-cell meter: just the track (thinner), with the label, readout, legend and status words kept for screen readers only. The meter keeps its spoken value text. */
    compact?: boolean
    /** Soft allowance (a paid plan's free amount, not a limit): the used amount is drawn in two parts, the free part muted and the billed part past it in ink. The meter never warns and never says "Limit reached"; the scale is the larger of the allowance and the used amount. Ignores `limit` and `segments`. */
    allowance?: number | null
    /** Text for the two parts of an allowance meter, read aloud and shown in the legend. */
    allowanceLabels?: { free: string; billed: string }
    /** A lighter part drawn from the used amount up to this forecast (an annual plan's month so far, then the rest of the month's forecast). */
    forecast?: number | null
    /** A commitment tick: a 2 px mark across the track at this value. The track widens to fit the tick and the forecast when they pass the limit. */
    tick?: number | null
    /** Name of the tick for the screen reader, such as `Commitment`. */
    tickLabel?: string
    /** Keeps the legend of a segmented or allowance meter for screen readers only, so the meter has no extra row when the figure is said elsewhere. */
    hideLegend?: boolean
    /** Keeps the status words (`Nearing limit`, `Limit reached`) for screen readers only. The track and the state colour still change, but the meter keeps the same box in every state: the caller says the state in its own line. */
    quietStatus?: boolean
  }>(),
  { compact: false, hideLegend: false, quietStatus: false, allowance: null, allowanceLabels: () => ({ free: 'free', billed: 'billed' }), forecast: null, tick: null, tickLabel: 'Commitment', layout: 'stacked', hideLabel: false, hideReadout: false, used: 0, limit: null, segments: () => [], formatValue: undefined, warningText: 'Nearing limit', limitText: 'Limit reached' },
)

const id = useId(undefined, 'roo-usage-meter')

function format(value: number): string {
  return props.formatValue ? props.formatValue(value) : value.toLocaleString('en-US')
}

const soft = computed(() => typeof props.allowance === 'number' && Number.isFinite(props.allowance) && props.allowance >= 0)
const finiteLimit = computed(() => {
  if (soft.value) return null
  return typeof props.limit === 'number' && Number.isFinite(props.limit) ? props.limit : null
})
const hasForecast = computed(() => typeof props.forecast === 'number' && Number.isFinite(props.forecast) && props.forecast > 0)
const hasTick = computed(() => typeof props.tick === 'number' && Number.isFinite(props.tick) && props.tick > 0)
// The track is drawn for a limit, a soft allowance, a forecast or a tick; with none of them an unlimited meter has no track.
const hasTrack = computed(() => !unlimited.value || soft.value || hasForecast.value || hasTick.value)
const unlimited = computed(() => finiteLimit.value === null)
const limitValue = computed(() => finiteLimit.value ?? 0)

const total = computed(() => (!soft.value && props.segments.length > 0 ? props.segments.reduce((sum, part) => sum + part.value, 0) : props.used))
const state = computed(() => usageMeterState(total.value, finiteLimit.value))
const percent = computed(() => (limitValue.value > 0 ? Math.round((total.value / limitValue.value) * 100) : 0))

// A meter's value stays inside its range, so an overage reads as full here and says how far over in the text.
const valueNow = computed(() => Math.min(Math.max(total.value, 0), Math.max(limitValue.value, 0)))

const scale = computed(() =>
  Math.max(finiteLimit.value ?? 0, soft.value ? (props.allowance as number) : 0, total.value, hasForecast.value ? (props.forecast as number) : 0, hasTick.value ? (props.tick as number) : 0, 1),
)
const freePart = computed(() => (soft.value ? Math.min(Math.max(total.value, 0), props.allowance as number) : 0))
const billedPart = computed(() => (soft.value ? Math.max(total.value - (props.allowance as number), 0) : 0))
const tickLeft = computed(() => (hasTick.value ? `${((props.tick as number) / scale.value) * 100}%` : '0%'))
const forecastWidth = computed(() => (hasForecast.value ? `${(Math.max(props.forecast as number, 0) / scale.value) * 100}%` : '0%'))

const valueText = computed(() => {
  if (soft.value) return `${format(freePart.value)} ${props.allowanceLabels.free}, ${format(billedPart.value)} ${props.allowanceLabels.billed}`
  if (hasForecast.value || hasTick.value) {
    const bits = [`${format(total.value)} used`]
    if (hasForecast.value) bits.push(`${format(props.forecast as number)} forecast`)
    if (hasTick.value) bits.push(`${props.tickLabel.toLowerCase()} ${format(props.tick as number)}`)
    return bits.join(', ')
  }
  if (unlimited.value) return format(total.value)
  const base = `${format(total.value)} of ${format(limitValue.value)}, ${percent.value}%`
  if (state.value === 'warning') return `${base}, ${props.warningText}`
  if (state.value === 'limit') return `${base}, ${props.limitText}`
  return base
})

const statusText = computed(() => (state.value === 'warning' ? props.warningText : state.value === 'limit' ? props.limitText : ''))

const parts = computed(() => {
  if (soft.value) {
    return [
      { key: 'free', kind: 'soft' as const, label: props.allowanceLabels.free, text: format(freePart.value), width: `${(freePart.value / scale.value) * 100}%` },
      { key: 'billed', kind: 'billed' as const, label: props.allowanceLabels.billed, text: format(billedPart.value), width: `${(billedPart.value / scale.value) * 100}%` },
    ]
  }
  const source: RooUsageMeterSegment[] = props.segments.length > 0 ? props.segments : [{ label: props.label, value: props.used, kind: 'paid' }]
  const fit = scale.value
  return source.map((part, index) => ({
    key: `${index}-${part.label}`,
    kind: part.kind ?? 'paid',
    label: part.label,
    text: format(part.value),
    width: `${limitValue.value > 0 || hasForecast.value || hasTick.value ? Math.min((Math.max(part.value, 0) / fit) * 100, 100) : 0}%`,
  }))
})
</script>

<template>
  <div class="roo-usage-meter" :data-state="state" :data-layout="layout" :data-compact="compact || undefined">
    <div class="roo-usage-meter-head">
      <span :id="`${id}-label`" class="roo-usage-meter-label" :class="{ 'roo-visually-hidden': hideLabel || compact }">{{ label }}</span>
      <span v-if="statusText" class="roo-usage-meter-status" :class="{ 'roo-visually-hidden': quietStatus }" :data-state="state">
        <RooIcon :name="state === 'limit' ? 'alert' : 'warning'" :size="12" />
        <span :class="{ 'roo-visually-hidden': compact }">{{ statusText }}</span>
      </span>
      <span v-if="!hideReadout && !compact && !$slots.figure" class="roo-usage-meter-readout" :aria-hidden="unlimited ? undefined : 'true'">{{ unlimited ? format(total) : `${format(total)} of ${format(limitValue)}` }}</span>
    </div>
    <div
      v-if="hasTrack"
      class="roo-usage-meter-track"
      role="meter"
      :aria-labelledby="`${id}-label`"
      :data-soft="soft || undefined"
      :data-ticked="hasTick || undefined"
      :aria-valuenow="soft || hasForecast || hasTick ? Math.min(total, scale) : valueNow"
      aria-valuemin="0"
      :aria-valuemax="soft || hasForecast || hasTick ? scale : limitValue"
      :aria-valuetext="valueText"
    >
      <span v-if="hasForecast" class="roo-usage-meter-part" data-kind="forecast" :style="{ width: forecastWidth, position: 'absolute', left: 0, top: 0 }" />
      <span v-for="part in parts" :key="part.key" class="roo-usage-meter-part" :data-kind="part.kind" :style="{ width: part.width }" />
      <span v-if="hasTick" class="roo-usage-meter-tick" :style="{ left: tickLeft }" :title="tickLabel" />
    </div>
    <div v-if="$slots.figure && !compact" class="roo-usage-meter-figure"><slot name="figure" :used="total" :limit="finiteLimit" :state="state" /></div>
    <ul v-if="(segments.length > 0 || soft) && !compact" class="roo-usage-meter-legend" :class="{ 'roo-visually-hidden': hideLegend }">
      <li v-for="part in parts" :key="part.key" class="roo-usage-meter-legend-item">
        <span class="roo-usage-meter-swatch" :data-kind="part.kind" aria-hidden="true" />
        <span>{{ part.label }}</span>
        <span class="roo-usage-meter-legend-value">{{ part.text }}</span>
      </li>
    </ul>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-usage-meter {
    display: flex;
    flex-direction: column;
    gap: var(--roo-p-space-2);
    width: 100%;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-13);
    color: var(--roo-text);
  }

  .roo-usage-meter[data-layout='inline'] {
    flex-direction: row;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--roo-p-space-2) var(--roo-p-space-3);
  }

  .roo-usage-meter[data-layout='inline'] .roo-usage-meter-head {
    display: contents;
  }

  .roo-usage-meter[data-layout='inline'] .roo-usage-meter-label {
    order: 1;
  }

  .roo-usage-meter[data-layout='inline'] .roo-usage-meter-track {
    order: 2;
    flex: 1 1 0;
    min-width: 0;
  }

  .roo-usage-meter[data-layout='inline'] .roo-usage-meter-status {
    order: 3;
  }

  .roo-usage-meter[data-layout='inline'] .roo-usage-meter-readout {
    order: 4;
    margin-left: 0;
  }

  .roo-usage-meter[data-layout='inline'] .roo-usage-meter-figure,
  .roo-usage-meter[data-layout='inline'] .roo-usage-meter-legend {
    order: 5;
    flex-basis: 100%;
  }

  /* In a table cell: the track alone, 4px tall, filling the cell width; the state icon stays beside it. */
  .roo-usage-meter[data-compact] {
    flex-direction: row;
    align-items: center;
    gap: var(--roo-p-space-2);
    min-width: 48px;
  }

  .roo-usage-meter[data-compact] .roo-usage-meter-head {
    display: contents;
  }

  .roo-usage-meter[data-compact] .roo-usage-meter-track {
    order: 1;
    flex: 1 1 0;
    min-width: 0;
    height: 4px;
  }

  .roo-usage-meter[data-compact] .roo-usage-meter-status {
    order: 2;
    line-height: 0;
  }

  .roo-usage-meter-head {
    display: flex;
    align-items: baseline;
    gap: var(--roo-p-space-2);
  }

  .roo-usage-meter-label {
    font-weight: 600;
  }

  .roo-usage-meter-status {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-1);
    font-size: var(--roo-p-size-12);
    font-weight: 600;
  }

  .roo-usage-meter-status[data-state='warning'] {
    color: var(--roo-warn);
  }

  .roo-usage-meter-status[data-state='limit'] {
    color: var(--roo-danger-text);
  }

  .roo-usage-meter-readout {
    margin-left: auto;
    color: var(--roo-muted);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
  }

  /* The figure slot sits under the track, so a caller can place the "1,236 of 3,000" figure there. */
  .roo-usage-meter-figure {
    color: var(--roo-muted);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
  }

  .roo-usage-meter-track {
    position: relative;
    display: flex;
    height: var(--roo-p-space-2);
    overflow: hidden;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-track);
  }

  .roo-usage-meter-part {
    flex: none;
    height: 100%;
    transition: width var(--roo-base) var(--roo-ease);
  }

  /* Normal is ink, not the brand accent: on an orange or red brand the accent reads as the limit colour, so a calm meter
     would look alarmed. Only warning and limit carry colour. */
  .roo-usage-meter-part[data-kind='paid'],
  .roo-usage-meter-swatch[data-kind='paid'] {
    background: var(--roo-text);
  }

  .roo-usage-meter[data-state='warning'] .roo-usage-meter-part[data-kind='paid'],
  .roo-usage-meter[data-state='warning'] .roo-usage-meter-swatch[data-kind='paid'] {
    background: var(--roo-warn);
  }

  .roo-usage-meter[data-state='limit'] .roo-usage-meter-part[data-kind='paid'],
  .roo-usage-meter[data-state='limit'] .roo-usage-meter-swatch[data-kind='paid'] {
    background: var(--roo-danger);
  }

  .roo-usage-meter-part[data-kind='free'],
  .roo-usage-meter-swatch[data-kind='free'] {
    background: var(--roo-ok);
  }

  /* Soft allowance (a paid plan's free amount): the free part muted, the billed part past it in ink. Neither warns. */
  .roo-usage-meter-part[data-kind='soft'],
  .roo-usage-meter-swatch[data-kind='soft'] {
    background: var(--roo-muted);
    opacity: 0.45;
  }

  .roo-usage-meter-part[data-kind='billed'],
  .roo-usage-meter-swatch[data-kind='billed'] {
    background: var(--roo-text);
  }

  .roo-usage-meter-track[data-soft] {
    gap: 2px;
  }

  /* The forecast sits under the used part, lighter; the commitment is a tick across the track, 3 px proud of it at each end. */
  .roo-usage-meter-part[data-kind='forecast'] {
    background: var(--roo-text);
    opacity: 0.3;
  }

  .roo-usage-meter-part[data-kind='paid'] {
    position: relative;
  }

  .roo-usage-meter-track[data-ticked] {
    overflow: visible;
  }

  .roo-usage-meter-tick {
    position: absolute;
    top: -3px;
    bottom: -3px;
    width: 2px;
    margin-left: -1px;
    background: var(--roo-text);
  }

  .roo-usage-meter-legend {
    display: flex;
    flex-wrap: wrap;
    gap: var(--roo-p-space-1) var(--roo-p-space-4);
    margin: 0;
    padding: 0;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    list-style: none;
  }

  .roo-usage-meter-legend-item {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-2);
  }

  .roo-usage-meter-legend-value {
    color: var(--roo-text);
    font-family: var(--roo-font-mono);
    font-variant-numeric: tabular-nums;
  }

  .roo-usage-meter-swatch {
    width: var(--roo-p-space-2);
    height: var(--roo-p-space-2);
    border-radius: var(--roo-p-radius-small);
  }
}
</style>
