<script lang="ts">
export type RooUsageMeterState = 'normal' | 'warning' | 'limit'

export interface RooUsageMeterSegment {
  /** What this part is, such as `Included` or `Paid`. It is shown in the legend, so the part never relies on colour. */
  label: string
  value: number
  /** `free` keeps its own colour at every state; `paid` follows the meter's state. */
  kind?: 'free' | 'paid'
}

/** A meter turns to its warning at this share of the limit. */
export const USAGE_METER_WARN_AT = 0.8

/** The state of a meter: normal, warning from 80% of the limit, at the limit from 100%. A limit of 0 or less never warns. */
export function usageMeterState(used: number, limit: number | null | undefined): RooUsageMeterState {
  if (limit === null || limit === undefined || !Number.isFinite(limit) || limit <= 0) return 'normal'
  const share = used / limit
  if (share >= 1) return 'limit'
  if (share >= USAGE_METER_WARN_AT) return 'warning'
  return 'normal'
}
</script>

<script setup lang="ts">
import { computed } from 'vue'
import RooIcon from './RooIcon.vue'
import { useId } from 'reka-ui'

const props = withDefaults(
  defineProps<{
    /** The visible name of what is measured, such as `Events`. It is also the accessible name. */
    label: string
    /** Used so far. Ignored when `segments` are given: the segments add up to it. */
    used?: number
    /** The most there is. Null, undefined or Infinity means unlimited: the readout shows only the used amount. */
    limit?: number | null
    /** The used amount in parts, such as the free part and the paid part. Drawn in order, left to right. */
    segments?: RooUsageMeterSegment[]
    /** Turns a number into text, such as `1.2M`. Used for the readout and for the screen reader. */
    formatValue?: ((value: number) => string) | undefined
    /** The words shown beside the icon at 80% and at 100%. */
    warningText?: string
    limitText?: string
  }>(),
  { used: 0, limit: null, segments: () => [], formatValue: undefined, warningText: 'Nearing limit', limitText: 'Limit reached' },
)

const id = useId(undefined, 'roo-usage-meter')

function format(value: number): string {
  return props.formatValue ? props.formatValue(value) : value.toLocaleString('en-US')
}

const finiteLimit = computed(() => (typeof props.limit === 'number' && Number.isFinite(props.limit) ? props.limit : null))
const unlimited = computed(() => finiteLimit.value === null)
const limitValue = computed(() => finiteLimit.value ?? 0)

const total = computed(() => (props.segments.length > 0 ? props.segments.reduce((sum, part) => sum + part.value, 0) : props.used))
const state = computed(() => usageMeterState(total.value, finiteLimit.value))
const percent = computed(() => (limitValue.value > 0 ? Math.round((total.value / limitValue.value) * 100) : 0))

// A meter's value stays inside its range, so an overage reads as full here and says how far over in the text.
const valueNow = computed(() => Math.min(Math.max(total.value, 0), Math.max(limitValue.value, 0)))

const valueText = computed(() => {
  if (unlimited.value) return format(total.value)
  const base = `${format(total.value)} of ${format(limitValue.value)}, ${percent.value}%`
  if (state.value === 'warning') return `${base}, ${props.warningText}`
  if (state.value === 'limit') return `${base}, ${props.limitText}`
  return base
})

const statusText = computed(() => (state.value === 'warning' ? props.warningText : state.value === 'limit' ? props.limitText : ''))

const parts = computed(() => {
  const source: RooUsageMeterSegment[] = props.segments.length > 0 ? props.segments : [{ label: props.label, value: props.used, kind: 'paid' }]
  const scale = limitValue.value > 0 ? Math.max(limitValue.value, total.value) : 1
  return source.map((part, index) => ({
    key: `${index}-${part.label}`,
    kind: part.kind ?? 'paid',
    label: part.label,
    text: format(part.value),
    width: `${limitValue.value > 0 ? Math.min((Math.max(part.value, 0) / scale) * 100, 100) : 0}%`,
  }))
})
</script>

<template>
  <div class="roo-usage-meter" :data-state="state">
    <div class="roo-usage-meter-head">
      <span :id="`${id}-label`" class="roo-usage-meter-label">{{ label }}</span>
      <span v-if="statusText" class="roo-usage-meter-status" :data-state="state">
        <RooIcon :name="state === 'limit' ? 'alert' : 'warning'" :size="12" />
        {{ statusText }}
      </span>
      <span class="roo-usage-meter-readout" :aria-hidden="unlimited ? undefined : 'true'">{{ unlimited ? format(total) : `${format(total)} of ${format(limitValue)}` }}</span>
    </div>
    <div
      v-if="!unlimited"
      class="roo-usage-meter-track"
      role="meter"
      :aria-labelledby="`${id}-label`"
      :aria-valuenow="valueNow"
      aria-valuemin="0"
      :aria-valuemax="limitValue"
      :aria-valuetext="valueText"
    >
      <span v-for="part in parts" :key="part.key" class="roo-usage-meter-part" :data-kind="part.kind" :style="{ width: part.width }" />
    </div>
    <ul v-if="segments.length > 0" class="roo-usage-meter-legend">
      <li v-for="part in parts" :key="part.key" class="roo-usage-meter-legend-item">
        <span class="roo-usage-meter-swatch" :data-kind="part.kind" aria-hidden="true" />
        <span>{{ part.label }}</span>
        <span class="roo-usage-meter-legend-value">{{ part.text }}</span>
      </li>
    </ul>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-usage-meter {
    display: flex;
    flex-direction: column;
    gap: var(--roo-p-space-2);
    width: 100%;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-13);
    color: var(--roo-text);
  }

  .roo-usage-meter-head {
    display: flex;
    align-items: baseline;
    gap: var(--roo-p-space-2);
  }

  .roo-usage-meter-label {
    font-weight: 600;
  }

  .roo-usage-meter-status {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-1);
    font-size: var(--roo-p-size-12);
    font-weight: 600;
  }

  .roo-usage-meter-status[data-state='warning'] {
    color: var(--roo-warn);
  }

  .roo-usage-meter-status[data-state='limit'] {
    color: var(--roo-danger-text);
  }

  .roo-usage-meter-readout {
    margin-left: auto;
    color: var(--roo-muted);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
  }

  .roo-usage-meter-track {
    display: flex;
    height: var(--roo-p-space-2);
    overflow: hidden;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-border);
  }

  .roo-usage-meter-part {
    flex: none;
    height: 100%;
    transition: width var(--roo-base) var(--roo-ease);
  }

  /* Normal is ink, not the brand accent: on an orange or red brand the accent reads as the limit colour, so a calm meter
     would look alarmed. Only warning and limit carry colour. */
  .roo-usage-meter-part[data-kind='paid'],
  .roo-usage-meter-swatch[data-kind='paid'] {
    background: var(--roo-text);
  }

  .roo-usage-meter[data-state='warning'] .roo-usage-meter-part[data-kind='paid'],
  .roo-usage-meter[data-state='warning'] .roo-usage-meter-swatch[data-kind='paid'] {
    background: var(--roo-warn);
  }

  .roo-usage-meter[data-state='limit'] .roo-usage-meter-part[data-kind='paid'],
  .roo-usage-meter[data-state='limit'] .roo-usage-meter-swatch[data-kind='paid'] {
    background: var(--roo-danger);
  }

  .roo-usage-meter-part[data-kind='free'],
  .roo-usage-meter-swatch[data-kind='free'] {
    background: var(--roo-ok);
  }

  .roo-usage-meter-legend {
    display: flex;
    flex-wrap: wrap;
    gap: var(--roo-p-space-1) var(--roo-p-space-4);
    margin: 0;
    padding: 0;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    list-style: none;
  }

  .roo-usage-meter-legend-item {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-2);
  }

  .roo-usage-meter-legend-value {
    color: var(--roo-text);
    font-family: var(--roo-font-mono);
    font-variant-numeric: tabular-nums;
  }

  .roo-usage-meter-swatch {
    width: var(--roo-p-space-2);
    height: var(--roo-p-space-2);
    border-radius: var(--roo-p-radius-small);
  }
}
</style>
