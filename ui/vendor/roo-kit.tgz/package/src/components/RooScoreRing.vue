<script lang="ts">
export type RooScoreBand = 'good' | 'needs-improvement' | 'poor'

/** Web vitals style bands on a 0 to 100 score: 90 and up is good, 50 to 89 needs improvement, under 50 is poor. */
export function scoreBand(score: number): RooScoreBand {
  if (score >= 90) return 'good'
  if (score >= 50) return 'needs-improvement'
  return 'poor'
}

export const SCORE_BAND_WORDS: Record<RooScoreBand, string> = {
  good: 'Good',
  'needs-improvement': 'Needs improvement',
  poor: 'Poor',
}
</script>

<script setup lang="ts">
// A circular score from 0 to 100. The number is in the middle, the band is a word with its own icon under the ring, and
// the arc is the same score drawn as a length, so no one reads the band from colour alone.
import { computed } from 'vue'
import RooIcon from './RooIcon.vue'

const props = withDefaults(defineProps<{ score: number; label: string; size?: number }>(), { size: 96 })

const STROKE = 8
const clamped = computed(() => (Number.isFinite(props.score) ? Math.min(100, Math.max(0, Math.round(props.score))) : 0))
const band = computed(() => scoreBand(clamped.value))
const word = computed(() => SCORE_BAND_WORDS[band.value])
const icon = computed(() => (band.value === 'good' ? 'check' : band.value === 'needs-improvement' ? 'warning' : 'circle-alert'))
const radius = computed(() => (props.size - STROKE) / 2)
const circumference = computed(() => 2 * Math.PI * radius.value)
const dash = computed(() => `${(clamped.value / 100) * circumference.value} ${circumference.value}`)
</script>

<template>
  <div
    class="roo-score-ring"
    role="meter"
    :aria-label="label"
    aria-valuemin="0"
    aria-valuemax="100"
    :aria-valuenow="clamped"
    :aria-valuetext="`${clamped}, ${word}`"
    :data-band="band"
  >
    <span class="roo-score-dial" :style="{ width: `${size}px`, height: `${size}px` }">
      <svg :width="size" :height="size" :viewBox="`0 0 ${size} ${size}`" aria-hidden="true" focusable="false">
        <circle class="roo-score-track" :cx="size / 2" :cy="size / 2" :r="radius" :stroke-width="STROKE" />
        <circle
          class="roo-score-arc"
          :cx="size / 2"
          :cy="size / 2"
          :r="radius"
          :stroke-width="STROKE"
          :stroke-dasharray="dash"
          :transform="`rotate(-90 ${size / 2} ${size / 2})`"
        />
      </svg>
      <span class="roo-score-number">{{ clamped }}</span>
    </span>
    <span class="roo-score-band"><RooIcon :name="icon" :size="16" />{{ word }}</span>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-score-ring {
    display: inline-flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
  }

  .roo-score-dial {
    position: relative;
    display: inline-grid;
    place-items: center;
  }

  .roo-score-dial svg {
    position: absolute;
    inset: 0;
  }

  .roo-score-track {
    fill: none;
    stroke: var(--roo-track);
  }

  .roo-score-arc {
    fill: none;
    stroke: var(--roo-ok-text);
    stroke-linecap: round;
    transition: stroke-dasharray var(--roo-draw) var(--roo-ease);
  }

  .roo-score-ring[data-band='needs-improvement'] .roo-score-arc {
    stroke: var(--roo-warn);
  }

  .roo-score-ring[data-band='poor'] .roo-score-arc {
    stroke: var(--roo-danger-text);
  }

  .roo-score-number {
    position: relative;
    color: var(--roo-text);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-20);
    font-variant-numeric: tabular-nums;
    font-weight: 600;
    letter-spacing: var(--roo-p-tracking-heading-sm);
  }

  .roo-score-band {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }

  .roo-score-ring[data-band='good'] .roo-score-band {
    color: var(--roo-ok-text);
  }

  .roo-score-ring[data-band='needs-improvement'] .roo-score-band {
    color: var(--roo-warn);
  }

  .roo-score-ring[data-band='poor'] .roo-score-band {
    color: var(--roo-danger-text);
  }
}
</style>
