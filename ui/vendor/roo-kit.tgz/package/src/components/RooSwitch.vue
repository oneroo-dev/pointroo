<script setup lang="ts">
import { SwitchRoot, SwitchThumb, useId } from 'reka-ui'

const model = defineModel<boolean>({ default: false })

withDefaults(
  defineProps<{
    /** The visible label. Leave it out when a row beside the switch already shows the text; then give an accessible name. */
    label?: string
    description?: string
    disabled?: boolean
    tone?: 'accent' | 'prod'
    /** The label stays beside the switch at every width: the text shrinks and wraps in its own column, and a RooSettingRow keeps the switch at the end of the row instead of stacking it under the text below 480 px of row width. */
    inline?: boolean
    /** The accessible name when there is no visible label. */
    ariaLabel?: string
    /** The id of the row's own label, when there is no visible label. */
    ariaLabelledby?: string
    /** The id of a help line outside the switch. Used when there is no `description`. */
    ariaDescribedby?: string
  }>(),
  {
  label: '',
  description: '',
  disabled: false,
  tone: 'accent',
  inline: false,
  },
)

const id = useId(undefined, 'roo-switch')
</script>

<template>
  <div class="roo-switch" :class="{ 'roo-switch-bare': !label }" :data-inline="inline ? '' : undefined">
    <div v-if="label" class="roo-switch-text">
      <label class="roo-switch-label" :for="id">{{ label }}</label>
      <p v-if="description" :id="`${id}-note`" class="roo-switch-note">{{ description }}</p>
    </div>
    <SwitchRoot
      :id="id"
      v-model="model"
      class="roo-switch-track"
      :data-tone="tone"
      :disabled="disabled"
      :aria-label="label ? undefined : ariaLabel"
      :aria-labelledby="label ? undefined : ariaLabelledby"
      :aria-describedby="label && description ? `${id}-note` : ariaDescribedby"
    >
      <SwitchThumb class="roo-switch-thumb" />
    </SwitchRoot>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-switch {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16px;
  }

  .roo-switch[data-inline] {
    flex-wrap: nowrap;
    align-items: center;
  }

  .roo-switch[data-inline] .roo-switch-text {
    flex: 1 1 0;
    overflow-wrap: anywhere;
  }

  .roo-switch.roo-switch-bare {
    display: inline-flex;
  }

  .roo-switch-text {
    min-width: 0;
  }

  .roo-switch-label {
    display: block;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-13);
    color: var(--roo-text);
  }

  .roo-switch-note {
    margin: 2px 0 0;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-switch-track {
    position: relative;
    display: inline-flex;
    flex-shrink: 0;
    align-items: center;
    width: 36px;
    height: 20px;
    padding: 0;
    border: 1px solid var(--roo-control-edge);
    border-radius: var(--roo-p-radius-pill);
    background: transparent;
    cursor: default;
    transition:
      background-color var(--roo-fast) var(--roo-ease),
      border-color var(--roo-fast) var(--roo-ease);
  }

  .roo-switch-track:hover:not(:disabled) {
    border-color: var(--roo-text);
  }

  /* Hover: an unset thumb darkens to the text colour; a set track darkens its fill (family rule F3), with no halo. */
  .roo-switch-track:hover:not(:disabled) .roo-switch-thumb[data-state='unchecked'] {
    background: var(--roo-text);
  }

  .roo-switch-track[data-state='checked']:hover:not(:disabled) {
    border-color: color-mix(in srgb, var(--roo-accent-fill) 90%, black);
    background: color-mix(in srgb, var(--roo-accent-fill) 90%, black);
  }

  .roo-switch-track[data-state='checked'][data-tone='prod']:hover:not(:disabled) {
    border-color: color-mix(in srgb, var(--roo-prod-button) 90%, black);
    background: color-mix(in srgb, var(--roo-prod-button) 90%, black);
  }

  /* Pressed: an unset track fills with the raised surface and the thumb stretches toward the side it will move to. */
  .roo-switch-track[data-state='unchecked']:active:not(:disabled) {
    background: var(--roo-raised);
  }

  .roo-switch-track:active:not(:disabled) .roo-switch-thumb {
    width: 18px;
  }

  .roo-switch-track[data-state='checked']:active:not(:disabled) .roo-switch-thumb {
    transform: translateX(14px);
  }

  /* On is the accent fill with a white thumb, as a ticked checkbox (Fable review Q3, Raja: apply all). Prod stays crimson. */
  .roo-switch-track[data-state='checked'] {
    border-color: var(--roo-accent-fill);
    background: var(--roo-accent-fill);
  }

  .roo-switch-track[data-state='checked'][data-tone='prod'] {
    border-color: var(--roo-prod-button);
    background: var(--roo-prod-button);
  }

  .roo-switch-track:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  /* Disabled (family rule F1): no opacity. Off is the raised fill with a faint thumb; on is a faint fill with a surface thumb, so a locked on switch still reads as on. */
  .roo-switch-track:disabled {
    background: var(--roo-raised);
    border-color: transparent;
    cursor: default;
    opacity: 1;
  }

  .roo-switch-track:disabled .roo-switch-thumb {
    background: var(--roo-faint);
  }

  .roo-switch-track[data-state='checked']:disabled,
  .roo-switch-track[data-state='checked'][data-tone='prod']:disabled {
    border-color: transparent;
    background: var(--roo-faint);
    opacity: 1;
  }

  .roo-switch-track[data-state='checked']:disabled .roo-switch-thumb {
    background: var(--roo-surface);
  }

  .roo-switch-thumb {
    display: block;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: var(--roo-muted);
    box-shadow: var(--roo-shadow-thumb);
    transform: translateX(2px);
    transition:
      transform var(--roo-base) var(--roo-spring),
      width var(--roo-fast) var(--roo-ease),
      background-color var(--roo-fast) var(--roo-ease);
  }

  .roo-switch-thumb[data-state='checked'] {
    background: var(--roo-on-accent-fill);
    transform: translateX(18px);
  }

  .roo-switch-track[data-tone='prod'] .roo-switch-thumb[data-state='checked'] {
    background: var(--roo-on-prod);
  }

  /* An invisible tap area of at least --roo-touch-target on a coarse pointer (family rule F6, Fable review). The drawn size never changes. */
  @media (pointer: coarse) {
    .roo-switch-track::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2));
    }
  }
}
</style>
