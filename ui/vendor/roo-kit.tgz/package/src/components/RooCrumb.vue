<script lang="ts">
export interface RooCrumbItem {
  id: string
  label: string
}
</script>

<script setup lang="ts">
// The breadcrumb for the Bar's `crumb` slot. Every item but the last is a button (the last is the current page, plain
// text), the whole trail is one Tab stop, and the arrows, Home and End move along it. Labels never wrap: the trail
// truncates its middle items before its last one.
import { onMounted, onUpdated, ref } from 'vue'
import RooIcon from './RooIcon.vue'
import { useRovingTabindex } from '../composables/useRovingTabindex'

defineProps<{ items: RooCrumbItem[]; label: string }>()
const emit = defineEmits<{ navigate: [id: string] }>()

const root = ref<HTMLElement | null>(null)
const roving = useRovingTabindex(root, { itemSelector: '[data-roving-item]', orientation: 'horizontal' })
onMounted(roving.sync)
onUpdated(roving.sync)
</script>

<template>
  <nav ref="root" class="roo-crumb" :aria-label="label" @keydown="roving.onKeydown" @focusin="roving.onFocusin">
    <ol class="roo-crumb-list">
      <li v-for="(item, index) in items" :key="item.id" class="roo-crumb-item" :data-last="index === items.length - 1">
        <span v-if="index > 0" class="roo-crumb-separator" aria-hidden="true"><RooIcon name="chevron" :size="12" /></span>
        <span v-if="index === items.length - 1" class="roo-crumb-current" aria-current="page">{{ item.label }}</span>
        <button v-else type="button" class="roo-crumb-button" data-roving-item @click="emit('navigate', item.id)"><span class="roo-crumb-label">{{ item.label }}</span></button>
      </li>
    </ol>
  </nav>
</template>

<style scoped>
@layer roo-components {
  .roo-crumb {
    min-width: 0;
    white-space: nowrap;
  }

  .roo-crumb-list {
    display: flex;
    min-width: 0;
    align-items: center;
    margin: 0;
    padding: 0;
    list-style: none;
  }

  .roo-crumb-item {
    display: flex;
    min-width: 0;
    flex: 0 1 auto;
    align-items: center;
  }

  .roo-crumb-item[data-last='true'] {
    flex-shrink: 0;
  }

  .roo-crumb-separator {
    display: inline-flex;
    flex: none;
    padding-inline: 2px;
    color: var(--roo-faint);
  }

  .roo-crumb-button,
  .roo-crumb-current {
    min-width: 0;
    overflow: hidden;
    border: 0;
    border-radius: var(--roo-p-radius-small);
    background: transparent;
    padding: 2px var(--roo-crumb-pad-inline);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  /* The clip and the ellipsis sit on the label, so the button itself clips nothing: the phone tap area below and the
     focus ring may extend past its box. */
  .roo-crumb-button {
    display: inline-flex;
    overflow: visible;
    color: var(--roo-muted);
    cursor: default;
  }

  .roo-crumb-label {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  /* An invisible tap area at least --roo-touch-target tall on a coarse pointer. The drawn box does not change. */
  @media (pointer: coarse) {
    .roo-crumb-button {
      position: relative;
    }

    .roo-crumb-button::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2)) 0;
    }
  }

  .roo-crumb-button:hover {
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  .roo-crumb-button:active {
    background: color-mix(in srgb, var(--roo-raised) 92%, var(--roo-text));
  }

  .roo-crumb-button:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: -2px;
  }

  .roo-crumb-current {
    color: var(--roo-text);
    font-weight: 600;
  }
}
</style>
