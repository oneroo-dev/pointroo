<script setup lang="ts">
import { computed } from 'vue'
import RooIcon from './RooIcon.vue'
import type { RooIconName } from '../icons/paths'

export type RooStateCardKind = 'error' | 'info' | 'ok' | 'warn' | 'waiting' | 'empty' | 'loading'

const props = withDefaults(
  defineProps<{
    kind?: RooStateCardKind
    /** Optional: with no title the icon centres on the first body line instead. */
    title?: string
    description?: string
    /** A request id, an error code or a trace, set in mono under the body. It wraps, so a long id is never cut off. */
    detail?: string
    /** Replace the icon the kind would draw. The kind still sets the colour and the role. */
    icon?: RooIconName | undefined
    /**
     * `card` stacks its parts; `strip` puts the icon, title and details on one line (a banner inside a pane);
     * `band` is the strip made flush and square-edged for the top of a pane, with a hairline below and no radius.
     */
    layout?: 'card' | 'strip' | 'band'
    /** A standalone card on the page gets the card shadow; one inside a pane does not. */
    block?: boolean
    /** Defaults to alert for an error and status for the rest. `none` drops it, for a card inside role="log". */
    role?: 'status' | 'alert' | 'none' | undefined
    /** Let the title wrap. Defaults on for the error kind in strip and band, whose message is content, not a label; a card keeps one line unless set. */
    wrap?: boolean | undefined
    /** `stacked` puts the actions in a vertical stack, each full width, the first (primary) on top. `inline` is the default row. */
    actionsLayout?: 'inline' | 'stacked'
    /** With the `strip` layout: the banner look of the billing frames. A tinted fill by kind (ok, warn, error), no outline, a 16 px icon, an 8 px gap, 8 and 12 px padding (the 4 px grid; the frames' 10 px rounds to it), an 18 px line. Info and the other kinds keep the plain surface. */
    tinted?: boolean
  }>(),
  { kind: 'info', description: '', detail: '', icon: undefined, layout: 'card', block: false, role: undefined, wrap: undefined, actionsLayout: 'inline', title: '', tinted: false },
)

// Each kind has its own glyph, so the kind is never carried by colour alone.
const icons: Record<RooStateCardKind, RooIconName> = {
  error: 'alert',
  info: 'info',
  ok: 'check',
  warn: 'alert',
  waiting: 'loader',
  empty: 'folder-open',
  loading: 'loader',
}

const resolvedRole = computed(() => {
  if (props.role === 'none') return undefined
  return props.role ?? (props.kind === 'error' ? 'alert' : 'status')
})

// A loading card tells assistive tech its content is still on the way.
const busy = computed(() => props.kind === 'loading' || props.kind === 'waiting')

// `wrap` is honoured in every layout; unset, only the strip and band error kind wraps, so a plain card keeps its one-line title.
const titleWraps = computed(() => props.wrap ?? (props.layout !== 'card' && props.kind === 'error'))
</script>

<template>
  <div
    class="roo-state-card"
    :role="resolvedRole"
    :data-kind="kind"
    :data-layout="layout"
    :data-block="block ? 'true' : undefined"
    :data-wrap="titleWraps ? 'true' : undefined"
    :data-tinted="tinted && layout === 'strip' ? 'true' : undefined"
    :aria-busy="busy ? 'true' : undefined"
  >
    <RooIcon class="roo-state-card-icon" :name="icon ?? icons[kind]" :size="tinted && layout === 'strip' ? 16 : 14" />
    <div class="roo-state-card-body">
      <p v-if="title" class="roo-state-card-title">{{ title }}</p>
      <p v-if="description" class="roo-state-card-description">{{ description }}</p>
      <p v-if="detail" class="roo-state-card-detail">{{ detail }}</p>
      <div v-if="$slots.system" class="roo-state-card-system"><slot name="system" /></div>
      <div v-if="$slots.fact" class="roo-state-card-fact"><slot name="fact" /></div>
      <div v-if="$slots.code" class="roo-state-card-code"><slot name="code" /></div>
      <div v-if="$slots.details" class="roo-state-card-details"><slot name="details" /></div>
      <div v-if="$slots.actions" class="roo-state-card-actions" :data-stacked="actionsLayout === 'stacked' ? 'true' : undefined"><slot name="actions" /></div>
      <div v-if="$slots.foot" class="roo-state-card-foot"><slot name="foot" /></div>
    </div>
  </div>
</template>

<style scoped>
@layer roo-components {
  /* The error card is plain: the surface, a hairline, and a crimson icon and title. No tint, no crimson box edge. */
  .roo-state-card {
    display: flex;
    flex-direction: column;
    gap: var(--roo-space-item);
    padding: var(--roo-space-group) var(--roo-space-card);
    border: 1px solid transparent;
    border-radius: var(--roo-p-radius-card);
    background: var(--roo-surface);
    box-shadow: var(--roo-shadow-card);
    color: var(--roo-text);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-13);
    /* One line height for every text line in the card, so the icon can centre on the first line whatever it holds.
       The icon's offset below the line top is half of line height less icon size. */
    --roo-state-card-icon-size: 14px;
    --roo-state-card-line: calc(var(--roo-p-size-13) * 1.5);
    --roo-state-card-icon-drop: calc((var(--roo-state-card-line) - var(--roo-state-card-icon-size)) / 2);
    line-height: var(--roo-state-card-line);
    animation: roo-rise var(--roo-base) var(--roo-ease) both;
  }

  .roo-state-card[data-block='true'] {
    border-color: transparent;
    box-shadow: var(--roo-shadow-card);
  }

  .roo-state-card[data-layout='card'] {
    position: relative;
    padding-left: calc(var(--roo-space-card) + var(--roo-state-card-icon-size) + var(--roo-space-item));
  }

  .roo-state-card[data-layout='card'] .roo-state-card-body {
    max-width: min(100%, var(--roo-measure-reading));
  }

  .roo-state-card[data-layout='card'] .roo-state-card-icon {
    position: absolute;
    top: calc(var(--roo-space-group) + var(--roo-state-card-icon-drop));
    left: var(--roo-p-space-4);
  }

  .roo-state-card[data-layout='strip'],
  .roo-state-card[data-layout='band'] {
    flex-direction: row;
    align-items: flex-start;
    gap: var(--roo-p-space-2);
    padding: var(--roo-p-space-1) var(--roo-p-space-3);
  }

  /* A strip title wraps at a narrow width rather than truncating, so the icon stays on its first line, not on the middle of the block. */
  .roo-state-card[data-layout='strip'] .roo-state-card-icon,
  .roo-state-card[data-layout='band'] .roo-state-card-icon {
    margin-top: var(--roo-state-card-icon-drop);
  }

  /* The band sits flush at the top of a pane: no radius, no outline, one hairline drawn below, full width. */
  .roo-state-card[data-layout='band'] {
    width: 100%;
    box-sizing: border-box;
    border: 0;
    border-radius: 0;
    box-shadow: inset 0 -1px 0 var(--roo-border);
    animation: none;
  }

  /* The tinted strip (billing banners): the fill carries the kind, so there is no outline; the text stays in ink and the icon takes the kind's colour. */
  .roo-state-card[data-tinted='true'] {
    --roo-state-card-icon-size: 16px;
    --roo-state-card-line: 18px;
    align-items: center;
    gap: var(--roo-p-space-2);
    padding: var(--roo-p-space-2) var(--roo-p-space-3);
    border: 0;
    background: var(--roo-raised);
    animation: none;
  }

  .roo-state-card[data-tinted='true'] .roo-state-card-icon {
    margin-top: 0;
  }


  .roo-state-card[data-tinted='true'][data-kind='ok'] {
    background: var(--roo-ok-bg);
  }

  .roo-state-card[data-tinted='true'][data-kind='warn'] {
    background: var(--roo-warn-bg);
  }

  .roo-state-card[data-tinted='true'][data-kind='error'] {
    background: var(--roo-danger-fill);
  }

  .roo-state-card[data-tinted='true'][data-kind='error'] .roo-state-card-title {
    color: var(--roo-text);
  }

  .roo-state-card-icon {
    flex: none;
    color: var(--roo-muted);
  }

  .roo-state-card[data-kind='ok'] .roo-state-card-icon {
    color: var(--roo-ok-text);
  }

  .roo-state-card[data-kind='warn'] .roo-state-card-icon {
    color: var(--roo-warn);
  }

  .roo-state-card[data-kind='error'] .roo-state-card-icon {
    color: var(--roo-danger-text);
  }

  .roo-state-card-body {
    display: flex;
    min-width: 0;
    flex: 1;
    flex-direction: column;
    gap: var(--roo-p-space-1);
  }

  .roo-state-card[data-layout='strip'] .roo-state-card-body,
  .roo-state-card[data-layout='band'] .roo-state-card-body {
    flex-direction: row;
    flex-wrap: wrap;
    align-items: flex-start;
    column-gap: var(--roo-p-space-2);
    row-gap: 0;
  }

  .roo-state-card[data-layout='strip'] .roo-state-card-title,
  .roo-state-card[data-layout='band'] .roo-state-card-title {
    min-width: 0;
    overflow: visible;
    text-overflow: clip;
    white-space: normal;
    overflow-wrap: anywhere;
  }

  .roo-state-card-title {
    margin: 0;
    overflow: hidden;
    color: var(--roo-text);
    font-weight: 600;
    text-overflow: ellipsis;
    white-space: nowrap;
    letter-spacing: var(--roo-p-tracking-heading-sm);
  }

  /* An error message is content, not a label, so it may wrap. Labels and buttons still never do. */
  .roo-state-card[data-wrap='true'] .roo-state-card-title {
    overflow: visible;
    text-overflow: clip;
    white-space: normal;
    overflow-wrap: anywhere;
  }

  .roo-state-card[data-kind='error'] .roo-state-card-title {
    color: var(--roo-danger-text);
  }

  .roo-state-card-description {
    margin: 0;
    color: var(--roo-text);
  }

  /* Mono and selectable, so a request id can be read out or copied whole. */
  .roo-state-card-detail {
    margin: 0;
    color: var(--roo-muted);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
    overflow-wrap: anywhere;
    user-select: text;
  }

  .roo-state-card-system {
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }

  /* One mono line that truncates. */
  .roo-state-card-fact {
    min-width: 0;
    overflow: hidden;
    color: var(--roo-muted);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-state-card-code {
    overflow: auto;
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
  }

  .roo-state-card-details {
    min-width: 0;
    color: var(--roo-muted);
  }

  .roo-state-card-actions {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--roo-p-space-2);
    margin-top: var(--roo-p-space-1);
  }

  .roo-state-card-actions[data-stacked='true'] {
    flex-direction: column;
    flex-wrap: nowrap;
    align-items: stretch;
  }

  .roo-state-card-actions[data-stacked='true'] > :deep(*) {
    box-sizing: border-box;
    width: 100%;
  }

  .roo-state-card[data-layout='strip'] .roo-state-card-actions,
  .roo-state-card[data-layout='band'] .roo-state-card-actions {
    flex: none;
    margin-top: 0;
    margin-left: auto;
  }

  .roo-state-card-foot {
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }

  /* One centre line: the icon, the title and the button share it, and the button never drops to a second line while the title can wrap beside it. */
  .roo-state-card[data-tinted='true'] .roo-state-card-body {
    flex-wrap: nowrap;
    align-items: center;
  }

  .roo-state-card[data-tinted='true'] .roo-state-card-title {
    flex: 1 1 0;
  }

  .roo-state-card[data-tinted='true'] .roo-state-card-actions {
    flex-wrap: nowrap;
    white-space: nowrap;
  }

  /* Under 720 px the text takes the whole column and the action sits under it, at the text's left edge: no 78 px text column beside a button. */
  @media (max-width: 720px) {
    .roo-state-card[data-tinted='true'] {
      align-items: flex-start;
    }

    /* The title and the (i) tip run as one inline text, so the tip sits after the last word, not alone on a line; the action drops below. */
    .roo-state-card[data-tinted='true'] .roo-state-card-body {
      display: block;
    }

    .roo-state-card[data-tinted='true'] .roo-state-card-title,
    .roo-state-card[data-tinted='true'] .roo-state-card-details {
      display: inline;
    }

    .roo-state-card[data-tinted='true'] .roo-state-card-details {
      margin-left: var(--roo-p-space-1);
      vertical-align: middle;
    }

    .roo-state-card[data-tinted='true'] .roo-state-card-actions {
      margin-top: var(--roo-p-space-2);
    }

    .roo-state-card[data-tinted='true'] .roo-state-card-actions {
      margin-left: 0;
    }

    .roo-state-card[data-tinted='true'] .roo-state-card-icon {
      margin-top: calc((var(--roo-state-card-line) - var(--roo-state-card-icon-size)) / 2);
    }
  }
}
</style>
