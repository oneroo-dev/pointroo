<script setup lang="ts">
// The accessible name is always the label; busy is conveyed by aria-busy and the spinner only, never by extra text.
// A busy button keeps its exact rest width and height. `busyStyle` says where the loader goes: `centred` (the default, Raja
// 2026-11-28: no spinner on the left) hides the icon and label in place and draws one loader in the middle of the button;
// `leading` is the earlier look, where the glyph of an `icon` slot crossfades into the loader inside one stacked cell (a button
// without an icon slot is centred in both). `loading` is the older name for `busy`.
// `disabledReason` shows as a tooltip and describes the button, so it needs one RooTooltipProvider above it. On hover and keyboard
// focus it opens as any tooltip does; a touch or pen tap on the disabled button opens it too and holds it for TOUCH_REASON_MS, or
// until the next tap anywhere else (Bugroo W-1 gap 6). On a coarse pointer every button also has an invisible 44 px hit area (--roo-touch-target)
// that never changes the visible box; `data-touch-target` says so for the tap-target probe.
import { computed, onBeforeUnmount, ref, useAttrs, useSlots } from 'vue'
import { useId } from 'reka-ui'
import RooTooltip from './RooTooltip.vue'

defineOptions({ inheritAttrs: false })

const props = withDefaults(
  defineProps<{
    /** `solid-neutral` is the neutral filled button of a sheet (TablePlus Dismiss, Refresh, Kill): the raised-on-raised fill, no outline, normal text colour, one step darker on hover and two on press. The orange `primary` is unchanged. */
    variant?: 'primary' | 'secondary' | 'solid-neutral' | 'ghost' | 'danger' | 'prod' | 'quiet'
    /** `compact` is the fixed dense-row height (--roo-compact-control-h), the same on every density. `quiet` is a borderless field-fill button.
     *  `ledge` is the text button among the Ledge facts: the fact's height (--roo-bar-fact-h: 20, 18 compact), 12 px text at normal weight, 4 px inline padding, small corner.
     *  `capsule` is the icon-and-text button of the toolbar capsule: the box of RooIconButton size="capsule" (--roo-control-h, no ring), so the two sit in one row at one height. Ghost, secondary and quiet look the same at this size: nothing at rest, a soft fill on hover. Inside a RooCapsuleGroup of two or more buttons the group draws the one hairline. */
    size?: 'capsule' | 'compact' | 'ledge' | 'sm' | 'md' | 'lg' | 'xl'
    type?: 'button' | 'submit'
    disabled?: boolean
    loading?: boolean
    busy?: boolean
    /** Where the loader sits while busy. `centred` (the default): the icon and label hide in place and one loader sits in the middle,
     *  so nothing moves and the box keeps its size. `leading`: the earlier look, the loader takes the icon's place at the start. */
    busyStyle?: 'centred' | 'leading'
    disabledReason?: string
    /** Where the disabled-reason tooltip opens. */
    tooltipSide?: 'top' | 'bottom' | 'left' | 'right'
    /** How the disabled-reason tooltip aligns along that side. */
    tooltipAlign?: 'start' | 'center' | 'end'
    /** Renders an anchor with the same classes and data attributes. Disabled drops the href and sets aria-disabled. */
    href?: string
    target?: string
    rel?: string
    /** Ghost only. Shifts the button outward by its own start padding plus border, so the label text lands where the box edge would
     *  have been. Use it on the first ghost button of a start-aligned action row under a text column (a ghost button has no visible
     *  box, so the eye lines up its text). Hover and pressed fills still draw around the text and may reach into the gutter. */
    flush?: boolean
    /** A minimum width in px, a layout size (the kit has no width tokens), so a row of buttons can share one width: the footer pair Refresh and Kill. The label never shrinks below its own width; only a longer label makes the button wider. */
    minWidth?: number
  }>(),
  { variant: 'secondary', size: 'md', type: 'button', disabled: false, loading: false, busy: false, busyStyle: 'centred', disabledReason: '', tooltipSide: 'bottom', tooltipAlign: 'center', flush: false },
)

/** How long a reason opened by a tap stays up with no further tap. */
const TOUCH_REASON_MS = 4000

const emit = defineEmits<{ click: [event: MouseEvent] }>()

const attributes = useAttrs()
const explicitBusy = computed(() => attributes['aria-busy'] === true || attributes['aria-busy'] === 'true')
const isBusy = computed(() => props.loading || props.busy || explicitBusy.value)
const slots = useSlots()
const spinsInIconCell = computed(() => props.busyStyle === 'leading' && slots.icon !== undefined)
const showsCentredSpinner = computed(() => isBusy.value && !spinsInIconCell.value)
const showsReason = computed(() => props.disabled && props.disabledReason !== '')
const isLink = computed(() => props.href !== undefined)
const isFlush = computed(() => props.flush && props.variant === 'ghost')
const minWidthStyle = computed(() => (props.minWidth === undefined ? undefined : { minWidth: `${props.minWidth}px` }))
const reasonId = useId(undefined, 'roo-button-reason')

const tooltip = ref<{ show: () => void; hide: () => void } | null>(null)
const reasonWrapper = ref<HTMLElement | null>(null)
const reasonOpenedByTouch = ref(false)
let lastPointerWasTouch = false
let touchTimer: ReturnType<typeof setTimeout> | undefined

function closeTouchReason(): void {
  clearTimeout(touchTimer)
  document.removeEventListener('pointerdown', onPointerDownElsewhere, true)
  reasonOpenedByTouch.value = false
  tooltip.value?.hide()
}

function onPointerDownElsewhere(event: PointerEvent): void {
  if (reasonWrapper.value?.contains(event.target as Node)) return
  closeTouchReason()
}

function onReasonPointerDown(event: PointerEvent): void {
  lastPointerWasTouch = event.pointerType === 'touch' || event.pointerType === 'pen'
}

// The tap is read on click, not pointerdown, because the tooltip trigger closes on that same click: showing after it wins.
function onReasonClick(): void {
  if (!lastPointerWasTouch) return
  lastPointerWasTouch = false
  if (reasonOpenedByTouch.value) {
    closeTouchReason()
    return
  }
  reasonOpenedByTouch.value = true
  tooltip.value?.show()
  document.addEventListener('pointerdown', onPointerDownElsewhere, true)
  clearTimeout(touchTimer)
  touchTimer = setTimeout(closeTouchReason, TOUCH_REASON_MS)
}

onBeforeUnmount(() => {
  clearTimeout(touchTimer)
  document.removeEventListener('pointerdown', onPointerDownElsewhere, true)
})

function onClick(event: MouseEvent): void {
  if (isBusy.value) {
    event.preventDefault()
    return
  }
  emit('click', event)
}
</script>

<template>
  <RooTooltip v-if="showsReason" ref="tooltip" :text="disabledReason" :side="tooltipSide" :align="tooltipAlign">
    <span ref="reasonWrapper" class="roo-button-reason" tabindex="0" data-touch-target="44" @pointerdown="onReasonPointerDown" @click="onReasonClick">
      <component
        :is="isLink ? 'a' : 'button'"
        v-bind="$attrs"
        class="roo-button"
        :type="isLink ? undefined : type"
        :href="isLink && !disabled ? href : undefined"
        :target="isLink ? target : undefined"
        :rel="isLink ? rel : undefined"
        :data-variant="variant"
        :data-size="size"
        :data-busy-style="isBusy ? busyStyle : undefined"
        :data-flush="isFlush || undefined"
        :style="minWidthStyle"
        :disabled="isLink ? undefined : disabled"
        :tabindex="isLink && disabled ? -1 : undefined"
        :aria-disabled="isLink && disabled ? 'true' : isBusy || undefined"
        :aria-busy="isBusy || undefined"
        :aria-describedby="reasonId"
        @click="onClick"
      >
        <span v-if="$slots.icon" class="roo-button-icon" :data-busy="isBusy || undefined">
          <span class="roo-button-glyph"><slot name="icon" /></span>
          <span v-if="spinsInIconCell" class="roo-spinner" aria-hidden="true"></span>
        </span>
        <span v-if="showsCentredSpinner" class="roo-button-held"><slot /></span>
        <slot v-else />
        <span v-if="showsCentredSpinner" class="roo-spinner" aria-hidden="true"></span>
      </component>
      <span :id="reasonId" class="roo-visually-hidden">{{ disabledReason }}</span>
    </span>
  </RooTooltip>
  <component
    :is="isLink ? 'a' : 'button'"
    v-else
    v-bind="$attrs"
    class="roo-button"
    :type="isLink ? undefined : type"
    :href="isLink && !disabled ? href : undefined"
    :target="isLink ? target : undefined"
    :rel="isLink ? rel : undefined"
    :data-variant="variant"
    :data-size="size"
    :data-busy-style="isBusy ? busyStyle : undefined"
    data-touch-target="44"
    :data-flush="isFlush || undefined"
    :style="minWidthStyle"
    :disabled="isLink ? undefined : disabled"
    :tabindex="isLink && disabled ? -1 : undefined"
    :aria-disabled="isLink && disabled ? 'true' : isBusy || undefined"
    :aria-busy="isBusy || undefined"
    @click="onClick"
  >
    <span v-if="$slots.icon" class="roo-button-icon" :data-busy="isBusy || undefined">
      <span class="roo-button-glyph"><slot name="icon" /></span>
      <span v-if="spinsInIconCell" class="roo-spinner" aria-hidden="true"></span>
    </span>
    <span v-if="showsCentredSpinner" class="roo-button-held"><slot /></span>
    <slot v-else />
    <span v-if="showsCentredSpinner" class="roo-spinner" aria-hidden="true"></span>
  </component>
</template>

<style scoped>
@layer roo-components {
  .roo-button {
    position: relative;
    box-sizing: border-box;
    text-decoration: none;
    display: inline-flex;
    flex-shrink: 0;
    align-items: center;
    justify-content: center;
    gap: var(--roo-control-icon-gap);
    --roo-button-border-width: 1px;
    border: 1px solid transparent;
    border-radius: var(--roo-radius-control);
    font-family: var(--roo-font-ui);
    font-weight: 500;
    cursor: default;
    user-select: none;
    transition:
      background-color var(--roo-fast) var(--roo-ease),
      color var(--roo-fast) var(--roo-ease),
      border-color var(--roo-fast) var(--roo-ease),
      filter var(--roo-fast) var(--roo-ease);
  }

  /* Dense in-panel rows (grid filter rows): one fixed height with the field beside it, 12px text, the small corner. */
  .roo-button[data-size='compact'] {
    --roo-button-padding-inline: var(--roo-space-item);
    height: var(--roo-compact-control-h);
    padding: 0 var(--roo-space-item);
    border-radius: var(--roo-p-radius-small);
    font-size: var(--roo-p-size-12);
  }

  /* The Ledge button: the same box as a RooLedgeFact button (20 high, 4 inline, small corner, 12 px text), at normal weight like the facts. */
  .roo-button[data-size='ledge'] {
    --roo-button-padding-inline: 4px;
    height: var(--roo-bar-fact-h);
    padding: 0 4px;
    border-radius: var(--roo-p-radius-small);
    font-size: var(--roo-p-size-12);
    font-weight: var(--roo-p-weight-regular);
  }

  /* The toolbar action (Raja 2026-11-22, option 1 "quiet" picked): the control height (--roo-control-h) in a 1px transparent edge, so a lone action has no ring and no fill at rest, only the soft fill on hover. Secondary and quiet variants take the same look at this size, so Export and Copy match Add. Inside a RooCapsuleGroup of two or more buttons the group draws the one hairline and the buttons sit 1px in. */
  .roo-button[data-size='capsule'] {
    --roo-button-padding-inline: var(--roo-control-pad-x-sm);
    height: var(--roo-control-h);
    padding: 0 var(--roo-control-pad-x-sm);
    font-size: var(--roo-ui-size);
    line-height: var(--roo-row-h);
  }

  .roo-button[data-size='capsule']:is([data-variant='ghost'], [data-variant='secondary'], [data-variant='quiet']):not(:disabled) {
    border-color: transparent;
    background: transparent;
    color: var(--roo-muted);
  }

  .roo-button[data-size='capsule'] :deep(svg) {
    width: var(--roo-icon);
    height: var(--roo-icon);
  }

  .roo-button[data-size='capsule']:is([data-variant='ghost'], [data-variant='secondary'], [data-variant='quiet']):hover:not(:disabled) {
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  [data-on-raised='true'] .roo-button[data-size='capsule']:is([data-variant='ghost'], [data-variant='secondary'], [data-variant='quiet']):hover:not(:disabled) {
    background: var(--roo-raised-hover);
  }

  .roo-button[data-size='sm'] {
    --roo-button-padding-inline: var(--roo-control-pad-x-sm);
    height: var(--roo-control-h);
    padding: 0 var(--roo-control-pad-x-sm);
    font-size: var(--roo-p-size-12);
  }

  /* The default. A bar holds one height (Raja, 2026-11-17): the main action stands out by its fill, never by being taller. */
  .roo-button[data-size='md'] {
    --roo-button-padding-inline: var(--roo-control-pad-x);
    height: var(--roo-control-h);
    padding: 0 var(--roo-control-pad-x);
    font-size: var(--roo-ui-size);
  }

  /* For a button standing alone beside a large field. Never a bar's default. */
  .roo-button[data-size='lg'] {
    --roo-button-padding-inline: var(--roo-control-pad-x);
    height: var(--roo-control-h-large);
    padding: 0 var(--roo-control-pad-x);
    font-size: var(--roo-ui-size);
  }

  /* Under compact density a whole-pixel line box keeps the label on a whole pixel: (height minus border minus line) is even. */
  :root[data-density='compact'] .roo-button:not([data-size='xl']) {
    line-height: var(--roo-control-line);
  }

  /* The capsule label line is the row height (whole pixel: the content box is exactly the row), not the compact 14 line box, which would sit half a pixel off in a 21 row. Same specificity as the rule above, so it comes after it. */
  :root[data-density='compact'] .roo-button[data-size='capsule'] {
    line-height: var(--roo-row-h);
  }

  /* Sign-in screens: 44px, 14px text (the Bugroo frame sets 14, the frame wins). Density never changes it. */
  .roo-button[data-size='xl'] {
    --roo-button-padding-inline: 16px;
    height: var(--roo-control-h-xl);
    padding: 0 16px;
    font-size: var(--roo-p-size-14);
  }

  /* The glyph side takes a little less padding than the text side, so the icon's ink and the label's ink sit the same distance from the edge (the glyph box carries a small margin of its own). The trim is 0 comfortable and 1 compact; xl and a button with no leading glyph are untouched. */
  .roo-button:has(> .roo-button-icon:first-child):not([data-size='xl']) {
    --roo-button-padding-start: calc(var(--roo-button-padding-inline) - var(--roo-control-icon-trim));
    padding-inline-start: var(--roo-button-padding-start);
  }

  /* The solid accent is the deeper fill with white on it (Raja, 2026-11-17). Hover and press darken the fill itself. */
  .roo-button[data-variant='primary'] {
    background: var(--roo-accent-fill);
    color: var(--roo-on-accent-fill);
  }

  .roo-button[data-variant='primary']:hover:not(:disabled) {
    background: color-mix(in srgb, var(--roo-accent-fill) 90%, black);
  }

  .roo-button[data-variant='primary']:active:not(:disabled) {
    background: color-mix(in srgb, var(--roo-accent-fill) 80%, black);
  }

  .roo-button[data-variant='secondary'] {
    border-color: var(--roo-border-floating);
    background: var(--roo-surface);
    color: var(--roo-text);
  }

  /* Quiet: a borderless button on the raised fill (the surface TablePlus draws every row control on). The kit's field fill equals the
     chrome in both themes, so on a panel it would show no button at all; the raised fill is visible and one token for the whole row. */
  .roo-button[data-variant='quiet'] {
    border-color: var(--roo-border);
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  .roo-button[data-variant='quiet']:hover:not(:disabled) {
    border-color: var(--roo-border-floating);
    background: color-mix(in srgb, var(--roo-raised) 88%, var(--roo-text));
  }

  /* Pressed is a colour and ring step, never a movement (no reference product moves a button when pressed): the fill takes more of the text colour and the hairline steps up to the floating strength. */
  .roo-button[data-variant='quiet']:active:not(:disabled) {
    border-color: var(--roo-border-floating);
    background: color-mix(in srgb, var(--roo-raised) 90%, var(--roo-text));
  }

  /* Solid neutral (Raja asked 2026-11-23, TablePlus Running Queries): the raised-on-raised fill with no outline, so it reads as a filled
     pill on a dialog or sheet surface in both themes. Hover and press mix the text colour in, because raised-hover equals the fill in dark. */
  .roo-button[data-variant='solid-neutral'] {
    background: var(--roo-raised-on-raised);
    color: var(--roo-text);
  }

  .roo-button[data-variant='solid-neutral']:hover:not(:disabled) {
    background: color-mix(in srgb, var(--roo-raised-on-raised) 88%, var(--roo-text));
  }

  .roo-button[data-variant='solid-neutral']:active:not(:disabled) {
    background: color-mix(in srgb, var(--roo-raised-on-raised) 78%, var(--roo-text));
  }

  .roo-button[data-variant='ghost'] {
    background: transparent;
    color: var(--roo-muted);
  }

  .roo-button[data-variant='ghost']:hover {
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  .roo-button[data-variant='ghost']:active:not(:disabled) {
    background: color-mix(in srgb, var(--roo-raised) 92%, var(--roo-text));
    color: var(--roo-text);
  }

  /* On a raised strip (an ancestor carries data-on-raised="true", the Ledge on --roo-raised) the raised fill would show nothing. */
  [data-on-raised='true'] .roo-button[data-variant='ghost']:hover:not(:disabled) {
    background: var(--roo-raised-hover);
  }

  /* Flush: the label, not the box, is the ghost button's edge. The offset is the size's own padding and border, so it follows the size. */
  .roo-button[data-variant='ghost'][data-flush='true'] {
    margin-inline-start: calc(-1 * (var(--roo-button-padding-start, var(--roo-button-padding-inline)) + var(--roo-button-border-width)));
  }

  /* Danger has no tint (Raja's ruling 3): the secondary surface and edge in every state, crimson text and icon, and
     only the colour deepens on hover and press. Solid crimson is kept for the production final confirm (variant prod). */
  .roo-button[data-variant='danger'] {
    border-color: var(--roo-border-floating);
    background: var(--roo-surface);
    color: var(--roo-danger-text);
  }

  .roo-button[data-variant='secondary']:hover,
  .roo-button[data-variant='danger']:hover {
    border-color: var(--roo-border-hover);
    background: var(--roo-raised);
  }

  .roo-button[data-variant='secondary']:active:not(:disabled),
  .roo-button[data-variant='danger']:active:not(:disabled) {
    border-color: var(--roo-border-hover);
    background: color-mix(in srgb, var(--roo-raised) 90%, var(--roo-text));
  }

  .roo-button[data-variant='danger']:hover {
    color: color-mix(in srgb, var(--roo-danger-text) 80%, var(--roo-text));
  }

  .roo-button[data-variant='danger']:active:not(:disabled) {
    color: color-mix(in srgb, var(--roo-danger-text) 60%, var(--roo-text));
  }

  .roo-button[data-variant='prod'] {
    background: var(--roo-prod-button);
    color: var(--roo-on-prod);
    font-weight: 600;
  }

  .roo-button[data-variant='prod']:hover:not(:disabled) {
    background: color-mix(in srgb, var(--roo-prod-button) 90%, black);
  }

  .roo-button[data-variant='prod']:active:not(:disabled) {
    background: color-mix(in srgb, var(--roo-prod-button) 80%, black);
  }

  .roo-button:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  /* Every disabled control is neutral grey: it should never compete or look like its live colour. */
  .roo-button:disabled,
  a.roo-button[aria-disabled='true']:not([href]) {
    background: var(--roo-raised);
    color: var(--roo-faint);
    border-color: transparent;
    box-shadow: none;
    pointer-events: none;
  }

  .roo-button[aria-disabled='true'] {
    opacity: 0.4;
    cursor: default;
  }

  .roo-button[aria-busy='true'] {
    opacity: 1;
  }

  .roo-button[data-variant='solid-neutral']:disabled {
    background: color-mix(in srgb, var(--roo-raised) 60%, var(--roo-surface));
  }

  .roo-button-reason {
    position: relative;
    display: inline-flex;
    flex-shrink: 0;
  }

  /* The wrapper takes the pointer, not the disabled button, so a touch tap reaches it in every browser. */
  .roo-button-reason > .roo-button:disabled {
    pointer-events: none;
  }

  /* An invisible tap area of at least --roo-touch-target on a coarse pointer. The visible box and the layout do not change: an
     absolutely placed pseudo-element, outset only on the axis where the box is smaller (min keeps a bigger box as it is). */
  @media (pointer: coarse) {
    .roo-button::before,
    .roo-button-reason::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2));
    }
  }

  .roo-visually-hidden {
    position: absolute;
    width: 1px;
    height: 1px;
    margin: -1px;
    padding: 0;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
    border: 0;
  }

  /* The glyph and the loader share one grid cell, so swapping them cannot change the button's width. */
  .roo-button-icon {
    position: relative;
    display: inline-grid;
    place-items: center;
  }

  .roo-button-icon > * {
    grid-area: 1 / 1;
  }

  .roo-button-glyph {
    display: inline-flex;
    transition: opacity var(--roo-fast) var(--roo-ease);
  }

  .roo-button-icon[data-busy='true'] .roo-button-glyph {
    opacity: 0;
  }

  /* The loader overlays the glyph without adding to the cell: a 12 px glyph in a 16 px loader box made the cell 16 and pushed the label out 2 px each side. */
  .roo-button-icon .roo-spinner {
    position: absolute;
    top: 50%;
    left: 50%;
    translate: -50% -50%;
    opacity: 0;
    transition: opacity var(--roo-fast) var(--roo-ease);
  }

  .roo-button-icon[data-busy='true'] .roo-spinner {
    opacity: 1;
  }

  /* Centred busy (and any busy button without an icon slot): the content stays in the layout, so the width and height hold, and
     fades while the one loader fades in over the middle of the button. The loader is the last child and absolutely placed, so it
     adds nothing to the flex row and the icon stays the first child (the start-padding trim above still applies). */
  .roo-button-held {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-control-icon-gap);
    animation: roo-button-fade-out var(--roo-fast) var(--roo-ease) forwards;
  }

  .roo-button > .roo-spinner {
    position: absolute;
    inset: 0;
    margin: auto;
    animation:
      roo-button-spin 700ms linear infinite,
      roo-button-fade-in var(--roo-fast) var(--roo-ease) both;
  }

  .roo-spinner {
    box-sizing: border-box;
    width: var(--roo-icon);
    height: var(--roo-icon);
    border: 2px solid currentColor;
    border-right-color: transparent;
    border-radius: 50%;
    animation: roo-button-spin 700ms linear infinite;
  }
}

@keyframes roo-button-spin {
  to {
    transform: rotate(360deg);
  }
}

@keyframes roo-button-fade-in {
  from {
    opacity: 0;
  }
}

@keyframes roo-button-fade-out {
  to {
    opacity: 0;
  }
}
</style>
