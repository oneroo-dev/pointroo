<script setup lang="ts">
// The anchored mode of RooSwitcher: an anchor around the trigger, and the panel handed to reka so it is portalled, placed
// under the anchor and kept off the window edge. Without a trigger (`anchored` false) the panel is drawn inline, untouched.
// reka's own focus and dismiss handling is switched off: the switcher moves focus to its row or field, returns it to the
// trigger, and closes on an outside press and on Escape itself.
import { computed, ref } from 'vue'
import { PopoverAnchor, PopoverContent, PopoverPortal, PopoverRoot } from 'reka-ui'
import { useEscapeLayer } from '../composables/useEscapeLayer'
import { useCollisionPadding } from '../composables/useWindowControlPadding'

const props = defineProps<{ anchored: boolean; open: boolean }>()
const emit = defineEmits<{ 'update:open': [open: boolean] }>()
const anchorReference = ref<unknown>(null)
const collisionPadding = useCollisionPadding(() => props.open, anchorReference)
const anchorElement = computed<HTMLElement | null>(() => {
  const target = anchorReference.value
  const element = target instanceof Element ? target : (target as { $el?: Element } | null | undefined)?.$el
  return element instanceof HTMLElement ? element : null
})
// RooSwitcher registers its own layer too; this one is the reka layer that exists only while the panel is portalled.
useEscapeLayer(() => props.anchored && props.open)
defineExpose({ anchorElement })

function keepOpen(event: Event): void {
  event.preventDefault()
}

function onEscapeKeyDown(event: KeyboardEvent): void {
  event.preventDefault()
  emit('update:open', false)
}
</script>

<template>
  <PopoverRoot v-if="anchored" :open="open" @update:open="emit('update:open', $event)">
    <PopoverAnchor ref="anchorReference" as-child>
      <div class="roo-switcher-anchor">
        <slot name="trigger" />
        <PopoverPortal>
          <PopoverContent
            class="roo-switcher-floating"
            side="bottom"
            align="start"
            :side-offset="4"
            :collision-padding="collisionPadding"
            @open-auto-focus="keepOpen"
            @close-auto-focus="keepOpen"
            @escape-key-down="onEscapeKeyDown"
            @pointer-down-outside="keepOpen"
            @focus-outside="keepOpen"
            @interact-outside="keepOpen"
          >
            <slot />
          </PopoverContent>
        </PopoverPortal>
      </div>
    </PopoverAnchor>
  </PopoverRoot>
  <slot v-else />
</template>

<style>
@layer roo-components {
  .roo-switcher-floating {
    z-index: 80;
    -webkit-app-region: no-drag;
  }
}
</style>
