<script setup lang="ts">
// A product glimpse: a window-like frame with a slim title bar (three dots and a title), a panel shadow plus a soft far
// shadow and a reflection line along the top. `tilt="subtle"` turns it in perspective, but never on touch or under reduced
// motion. `fade` fades the bottom 30% of the frame. On mount it rises 12 px and fades in over --roo-slow; children marked
// `data-roo-stagger` follow one after another, and a path marked `data-roo-draw` (give it pathLength="1") draws itself over
// --roo-draw once the frame has landed. All of it is off under reduced motion.
import { computed, onMounted, ref } from 'vue'
import { REDUCED_MOTION_QUERY, TOUCH_QUERY, useMediaMatch } from '../composables/useMediaMatch'

const props = withDefaults(
  defineProps<{
    /** The window title shown in the title bar. */
    title?: string
    tilt?: 'none' | 'subtle'
    /** Fade the bottom 30% of the frame into what is behind it. */
    fade?: boolean
    /** `shadow` keeps the panel shadow; `glow` lifts a dark frame with a halo of the brand light and a 1 px ring (light mode keeps the panel shadow). */
    lift?: 'shadow' | 'glow'
  }>(),
  { title: '', tilt: 'none', fade: false, lift: 'shadow' },
)

const glowing = computed(() => props.lift === 'glow')
const reducedMotion = useMediaMatch(REDUCED_MOTION_QUERY)
const touch = useMediaMatch(TOUCH_QUERY)
const effectiveTilt = computed(() => (props.tilt === 'subtle' && !reducedMotion.value && !touch.value ? 'subtle' : 'none'))

const body = ref<HTMLElement | null>(null)
onMounted(() => {
  body.value?.querySelectorAll<HTMLElement>('[data-roo-stagger]').forEach((element, index) => element.style.setProperty('--roo-index', String(index)))
})
</script>

<template>
  <figure class="roo-floating-frame" :data-tilt="effectiveTilt" :data-fade="fade ? 'true' : 'false'" :data-lift="lift" :class="{ 'roo-floating-frame-fade': fade, 'roo-floating-frame-glow': glowing }">
    <div class="roo-floating-frame-surface">
      <div class="roo-floating-frame-bar">
        <span class="roo-floating-frame-dots" aria-hidden="true"><i></i><i></i><i></i></span>
        <span v-if="title" class="roo-floating-frame-title">{{ title }}</span>
      </div>
      <div ref="body" class="roo-floating-frame-body"><slot /></div>
      <span class="roo-floating-frame-reflection" aria-hidden="true"></span>
    </div>
  </figure>
</template>

<style scoped>
@layer roo-components {
  .roo-floating-frame {
    --roo-frame-rise: var(--roo-p-space-3);
    --roo-frame-far-shadow: 0 var(--roo-p-space-10) var(--roo-p-space-16) color-mix(in srgb, var(--roo-p-graphite) 28%, transparent);
    margin: 0;
    perspective: 1200px;
    font-family: var(--roo-font-ui);
    color: var(--roo-text);
  }

  .roo-floating-frame-surface {
    position: relative;
    overflow: hidden;
    border-radius: var(--roo-p-radius-large);
    background: var(--roo-raised);
    box-shadow: var(--roo-shadow-panel), var(--roo-frame-far-shadow);
    transform-origin: center;
    animation: roo-floating-frame-rise var(--roo-slow) var(--roo-ease) both;
  }

  .roo-floating-frame-glow {
    --roo-brand-glow-lift: var(--roo-shadow-panel);
  }

  :global(.dark) .roo-floating-frame-glow {
    --roo-brand-glow-lift: 0 var(--roo-p-space-6) 80px color-mix(in srgb, var(--roo-x-brand-glow-1) 22%, transparent), 0 0 0 1px color-mix(in srgb, var(--roo-p-white) 10%, transparent);
  }

  .roo-floating-frame-glow .roo-floating-frame-surface {
    box-shadow: var(--roo-brand-glow-lift);
  }

  .roo-floating-frame[data-tilt='subtle'] .roo-floating-frame-surface {
    transform: rotateX(6deg) rotateY(-10deg);
    animation-name: roo-floating-frame-rise-tilted;
  }

  .roo-floating-frame-fade .roo-floating-frame-surface {
    mask-image: linear-gradient(to bottom, var(--roo-p-graphite) 70%, transparent);
  }

  .roo-floating-frame-reflection {
    position: absolute;
    inset: 0 0 auto;
    height: 1px;
    background: linear-gradient(to right, transparent, color-mix(in srgb, var(--roo-p-white) 55%, transparent), transparent);
    pointer-events: none;
  }

  .roo-floating-frame-bar {
    display: flex;
    align-items: center;
    gap: var(--roo-p-space-3);
    height: var(--roo-p-space-8);
    padding: 0 var(--roo-p-space-3);
    border-bottom: 1px solid var(--roo-line);
    background: var(--roo-surface);
  }

  .roo-floating-frame-dots {
    display: inline-flex;
    gap: var(--roo-p-space-1);
  }

  .roo-floating-frame-dots i {
    width: var(--roo-p-space-2);
    height: var(--roo-p-space-2);
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-border);
  }

  .roo-floating-frame-title {
    min-width: 0;
    overflow: hidden;
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-floating-frame-body {
    position: relative;
  }

  .roo-floating-frame-body :deep([data-roo-stagger]) {
    animation: roo-floating-frame-rise var(--roo-slow) var(--roo-ease) both;
    animation-delay: calc(var(--roo-slow) + min(calc(var(--roo-index, 0) * var(--roo-fast) / 2), var(--roo-line-delay)));
  }

  .roo-floating-frame-body :deep([data-roo-draw]) {
    stroke-dasharray: 1;
    stroke-dashoffset: 1;
    animation: roo-floating-frame-draw var(--roo-draw) var(--roo-ease) var(--roo-slow) forwards;
  }

  @keyframes roo-floating-frame-rise {
    from { opacity: 0; transform: translateY(var(--roo-frame-rise)); }
    to { opacity: 1; transform: translateY(0); }
  }

  @keyframes roo-floating-frame-rise-tilted {
    from { opacity: 0; transform: translateY(var(--roo-frame-rise)) rotateX(6deg) rotateY(-10deg); }
    to { opacity: 1; transform: translateY(0) rotateX(6deg) rotateY(-10deg); }
  }

  @keyframes roo-floating-frame-draw {
    to { stroke-dashoffset: 0; }
  }

  @media (hover: none), (pointer: coarse) {
    .roo-floating-frame[data-tilt] .roo-floating-frame-surface {
      transform: none;
      animation-name: roo-floating-frame-rise;
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .roo-floating-frame[data-tilt] .roo-floating-frame-surface,
    .roo-floating-frame-body :deep([data-roo-stagger]) {
      transform: none;
      animation: none;
    }

    .roo-floating-frame-body :deep([data-roo-draw]) {
      stroke-dasharray: none;
      stroke-dashoffset: 0;
      animation: none;
    }
  }
}
</style>
