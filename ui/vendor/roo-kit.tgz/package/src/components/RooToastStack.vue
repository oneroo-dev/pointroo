<script setup lang="ts">
import { TransitionGroup, computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import RooToast from './RooToast.vue'
import { toastClearance } from '../composables/useToastClearance'
import { useToasts, type ToastStore } from '../composables/useToasts'

const props = withDefaults(
  defineProps<{
    /** Defaults to the app-wide queue. */
    store?: ToastStore | undefined
    /** The name of the region, for the F6 cycle and screen readers. */
    label?: string
  }>(),
  { store: undefined, label: 'Notifications' },
)

const store = props.store ?? useToasts()

// Left unset when no area is registered, so a --roo-toast-clearance an app sets by hand still applies.
const clearanceStyle = computed(() =>
  toastClearance.value > 0 ? { '--roo-toast-clearance': `${toastClearance.value}px` } : undefined,
)

// Motion. The newest toast is index 0 and sits in front; older ones fold behind it, scaled down and lifted a little.
// Hover or focus opens the stack out: each toast lifts by the measured height of the newer ones. A toast that is still
// leaving keeps the section on screen until its slide is done (the 'leaving' count), so the last one can slide out too.
const listComponent = ref<{ $el: HTMLElement } | null>(null)
const expanded = ref(false)
const leaving = ref(0)
const visible = computed(() => store.toasts.value.length > 0 || leaving.value > 0)

function onFocusout(event: FocusEvent): void {
  const element = listComponent.value?.$el
  if (element && event.relatedTarget instanceof Node && element.contains(event.relatedTarget)) return
  expanded.value = false
}

function indexOf(position: number): number {
  return store.toasts.value.length - 1 - position
}

let observer: ResizeObserver | undefined

// Sets --roo-toast-lift on each toast: the height of every newer toast plus the gaps between them.
function measure(): void {
  const element = listComponent.value?.$el ?? null
  if (element === null || element === undefined) return
  const toasts = [...element.children].filter((child): child is HTMLElement => child instanceof HTMLElement && !child.classList.contains('roo-toast-leave-active'))
  let lift = 0
  for (let position = toasts.length - 1; position >= 0; position -= 1) {
    const toast = toasts[position]!
    toast.style.setProperty('--roo-toast-lift', `${lift}px`)
    lift += toast.offsetHeight + 8
  }
}

function watchHeights(): void {
  const element = listComponent.value?.$el ?? null
  if (element === null || element === undefined || typeof ResizeObserver === 'undefined') return
  observer?.disconnect()
  observer = new ResizeObserver(measure)
  for (const child of element.children) observer.observe(child)
}

watch(
  () => store.toasts.value.length,
  async () => {
    await nextTick()
    measure()
    watchHeights()
  },
  { flush: 'post' },
)

// Placement. The stack sits bottom right; while an open popover, menu or dialog overlaps that corner it moves to the top
// right, and goes back when nothing overlaps. reka renders popper content inside [data-reka-popper-content-wrapper].
const placement = ref<'top' | 'bottom'>('bottom')
const stackComponent = ref<HTMLElement | null>(null)
const emptyStackWidth = 400
const emptyStackHeight = 120
let overlayWatcher: MutationObserver | undefined

function overlapsBottomRight(): boolean {
  const stackRect = stackComponent.value?.getBoundingClientRect()
  const corner = {
    left: window.innerWidth - Math.max(stackRect?.width ?? 0, emptyStackWidth),
    top: window.innerHeight - Math.max(stackRect?.height ?? 0, emptyStackHeight) - Math.max(toastClearance.value, 0),
  }
  const overlays = document.querySelectorAll<HTMLElement>(
    "[data-reka-popper-content-wrapper] [data-state='open'], [role='dialog'][data-state='open'], [data-reka-popper-content-wrapper][data-state='open']",
  )
  for (const overlay of overlays) {
    const rect = overlay.getBoundingClientRect()
    if (rect.width <= 0 || rect.height <= 0) continue
    if (rect.right > corner.left && rect.left < window.innerWidth && rect.bottom > corner.top && rect.top < window.innerHeight) return true
  }
  return false
}

function updatePlacement(): void {
  placement.value = overlapsBottomRight() ? 'top' : 'bottom'
}

// Watched only while a toast is on screen, so a page that changes its DOM all the time (an editor) pays nothing otherwise.
// Many mutations in one frame cause one check.
let framePending = false
let frameHandle = 0

function scheduleCheck(): void {
  if (framePending) return
  framePending = true
  frameHandle = requestAnimationFrame(() => {
    framePending = false
    updatePlacement()
  })
}

function startWatching(): void {
  if (overlayWatcher !== undefined) return
  updatePlacement()
  if (typeof MutationObserver !== 'undefined') {
    overlayWatcher = new MutationObserver(scheduleCheck)
    overlayWatcher.observe(document.body, { attributes: true, attributeFilter: ['data-state'], childList: true, subtree: true })
  }
  window.addEventListener('resize', scheduleCheck)
}

function stopWatching(): void {
  overlayWatcher?.disconnect()
  overlayWatcher = undefined
  window.removeEventListener('resize', scheduleCheck)
  if (framePending) cancelAnimationFrame(frameHandle)
  framePending = false
  placement.value = 'bottom'
}

watch(visible, (isVisible) => (isVisible ? startWatching() : stopWatching()), { flush: 'post' })
onMounted(() => {
  measure()
  if (visible.value) startWatching()
})
onBeforeUnmount(() => {
  observer?.disconnect()
  stopWatching()
})
</script>

<template>
  <section
    v-if="visible"
    ref="stackComponent"
    class="roo-toast-stack"
    :data-placement="placement"
    :style="clearanceStyle"
    :aria-label="label"
    data-roo-region="toasts"
    tabindex="-1"
  >
    <TransitionGroup
      ref="listComponent"
      tag="div"
      name="roo-toast"
      class="roo-toast-list"
      :data-expanded="expanded ? 'true' : 'false'"
      @before-leave="leaving += 1"
      @after-leave="leaving -= 1"
      @mouseenter="expanded = true"
      @mouseleave="expanded = false"
      @focusin="expanded = true"
      @focusout="onFocusout"
    >
      <RooToast
        v-for="(toast, position) in store.toasts.value"
        :key="toast.id"
        :style="{ '--roo-toast-index': String(indexOf(position)) }"
        :title="toast.title"
        :message="toast.message"
        :detail="toast.detail"
        :tone="toast.tone"
        :count="toast.count"
        :undo="toast.hasUndo"
        :action-label="toast.action?.label ?? ''"
        :icon="toast.icon"
        :single-line="toast.singleLine"
        :width="toast.width"
        @dismiss="store.dismiss(toast.id)"
        @undo="store.runUndo(toast.id)"
        @action="store.runAction(toast.id)"
        @pause="store.pause(toast.id)"
        @resume="store.resume(toast.id)"
      />
    </TransitionGroup>
  </section>
</template>

<style scoped>
@layer roo-components {
  .roo-toast-stack {
    position: fixed;
    right: var(--roo-p-space-4);
    bottom: calc(var(--roo-toast-clearance, 0px) + var(--roo-p-space-4));
    z-index: 85;
    display: flex;
    flex-direction: column;
    gap: var(--roo-p-space-2);
    outline: none;
    transition: bottom var(--roo-fast) var(--roo-ease), top var(--roo-fast) var(--roo-ease);
  }

  .roo-toast-stack[data-placement='top'] {
    top: var(--roo-p-space-4);
    bottom: auto;
  }

  /* One grid cell holds every toast: the newest is in front, older ones fold behind it, a little smaller and lifted. */
  .roo-toast-list {
    display: grid;
    justify-items: end;
    align-items: end;
  }

  .roo-toast-list > .roo-toast {
    grid-area: 1 / 1;
    /* The default; RooToast sets it inline while a swipe is under way. */
    --roo-toast-swipe: 0px;
    z-index: calc(10 - var(--roo-toast-index, 0));
    transform-origin: bottom right;
    transform: translateX(var(--roo-toast-swipe, 0px)) translateY(calc(var(--roo-toast-index, 0) * -8px)) scale(calc(1 - var(--roo-toast-index, 0) * 0.05));
    opacity: calc(1 - var(--roo-toast-index, 0) * 0.2);
    animation: none;
    transition: transform var(--roo-base) var(--roo-ease), opacity var(--roo-base) var(--roo-ease);
  }

  /* Hover or focus opens the stack out. --roo-toast-lift is the measured height of the newer toasts. */
  .roo-toast-list[data-expanded='true'] > .roo-toast {
    transform: translateX(var(--roo-toast-swipe, 0px)) translateY(calc(var(--roo-toast-lift, 0px) * -1));
    opacity: 1;
  }

  /* A toast under the pointer follows it with no delay. */
  .roo-toast-list > .roo-toast[data-swiping] {
    transition: none;
  }

  .roo-toast-enter-active,
  .roo-toast-leave-active {
    transition: transform var(--roo-base) var(--roo-ease), opacity var(--roo-base) var(--roo-ease);
  }

  .roo-toast-leave-active {
    pointer-events: none;
  }

  .roo-toast-list > .roo-toast.roo-toast-enter-from {
    opacity: 0;
    transform: translateY(16px);
  }

  .roo-toast-list > .roo-toast.roo-toast-leave-to {
    opacity: 0;
    transform: translateX(calc(100% + var(--roo-p-space-4)));
  }

  @media (prefers-reduced-motion: reduce) {
    .roo-toast-stack {
      transition: none;
    }
  }

  [data-surface='desktop'] .roo-toast-stack {
    transition: none;
  }
}
</style>
