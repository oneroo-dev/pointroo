<script setup lang="ts">
// A small line with no axes: the shape of a series at a glance. It is decoration unless it is given a label, and then it
// is a labelled image, so a tile that already says the number does not make a screen reader read the shape twice.
import { computed } from 'vue'
import { linePath, linearScale } from './RooChartMath'

const props = withDefaults(
  defineProps<{
    values: Array<number | null>
    /** Spoken for the sparkline, such as `Last 7 days`. Left out, the sparkline is hidden from assistive technology. */
    label?: string
    width?: number
    height?: number
    /** 1 to 6: which categorical series colour the line takes. */
    colour?: number
  }>(),
  { label: '', width: 80, height: 28, colour: 1 },
)

const COLOURS = [
  'var(--roo-x-series-1)',
  'var(--roo-x-series-2)',
  'var(--roo-x-series-3)',
  'var(--roo-x-series-4)',
  'var(--roo-x-series-5)',
  'var(--roo-x-series-6)',
]

const INSET = 3

const shape = computed(() => {
  const present = props.values.filter((value): value is number => value !== null && value !== undefined)
  if (present.length === 0) return { path: '', endX: 0, endY: 0 }
  const low = Math.min(...present)
  const high = Math.max(...present)
  const horizontal = linearScale(0, Math.max(props.values.length - 1, 1), INSET, props.width - INSET)
  const vertical = linearScale(low, high, props.height - INSET, INSET)
  const xs = props.values.map((_, index) => horizontal(index))
  const ys = props.values.map((value) => (value === null || value === undefined ? null : high === low ? props.height / 2 : vertical(value)))
  let last = -1
  ys.forEach((value, index) => {
    if (value !== null) last = index
  })
  return { path: linePath(xs, ys), endX: xs[last] ?? 0, endY: ys[last] ?? 0 }
})

const colourValue = computed(() => COLOURS[Math.min(Math.max(Math.round(props.colour), 1), COLOURS.length) - 1] ?? COLOURS[0])
</script>

<template>
  <svg
    class="roo-sparkline"
    :width="width"
    :height="height"
    :viewBox="`0 0 ${width} ${height}`"
    :role="label ? 'img' : undefined"
    :aria-label="label || undefined"
    :aria-hidden="label ? undefined : 'true'"
    focusable="false"
    :style="{ '--roo-chart-colour': colourValue }"
  >
    <path v-if="shape.path" class="roo-sparkline-line" data-roo-draw pathLength="1" :d="shape.path" />
    <circle v-if="shape.path" class="roo-sparkline-end" :cx="shape.endX" :cy="shape.endY" r="2.5" />
  </svg>
</template>

<style scoped>
@layer roo-components {
  .roo-sparkline {
    display: block;
    flex: none;
    overflow: visible;
  }

  .roo-sparkline-line {
    fill: none;
    stroke: var(--roo-chart-colour);
    stroke-width: 1.5;
    stroke-linejoin: round;
    stroke-linecap: round;
  }

  .roo-sparkline-end {
    fill: var(--roo-chart-colour);
  }
}
</style>
