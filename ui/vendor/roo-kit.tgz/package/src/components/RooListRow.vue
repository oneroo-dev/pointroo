<script setup lang="ts">
// A two-line list row: a leading `tile` slot, a title and a subtitle, a trailing `actions` slot, and an optional failure line
// that grows the row by one line. The row is --roo-list-row-2-h (44 or 52); `size="dense"` is --roo-list-row-2-dense-h (38) with
// 12px lines. `size="single"` is a one-line row that follows density: --roo-list-row-h (36 comfortable, 21 compact) as a
// min-height, so a failure line still grows it. A `title-trailing` slot sits right-aligned on the title line, on the title's
// baseline, never wraps and never pushes the title off its line: the title truncates first. Actions are always in the DOM and the tab order; they fade in on hover and focus within.
// `title` and `subtitle` are also slots (the prop is the default), for a status dot, a loader or an environment word; the slot
// sits inside the truncating element, so keep slotted pieces inline.
// A `title-prefix` slot puts a dot or loader in a flex row with the title text, centred on the title's line; only the text
// ellipsizes, so the prefix needs no vertical-align.
// The `trailing` slot comes after the actions, never fades, and is centred on the row (an "open" dot).
// Attributes pass to the root, so the app sets the role (`option`, `listitem`, `row`) and aria state itself. With `split` the
// root is a plain container and role, aria-* and the rest of the attributes (not class and style) go to the main region
// (tile and text), which is focusable (tabindex 0 unless the app passes its own); actions and trailing stay outside it as
// siblings, so a listbox option never contains buttons. `selected` sets aria-selected and the selected fill.
// `surface` ('auto' by default) names the fill family: auto follows the ancestor, popover and raised force it, plain opts out.
import { computed, useAttrs } from 'vue'

defineOptions({ inheritAttrs: false })

const props = withDefaults(
  defineProps<{
    title?: string
    subtitle?: string
    /** One extra line in the danger text colour, such as why a connection failed. */
    failure?: string
    size?: 'dense' | 'single'
    /** Sets aria-selected on the role element (the root, or the main region in split mode) and the selected fill. */
    selected?: boolean | undefined
    /** Put the attributes (role, aria-*) on the main region only; actions and trailing sit outside it. */
    split?: boolean
    /** Which fill family the row takes: 'auto' follows the ancestor (a popover family class or data-on-raised), 'popover' and 'raised' force that look, 'plain' keeps the default look even inside a popover. */
    surface?: 'auto' | 'popover' | 'raised' | 'plain'
  }>(),
  { title: '', subtitle: '', failure: '', selected: undefined, surface: 'auto' },
)

const attrs = useAttrs()
const ariaSelected = computed(() => (props.selected === undefined ? undefined : String(props.selected)))
const rootAttrs = computed<Record<string, unknown>>(() => {
  if (!props.split) return { ...attrs, 'aria-selected': ariaSelected.value ?? attrs['aria-selected'] }
  return { class: attrs.class, style: attrs.style }
})
const mainAttrs = computed<Record<string, unknown>>(() => {
  if (!props.split) return {}
  const { class: _class, style: _style, ...rest } = attrs
  return { tabindex: 0, ...rest, 'aria-selected': ariaSelected.value ?? attrs['aria-selected'] }
})
const isSelected = computed(() => props.selected === true || (props.selected === undefined && attrs['aria-selected'] === 'true'))
</script>

<template>
  <div class="roo-list-row" :data-size="size" :data-split="split ? 'true' : undefined" :data-surface="surface" :data-selected="isSelected ? 'true' : undefined" v-bind="rootAttrs">
    <span class="roo-list-row-main" v-bind="mainAttrs">
      <span v-if="$slots.tile" class="roo-list-row-tile"><slot name="tile" /></span>
      <span class="roo-list-row-text">
        <span class="roo-list-row-title">
          <span v-if="$slots['title-prefix']" class="roo-list-row-title-prefix"><slot name="title-prefix" /></span>
          <span class="roo-list-row-title-text"><slot name="title">{{ title }}</slot></span>
          <span v-if="$slots['title-trailing']" class="roo-list-row-title-trailing"><slot name="title-trailing" /></span>
        </span>
        <span v-if="subtitle || $slots.subtitle" class="roo-list-row-subtitle"><slot name="subtitle">{{ subtitle }}</slot></span>
        <span v-if="failure" class="roo-list-row-failure">{{ failure }}</span>
      </span>
    </span>
    <span v-if="$slots.actions" class="roo-list-row-actions"><slot name="actions" /></span>
    <span v-if="$slots.trailing" class="roo-list-row-trailing"><slot name="trailing" /></span>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-list-row {
    display: flex;
    min-height: var(--roo-list-row-2-h);
    box-sizing: border-box;
    align-items: center;
    gap: var(--roo-gap);
    border-radius: var(--roo-tree-radius);
    padding: 6px var(--roo-list-row-pad-inline);
    color: var(--roo-text);
    font-size: var(--roo-ui-size);
  }

  .roo-list-row[data-size='dense'] {
    /* The dense row is never taller than the density's two-line row (38 against 52 comfortable, 35 compact). */
    min-height: min(var(--roo-list-row-2-dense-h), var(--roo-list-row-2-h));
    padding-block: 4px;
    font-size: var(--roo-p-size-12);
  }

  /* One line, at the density's one-line row height (36 comfortable, 21 compact). A minimum, so a failure line still grows the row. */
  .roo-list-row[data-size='single'] {
    min-height: var(--roo-list-row-h);
    padding-block: 0;
  }

  /* Under compact density a whole-pixel line box keeps the line centred on a whole pixel: 21 less 15 is even. */
  :root[data-density='compact'] .roo-list-row[data-size='single'] .roo-list-row-title {
    line-height: 15px;
  }

  .roo-list-row[data-size='dense'] .roo-list-row-title,
  .roo-list-row[data-size='dense'] .roo-list-row-subtitle,
  .roo-list-row[data-size='dense'] .roo-list-row-failure {
    line-height: 14px;
  }

  /* One hover fill for every row-like thing (--roo-row-hover: 5% in light, 10% in dark). */
  .roo-list-row:hover {
    background: var(--roo-row-hover);
  }

  .roo-list-row[data-selected='true'] {
    background: var(--roo-select);
  }

  .roo-list-row[data-selected='true']:hover {
    background: var(--roo-select-hover);
  }

  .roo-list-row:active:not([data-selected='true']) {
    background: color-mix(in srgb, var(--roo-text) 9%, transparent);
  }

  :root[data-appearance='dark'] .roo-list-row:active:not([data-selected='true']),
  .dark .roo-list-row:active:not([data-selected='true']) {
    background: color-mix(in srgb, var(--roo-text) 14%, transparent);
  }

  .roo-list-row:focus-visible,
  .roo-list-row-main:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: -2px;
    border-radius: inherit;
  }

  .roo-list-row[data-split='true']:focus-visible {
    outline: none;
  }

  .roo-list-row-main {
    display: flex;
    min-width: 0;
    flex: 1;
    align-items: center;
    gap: var(--roo-gap);
    align-self: stretch;
    outline: none;
  }

  .roo-list-row-trailing {
    display: inline-flex;
    flex: none;
    align-items: center;
  }

  /* Surface: 'auto' reads the ancestor (a popover family class, or data-on-raised); 'popover' and 'raised' force the same
     declarations by prop; 'plain' matches neither, so it keeps the default look anywhere. The :where gate adds no specificity. */
  :is(.roo-popover, .roo-select-popover, .roo-menu, .roo-palette, .roo-dialog) .roo-list-row:where([data-surface='auto']),
  .roo-list-row[data-surface='popover'] {
    border-radius: var(--roo-p-radius-medium);
  }

  :is(.roo-popover, .roo-select-popover, .roo-menu, .roo-palette, .roo-dialog) .roo-list-row:hover:where([data-surface='auto']),
  :is(.roo-popover, .roo-select-popover, .roo-menu, .roo-palette, .roo-dialog) .roo-list-row[data-selected='true']:where([data-surface='auto']),
  .roo-list-row[data-surface='popover']:hover,
  .roo-list-row[data-surface='popover'][data-selected='true'] {
    background: var(--roo-raised-on-raised);
  }

  /* On a raised strip or card the popover fills show nothing, so the hover step. */
  [data-on-raised='true'] .roo-list-row:hover:where([data-surface='auto']),
  [data-on-raised='true'] .roo-list-row[data-selected='true']:where([data-surface='auto']),
  .roo-list-row[data-surface='raised']:hover,
  .roo-list-row[data-surface='raised'][data-selected='true'] {
    background: var(--roo-raised-hover);
  }

  .roo-list-row-tile {
    display: inline-flex;
    width: var(--roo-icon-tile);
    height: var(--roo-icon-tile);
    flex: none;
    align-items: center;
    justify-content: center;
  }

  .roo-list-row-text {
    display: flex;
    min-width: 0;
    flex: 1;
    flex-direction: column;
  }

  .roo-list-row-title,
  .roo-list-row-subtitle,
  .roo-list-row-failure {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  /* The title is a flex row: an optional prefix (a status dot or loader) centred on the line box, then the text, which alone ellipsizes. */
  .roo-list-row-title {
    display: flex;
    align-items: center;
    gap: var(--roo-p-space-2);
  }

  .roo-list-row-title-prefix {
    display: inline-flex;
    flex: none;
    align-items: center;
  }

  .roo-list-row-title-text {
    min-width: 0;
    flex: 0 1 auto;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  /* The title text sits on the title's baseline. */
  .roo-list-row-title-text {
    align-self: baseline;
  }

  /* Right-aligned on the title line and centred on it. The items inside (a RooMeta, a RooEnvPill size small) sit in one
     cluster with the item gap between them, so an app adds no margin or vertical-align of its own. It never shrinks or wraps, so the title text truncates first. */
  .roo-list-row-title-trailing {
    display: inline-flex;
    flex: none;
    align-items: center;
    align-self: center;
    gap: var(--roo-space-item);
    margin-inline-start: auto;
    white-space: nowrap;
  }

  .roo-list-row-subtitle {
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }

  .roo-list-row-failure {
    color: var(--roo-danger-text);
    font-size: var(--roo-p-size-12);
  }

  /* Hidden by opacity, never display or visibility, so the buttons stay focusable and in the tab order. */
  .roo-list-row-actions {
    display: inline-flex;
    flex: none;
    align-items: center;
    opacity: 0;
  }

  .roo-list-row:hover .roo-list-row-actions,
  .roo-list-row:focus-within .roo-list-row-actions {
    opacity: 1;
  }
}
</style>
