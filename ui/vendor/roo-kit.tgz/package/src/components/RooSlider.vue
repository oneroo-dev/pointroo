<script lang="ts">
export interface RooSliderMark {
  value: number
  /** The text under the tick, such as `500K`. Leave it out for a bare tick. */
  label?: string
}

/** Positions along a log slider. One arrow press is one position (1%), Page Up and Page Down are ten. */
export const SLIDER_LOG_POSITIONS = 100

/** Where a value sits along the track, from 0 (min) to 1 (max). A log scale reads None (the minimum) as the start. */
export function sliderRatio(value: number, minimum: number, maximum: number, scale: 'linear' | 'log'): number {
  const span = maximum - minimum
  if (span <= 0) return 0
  const clamped = Math.min(Math.max(value, minimum), maximum)
  if (scale === 'linear') return (clamped - minimum) / span
  return Math.log(clamped - minimum + 1) / Math.log(span + 1)
}

/** The value at a place along the track, before it is snapped to a step. The inverse of sliderRatio. */
export function sliderValueAt(ratio: number, minimum: number, maximum: number, scale: 'linear' | 'log'): number {
  const span = maximum - minimum
  const clamped = Math.min(Math.max(ratio, 0), 1)
  if (scale === 'linear') return minimum + span * clamped
  return minimum + Math.pow(span + 1, clamped) - 1
}
</script>

<script setup lang="ts">
import { SliderRange, SliderRoot, SliderThumb, SliderTrack, useId } from 'reka-ui'
import { computed, onBeforeUnmount, onMounted, ref, watchPostEffect } from 'vue'

const model = defineModel<number>({ default: 0 })

const props = withDefaults(
  defineProps<{
    min?: number
    max?: number
    step?: number
    /** `log` spreads the track so each tenfold step takes the same room. It starts at `min`, which may be 0 (None). */
    scale?: 'linear' | 'log'
    /** Labelled ticks under the track, such as None, 500K, 5M and 100M. */
    marks?: RooSliderMark[]
    /** A value marked on the track, such as the free amount. It is drawn as a notch and read out to assistive tech. */
    included?: number | undefined
    /** The words for the included notch when read out, such as `Included: 500K`. Defaults to the formatted value. */
    includedLabel?: string
    /** Turns a value into the words a screen reader says, such as `5 million events`. Defaults to the plain number. */
    formatValue?: ((value: number) => string) | undefined
    disabled?: boolean
    ariaLabel?: string | undefined
    ariaLabelledby?: string | undefined
  }>(),
  {
    min: 0,
    max: 100,
    step: 1,
    scale: 'linear',
    marks: () => [],
    included: undefined,
    includedLabel: '',
    formatValue: undefined,
    disabled: false,
    ariaLabel: undefined,
    ariaLabelledby: undefined,
  },
)

const id = useId(undefined, 'roo-slider')
const isLog = computed(() => props.scale === 'log')

function snap(value: number): number {
  const steps = Math.round((value - props.min) / props.step)
  const snapped = props.min + steps * props.step
  return Math.min(Math.max(snapped, props.min), props.max)
}

function ratioOf(value: number): number {
  return sliderRatio(value, props.min, props.max, props.scale)
}

const clampedModel = computed(() => Math.min(Math.max(model.value, props.min), props.max))

// What reka-ui sees. A linear slider hands it the real values. A log slider hands it a position from 0 to 100, because
// reka only knows even steps, and this component turns each position back into a value.
const inner = computed(() =>
  isLog.value
    ? { min: 0, max: SLIDER_LOG_POSITIONS, step: 1, value: ratioOf(clampedModel.value) * SLIDER_LOG_POSITIONS }
    : { min: props.min, max: props.max, step: props.step, value: clampedModel.value },
)

function update(values: number[] | undefined): void {
  const next = values?.[0]
  if (next === undefined) return
  if (!isLog.value) {
    if (next !== model.value) model.value = next
    return
  }
  const direction = Math.sign(next - inner.value.value)
  let position = next
  let candidate = snap(sliderValueAt(position / SLIDER_LOG_POSITIONS, props.min, props.max, 'log'))
  // Near the low end a whole position can be smaller than one step, so the value would not move. Keep going in the
  // direction of the key or the drag until the value does change, or the track ends.
  while (candidate === clampedModel.value && direction !== 0) {
    position += direction
    if (position < 0 || position > SLIDER_LOG_POSITIONS) return
    candidate = snap(sliderValueAt(position / SLIDER_LOG_POSITIONS, props.min, props.max, 'log'))
  }
  if (candidate !== model.value) model.value = candidate
}

function describe(value: number): string {
  return props.formatValue ? props.formatValue(value) : String(value)
}

const valueText = computed(() => describe(clampedModel.value))
const includedText = computed(() => props.includedLabel || (props.included === undefined ? '' : `Included: ${describe(props.included)}`))

// The thumb is kept inside the track by reka, which shifts it by up to half its width. A tick at a plain percentage would
// drift from the thumb at the ends, so ticks take the same shift.
function placement(value: number): Record<string, string> {
  const ratio = ratioOf(value)
  return { left: `calc(${ratio * 100}% + var(--roo-slider-thumb) * ${(0.5 - ratio).toFixed(4)})` }
}

const pressed = ref(false)

function release(): void {
  pressed.value = false
  window.removeEventListener('pointerup', release)
  window.removeEventListener('pointercancel', release)
}

function press(): void {
  if (props.disabled) return
  pressed.value = true
  window.addEventListener('pointerup', release)
  window.addEventListener('pointercancel', release)
}

onBeforeUnmount(release)

// reka-ui writes the thumb's aria-valuenow, -min and -max from the values it was given, and a log slider gives it positions
// from 0 to 100. Its attributes win over any passed in, and it writes them again on its own schedule, so the real value is put
// back whenever they change.
const thumb = ref<{ $el: HTMLElement } | null>(null)
let ariaObserver: MutationObserver | null = null

function putRealValueBack(): void {
  const element = thumb.value?.$el
  if (!element || !isLog.value) return
  const wanted: Record<string, string> = {
    'aria-valuenow': String(clampedModel.value),
    'aria-valuemin': String(props.min),
    'aria-valuemax': String(props.max),
  }
  for (const [name, value] of Object.entries(wanted)) {
    if (element.getAttribute(name) !== value) element.setAttribute(name, value)
  }
}

onMounted(() => {
  const element = thumb.value?.$el
  if (!element) return
  ariaObserver = new MutationObserver(putRealValueBack)
  ariaObserver.observe(element, { attributes: true, attributeFilter: ['aria-valuenow', 'aria-valuemin', 'aria-valuemax'] })
  putRealValueBack()
})

onBeforeUnmount(() => ariaObserver?.disconnect())

watchPostEffect(putRealValueBack)
</script>

<template>
  <div class="roo-slider" :data-scale="scale" :data-disabled="disabled ? 'true' : undefined" :data-pressed="pressed ? 'true' : undefined" :data-has-marks="marks.length > 0 ? 'true' : undefined">
    <SliderRoot
      class="roo-slider-root"
      :model-value="[inner.value]"
      :min="inner.min"
      :max="inner.max"
      :step="inner.step"
      :disabled="disabled"
      :inverted="false"
      @update:model-value="update"
      @pointerdown="press"
    >
      <SliderTrack class="roo-slider-track">
        <SliderRange class="roo-slider-range" />
      </SliderTrack>
      <span v-if="included !== undefined" class="roo-slider-included" data-included="true" :style="placement(included)" aria-hidden="true" />
      <SliderThumb
        ref="thumb"
        class="roo-slider-thumb"
        :aria-label="ariaLabelledby ? undefined : ariaLabel"
        :aria-labelledby="ariaLabelledby"
        :aria-describedby="includedText ? `${id}-included` : undefined"
        :aria-valuetext="valueText"
      />
    </SliderRoot>
    <p v-if="includedText" :id="`${id}-included`" class="roo-visually-hidden">{{ includedText }}</p>
    <div v-if="marks.length > 0" class="roo-slider-marks" aria-hidden="true">
      <span v-for="mark in marks" :key="mark.value" class="roo-slider-mark" :style="placement(mark.value)">
        <span class="roo-slider-tick" />
        <span v-if="mark.label" class="roo-slider-mark-label">{{ mark.label }}</span>
      </span>
    </div>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-slider {
    --roo-slider-thumb: 16px;
    --roo-slider-track: 4px;

    display: flex;
    flex-direction: column;
    gap: var(--roo-p-space-1);
    width: 100%;
  }

  .roo-slider-root {
    position: relative;
    display: flex;
    height: var(--roo-slider-thumb);
    align-items: center;
    touch-action: none;
    user-select: none;
  }

  .roo-slider-track {
    position: relative;
    height: var(--roo-slider-track);
    flex: 1;
    overflow: hidden;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-track);
  }

  .roo-slider-range {
    position: absolute;
    height: 100%;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-accent-fill);
  }

  .roo-slider-included {
    position: absolute;
    top: 50%;
    width: 2px;
    height: calc(var(--roo-slider-track) + 8px);
    background: var(--roo-text);
    transform: translate(-50%, -50%);
    pointer-events: none;
  }

  .roo-slider-thumb {
    display: block;
    width: var(--roo-slider-thumb);
    height: var(--roo-slider-thumb);
    box-sizing: border-box;
    border: 2px solid var(--roo-accent-fill);
    border-radius: 50%;
    background: var(--roo-surface);
    box-shadow: var(--roo-shadow-thumb);
    cursor: default;
    transition:
      box-shadow var(--roo-fast) var(--roo-ease),
      transform var(--roo-fast) var(--roo-ease);
  }

  .roo-slider-thumb:hover {
    box-shadow: var(--roo-shadow-thumb), 0 0 0 4px var(--roo-accent-bg);
  }

  .roo-slider[data-pressed='true'] .roo-slider-thumb,
  .roo-slider-thumb:active {
    background: var(--roo-accent-bg);
    box-shadow: var(--roo-shadow-thumb), 0 0 0 5px var(--roo-accent-ring);
    transform: scale(1.1);
  }

  .roo-slider-thumb:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  .roo-slider[data-disabled='true'] .roo-slider-range {
    background: var(--roo-control-edge);
  }

  .roo-slider[data-disabled='true'] .roo-slider-thumb {
    border-color: var(--roo-control-edge);
    background: var(--roo-bg);
    box-shadow: none;
    transform: none;
  }

  .roo-slider-marks {
    position: relative;
    height: calc(var(--roo-p-space-2) + var(--roo-p-size-12) * 1.4);
  }

  .roo-slider-mark {
    position: absolute;
    top: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: var(--roo-p-space-1);
    transform: translateX(-50%);
  }

  .roo-slider-tick {
    width: 1px;
    height: var(--roo-p-space-2);
    background: var(--roo-control-edge);
  }

  .roo-slider-mark-label {
    color: var(--roo-muted);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
    line-height: 1.4;
    white-space: nowrap;
  }

  /* An invisible tap area of at least --roo-touch-target on a coarse pointer (family rule F6, Fable review). The drawn size never changes. */
  @media (pointer: coarse) {
    .roo-slider-thumb {
      position: relative;
    }

    .roo-slider-thumb::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2));
    }
  }
}
</style>
