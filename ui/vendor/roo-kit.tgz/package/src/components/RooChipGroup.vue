<script setup lang="ts">
// One line of chips. The chips that do not fit fold, last first, into a "+N" button that opens a menu listing them, and the
// `trailing` slot (an assignee avatar, say) keeps its place at the end. The row never wraps. The pattern is Fluent 2 Tag and
// Dynatrace ChipGroup overflow, as proved in Bellroo's inbox frames. The arithmetic is in RooChipGroupFit.ts.
import { computed, nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import RooChip from './RooChip.vue'
import { moreLabel as describeFolded, visibleCount } from './RooChipGroupFit'
import RooMenu from './RooMenu.vue'
import RooMenuItem from './RooMenuItem.vue'

export interface RooChipGroupChip {
  id: string
  label: string
  tone?: 'neutral' | 'accent' | 'ok' | 'warn' | 'danger'
}

const props = defineProps<{
  chips: RooChipGroupChip[]
  /** `small` passes the small chip size to every chip (and the +N) and tightens the gap to 4. */
  size?: 'default' | 'small'
  /** The "+N" button's accessible name from the folded labels, for translation. Default: "2 more: Urgent, Email". */
  moreLabel?: ((foldedLabels: string[]) => string) | undefined
}>()

const root = ref<HTMLElement | null>(null)
const probe = ref<HTMLElement | null>(null)
const chipElements = new Map<string, HTMLElement>()
const keptCount = ref(props.chips.length)

const kept = computed(() => Math.min(keptCount.value, props.chips.length))
const folded = computed(() => props.chips.slice(kept.value))
const foldedLabels = computed(() => folded.value.map((chip) => chip.label))
const accessibleName = computed(() => (props.moreLabel ? props.moreLabel(foldedLabels.value) : describeFolded(foldedLabels.value)))

function holdChip(chipId: string, element: unknown): void {
  const target = (element as { $el?: HTMLElement } | null)?.$el ?? (element as HTMLElement | null)
  if (target) chipElements.set(chipId, target)
  else chipElements.delete(chipId)
}

// Every chip is shown, measured, and then Vue hides the ones that do not fit. Hidden chips are `hidden`, so each pass
// first shows them all again.
function measure(): void {
  const row = root.value
  if (!row || props.chips.length === 0) return
  const elements = props.chips.map((chip) => chipElements.get(chip.id))
  if (elements.some((element) => element === undefined)) return
  const chipElementList = elements as HTMLElement[]
  chipElementList.forEach((element) => {
    element.hidden = false
  })
  const trailing = row.querySelector<HTMLElement>(':scope > .roo-chip-group-trailing')
  const gap = Number.parseFloat(getComputedStyle(row).columnGap) || 0
  const trailingWidth = trailing ? trailing.getBoundingClientRect().width + gap : 0
  const widths = chipElementList.map((element) => element.getBoundingClientRect().width)
  const moreWidth = (hiddenCount: number): number => {
    if (!probe.value) return 0
    probe.value.textContent = `+${hiddenCount}`
    return probe.value.getBoundingClientRect().width
  }
  const count = visibleCount(widths, row.clientWidth - trailingWidth, gap, moreWidth)
  keptCount.value = count
  // Fold here as well: when the count is unchanged Vue does not patch `hidden` again, and the chips shown above for
  // measuring would stay in view.
  chipElementList.forEach((element, index) => {
    element.hidden = index >= count
  })
}

let observer: ResizeObserver | undefined
let frame = 0
function schedule(): void {
  if (typeof requestAnimationFrame === 'undefined') {
    measure()
    return
  }
  cancelAnimationFrame(frame)
  frame = requestAnimationFrame(measure)
}

onMounted(() => {
  measure()
  if (root.value && typeof ResizeObserver !== 'undefined') {
    observer = new ResizeObserver(schedule)
    observer.observe(root.value)
  }
})

onBeforeUnmount(() => {
  observer?.disconnect()
  if (typeof cancelAnimationFrame !== 'undefined') cancelAnimationFrame(frame)
})

// A changed list shows everything again, then folds from there.
watch(
  () => props.chips.map((chip) => `${chip.id}:${chip.label}`).join('|'),
  async () => {
    keptCount.value = props.chips.length
    await nextTick()
    measure()
  },
)
</script>

<template>
  <div ref="root" class="roo-chip-group" :data-size="size ?? 'default'">
    <RooChip
      v-for="(chip, index) in chips"
      :key="chip.id"
      :ref="(element) => holdChip(chip.id, element)"
      :label="chip.label"
      :tone="chip.tone ?? 'neutral'"
      :size="size ?? 'default'"
      :hidden="index >= kept"
    />
    <RooMenu v-if="folded.length > 0" align="end">
      <template #trigger>
        <RooChip class="roo-chip-group-more" interactive :size="size ?? 'default'" :aria-label="accessibleName" :label="`+${folded.length}`" />
      </template>
      <RooMenuItem v-for="chip in folded" :key="chip.id">{{ chip.label }}</RooMenuItem>
    </RooMenu>
    <span ref="probe" class="roo-chip-group-probe" aria-hidden="true" />
    <div v-if="$slots.trailing" class="roo-chip-group-trailing"><slot name="trailing" /></div>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-chip-group {
    position: relative;
    display: flex;
    flex-wrap: nowrap;
    align-items: center;
    gap: var(--roo-p-space-2);
    min-width: 0;
    overflow: hidden;
  }

  .roo-chip-group[data-size='small'] {
    gap: var(--roo-p-space-1);
  }

  .roo-chip-group > :deep([hidden]) {
    display: none;
  }

  /* Never seen: the +N is measured here for each count before it is shown. It takes the chip's own box. */
  .roo-chip-group-probe {
    position: absolute;
    visibility: hidden;
    pointer-events: none;
    box-sizing: border-box;
    padding: 0 var(--roo-p-space-3);
    font-size: var(--roo-p-size-12);
    font-weight: 500;
    white-space: nowrap;
  }

  .roo-chip-group-trailing {
    display: inline-flex;
    flex: none;
    margin-inline-start: auto;
  }
}
</style>
