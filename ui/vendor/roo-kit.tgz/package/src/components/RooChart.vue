<script lang="ts">
import type { RooIconName } from '../icons/paths'
import type { ChartValue } from './RooChartMath'

export interface RooChartSeries {
  id: string
  label: string
  /** One value per entry of `x`. A null is a gap in the line. */
  values: ChartValue[]
  /** A comparison series (such as "a week ago") is drawn dashed and muted, never in a series colour. */
  comparison?: boolean
  /** Stacked bars only: draw the series with a diagonal hatch, for values that were turned away, so the meaning never rests on colour. */
  hatched?: boolean
}

export type RooChartKind = 'line' | 'stacked-bar'

export interface RooChartThreshold {
  value: number
  /** Drawn at the right end of the line, such as `+50%`. */
  label: string
  tone?: 'neutral' | 'warn' | 'danger'
}

export interface RooChartMarker {
  /** An x value, such as the time of a deploy. */
  at: number
  label: string
  detail?: string
  icon?: RooIconName
}

export interface RooChartBand {
  from: number
  to: number
  label: string
  tone?: 'neutral' | 'danger'
}

export interface RooChartRange {
  label: string
  /** A series id, or values of your own, one per entry of `x`. */
  lower: string | ChartValue[]
  upper: string | ChartValue[]
}
</script>

<script setup lang="ts">
// A line chart in plain SVG. Series, an optional dashed comparison series, threshold lines, breakpoint markers, shaded
// time bands and shaded range bands between two lines. Hovering, or focusing and pressing the arrow keys, puts a crosshair
// on one point and shows every series' value there in one tooltip. The chart is a labelled image with a summary, and the
// same numbers sit in a visually hidden table, so nothing here is reachable only by sight, pointer or colour.
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { useId } from 'reka-ui'
import RooIcon from './RooIcon.vue'
import {
  areaBetweenPath,
  areaToBaselinePath,
  axisTickIndexes,
  chartSummary,
  crosshairIndexForKey,
  linePath,
  linearScale,
  barSlots,
  nearestIndex,
  niceScale,
  spreadLabels,
  stackSegments,
  stackTotals,
} from './RooChartMath'

const props = withDefaults(
  defineProps<{
    /** What the chart shows, such as `Error rate`. It is the accessible name and the start of the summary. */
    label: string
    /** The shared x values, in order (a time in milliseconds, or an index). */
    x: number[]
    series: RooChartSeries[]
    /** `line` (default) draws one line per series. `stacked-bar` draws one bar per x value, the series stacked bottom to top in series order. */
    kind?: RooChartKind
    thresholds?: RooChartThreshold[]
    markers?: RooChartMarker[]
    bands?: RooChartBand[]
    ranges?: RooChartRange[]
    formatX?: ((value: number) => string) | undefined
    formatValue?: ((value: number) => string) | undefined
    height?: number
    /** Fix the lower end of the y axis, such as 0. Otherwise the axis fits the data. */
    yMin?: number | undefined
    yMax?: number | undefined
    /** Smallest left axis width in px. Give charts stacked in one column the same value so their plots start on one edge. */
    axisGutter?: number | undefined
    /** Smallest right end-label width in px, for the same reason. */
    labelGutter?: number | undefined
    /** The index of the bucket that is still filling, such as today. It is outlined (bars) or guided (line), always labelled, and named in the summary. */
    currentIndex?: number | undefined
    /** What to call the current bucket in the summary, such as `Today, still counting`. */
    currentLabel?: string
    /** Line charts only: a light fill of each series colour under its line (comparison series stay unfilled). */
    fill?: boolean
  }>(),
  { kind: 'line', thresholds: () => [], markers: () => [], bands: () => [], ranges: () => [], formatX: undefined, formatValue: undefined, height: 240, yMin: undefined, yMax: undefined, axisGutter: undefined, labelGutter: undefined, currentIndex: undefined, currentLabel: 'Current', fill: false },
)

const id = useId(undefined, 'roo-chart')

// The categorical series colours. Written out in full so the token lint can read each name.
const SERIES_COLOURS = [
  'var(--roo-x-series-1)',
  'var(--roo-x-series-2)',
  'var(--roo-x-series-3)',
  'var(--roo-x-series-4)',
  'var(--roo-x-series-5)',
  'var(--roo-x-series-6)',
]
const COMPARISON_COLOUR = 'var(--roo-muted)'

const AXIS_CHARACTER_WIDTH = 7.2
const END_PADDING = 12
const LABEL_CHARACTER_WIDTH = 6.6
const LABEL_LINE_HEIGHT = 14
const BOTTOM_AXIS = 26

const frame = ref<HTMLElement | null>(null)
const measuredWidth = ref(0)
const activeIndex = ref<number | null>(null)
const announcement = ref('')
let resizeObserver: ResizeObserver | null = null

onMounted(() => {
  const element = frame.value
  if (!element) return
  measuredWidth.value = element.getBoundingClientRect().width
  if (typeof ResizeObserver === 'undefined') return
  resizeObserver = new ResizeObserver((entries) => {
    const entry = entries[0]
    if (entry) measuredWidth.value = entry.contentRect.width
  })
  resizeObserver.observe(element)
})
onBeforeUnmount(() => resizeObserver?.disconnect())

const width = computed(() => (measuredWidth.value > 0 ? measuredWidth.value : 640))

function format(value: number): string {
  if (props.formatValue) return props.formatValue(value)
  return String(Math.round(value * 100) / 100)
}

function formatTime(value: number): string {
  return props.formatX ? props.formatX(value) : String(value)
}

function resolveValues(source: string | ChartValue[]): ChartValue[] {
  if (typeof source !== 'string') return source
  return props.series.find((entry) => entry.id === source)?.values ?? []
}

const isBars = computed(() => props.kind === 'stacked-bar')
const drawsEndLabels = computed(() => !isBars.value)

const colours = computed(() => {
  let next = 0
  return props.series.map((entry) => {
    if (entry.comparison) return COMPARISON_COLOUR
    const colour = SERIES_COLOURS[next % SERIES_COLOURS.length] ?? COMPARISON_COLOUR
    next += 1
    return colour
  })
})

const rangeColours = computed(() => props.ranges.map((_, index) => SERIES_COLOURS[index % SERIES_COLOURS.length] ?? COMPARISON_COLOUR))

const yScale = computed(() => {
  const numbers: number[] = []
  if (isBars.value) {
    numbers.push(0, ...stackTotals(props.series.map((entry) => entry.values), props.x.length))
  } else {
    for (const entry of props.series) for (const value of entry.values) if (value !== null && value !== undefined) numbers.push(value)
  }
  for (const range of props.ranges) {
    for (const value of [...resolveValues(range.lower), ...resolveValues(range.upper)]) if (value !== null && value !== undefined) numbers.push(value)
  }
  for (const threshold of props.thresholds) numbers.push(threshold.value)
  if (props.yMin !== undefined) numbers.push(props.yMin)
  if (props.yMax !== undefined) numbers.push(props.yMax)
  const low = numbers.length > 0 ? Math.min(...numbers) : 0
  const high = numbers.length > 0 ? Math.max(...numbers) : 1
  const fitted = niceScale(low, high, Math.max(3, Math.round(props.height / 56)))
  return { ...fitted, min: props.yMin ?? fitted.min, max: props.yMax ?? fitted.max }
})

const yTicks = computed(() => yScale.value.ticks.filter((tick) => tick >= yScale.value.min && tick <= yScale.value.max))

const margins = computed(() => {
  const longestTick = Math.max(1, ...yTicks.value.map((tick) => format(tick).length))
  const longestEnd = Math.max(0, ...props.series.map((entry) => entry.label.length))
  const left = Math.max(props.axisGutter ?? 0, Math.ceil(longestTick * AXIS_CHARACTER_WIDTH) + 12)
  const endLabelWidth = drawsEndLabels.value ? Math.min(Math.ceil(longestEnd * LABEL_CHARACTER_WIDTH) + 16, width.value * 0.35) : END_PADDING
  const right = Math.max(props.labelGutter ?? 0, endLabelWidth)
  const top = props.markers.length > 0 ? 30 : 12
  return { left, right, top, bottom: props.height - BOTTOM_AXIS }
})

const plot = computed(() => ({
  left: margins.value.left,
  right: width.value - margins.value.right,
  top: margins.value.top,
  bottom: margins.value.bottom,
}))

const xDomain = computed(() => ({ start: props.x[0] ?? 0, end: props.x[props.x.length - 1] ?? 1 }))
const xScale = computed(() => linearScale(xDomain.value.start, xDomain.value.end, plot.value.left, plot.value.right))
const yPosition = computed(() => linearScale(yScale.value.min, yScale.value.max, plot.value.bottom, plot.value.top))
const barLayout = computed(() => barSlots(props.x.length, plot.value.left, plot.value.right))
// A bar chart puts each bucket in an equal slot, so bars never run over the axis edge; a line chart spaces points by x value.
const xPositions = computed(() => (isBars.value ? barLayout.value.centres : props.x.map((value) => xScale.value(value))))

function clampToPlot(value: number): number {
  return Math.min(Math.max(xScale.value(value), plot.value.left), plot.value.right)
}

function scaleValues(values: ChartValue[]): ChartValue[] {
  return values.map((value) => (value === null || value === undefined ? null : yPosition.value(value)))
}

const lines = computed(() =>
  (isBars.value ? [] : props.series).map((entry, index) => {
    const ys = scaleValues(entry.values)
    let lastIndex = -1
    ys.forEach((value, position) => {
      if (value !== null) lastIndex = position
    })
    return {
      id: entry.id,
      label: entry.label,
      comparison: entry.comparison === true,
      colour: colours.value[index] ?? COMPARISON_COLOUR,
      path: linePath(xPositions.value, ys),
      areaPath: props.fill && entry.comparison !== true ? areaToBaselinePath(xPositions.value, ys, plot.value.bottom) : '',
      endX: lastIndex >= 0 ? (xPositions.value[lastIndex] ?? 0) : 0,
      endY: lastIndex >= 0 ? (ys[lastIndex] ?? 0) : null,
    }
  }),
)

const bars = computed(() => {
  if (!isBars.value) return []
  const segments = stackSegments(props.series.map((entry) => entry.values), props.x.length)
  const halfWidth = barLayout.value.barWidth / 2
  return props.series.flatMap((entry, seriesIndex) =>
    (segments[seriesIndex] ?? []).flatMap((segment, bucket) => {
      if (!segment) return []
      const top = yPosition.value(segment.high)
      const bottom = yPosition.value(segment.low)
      return [
        {
          key: `${entry.id}-${bucket}`,
          seriesId: entry.id,
          bucket,
          hatched: entry.hatched === true,
          colour: colours.value[seriesIndex] ?? COMPARISON_COLOUR,
          patternId: `${id}-hatch-${seriesIndex}`,
          x: (xPositions.value[bucket] ?? 0) - halfWidth,
          y: top,
          width: barLayout.value.barWidth,
          height: Math.max(bottom - top, 0),
        },
      ]
    }),
  )
})

const hatchPatterns = computed(() =>
  isBars.value
    ? props.series.flatMap((entry, index) => (entry.hatched ? [{ id: `${id}-hatch-${index}`, colour: colours.value[index] ?? COMPARISON_COLOUR }] : []))
    : [],
)

const endLabels = computed(() => {
  if (!drawsEndLabels.value) return []
  const present = lines.value.filter((line) => line.endY !== null)
  const spread = spreadLabels(
    present.map((line) => line.endY ?? 0),
    LABEL_LINE_HEIGHT,
    plot.value.top + 4,
    plot.value.bottom - 2,
  )
  return present.map((line, index) => ({ ...line, labelY: spread[index] ?? 0 }))
})

const rangeShapes = computed(() =>
  props.ranges.map((range, index) => ({
    label: range.label,
    colour: rangeColours.value[index] ?? COMPARISON_COLOUR,
    path: areaBetweenPath(xPositions.value, scaleValues(resolveValues(range.upper)), scaleValues(resolveValues(range.lower))),
  })),
)

const bandShapes = computed(() =>
  props.bands.map((band) => {
    const left = clampToPlot(Math.min(band.from, band.to))
    const right = clampToPlot(Math.max(band.from, band.to))
    return { ...band, tone: band.tone ?? 'neutral', left, width: Math.max(right - left, 1) }
  }),
)

const thresholdLines = computed(() =>
  props.thresholds.map((threshold) => ({ ...threshold, tone: threshold.tone ?? 'neutral', y: yPosition.value(threshold.value) })),
)

const markerShapes = computed(() =>
  props.markers.map((marker, index) => ({
    ...marker,
    key: `${id}-marker-${index}`,
    icon: marker.icon ?? ('flag' as RooIconName),
    left: clampToPlot(marker.at),
    text: `${marker.label}, ${formatTime(marker.at)}${marker.detail ? `. ${marker.detail}` : ''}`,
  })),
)

const currentBucket = computed(() => {
  const index = props.currentIndex
  return index !== undefined && Number.isInteger(index) && index >= 0 && index < props.x.length ? index : null
})

const currentOutline = computed(() => {
  const bucket = currentBucket.value
  if (bucket === null || !isBars.value) return null
  const totals = stackTotals(props.series.map((entry) => entry.values), props.x.length)
  const top = yPosition.value(Math.max(totals[bucket] ?? 0, 0))
  const bottom = yPosition.value(Math.max(yScale.value.min, 0))
  const half = barLayout.value.barWidth / 2 + 2
  return { x: (xPositions.value[bucket] ?? 0) - half, y: top - 2, width: half * 2, height: Math.max(bottom - top, 0) + 4 }
})

const currentGuide = computed(() => (currentBucket.value !== null && !isBars.value ? (xPositions.value[currentBucket.value] ?? 0) : null))

const xTicks = computed(() => {
  const widest = Math.max(1, ...props.x.map((value) => formatTime(value).length))
  const room = Math.floor((plot.value.right - plot.value.left) / (widest * AXIS_CHARACTER_WIDTH + 24))
  const ticks: Array<{ index: number; label: string; at: number; current: boolean }> = []
  for (const index of axisTickIndexes(props.x.length, room, currentBucket.value ?? undefined)) {
    ticks.push({ index, label: formatTime(props.x[index] ?? 0), at: xPositions.value[index] ?? 0, current: index === currentBucket.value })
  }
  return ticks
})

const summary = computed(() =>
  chartSummary(
    props.label,
    formatTime(props.x[0] ?? 0),
    formatTime(props.x[props.x.length - 1] ?? 0),
    props.x.length,
    props.series.map((entry) => ({ label: entry.label, values: entry.values })),
    format,
  ) + (currentBucket.value === null ? '' : ` ${props.currentLabel}: ${formatTime(props.x[currentBucket.value] ?? 0)}.`),
)

interface TooltipRow {
  key: string
  label: string
  value: string
  colour: string
  kind: 'line' | 'dashed' | 'band' | 'bar' | 'hatched'
}

const tooltip = computed(() => {
  const index = activeIndex.value
  if (index === null || index < 0 || index >= props.x.length) return null
  const rows: TooltipRow[] = props.series.map((entry, position) => {
    const value = entry.values[index]
    return {
      key: entry.id,
      label: entry.label,
      value: value === null || value === undefined ? 'No data' : format(value),
      colour: colours.value[position] ?? COMPARISON_COLOUR,
      kind: isBars.value ? (entry.hatched ? 'hatched' : 'bar') : entry.comparison ? 'dashed' : 'line',
    }
  })
  props.ranges.forEach((range, position) => {
    const lower = resolveValues(range.lower)[index]
    const upper = resolveValues(range.upper)[index]
    rows.push({
      key: `range-${position}`,
      label: range.label,
      value: lower === null || lower === undefined || upper === null || upper === undefined ? 'No data' : `${format(lower)} to ${format(upper)}`,
      colour: rangeColours.value[position] ?? COMPARISON_COLOUR,
      kind: 'band',
    })
  })
  const xValue = props.x[index] ?? 0
  const events = props.markers.filter((marker) => marker.at === xValue).map((marker) => marker.label)
  const left = xPositions.value[index] ?? 0
  const flip = left > width.value / 2
  return {
    heading: formatTime(xValue),
    rows,
    events,
    left,
    flip,
    style: flip ? { right: `${width.value - left + 12}px` } : { left: `${left + 12}px` },
  }
})

const crosshairDots = computed(() => {
  const index = activeIndex.value
  if (index === null || isBars.value) return []
  return props.series.flatMap((entry, position) => {
    const value = entry.values[index]
    if (value === null || value === undefined) return []
    return [{ key: entry.id, x: xPositions.value[index] ?? 0, y: yPosition.value(value), colour: colours.value[position] ?? COMPARISON_COLOUR }]
  })
})

function announce(): void {
  const current = tooltip.value
  if (!current) {
    announcement.value = ''
    return
  }
  const rows = current.rows.map((row) => `${row.label} ${row.value}`).join(', ')
  announcement.value = `${current.heading}. ${rows}${current.events.length > 0 ? `. ${current.events.join(', ')}` : ''}`
}

function onKeydown(event: KeyboardEvent): void {
  if (event.key === 'Escape') {
    if (activeIndex.value !== null) {
      activeIndex.value = null
      announcement.value = ''
    }
    return
  }
  const next = crosshairIndexForKey(event.key, activeIndex.value, props.x.length)
  if (next === null) return
  event.preventDefault()
  activeIndex.value = next
  announce()
}

function onPointerMove(event: PointerEvent): void {
  const element = frame.value
  if (!element || props.x.length === 0) return
  const box = element.getBoundingClientRect()
  const pointer = event.clientX - box.left
  // Left of the first point and right of the last one still snap to the nearest end, but not from outside the chart.
  if (pointer < plot.value.left - 8 || pointer > width.value) {
    activeIndex.value = null
    return
  }
  activeIndex.value = nearestIndex(xPositions.value, pointer)
}

function onPointerLeave(): void {
  if (document.activeElement !== frame.value) activeIndex.value = null
}

function onFocus(): void {
  if (activeIndex.value === null && props.x.length > 0) {
    activeIndex.value = props.x.length - 1
    announce()
  }
}

function onBlur(): void {
  activeIndex.value = null
  announcement.value = ''
}

const hintId = `${id}-hint`
</script>

<template>
  <figure class="roo-chart">
    <ul class="roo-chart-legend" aria-label="Legend">
      <li v-for="(entry, index) in series" :key="entry.id" class="roo-chart-legend-item">
        <span class="roo-chart-swatch" :data-kind="isBars ? (entry.hatched ? 'hatched' : 'bar') : entry.comparison ? 'dashed' : 'line'" :style="{ '--roo-chart-colour': colours[index] }" aria-hidden="true" />
        {{ entry.label }}
      </li>
      <li v-for="(range, index) in ranges" :key="`range-${index}`" class="roo-chart-legend-item">
        <span class="roo-chart-swatch" data-kind="band" :style="{ '--roo-chart-colour': rangeColours[index] }" aria-hidden="true" />
        {{ range.label }}
      </li>
    </ul>

    <div class="roo-chart-plot" :style="{ height: `${height}px` }">
      <div
        ref="frame"
        class="roo-chart-frame"
        role="img"
        tabindex="0"
        :aria-label="summary"
        :aria-describedby="hintId"
        @keydown="onKeydown"
        @pointermove="onPointerMove"
        @pointerleave="onPointerLeave"
        @focus="onFocus"
        @blur="onBlur"
      >
        <svg class="roo-chart-svg" :width="width" :height="height" :viewBox="`0 0 ${width} ${height}`" aria-hidden="true" focusable="false">
          <defs v-if="hatchPatterns.length > 0">
            <pattern v-for="pattern in hatchPatterns" :id="pattern.id" :key="pattern.id" class="roo-chart-hatch" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)" :style="{ '--roo-chart-colour': pattern.colour }">
              <rect class="roo-chart-hatch-ground" width="6" height="6" />
              <line class="roo-chart-hatch-stroke" x1="0" y1="0" x2="0" y2="6" />
            </pattern>
          </defs>
          <g class="roo-chart-grid">
            <g v-for="tick in yTicks" :key="`y-${tick}`">
              <line class="roo-chart-gridline" :x1="plot.left" :x2="plot.right" :y1="yPosition(tick)" :y2="yPosition(tick)" />
              <text class="roo-chart-axis-label" :x="plot.left - 8" :y="yPosition(tick)" text-anchor="end" dominant-baseline="middle">{{ format(tick) }}</text>
            </g>
            <line class="roo-chart-baseline" :x1="plot.left" :x2="plot.right" :y1="plot.bottom" :y2="plot.bottom" />
            <text v-for="tick in xTicks" :key="`x-${tick.index}`" class="roo-chart-axis-label" :data-current="tick.current ? 'true' : undefined" :x="tick.at" :y="plot.bottom + 17" text-anchor="middle">{{ tick.label }}</text>
          </g>

          <g class="roo-chart-data">
            <g v-for="band in bandShapes" :key="`band-${band.label}-${band.from}`" class="roo-chart-band" :data-tone="band.tone">
              <rect class="roo-chart-band-fill" :x="band.left" :y="plot.top" :width="band.width" :height="plot.bottom - plot.top" />
              <line class="roo-chart-band-edge" :x1="band.left" :x2="band.left" :y1="plot.top" :y2="plot.bottom" />
              <line class="roo-chart-band-edge" :x1="band.left + band.width" :x2="band.left + band.width" :y1="plot.top" :y2="plot.bottom" />
            </g>

            <path v-for="shape in rangeShapes" :key="`range-${shape.label}`" class="roo-chart-range" :d="shape.path" :style="{ '--roo-chart-colour': shape.colour }" />

            <g v-for="threshold in thresholdLines" :key="`threshold-${threshold.label}`" class="roo-chart-threshold" :data-tone="threshold.tone">
              <line :x1="plot.left" :x2="plot.right" :y1="threshold.y" :y2="threshold.y" />
              <text :x="plot.right - 4" :y="threshold.y - 5" text-anchor="end">{{ threshold.label }}</text>
            </g>

            <g v-for="marker in markerShapes" :key="marker.key" class="roo-chart-marker-line">
              <line :x1="marker.left" :x2="marker.left" :y1="plot.top - 6" :y2="plot.bottom" />
            </g>

            <line v-if="currentGuide !== null" class="roo-chart-current-guide" :x1="currentGuide" :x2="currentGuide" :y1="plot.top" :y2="plot.bottom" />

            <rect
              v-for="bar in bars"
              :key="bar.key"
              class="roo-chart-bar"
              :data-series="bar.seriesId"
              :data-hatched="bar.hatched ? 'true' : 'false'"
              :x="bar.x"
              :y="bar.y"
              :width="bar.width"
              :height="bar.height"
              :style="bar.hatched ? { '--roo-chart-colour': bar.colour, fill: `url(#${bar.patternId})` } : { '--roo-chart-colour': bar.colour }"
            />

            <rect v-if="currentOutline" class="roo-chart-current-outline" :x="currentOutline.x" :y="currentOutline.y" :width="currentOutline.width" :height="currentOutline.height" rx="2" />

            <path v-for="line in lines.filter((entry) => entry.areaPath !== '')" :key="`area-${line.id}`" class="roo-chart-area" :d="line.areaPath" :style="{ '--roo-chart-colour': line.colour }" />

            <path
              v-for="line in lines"
              :key="line.id"
              class="roo-chart-line"
              :data-comparison="line.comparison ? 'true' : 'false'"
              :d="line.path"
              :style="{ '--roo-chart-colour': line.colour }"
            />
            <circle v-for="line in endLabels" :key="`end-${line.id}`" class="roo-chart-end-dot" :cx="line.endX" :cy="line.endY ?? 0" r="3" :style="{ '--roo-chart-colour': line.colour }" />
            <!-- Band labels draw after the lines so a line that runs through one passes under its halo, never across the words. -->
            <text v-for="band in bandShapes" :key="`band-label-${band.label}-${band.from}`" class="roo-chart-band-label" :data-tone="band.tone" :x="band.left + 6" :y="plot.top + 14">{{ band.label }}</text>
          </g>

          <text
            v-for="line in endLabels"
            :key="`label-${line.id}`"
            class="roo-chart-end-label"
            :x="plot.right + 8"
            :y="line.labelY"
            dominant-baseline="middle"
            :style="{ '--roo-chart-colour': line.colour }"
          >{{ line.label }}</text>

          <g v-if="tooltip" class="roo-chart-crosshair">
            <rect v-if="isBars" class="roo-chart-column" :x="tooltip.left - barLayout.barWidth / 2 - 4" :y="plot.top" :width="barLayout.barWidth + 8" :height="plot.bottom - plot.top" />
            <line v-else :x1="tooltip.left" :x2="tooltip.left" :y1="plot.top" :y2="plot.bottom" />
            <circle v-for="dot in crosshairDots" :key="dot.key" :cx="dot.x" :cy="dot.y" r="4" :style="{ '--roo-chart-colour': dot.colour }" />
          </g>
        </svg>

        <div v-if="tooltip" class="roo-chart-tooltip" :style="tooltip.style" aria-hidden="true">
          <div class="roo-chart-tooltip-heading">{{ tooltip.heading }}</div>
          <div v-for="row in tooltip.rows" :key="row.key" class="roo-chart-tooltip-row">
            <span class="roo-chart-swatch" :data-kind="row.kind" :style="{ '--roo-chart-colour': row.colour }" />
            <span class="roo-chart-tooltip-label">{{ row.label }}</span>
            <span class="roo-chart-tooltip-value">{{ row.value }}</span>
          </div>
          <div v-for="event in tooltip.events" :key="event" class="roo-chart-tooltip-event">{{ event }}</div>
        </div>
      </div>

      <div v-if="markerShapes.length > 0" class="roo-chart-markers">
        <span v-for="marker in markerShapes" :key="marker.key" class="roo-chart-marker" :style="{ left: `${marker.left}px`, top: '2px' }">
          <button type="button" class="roo-chart-marker-button" :aria-label="marker.text" :aria-describedby="`${marker.key}-tip`">
            <RooIcon :name="marker.icon" :size="16" />
          </button>
          <span :id="`${marker.key}-tip`" role="tooltip" class="roo-chart-marker-tip">
            <span class="roo-chart-marker-tip-title">{{ marker.label }}</span>
            <span class="roo-chart-marker-tip-time">{{ formatTime(marker.at) }}</span>
            <span v-if="marker.detail" class="roo-chart-marker-tip-detail">{{ marker.detail }}</span>
          </span>
        </span>
      </div>
    </div>

    <p :id="hintId" class="roo-visually-hidden">Press the arrow keys to move between points, Home and End to jump to the ends, Escape to hide the readout.</p>
    <p class="roo-visually-hidden" aria-live="polite">{{ announcement }}</p>

    <div class="roo-visually-hidden">
      <p v-for="threshold in thresholds" :key="`threshold-text-${threshold.label}`">Threshold {{ threshold.label }} at {{ format(threshold.value) }}.</p>
      <p v-for="band in bands" :key="`band-text-${band.label}-${band.from}`">{{ band.label }} from {{ formatTime(band.from) }} to {{ formatTime(band.to) }}.</p>
      <p v-for="marker in markerShapes" :key="`marker-text-${marker.key}`">{{ marker.text }}.</p>
      <table>
        <caption>{{ label }}</caption>
        <thead>
          <tr>
            <th scope="col">Time</th>
            <th v-for="entry in series" :key="entry.id" scope="col">{{ entry.label }}</th>
            <th v-for="(range, index) in ranges" :key="`range-head-${index}`" scope="col">{{ range.label }}</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(xValue, row) in x" :key="row">
            <th scope="row">{{ formatTime(xValue) }}</th>
            <td v-for="entry in series" :key="entry.id">{{ entry.values[row] === null || entry.values[row] === undefined ? 'No data' : format(entry.values[row] as number) }}</td>
            <td v-for="(range, index) in ranges" :key="`range-cell-${index}`">
              {{
                resolveValues(range.lower)[row] === null || resolveValues(range.lower)[row] === undefined || resolveValues(range.upper)[row] === null || resolveValues(range.upper)[row] === undefined
                  ? 'No data'
                  : `${format(resolveValues(range.lower)[row] as number)} to ${format(resolveValues(range.upper)[row] as number)}`
              }}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </figure>
</template>

<style scoped>
@layer roo-components {
  .roo-chart {
    position: relative;
    margin: 0;
    color: var(--roo-text);
    font-family: var(--roo-font-ui);
  }

  .roo-chart-legend {
    display: flex;
    flex-wrap: wrap;
    gap: 4px 16px;
    margin: 0 0 8px;
    padding: 0;
    list-style: none;
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-chart-legend-item {
    display: inline-flex;
    align-items: center;
    gap: 8px;
  }

  /* The sample of a line in the legend and the tooltip: solid for a series, dashed for a comparison, a block for a band. */
  .roo-chart-swatch {
    display: inline-block;
    width: 16px;
    height: 0;
    flex: none;
    border-top: 2px solid var(--roo-chart-colour);
  }

  .roo-chart-swatch[data-kind='dashed'] {
    border-top-style: dashed;
  }

  .roo-chart-swatch[data-kind='bar'],
  .roo-chart-swatch[data-kind='hatched'] {
    width: 12px;
    height: 12px;
    border-top: 0;
    border-radius: var(--roo-p-radius-mark);
    background: var(--roo-chart-colour);
  }

  .roo-chart-swatch[data-kind='hatched'] {
    border: 1px solid var(--roo-chart-colour);
    background: repeating-linear-gradient(135deg, var(--roo-chart-colour) 0 2px, color-mix(in srgb, var(--roo-chart-colour) 26%, var(--roo-surface)) 2px 4px);
  }

  .roo-chart-swatch[data-kind='band'] {
    height: 8px;
    border-top: 0;
    border-radius: var(--roo-p-radius-mark);
    background: color-mix(in srgb, var(--roo-chart-colour) 22%, transparent);
    box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--roo-chart-colour) 55%, transparent);
  }

  .roo-chart-plot {
    position: relative;
  }

  .roo-chart-frame {
    position: relative;
    height: 100%;
    border-radius: var(--roo-p-radius-small);
    cursor: default;
    touch-action: pan-y;
  }

  .roo-chart-frame:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  .roo-chart-svg {
    display: block;
    overflow: visible;
  }

  .roo-chart-gridline {
    stroke: var(--roo-line);
    stroke-width: 1;
  }

  .roo-chart-baseline {
    stroke: var(--roo-border);
    stroke-width: 1;
  }

  .roo-chart-axis-label {
    fill: var(--roo-muted);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
  }

  .roo-chart-line {
    fill: none;
    stroke: var(--roo-chart-colour);
    stroke-width: 2;
    stroke-linejoin: round;
    stroke-linecap: round;
  }

  .roo-chart-line[data-comparison='true'] {
    stroke-width: 1.5;
    stroke-dasharray: 5 4;
  }

  .roo-chart-axis-label[data-current='true'] {
    fill: var(--roo-text);
    font-weight: 500;
  }

  .roo-chart-current-outline {
    fill: none;
    stroke: var(--roo-text);
    stroke-width: 1.5;
    stroke-dasharray: 4 3;
    pointer-events: none;
  }

  .roo-chart-current-guide {
    stroke: var(--roo-muted);
    stroke-width: 1;
    stroke-dasharray: 3 4;
    pointer-events: none;
  }

  .roo-chart-bar {
    fill: var(--roo-chart-colour);
  }

  /* A hatched bar takes its fill from an inline style (the pattern), because a class rule would beat an SVG fill attribute. The pattern is the series colour as a faint ground with a diagonal stroke, and the bar keeps an outline in the colour. */
  .roo-chart-bar[data-hatched='true'] {
    stroke: var(--roo-chart-colour);
    stroke-width: 1;
  }

  .roo-chart-hatch-ground {
    fill: color-mix(in srgb, var(--roo-chart-colour) 26%, var(--roo-surface));
  }

  .roo-chart-hatch-stroke {
    stroke: var(--roo-chart-colour);
    stroke-width: 2;
  }

  .roo-chart-crosshair .roo-chart-column {
    fill: color-mix(in srgb, var(--roo-muted) 14%, transparent);
    stroke: none;
  }

  .roo-chart-end-dot {
    fill: var(--roo-chart-colour);
    stroke: var(--roo-bg);
    stroke-width: 1.5;
  }

  .roo-chart-end-label {
    fill: var(--roo-chart-colour);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    font-weight: 500;
  }

  .roo-chart-area {
    fill: color-mix(in srgb, var(--roo-chart-colour) 14%, transparent);
    stroke: none;
  }

  .roo-chart-range {
    fill: color-mix(in srgb, var(--roo-chart-colour) 16%, transparent);
    stroke: none;
  }

  .roo-chart-band-fill {
    fill: color-mix(in srgb, var(--roo-muted) 14%, transparent);
  }

  .roo-chart-band[data-tone='danger'] .roo-chart-band-fill {
    fill: color-mix(in srgb, var(--roo-danger-text) 11%, transparent);
  }

  .roo-chart-band-edge {
    stroke: var(--roo-muted);
    stroke-width: 1;
    stroke-dasharray: 2 3;
  }

  .roo-chart-band[data-tone='danger'] .roo-chart-band-edge {
    stroke: var(--roo-danger-text);
  }

  .roo-chart-band-label {
    fill: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    paint-order: stroke;
    stroke: var(--roo-bg);
    stroke-width: 3px;
    stroke-linejoin: round;
  }

  .roo-chart-band-label[data-tone='danger'] {
    fill: var(--roo-danger-text);
  }

  .roo-chart-threshold line {
    stroke: var(--roo-muted);
    stroke-width: 1;
    stroke-dasharray: 1 3;
    stroke-linecap: round;
  }

  .roo-chart-threshold text {
    fill: var(--roo-muted);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
    paint-order: stroke;
    stroke: var(--roo-bg);
    stroke-width: 3px;
    stroke-linejoin: round;
  }

  .roo-chart-threshold[data-tone='warn'] line {
    stroke: var(--roo-warn);
  }

  .roo-chart-threshold[data-tone='warn'] text {
    fill: var(--roo-warn);
  }

  .roo-chart-threshold[data-tone='danger'] line {
    stroke: var(--roo-danger-text);
  }

  .roo-chart-threshold[data-tone='danger'] text {
    fill: var(--roo-danger-text);
  }

  .roo-chart-marker-line line {
    stroke: var(--roo-text);
    stroke-width: 1;
    opacity: 0.55;
  }

  .roo-chart-crosshair line {
    stroke: var(--roo-muted);
    stroke-width: 1;
  }

  .roo-chart-crosshair circle {
    fill: var(--roo-surface);
    stroke: var(--roo-chart-colour);
    stroke-width: 2;
  }

  /* The lines are revealed from the left, once. Reduced motion draws them already in place. */
  .roo-chart-data {
    animation: roo-chart-reveal calc(var(--roo-draw) * 2) var(--roo-ease) both;
  }

  @keyframes roo-chart-reveal {
    from {
      clip-path: inset(0 100% 0 0);
    }

    to {
      clip-path: inset(0 -8px 0 0);
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .roo-chart-data {
      animation: none;
    }
  }

  .roo-force-reduced .roo-chart-data,
  [data-motion='still'] .roo-chart-data {
    animation: none;
  }

  .roo-chart-tooltip {
    position: absolute;
    top: 4px;
    z-index: 2;
    min-width: 160px;
    max-width: 280px;
    box-sizing: border-box;
    padding: 8px 12px;
    border-radius: var(--roo-p-radius-medium);
    background: var(--roo-surface);
    box-shadow: var(--roo-shadow-popover);
    font-size: var(--roo-p-size-12);
    pointer-events: none;
  }

  .roo-chart-tooltip-heading {
    margin-bottom: 4px;
    color: var(--roo-muted);
    font-family: var(--roo-font-mono);
  }

  .roo-chart-tooltip-row {
    display: flex;
    align-items: center;
    gap: 8px;
    padding-block: 2px;
  }

  .roo-chart-tooltip-label {
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-chart-tooltip-value {
    font-family: var(--roo-font-mono);
    font-variant-numeric: tabular-nums;
  }

  .roo-chart-tooltip-event {
    margin-top: 4px;
    color: var(--roo-muted);
  }

  .roo-chart-markers {
    position: absolute;
    inset: 0;
    pointer-events: none;
  }

  .roo-chart-marker {
    position: absolute;
    transform: translateX(-50%);
  }

  .roo-chart-marker-button {
    display: inline-flex;
    width: 22px;
    height: 22px;
    align-items: center;
    justify-content: center;
    border: 1px solid var(--roo-control-edge);
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-surface);
    padding: 0;
    color: var(--roo-text);
    cursor: default;
    pointer-events: auto;
  }

  .roo-chart-marker-button:hover {
    background: var(--roo-raised);
  }

  .roo-chart-marker-button:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  .roo-chart-marker-tip {
    position: absolute;
    top: 28px;
    left: 50%;
    z-index: 3;
    display: none;
    min-width: 140px;
    max-width: 260px;
    box-sizing: border-box;
    flex-direction: column;
    gap: 2px;
    transform: translateX(-50%);
    padding: 8px 12px;
    border-radius: var(--roo-p-radius-medium);
    background: var(--roo-surface);
    box-shadow: var(--roo-shadow-popover);
    font-size: var(--roo-p-size-12);
    pointer-events: none;
  }

  .roo-chart-marker-button:hover + .roo-chart-marker-tip,
  .roo-chart-marker-button:focus-visible + .roo-chart-marker-tip {
    display: flex;
  }

  .roo-chart-marker-tip-title {
    font-weight: 600;
  }

  .roo-chart-marker-tip-time {
    color: var(--roo-muted);
    font-family: var(--roo-font-mono);
  }

  .roo-chart-marker-tip-detail {
    color: var(--roo-muted);
  }
}
</style>
