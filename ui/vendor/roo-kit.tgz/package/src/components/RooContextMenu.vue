<script setup lang="ts">
// A right-click menu with the family order built in. The named slots are drawn in one fixed order, whatever order they are
// written in: `actions`, `open-in`, `copy`, `destructive` (last, as danger), with a separator between groups that exist.
// It opens at the pointer on a right-click, and from the keyboard (Menu key, Shift F10, Ctrl Enter) at the focused row with
// the first item highlighted. Items take `kbd` or a `command`, so they show the same keys as the palette.
import { DropdownMenuGroup, DropdownMenuSeparator } from 'reka-ui'
import { defineComponent, nextTick, provide, ref, useId, useSlots } from 'vue'
import { ROO_MENU_DESTRUCTIVE_GROUP } from '../composables/menuGroup'
import RooMenu from './RooMenu.vue'

const ORDER = ['actions', 'open-in', 'copy', 'destructive'] as const

const open = defineModel<boolean>('open', { default: false })
const slots = useSlots()
const instanceId = useId()

const x = ref(0)
const y = ref(0)

// The destructive group tells its items to take the danger tone, so an item cannot be placed there and look ordinary.
const DestructiveScope = defineComponent({
  setup(_props, { slots: scopeSlots }) {
    provide(ROO_MENU_DESTRUCTIVE_GROUP, true)
    return () => scopeSlots.default?.()
  },
})

const present = () => ORDER.filter((name) => Boolean(slots[name]))

function openAt(clientX: number, clientY: number, highlightFirst: boolean): void {
  x.value = clientX
  y.value = clientY
  open.value = true
  if (!highlightFirst) return
  void nextTick().then(() => nextTick()).then(() => {
    document.querySelector<HTMLElement>(`[data-roo-context-menu="${instanceId}"] [role=menuitem]:not([data-disabled])`)?.focus()
  })
}

function onContextmenu(event: MouseEvent): void {
  event.preventDefault()
  openAt(event.clientX, event.clientY, false)
}

function onKeydown(event: KeyboardEvent): void {
  const menuKey = event.key === 'ContextMenu' || (event.key === 'F10' && event.shiftKey) || (event.key === 'Enter' && event.ctrlKey && !event.metaKey)
  if (!menuKey || event.isComposing) return
  event.preventDefault()
  const target = event.target instanceof Element ? event.target : null
  const rect = target?.getBoundingClientRect()
  openAt(rect?.left ?? 0, rect?.bottom ?? 0, true)
}
</script>

<template>
  <div class="roo-context-menu" @contextmenu="onContextmenu" @keydown="onKeydown">
    <slot />
    <RooMenu v-model:open="open">
      <template #trigger>
        <span class="roo-context-menu-anchor" aria-hidden="true" :style="{ left: `${x}px`, top: `${y}px` }" />
      </template>
      <template v-for="(name, index) in present()" :key="name">
        <DropdownMenuSeparator v-if="index > 0" class="roo-context-menu-separator" />
        <DropdownMenuGroup :data-roo-context-menu="instanceId" :data-roo-context-group="name">
          <DestructiveScope v-if="name === 'destructive'"><slot :name="name" /></DestructiveScope>
          <slot v-else :name="name" />
        </DropdownMenuGroup>
      </template>
    </RooMenu>
  </div>
</template>

<!-- The separator lives inside reka's portalled panel, so these rules are not scoped. -->
<style>
@layer roo-components {
  .roo-context-menu {
    display: contents;
  }

  .roo-context-menu-anchor {
    position: fixed;
    width: 0;
    height: 0;
    pointer-events: none;
  }

  .roo-context-menu-separator {
    height: 1px;
    margin: var(--roo-p-space-1) 0;
    background: var(--roo-line);
  }
}
</style>
