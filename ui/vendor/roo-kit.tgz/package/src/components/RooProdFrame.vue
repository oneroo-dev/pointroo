<script lang="ts">
/**
 * Kept so older callers still build. Raja, 2026-11-12: no prod window frame, no corner tag, so there is nothing
 * drawn and nothing to forget.
 * @deprecated The production frame is gone. Show production with the Pill, the band and the Ledge.
 */
export function forgetDrawnConnections(): void {}
</script>

<script setup lang="ts">
/**
 * Raja, 2026-11-12: no prod window frame, no corner tag. This component now only renders its slot in a plain
 * wrapper, so apps that still use it keep their layout and lose the red border and the hidden "Production" word
 * (which showed as a tag over the traffic lights when the kit's base styles were not loaded).
 * @deprecated Drop it and render the content directly. Production is shown by the Pill, the band and the Ledge.
 */
withDefaults(
  defineProps<{
    /** @deprecated Ignored. */
    drawKey?: string
    /** @deprecated Ignored. */
    unclassified?: boolean
  }>(),
  { drawKey: '', unclassified: false },
)
</script>

<template>
  <div class="roo-prod-frame">
    <slot />
  </div>
</template>

<style scoped>
@layer roo-components {
  /* Only the containing block the old frame gave, so children placed absolutely do not move. */
  .roo-prod-frame {
    position: relative;
  }
}
</style>
