<script setup lang="ts">
// A lit brand surface for a sign-in or landing panel. It sits on the graphite tile colour inside its own dark scope, so
// it looks the same in a light or a dark app. Layers, back to front: two radial lights in the brand's glow pair, a hairline
// grid that fades toward the edges, a fine grain and a one-pixel inner edge. `light="drift"` moves the lights on a slow
// ellipse (opacity and transform only); it stays still under prefers-reduced-motion. Slots: top, default, bottom.
import { computed } from 'vue'
import { REDUCED_MOTION_QUERY, useMediaMatch } from '../composables/useMediaMatch'

const props = withDefaults(
  defineProps<{
    /** `still` holds the lights in place; `drift` moves them on a 28 s ellipse. */
    light?: 'still' | 'drift'
    /** `stage` is the full graphite stage. `wash` is only the two lights, transparent, sitting on the app background. */
    variant?: 'stage' | 'wash'
    /** The edge a wash is lit from, in logical directions so right-to-left flips start and end. */
    edge?: 'start' | 'end' | 'top' | 'bottom'
  }>(),
  { light: 'still', variant: 'stage', edge: 'start' },
)

const reducedMotion = useMediaMatch(REDUCED_MOTION_QUERY)
const isWash = computed(() => props.variant === 'wash')
const drifting = computed(() => props.light === 'drift' && !reducedMotion.value)
</script>

<template>
  <div
    class="roo-brand-stage"
    :class="{ dark: !isWash, 'roo-brand-stage-wash': isWash, 'roo-brand-stage-drift': drifting }"
    :data-appearance="isWash ? undefined : 'dark'"
    :data-variant="variant"
    :data-edge="isWash ? edge : undefined"
    :data-light="drifting ? 'drift' : 'still'"
  >
    <div class="roo-brand-stage-lights" aria-hidden="true"></div>
    <div v-if="!isWash" class="roo-brand-stage-grid" aria-hidden="true"></div>
    <div v-if="!isWash" class="roo-brand-stage-grain" aria-hidden="true"></div>
    <div v-if="$slots.top" class="roo-brand-stage-top"><slot name="top" /></div>
    <div class="roo-brand-stage-body"><slot /></div>
    <div v-if="$slots.bottom" class="roo-brand-stage-bottom"><slot name="bottom" /></div>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-brand-stage {
    /* The grid pitch is the 32 px space step. The drift period, the light and grid strengths, the grain opacity and the grain
       tile are this piece's own literals: they are not shared tokens, and the grain is an inline SVG data URI. */
    --roo-brand-stage-pitch: var(--roo-p-space-8);
    --roo-brand-stage-drift-period: 28s;
    --roo-brand-stage-grain: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
    position: relative;
    isolation: isolate;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    background: var(--roo-x-tile);
    color: var(--roo-text);
    font-family: var(--roo-font-ui);
    box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--roo-p-white) 8%, transparent);
  }

  .roo-brand-stage-lights,
  .roo-brand-stage-grid,
  .roo-brand-stage-grain {
    position: absolute;
    inset: 0;
    z-index: -1;
    pointer-events: none;
  }

  .roo-brand-stage-lights {
    inset: -20%;
    background:
      radial-gradient(48% 42% at 28% 24%, color-mix(in srgb, var(--roo-x-brand-glow-1) 34%, transparent), transparent 70%),
      radial-gradient(44% 40% at 74% 78%, color-mix(in srgb, var(--roo-x-brand-glow-2) 28%, transparent), transparent 70%);
  }

  .roo-brand-stage-wash {
    /* The wash strength (6% on a light app, 10% on a dark one) and the light positions are this piece's own literals. */
    --roo-brand-wash-strength: 6%;
    --roo-brand-wash-x: 0%;
    --roo-brand-wash-y-1: 30%;
    --roo-brand-wash-y-2: 80%;
    background: transparent;
    box-shadow: none;
  }

  :global(.dark) .roo-brand-stage-wash {
    --roo-brand-wash-strength: 10%;
  }

  .roo-brand-stage-wash[data-edge='end'] {
    --roo-brand-wash-x: 100%;
  }

  .roo-brand-stage-wash:dir(rtl) {
    --roo-brand-wash-x: 100%;
  }

  .roo-brand-stage-wash[data-edge='end']:dir(rtl) {
    --roo-brand-wash-x: 0%;
  }

  .roo-brand-stage-wash[data-edge='top'],
  .roo-brand-stage-wash[data-edge='bottom'] {
    --roo-brand-wash-x: 30%;
    --roo-brand-wash-y-1: 0%;
    --roo-brand-wash-y-2: 0%;
  }

  .roo-brand-stage-wash[data-edge='bottom'] {
    --roo-brand-wash-y-1: 100%;
    --roo-brand-wash-y-2: 100%;
  }

  .roo-brand-stage-wash .roo-brand-stage-lights {
    inset: 0;
    background:
      radial-gradient(60% 50% at var(--roo-brand-wash-x) var(--roo-brand-wash-y-1), color-mix(in srgb, var(--roo-x-brand-glow-1) var(--roo-brand-wash-strength), transparent), transparent 70%),
      radial-gradient(50% 45% at var(--roo-brand-wash-x) var(--roo-brand-wash-y-2), color-mix(in srgb, var(--roo-x-brand-glow-2) var(--roo-brand-wash-strength), transparent), transparent 70%);
  }

  .roo-brand-stage-grid {
    background-image:
      linear-gradient(to right, color-mix(in srgb, var(--roo-p-white) 4%, transparent) 1px, transparent 1px),
      linear-gradient(to bottom, color-mix(in srgb, var(--roo-p-white) 4%, transparent) 1px, transparent 1px);
    background-size: var(--roo-brand-stage-pitch) var(--roo-brand-stage-pitch);
    mask-image: radial-gradient(ellipse at center, var(--roo-p-graphite) 30%, transparent 82%);
  }

  .roo-brand-stage-grain {
    background-image: var(--roo-brand-stage-grain);
    opacity: 0.03;
  }

  .roo-brand-stage-top,
  .roo-brand-stage-bottom {
    position: relative;
    flex: none;
  }

  .roo-brand-stage-body {
    position: relative;
    flex: 1 1 auto;
    min-height: 0;
  }

  .roo-brand-stage-drift .roo-brand-stage-lights {
    animation: roo-brand-stage-drift var(--roo-brand-stage-drift-period) ease-in-out infinite;
    will-change: transform, opacity;
  }

  @keyframes roo-brand-stage-drift {
    0% { transform: translate(0, 0); opacity: 0.9; }
    25% { transform: translate(4%, 3%); opacity: 1; }
    50% { transform: translate(0, 6%); opacity: 0.85; }
    75% { transform: translate(-4%, 3%); opacity: 1; }
    100% { transform: translate(0, 0); opacity: 0.9; }
  }

  @media (prefers-reduced-motion: reduce) {
    .roo-brand-stage-drift .roo-brand-stage-lights {
      animation: none;
    }
  }
}
</style>
