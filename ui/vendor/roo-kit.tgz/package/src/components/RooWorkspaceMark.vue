<script setup lang="ts">
// A round workspace mark for the foot of a closed sidebar rail: a 32px ring button holding one small square tile with
// the workspace's first letter. It is a button, so the app gives it an aria-label and wraps it in a RooTooltip, or in
// a PopoverTrigger or DropdownMenuTrigger with as-child. Attrs go to the button, and the button is the only root, so a ref on this component is the button.
import { computed } from 'vue'
import { firstLetter } from '../composables/firstLetter'
import RooIcon from './RooIcon.vue'
import type { RooIconName } from '../icons/paths'

defineOptions({ inheritAttrs: false })

const props = withDefaults(
  defineProps<{
    /** The workspace name. The letter is its first character, uppercased like RooLetterTile. */
    name?: string
    /** Any CSS colour for the tile. */
    color?: string
    /** The empty state (no workspace open): this icon replaces the tile, centred in the ring with the same inset. */
    icon?: RooIconName | undefined
    /** Pixels. Default is the bar control height. The tile and its inset scale with it. */
    size?: number
  }>(),
  { name: '', color: 'transparent', icon: undefined, size: 32 },
)

const letter = computed(() => firstLetter(props.name))

// The tile is 20/32 of the ring, so a 32px ring gives a 20px tile with 6px all round. The letter size follows the bar token.
const dimensions = computed(() => ({
  '--roo-workspace-mark-size': `${props.size}px`,
  '--roo-workspace-mark-tile': `${(props.size * 20) / 32}px`,
  '--roo-workspace-mark-fill': props.color,
}))

// The icon sits in the same box the tile would, so the ring inset is 6px all round at size 32.
const iconSize = computed(() => Math.round((props.size * 20) / 32))
</script>

<template>
  <button v-bind="$attrs" type="button" class="roo-workspace-mark" :style="dimensions">
    <span v-if="icon" class="roo-workspace-mark-icon" aria-hidden="true"><RooIcon :name="icon" :size="iconSize" /></span>
    <span v-else class="roo-workspace-mark-tile" aria-hidden="true">{{ letter }}</span>
  </button>
</template>

<style scoped>
@layer roo-components {
  .roo-workspace-mark {
    display: grid;
    flex: none;
    place-items: center;
    box-sizing: border-box;
    width: var(--roo-workspace-mark-size);
    height: var(--roo-workspace-mark-size);
    border: 1px solid var(--roo-bar-edge);
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-surface);
    padding: 0;
    cursor: default;
    transition: background-color var(--roo-fast) var(--roo-ease);
  }

  .roo-workspace-mark:hover,
  .roo-workspace-mark[data-state='open'] {
    background: var(--roo-raised);
  }

  .roo-workspace-mark:active {
    background: var(--roo-raised-hover);
  }

  .roo-workspace-mark:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: var(--roo-focus-offset);
  }

  .roo-workspace-mark-tile {
    display: grid;
    width: var(--roo-workspace-mark-tile);
    height: var(--roo-workspace-mark-tile);
    place-items: center;
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-workspace-mark-fill);
    /* --roo-on-accent is the dark graphite text colour for light accents. Workspace colours are pastel, where the
       white of --roo-on-accent-fill would be hard to read. */
    color: var(--roo-on-accent);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-bar-tile-letter);
    font-weight: 600;
    line-height: 1;
    user-select: none;
  }

  .roo-workspace-mark-icon {
    display: grid;
    width: var(--roo-workspace-mark-tile);
    height: var(--roo-workspace-mark-tile);
    place-items: center;
    color: var(--roo-muted);
  }

  .roo-workspace-mark:hover .roo-workspace-mark-icon,
  .roo-workspace-mark[data-state='open'] .roo-workspace-mark-icon {
    color: var(--roo-text);
  }

  @media (prefers-reduced-motion: reduce) {
    .roo-workspace-mark {
      transition: none;
    }
  }

  /* An invisible tap area of at least --roo-touch-target on a coarse pointer (family rule F6, Fable review). The drawn size never changes. */
  @media (pointer: coarse) {
    .roo-workspace-mark {
      position: relative;
    }

    .roo-workspace-mark::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2));
    }
  }
}
</style>
