<script setup lang="ts">
// A toast carries no live-region role. The family has one announcer (useAnnouncer, rendered by RooLiveRegion), and
// useToasts speaks each toast through it, so nothing is read twice.
import { computed } from 'vue'
import RooIcon from './RooIcon.vue'
import RooTooltip from './RooTooltip.vue'
import { useSwipeDismiss } from '../composables/useSwipeDismiss'
import type { RooIconName } from '../icons/paths'

const props = withDefaults(
  defineProps<{
    title?: string
    message: string
    /** A second, quieter line. */
    detail?: string
    tone?: 'ok' | 'muted' | 'warn'
    /** How many repeats coalesced into this one. */
    count?: number
    /** Shows the Undo button. */
    undo?: boolean
    undoLabel?: string
    /** Shows a text button with this label. */
    actionLabel?: string
    /** Replaces the tone's glyph (a lock, a trash, a download). The tone still sets the colour. */
    icon?: RooIconName | undefined
    /** Cuts every line of the body to one line with an ellipsis; the full text shows in a RooTooltip (needs a RooTooltipProvider above). */
    singleLine?: boolean
    /** The toast's own width: a number is pixels, a string is any CSS length. Left out, it fits its content between 240 and 400. */
    width?: number | string | undefined
  }>(),
  { title: '', detail: '', tone: 'muted', count: 1, undo: false, undoLabel: 'Undo', actionLabel: '', icon: undefined, singleLine: false, width: undefined },
)

const emit = defineEmits<{ dismiss: []; undo: []; action: []; pause: []; resume: [] }>()

// A swipe to the right dismisses (far enough, or fast enough). Buttons keep their own clicks. Escape on a focused toast
// dismisses too, so the keyboard has the same way out as the pointer.
const swipe = useSwipeDismiss({ onDismiss: () => emit('dismiss') })

// A different glyph per tone, so the tone is not colour alone.
const icons: Record<'ok' | 'muted' | 'warn', RooIconName> = { ok: 'check', muted: 'info', warn: 'alert' }

const glyph = computed<RooIconName>(() => props.icon ?? icons[props.tone])
const widthValue = computed(() => (props.width === undefined ? undefined : typeof props.width === 'number' ? `${props.width}px` : props.width))

function onFocusOut(event: FocusEvent): void {
  const target = event.currentTarget as HTMLElement | null
  if (target && event.relatedTarget instanceof Node && target.contains(event.relatedTarget)) return
  emit('resume')
}
</script>

<template>
  <div
    class="roo-toast"
    :data-tone="props.tone"
    :data-swiping="swipe.swiping.value || undefined"
    :data-single-line="props.singleLine || undefined"
    :data-width="widthValue === undefined ? undefined : ''"
    :style="{ '--roo-toast-swipe': `${swipe.offset.value}px`, '--roo-toast-width': widthValue }"
    @pointerdown="swipe.onPointerdown"
    @pointermove="swipe.onPointermove"
    @pointerup="swipe.onPointerup"
    @pointercancel="swipe.onPointercancel"
    @keydown.esc="emit('dismiss')"
    @mouseenter="emit('pause')"
    @mouseleave="emit('resume')"
    @focusin="emit('pause')"
    @focusout="onFocusOut"
  >
    <RooIcon class="roo-toast-icon" :name="glyph" :size="14" />
    <div class="roo-toast-body">
      <template v-if="props.singleLine">
        <RooTooltip v-if="props.title" :text="props.title" side="top"><p class="roo-toast-title">{{ props.title }}</p></RooTooltip>
        <RooTooltip :text="props.message" side="top"><p class="roo-toast-message">{{ props.message }}</p></RooTooltip>
        <RooTooltip v-if="props.detail" :text="props.detail" side="top"><p class="roo-toast-detail">{{ props.detail }}</p></RooTooltip>
      </template>
      <template v-else>
        <p v-if="props.title" class="roo-toast-title">{{ props.title }}</p>
        <p class="roo-toast-message">{{ props.message }}</p>
        <p v-if="props.detail" class="roo-toast-detail">{{ props.detail }}</p>
      </template>
    </div>
    <span v-if="props.count > 1" class="roo-toast-count">{{ props.count }}</span>
    <button v-if="props.undo" class="roo-toast-undo" type="button" @click="emit('undo')">{{ props.undoLabel }}</button>
    <button v-if="props.actionLabel" class="roo-toast-action" type="button" @click="emit('action')">{{ props.actionLabel }}</button>
    <button class="roo-toast-close" type="button" aria-label="Dismiss" @click="emit('dismiss')">
      <RooIcon name="x" :size="14" />
    </button>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-toast {
    display: flex;
    /* Every item in the row is one control height tall (--roo-toast-line) and sits at the top, and the body's first line has
       that same line height, so the icon, the actions, the count and the close share the first line's centre: on a one-line
       toast that is the row's centre, on a wrapping one it stays on the first line, not the box top or middle. */
    --roo-toast-line: var(--roo-compact-control-h);
    --roo-toast-icon-size: 14px;
    align-items: flex-start;
    gap: var(--roo-p-space-2);
    min-width: 240px;
    max-width: 400px;
    padding: var(--roo-p-space-2) var(--roo-p-space-2) var(--roo-p-space-2) var(--roo-p-space-3);
    border: 1px solid transparent;
    border-radius: var(--roo-p-radius-card);
    background: var(--roo-raised);
    color: var(--roo-text);
    box-shadow: var(--roo-shadow-popover);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-13);
    animation: roo-rise var(--roo-base) var(--roo-ease) both;
    touch-action: pan-y;
  }

  .roo-toast[data-width] {
    box-sizing: border-box;
    width: var(--roo-toast-width);
    min-width: 0;
    max-width: 100%;
  }

  .roo-toast[data-swiping] {
    user-select: none;
  }

  .roo-toast-icon {
    flex: none;
    margin-block: calc((var(--roo-toast-line) - var(--roo-toast-icon-size)) / 2);
    color: var(--roo-muted);
  }

  .roo-toast[data-tone='ok'] .roo-toast-icon {
    color: var(--roo-ok-text);
  }

  .roo-toast[data-tone='warn'] .roo-toast-icon {
    color: var(--roo-warn);
  }

  .roo-toast[data-tone='muted'] .roo-toast-icon {
    color: var(--roo-muted);
  }

  .roo-toast-body {
    display: flex;
    min-width: 0;
    flex: 1;
    flex-direction: column;
  }

  .roo-toast-title,
  .roo-toast-message {
    margin: 0;
    line-height: var(--roo-toast-line);
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .roo-toast-title {
    font-weight: 600;
    white-space: nowrap;
  }

  .roo-toast[data-single-line] .roo-toast-message {
    display: block;
    white-space: nowrap;
  }

  /* The message wraps to two lines, and only text beyond two is cut. */
  .roo-toast-message {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    overflow-wrap: anywhere;
  }

  .roo-toast-detail {
    margin: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }

  .roo-toast-count {
    display: inline-flex;
    flex: none;
    align-items: center;
    height: var(--roo-toast-line);
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
  }

  .roo-toast-undo,
  .roo-toast-action,
  .roo-toast-close {
    flex: none;
    box-sizing: border-box;
    height: var(--roo-toast-line);
    border: 0;
    border-radius: var(--roo-p-radius-small);
    background: transparent;
    color: var(--roo-text);
    cursor: default;
    font: inherit;
    white-space: nowrap;
  }

  .roo-toast-undo,
  .roo-toast-action {
    display: inline-flex;
    align-items: center;
    padding: 0 var(--roo-p-space-2);
    font-weight: 600;
    line-height: 1;
  }

  .roo-toast-close {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: var(--roo-toast-line);
    padding: 0;
    color: var(--roo-muted);
  }

  .roo-toast-undo:hover,
  .roo-toast-action:hover,
  .roo-toast-close:hover {
    background: var(--roo-row-hover);
    color: var(--roo-text);
  }

  .roo-toast-undo:active,
  .roo-toast-action:active,
  .roo-toast-close:active {
    background: color-mix(in srgb, var(--roo-text) 14%, transparent);
    color: var(--roo-text);
  }

  .roo-toast-undo:focus-visible,
  .roo-toast-action:focus-visible,
  .roo-toast-close:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: var(--roo-focus-offset);
  }

  /* An invisible tap area of at least --roo-touch-target on a coarse pointer (family rule F6, Fable review). The drawn size never changes. */
  @media (pointer: coarse) {
    .roo-toast-undo,
    .roo-toast-action,
    .roo-toast-close {
      position: relative;
    }

    .roo-toast-undo::before,
    .roo-toast-action::before,
    .roo-toast-close::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2));
    }

    .roo-toast {
      gap: var(--roo-p-space-3);
    }
  }
}
</style>
