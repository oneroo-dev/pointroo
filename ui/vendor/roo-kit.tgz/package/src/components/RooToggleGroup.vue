<script lang="ts">
export interface RooToggleGroupItem {
  value: string
  /** The glyph. An item with no `text` is icon-only and is named by `label` alone. */
  icon?: RooIconName
  /** A visible label drawn at the kit control font. An item with `text` is compact (--roo-compact-control-h) and is named by its text. */
  text?: string
  /** The accessible name of an icon-only item. Also the tooltip text unless `tooltip` is given. */
  label: string
  /** Tooltip text, when it should say more than the label. */
  tooltip?: string
  shortcut?: string
  disabled?: boolean
}
</script>

<script setup lang="ts">
// A group of icon toggles where each one turns on and off by itself (layout, streaming, query log). The model is the list
// of values that are on. Each item is a button with aria-pressed and a tooltip (needs one RooTooltipProvider above it). An item
// may carry `text` (with or without an icon): a text item takes its name from the text and gets a tooltip only when it gives one.
// One Tab stop for the group; the left and right arrows, Home and End move focus and skip disabled items, like
// RooSegmented, and the group has the same height, corner and inner padding so the two sit side by side in a header.
import { computed, type FunctionalComponent, onMounted, onUpdated, ref } from 'vue'
import RooIcon from './RooIcon.vue'
import RooTooltip from './RooTooltip.vue'
import { useRovingTabindex } from '../composables/useRovingTabindex'
import type { RooIconName } from '../icons/paths'

const props = defineProps<{
  items: RooToggleGroupItem[]
  label: string
  /** Spans the column instead of the content width: the items share the width equally and each label is centred in its share. Text items only. */
  block?: boolean
}>()
const hasText = computed(() => props.items.some((item) => Boolean(item.text)))
const model = defineModel<string[]>({ default: () => [] })

const root = ref<HTMLElement | null>(null)
const roving = useRovingTabindex(root, { itemSelector: '[data-roving-item]', orientation: 'horizontal' })
onMounted(roving.sync)
onUpdated(roving.sync)

// A text item with no tooltip of its own is drawn bare: a tooltip repeating the visible text would only be noise.
const Bare: FunctionalComponent = (_properties, { slots }) => slots.default?.()

function hasTooltip(item: RooToggleGroupItem): boolean {
  return !item.text || Boolean(item.tooltip) || Boolean(item.shortcut)
}

function toggle(item: RooToggleGroupItem): void {
  if (item.disabled) return
  model.value = model.value.includes(item.value) ? model.value.filter((value) => value !== item.value) : [...model.value, item.value]
}
</script>

<template>
  <div ref="root" class="roo-toggle-group" :data-text="hasText ? 'true' : undefined" :data-block="block ? 'true' : undefined" role="group" :aria-label="label" @keydown="roving.onKeydown" @focusin="roving.onFocusin">
    <component
      :is="hasTooltip(item) ? RooTooltip : Bare"
      v-for="item in items"
      :key="item.value"
      v-bind="hasTooltip(item) ? { text: item.tooltip ?? item.label, shortcut: item.shortcut ?? '' } : {}"
    >
      <button
        type="button"
        class="roo-toggle-group-item"
        data-roving-item
        :data-value="item.value"
        :aria-label="item.text ? undefined : item.label"
        :data-text="item.text ? 'true' : undefined"
        :aria-pressed="model.includes(item.value) ? 'true' : 'false'"
        :data-pressed="model.includes(item.value) ? 'true' : undefined"
        :disabled="item.disabled"
        @click="toggle(item)"
      >
        <RooIcon v-if="item.icon" :name="item.icon" :size="16" />
        <span v-if="item.text" class="roo-toggle-group-text">{{ item.text }}</span>
      </button>
    </component>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-toggle-group {
    display: inline-flex;
    height: var(--roo-segmented-h);
    box-sizing: border-box;
    align-items: stretch;
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-radius-control);
    background: var(--roo-bg);
    /* The pill inset is measured from the outer edge, so the padding is the inset less the 1px border. */
    --roo-segmented-pad: calc(var(--roo-segmented-pill-inset) - 1px);
    padding: var(--roo-segmented-pad);
  }

  .roo-toggle-group-item {
    display: inline-flex;
    min-width: calc(var(--roo-segmented-h) - 2 * var(--roo-segmented-pill-inset));
    align-items: center;
    justify-content: center;
    border: 0;
    border-radius: var(--roo-radius-inner);
    background: transparent;
    padding: 0 var(--roo-segment-pad-x);
    color: var(--roo-muted);
    cursor: default;
    transition:
      color var(--roo-fast) var(--roo-ease),
      background-color var(--roo-fast) var(--roo-ease),
      transform var(--roo-fast) var(--roo-spring);
  }

  /* Text items: the compact chip height (the same --roo-compact-control-h RooInput size sm uses) and the item padding. The frame keeps the
     segmented border and corner; the item steps in 1px so it sits inside the border at the pill height. Never wraps. */
  .roo-toggle-group[data-text='true'] {
    height: var(--roo-compact-control-h);
    padding: 0;
  }

  .roo-toggle-group-item[data-text='true'] {
    gap: var(--roo-p-space-1);
    min-width: 0;
    padding: 0 var(--roo-space-item);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    white-space: nowrap;
  }

  /* Block: the group fills its column (a sidebar filter row spans the same width as the search field) and the items share it, each
     keeping at least its content. Every label is centred in its share, so the row is even by construction. */
  .roo-toggle-group[data-block='true'] {
    display: flex;
    width: 100%;
  }

  .roo-toggle-group[data-block='true'] .roo-toggle-group-item {
    flex: 1 1 0;
    min-width: max-content;
    justify-content: center;
  }

  .roo-toggle-group-item:hover:not(:disabled) {
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  /* On is the same raised-on-raised step the segmented thumb uses, plus the text colour, so it never rests on colour alone: aria-pressed carries it for assistive technology. */
  .roo-toggle-group-item[data-pressed='true'] {
    background: var(--roo-raised-on-raised);
    color: var(--roo-text);
  }

  .roo-toggle-group-item:active:not(:disabled) {
    transform: scale(0.98);
  }

  .roo-toggle-group-item:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 1px;
  }

  .roo-toggle-group-item:disabled {
    background: transparent;
    color: var(--roo-faint);
    pointer-events: none;
  }
}
</style>
