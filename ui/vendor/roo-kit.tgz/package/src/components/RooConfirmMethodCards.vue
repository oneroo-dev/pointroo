<script setup lang="ts" generic="Value extends string = ConfirmGestureMethod">
// How a destructive or prod action is confirmed, as two picture cards, each drawing what the confirm looks like: a pill
// filling (Hold to confirm) and the two steps (Press twice). Lifted from Tinkeroo's settings. A radio group with one Tab
// stop on the picked card; the arrow keys move the pick and the focus together; the picked card has the accent edge, and
// the dot inside it says the same, so the pick never rests on colour. The two drawings stay neutral (text tint, secondary
// button look): the accent reads close to the prod crimson, and a pick is not a danger signal. Props in, events out, no store.
import { computed, nextTick, ref } from 'vue'
import { CONFIRM_ARM_WINDOW_MS, CONFIRM_HOLD_MS, type ConfirmGestureMethod } from '../composables/useConfirmGesture'

export interface ConfirmMethodOption<Value extends string = string> {
  value: Value
  title: string
  help: string
}

const model = defineModel<Value>({ required: true })
const props = defineProps<{ label: string; options?: ReadonlyArray<ConfirmMethodOption<Value>>; columns?: 1 | 2 | 3 | 4 }>()

const root = ref<HTMLElement | null>(null)

const defaultMethods: Array<ConfirmMethodOption<ConfirmGestureMethod>> = [
  { value: 'hold', title: 'Hold to confirm', help: `Press and hold for ${CONFIRM_HOLD_MS / 1000} s. Hard to do by accident.` },
  { value: 'two-step', title: 'Press twice', help: `Press, then press again within ${CONFIRM_ARM_WINDOW_MS / 1000} s. Faster, still deliberate.` },
]

const methods = computed(() => (props.options ?? (defaultMethods as unknown as ReadonlyArray<ConfirmMethodOption<Value>>)))

function onKeydown(event: KeyboardEvent): void {
  if (!['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(event.key)) return
  event.preventDefault()
  const list = methods.value
  const step = event.key === 'ArrowLeft' || event.key === 'ArrowUp' ? -1 : 1
  const current = list.findIndex((method) => method.value === model.value)
  model.value = list[(current + step + list.length) % list.length]!.value
  void nextTick(() => root.value?.querySelector<HTMLElement>('[aria-checked="true"]')?.focus())
}
</script>

<template>
  <div ref="root" class="roo-confirm-methods" role="radiogroup" :aria-label="label" :data-columns="columns" @keydown="onKeydown">
    <button
      v-for="method in methods"
      :key="method.value"
      type="button"
      role="radio"
      class="roo-confirm-method"
      :aria-checked="model === method.value"
      :tabindex="model === method.value ? 0 : -1"
      :data-confirm-method="method.value"
      @click="model = method.value"
    >
      <span class="roo-confirm-method-head">
        <span class="roo-confirm-method-dot" aria-hidden="true"></span>
        <span class="roo-confirm-method-title">{{ method.title }}</span>
      </span>
      <slot name="art" :option="method">
        <span v-if="method.value === 'hold'" class="roo-confirm-method-pill" aria-hidden="true">
          <span class="roo-confirm-method-pill-fill"></span>
          <span class="roo-confirm-method-pill-word">Hold to confirm</span>
        </span>
        <span v-else-if="method.value === 'two-step'" class="roo-confirm-method-steps" aria-hidden="true">
          <span class="roo-confirm-method-step">Confirm</span>
          <span class="roo-confirm-method-step" data-second>Press again</span>
        </span>
      </slot>
      <span class="roo-confirm-method-help">{{ method.help }}</span>
    </button>
  </div>
</template>

<style>
@layer roo-components {
  .roo-confirm-methods {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: var(--roo-p-space-3);
    font-family: var(--roo-font-ui);
  }

  .roo-confirm-methods[data-columns='1'] {
    grid-template-columns: 1fr;
  }

  .roo-confirm-methods[data-columns='3'] {
    grid-template-columns: repeat(3, 1fr);
  }

  .roo-confirm-methods[data-columns='4'] {
    grid-template-columns: repeat(4, 1fr);
  }

  @media (max-width: 479.98px) {
    .roo-confirm-methods[data-columns='3'],
    .roo-confirm-methods[data-columns='4'] {
      grid-template-columns: 1fr;
    }
  }

  .roo-confirm-method {
    display: flex;
    min-width: 0;
    flex-direction: column;
    gap: var(--roo-p-space-3);
    border: 0;
    border-radius: var(--roo-p-radius-card);
    background: transparent;
    padding: var(--roo-p-space-3);
    text-align: left;
    color: var(--roo-text);
    box-shadow: inset 0 0 0 1px var(--roo-border-floating);
    cursor: default;
    transition:
      background-color var(--roo-fast) var(--roo-ease),
      box-shadow var(--roo-fast) var(--roo-ease);
  }

  .roo-confirm-method:hover {
    background: var(--roo-raised);
  }

  .roo-confirm-method:hover:not([aria-checked='true']) {
    box-shadow: inset 0 0 0 1px var(--roo-border-hover);
  }

  .roo-confirm-method[aria-checked='true'] {
    background: var(--roo-surface);
    box-shadow: inset 0 0 0 2px var(--roo-accent);
  }

  .roo-confirm-method:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: var(--roo-focus-offset);
  }

  .roo-confirm-method[aria-checked='true']:focus-visible {
    outline-offset: 3px;
  }

  .roo-confirm-method-head {
    display: flex;
    align-items: center;
    gap: var(--roo-p-space-2);
  }

  .roo-confirm-method-dot {
    display: grid;
    width: 16px;
    height: 16px;
    flex: none;
    place-items: center;
    border-radius: 50%;
    box-shadow: inset 0 0 0 1.5px var(--roo-control-edge);
  }

  .roo-confirm-method[aria-checked='true'] .roo-confirm-method-dot {
    background: var(--roo-accent);
    box-shadow: none;
  }

  .roo-confirm-method[aria-checked='true'] .roo-confirm-method-dot::after {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--roo-on-accent);
    content: '';
  }

  .roo-confirm-method-title {
    font-size: var(--roo-p-size-13);
    font-weight: 600;
  }

  .roo-confirm-method-pill,
  .roo-confirm-method-step {
    height: 32px;
    border-radius: var(--roo-p-radius-pill);
    font-size: var(--roo-p-size-12);
  }

  .roo-confirm-method-pill {
    position: relative;
    display: block;
    overflow: hidden;
    background: var(--roo-raised);
  }

  .roo-confirm-method-pill-fill {
    position: absolute;
    inset: 0 auto 0 0;
    width: 55%;
    background: color-mix(in srgb, var(--roo-text) 16%, transparent);
  }

  .roo-confirm-method-pill-word {
    position: relative;
    display: grid;
    height: 100%;
    place-items: center;
  }

  .roo-confirm-method-steps {
    display: flex;
    gap: var(--roo-p-space-2);
  }

  .roo-confirm-method-step {
    display: grid;
    min-width: 0;
    flex: 1;
    place-items: center;
    box-shadow: inset 0 0 0 1px var(--roo-border);
  }

  .roo-confirm-method-step[data-second] {
    background: var(--roo-raised);
    box-shadow: inset 0 0 0 1px var(--roo-control-edge);
  }

  .roo-confirm-method-help {
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }

  @media (prefers-reduced-motion: reduce) {
    .roo-confirm-method {
      transition: none;
    }
  }
}
</style>
