<script setup lang="ts">
// The Bar field that opens the palette. Focus opens it (emits `open`); the palette gives focus back to this field when it
// closes and announces that with `roo-return-focus`, so the field does not open it again. `folded` is the icon-only form
// for a narrow Bar. `form="trigger"` is the search trigger: a button with the magnifier and the key, no words (it looks
// like a field but opens the palette on click, Enter or Space). `folded` wins over `form`. Enter hands the typed text back with `submit`.
import { computed, ref } from 'vue'
import { detectPlatform, type ShortcutPlatform } from '../composables/useShortcuts'
import RooIcon from './RooIcon.vue'
import RooKbd from './RooKbd.vue'

const props = withDefaults(
  defineProps<{
    placeholder?: string
    /** The accessible name. Falls back to the placeholder. */
    label?: string | undefined
    /** `field` types into an input; `trigger` is a button with the magnifier and the key only. */
    form?: 'field' | 'trigger'
    /** The chord shown at the right. */
    keys?: string
    platform?: ShortcutPlatform | undefined
    /** What joins the keys of the cap off macOS (see RooKbd). */
    joiner?: 'plus' | 'space'
    folded?: boolean
    /** `md` is the control height. `capsule` is the outer box of RooButton size="capsule": the control height, with no ring. */
    size?: 'md' | 'capsule'
    /** The palette is open. */
    expanded?: boolean
    /** Extra attributes for the inner input, such as data-testid. */
    inputAttrs?: Record<string, string>
  }>(),
  { placeholder: 'Jump or ask', label: undefined, form: 'field', keys: 'Mod+K', platform: undefined, joiner: 'space', folded: false, size: 'md', expanded: false, inputAttrs: () => ({}) },
)

const emit = defineEmits<{ open: []; submit: [text: string] }>()
const text = defineModel<string>({ default: '' })

const accessibleName = computed(() => props.label ?? props.placeholder)
const shortcutAttribute = computed(() => ((props.platform ?? detectPlatform()) === 'mac' ? 'Meta+K' : 'Control+K'))

let returning = false
function onReturnFocus(): void {
  returning = true
}

function onFocus(): void {
  if (returning) {
    returning = false
    return
  }
  emit('open')
}

function onKeydown(event: KeyboardEvent): void {
  if (event.key !== 'Enter' || event.isComposing) return
  emit('submit', text.value)
}

const input = ref<HTMLInputElement | null>(null)
defineExpose({ focus: () => input.value?.focus() })
</script>

<template>
  <button
    v-if="folded"
    class="roo-jump-field-folded"
    :data-size="size"
    type="button"
    :aria-label="accessibleName"
    aria-haspopup="dialog"
    :aria-expanded="expanded"
    :aria-keyshortcuts="shortcutAttribute"
    @click="emit('open')"
    @roo-return-focus="onReturnFocus"
  >
    <RooIcon name="search" size="token" />
  </button>
  <button
    v-else-if="form === 'trigger'"
    class="roo-jump-field roo-jump-field-trigger"
    :data-size="size"
    type="button"
    :aria-label="accessibleName"
    aria-haspopup="dialog"
    :aria-expanded="expanded"
    :aria-keyshortcuts="shortcutAttribute"
    :data-expanded="expanded ? '' : undefined"
    @click="emit('open')"
    @roo-return-focus="onReturnFocus"
  >
    <RooIcon class="roo-jump-field-icon" name="search" size="token" />
    <RooKbd class="roo-jump-field-kbd" :keys="keys" :platform="platform" :joiner="joiner" />
  </button>
  <div v-else class="roo-jump-field" :data-size="size" :data-expanded="expanded ? '' : undefined">
    <RooIcon class="roo-jump-field-icon" name="search" size="token" />
    <input
      ref="input"
      v-model="text"
      class="roo-jump-field-input"
      v-bind="inputAttrs"
      type="text"
      role="combobox"
      autocomplete="off"
      spellcheck="false"
      aria-haspopup="dialog"
      :aria-expanded="expanded"
      :aria-keyshortcuts="shortcutAttribute"
      :placeholder="placeholder"
      :aria-label="accessibleName"
      @focus="onFocus"
      @click="emit('open')"
      @keydown="onKeydown"
      @roo-return-focus="onReturnFocus"
    />
    <RooKbd class="roo-jump-field-kbd" :keys="keys" :platform="platform" :joiner="joiner" />
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-jump-field {
    display: flex;
    height: var(--roo-control-h);
    min-width: 0;
    box-sizing: border-box;
    align-items: center;
    gap: var(--roo-p-space-2);
    padding: 0 var(--roo-p-space-2);
    border: 1px solid var(--roo-field-edge);
    border-radius: var(--roo-p-radius-medium);
    background: var(--roo-surface);
    color: var(--roo-text);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-13);
  }

  .roo-jump-field-icon {
    flex: none;
    color: var(--roo-muted);
  }

  .roo-jump-field-input {
    min-width: 0;
    flex: 1;
    border: 0;
    background: transparent;
    color: inherit;
    font: inherit;
    outline: none;
  }

  .roo-jump-field-input::placeholder {
    color: var(--roo-muted);
  }

  .roo-jump-field:not(.roo-jump-field-trigger):focus-within,
  .roo-jump-field-trigger:focus-visible,
  .roo-jump-field[data-expanded] {
    border-color: var(--roo-focus);
  }

  /* The trigger is a button: its focus shows once, as the field's edge, only after keyboard focus. The button outline
     on top drew a second ring (Bugroo crop, 2026-11-17). */
  .roo-jump-field-trigger:focus-visible {
    outline: none;
  }

  .roo-jump-field-kbd {
    flex: none;
  }

  /* The cap inside a field or trigger is a hint, not a control: shorter than a menu cap (--roo-kbd-field-h, 16 in a 32 control),
     the raised fill, the muted text (the kit lints faint text off a raised fill) and the mono face of Tinkeroo's trigger (Raja, 2026-11-23: "i loved the tinkeroo one"), 11px. */
  .roo-jump-field .roo-jump-field-kbd {
    height: var(--roo-kbd-field-h);
    padding: 0 calc(var(--roo-p-space-1) - 1px);
    background: var(--roo-raised);
    color: var(--roo-muted);
    font-family: var(--roo-font-mono);
  }

  /* The pill keeps its own width: magnifier, a small gap, the cap. */
  .roo-jump-field-trigger {
    width: max-content;
    flex: none;
    gap: var(--roo-p-space-2);
  }

  /* The trigger has no visible edge at rest (the 1px box stays, so the size never changes): the same soft fill as a bar
     chip at rest, one step darker on hover (Raja, 2026-11-17). */
  .roo-jump-field-trigger {
    justify-content: space-between;
    border-color: transparent;
    background: var(--roo-raised);
    cursor: default;
  }

  .roo-jump-field-trigger:hover {
    background: color-mix(in srgb, var(--roo-raised) 90%, var(--roo-text));
  }

  /* The folded trigger follows the trigger: no visible edge at rest, the bar chip's soft fill, one step darker on hover
     (Raja, 2026-11-17; the folded form had kept the old edge until Pingroo's crops caught it). */
  .roo-jump-field-folded {
    display: inline-flex;
    width: var(--roo-control-h);
    height: var(--roo-control-h);
    align-items: center;
    justify-content: center;
    border: 1px solid transparent;
    border-radius: var(--roo-p-radius-medium);
    background: var(--roo-raised);
    color: var(--roo-muted);
    cursor: default;
  }

  .roo-jump-field-folded:hover {
    background: color-mix(in srgb, var(--roo-raised) 90%, var(--roo-text));
  }

  /* Same single ring as the trigger: the edge lights on keyboard focus, with no outline outside it. */
  .roo-jump-field-folded:focus-visible {
    border-color: var(--roo-focus);
    outline: none;
  }

  /* The capsule size: the same outer box as RooButton size="capsule" (--roo-control-h, with the 1px edge every field keeps), so the
     field sits in one row with the toolbar actions. No ring (the old 2px ground was the thick edge the toolbar dropped), and the
     trigger and the folded form rest with no fill, like the actions beside them: the soft fill only on hover. The md trigger keeps
     its soft fill (Raja 2026-11-17). */
  .roo-jump-field[data-size='capsule'],
  .roo-jump-field-folded[data-size='capsule'] {
    height: var(--roo-control-h);
    line-height: var(--roo-row-h);
  }

  .roo-jump-field-folded.roo-jump-field-folded[data-size='capsule'] {
    background: transparent;
  }

  .roo-jump-field-folded.roo-jump-field-folded[data-size='capsule']:hover {
    background: var(--roo-raised);
  }

  /* The capsule trigger is Tinkeroo's search trigger (Raja, 2026-11-23: "i loved the tinkeroo one"): the 1px border shows at
     rest, the surface fill, 10px left and 6px right, an 8px gap; on hover the edge steps to muted and the text to the text colour. */
  .roo-jump-field-trigger.roo-jump-field-trigger[data-size='capsule'] {
    padding: 0 var(--roo-trigger-pad-end) 0 var(--roo-trigger-pad-start);
    gap: var(--roo-control-icon-gap);
    border-color: var(--roo-border);
    background: var(--roo-surface);
    color: var(--roo-muted);
    transition: border-color 150ms, color 150ms;
  }

  .roo-jump-field-trigger.roo-jump-field-trigger[data-size='capsule'] .roo-jump-field-icon {
    color: currentColor;
  }

  .roo-jump-field-trigger.roo-jump-field-trigger[data-size='capsule']:hover {
    border-color: var(--roo-muted);
    background: var(--roo-surface);
    color: var(--roo-text);
  }

  @media (prefers-reduced-motion: reduce) {
    .roo-jump-field-trigger.roo-jump-field-trigger[data-size='capsule'] {
      transition: none;
    }
  }

  .roo-jump-field-trigger[data-size='capsule']:focus-visible,
  .roo-jump-field-folded[data-size='capsule']:focus-visible {
    border-color: var(--roo-focus);
  }

  .roo-jump-field[data-size='capsule'] .roo-jump-field-input {
    line-height: inherit;
  }

  :root[data-density='compact'] .roo-jump-field[data-size='capsule'],
  :root[data-density='compact'] .roo-jump-field-folded[data-size='capsule'] {
    line-height: var(--roo-row-h);
  }
}
</style>
