<script setup lang="ts">
import { computed } from 'vue'
import { useRooHost } from '../composables/rooHost'
import type { TrailSource } from '../composables/useTrail'
import RooAppTile from './RooAppTile.vue'
import RooBarChip from './RooBarChip.vue'

// "from Tableroo", "from Queue · job 9f3c" or "from a link": where the person came from, with a way back. It stays in the
// suite too; `back` asks the host (conflict C16). The app removes it when the person moves on (see createTrail).
const props = withDefaults(
  defineProps<{
    source: TrailSource
    /** The tile only. Left off, the chip shrinks to the tile by itself under 1280 px wide. */
    compact?: boolean | undefined
  }>(),
  { compact: undefined },
)

const emit = defineEmits<{ back: [] }>()

const host = useRooHost()

const place = computed(() => props.source.label || props.source.app || '')
const accessibleName = computed(() => `Back to ${place.value || 'the previous place'}`)

async function goBack(): Promise<void> {
  await host.back()
  emit('back')
}
</script>

<template>
  <RooBarChip
    class="roo-trail-chip"
    interactive
    :compact="compact === true"
    :data-narrow-tile="compact === undefined && source.app ? 'true' : undefined"
    :aria-label="accessibleName"
    @press="goBack"
  >
    <template v-if="source.app" #leading>
      <RooAppTile :size="16"><slot name="mark" /></RooAppTile>
    </template>
    <template v-if="place">from {{ place }}</template>
    <template v-else>from a link</template>
  </RooBarChip>
</template>

<style scoped>
@layer roo-components {
  @media (max-width: 1279px) {
    .roo-trail-chip[data-narrow-tile='true'] :deep(.roo-bar-chip-label) {
      position: absolute;
      width: 1px;
      height: 1px;
      margin: -1px;
      overflow: hidden;
      clip-path: inset(50%);
    }
  }
}
</style>
