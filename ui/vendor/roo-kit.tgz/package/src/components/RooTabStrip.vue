<script lang="ts">
export const TAB_DRAG_OUT_DISTANCE = 24
export const TAB_DRAG_START_DISTANCE = 4
export const TAB_OVERFLOW_RESERVE = 48
export const TAB_NUMBER_LIMIT = 9
/** A tab opens and closes by growing from or shrinking to zero width over this long, ease-out. */
export const TAB_MOTION_MS = 160
export const TAB_MOTION_EASING = 'cubic-bezier(0.2, 0, 0, 1)'
/** The label fades in this long after the tab starts to open. */
export const TAB_LABEL_DELAY_MS = 50

/** False when the person asked for reduced motion: a tab then appears and disappears at once. */
export function tabMotionAllowed(): boolean {
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return true
  return !window.matchMedia('(prefers-reduced-motion: reduce)').matches
}

export interface RooTabStripTab {
  id: string
  label: string
  icon?: RooIconName
  /** Pinned tabs come first, show compact (the icon, or the label's first letter, at a fixed narrow width), never close from the strip and never go into the overflow menu. A 1px separator follows the last one. */
  pinned?: boolean
  /** A second line in the tab's tooltip, such as the file's path. The tooltip's first line is the label. */
  description?: string
  kind?: 'default' | 'terminal'
  /** Unsaved changes: a small accent dot after the label, the same in the folded tab list, and "unsaved" for screen readers in both. */
  dirty?: boolean
}

export interface OverflowInput {
  widths: number[]
  pinned: boolean[]
  /** Index of the active tab, or -1. */
  active: number
  available: number
  /** Room the overflow button takes when it shows. */
  reserve: number
}

/**
 * Which tabs stay in the strip. If they all fit, all of them. If not, room is kept for the tab list button, the pinned
 * tabs and the active tab always stay, and the rest are kept nearest the active tab first (the left one first on a
 * tie), stopping at the first that does not fit. So the tabs that fold away are the ones farthest from the active tab.
 * The widths are measured after the tabs have already shrunk together to their minimum, so this only runs when even
 * that does not fit.
 */
export function splitOverflow(input: OverflowInput): { visible: number[]; hidden: number[] } {
  const everything = input.widths.map((_, index) => index)
  if (input.widths.reduce((sum, width) => sum + width, 0) <= input.available) return { visible: everything, hidden: [] }
  const keep = new Set<number>()
  let used = 0
  input.widths.forEach((width, index) => {
    if (input.pinned[index]) {
      keep.add(index)
      used += width
    }
  })
  if (input.active >= 0 && !keep.has(input.active)) {
    keep.add(input.active)
    used += input.widths[input.active] ?? 0
  }
  const budget = input.available - input.reserve
  const distance = (index: number) => (input.active >= 0 ? Math.abs(index - input.active) : index)
  const byNearness = everything.filter((index) => !keep.has(index)).sort((first, second) => distance(first) - distance(second) || first - second)
  for (const index of byNearness) {
    const width = input.widths[index] ?? 0
    if (used + width > budget) break
    keep.add(index)
    used += width
  }
  return { visible: everything.filter((index) => keep.has(index)), hidden: everything.filter((index) => !keep.has(index)) }
}

/** Where a tab lands when moved one place, staying inside its own group (pinned tabs with pinned, the rest with the rest). */
export function reorderIndex(tabs: Array<{ pinned?: boolean }>, from: number, delta: -1 | 1): number {
  const target = from + delta
  if (target < 0 || target >= tabs.length) return from
  return Boolean(tabs[target]?.pinned) === Boolean(tabs[from]?.pinned) ? target : from
}

/** The place a dragged tab drops into: how many of the other tabs have their centre left of the pointer. */
export function dropIndexAt(centres: number[], x: number): number {
  return centres.filter((centre) => centre < x).length
}

export interface TabDragInput {
  start: { x: number; y: number }
  point: { x: number; y: number }
  bounds: { left: number; right: number; top: number; bottom: number }
}

/** A small move is nothing, a sideways move reorders, and letting go well above or below the strip drags the tab out. */
export function tabDragIntent(input: TabDragInput): 'none' | 'reorder' | 'out' {
  const { point, start, bounds } = input
  if (point.y > bounds.bottom + TAB_DRAG_OUT_DISTANCE || point.y < bounds.top - TAB_DRAG_OUT_DISTANCE) return 'out'
  return Math.abs(point.x - start.x) >= TAB_DRAG_START_DISTANCE ? 'reorder' : 'none'
}
</script>

<script setup lang="ts">
// API added for the Markroo title bar (all behaviour; the look is untouched):
//   props   `tabList` (boolean, optional): the chevron tab list at the strip's end. Left unset it shows only while tabs
//           are folded; `true` always shows it, `false` never.
//   slots   `close-button` ({ tab, close }): replaces the close button of a tab, so an app can wrap it (a confirm popover
//           from useConfirmGesture for a tab with unsaved changes). Put one <button> in it; the kit sizes and shows it
//           as it does the default. Without the slot the default button runs as before.
//           `after`: sits right after the last tab, for a + button. It is never folded away.
//   add     `addLabel` (string, optional) turns on a built-in + button right after the last tab: a 24px box with a 16px plus,
//           hovered like an inactive tab, named and tooltipped by the label (`addShortcut` adds a keycap), emitting `add`. It
//           is never folded away and counts in the width like the `after` slot, which still works and sits after it.
//   tips    Hovering or keyboard-focusing a tab shows its label (and `description`, when set) in a RooTooltip, with the provider's
//           open delay and no delay between neighbours. It needs one RooTooltipProvider above the strip; without one the strip renders with no tooltips.
//   pinned  A tab with `pinned: true` is compact: the icon (or the label's first letter) at the fixed `--roo-tab-pinned-w`, no label shown
//           and no close button. Pinned tabs sit first with a 1px separator after the last; moving or dragging never crosses it.
//   menu    The ContextMenu key and Shift+F10 on a focused tab open the same `tab-menu` a right click opens, under the tab.
//   events  `rename` now also turns renaming on by itself when something listens to it (no need for `renamable`).
//   keys    Alt with Left or Right reorders only with no Command, Control or Shift held, so Command or Control with Alt and
//           an arrow reaches the app. F2 is taken only when the strip can rename, otherwise it goes on to the app.
//   drag    While a tab is dragged along the strip a 2px accent drop line, `.roo-tab-strip-drop-line`, shows where it lands.
//   fold    Tabs first shrink together to their 96px minimum; then those farthest from the active tab fold into the tab
//           list, and the active tab never folds. The tab list names every tab and marks the active one.
// The tab strip of a window. The active tab takes the editor fill and joins the content under it, on a strip painted
// the page colour, semibold, with no divider (C2). Tabs that do not fit go into a chevron menu with a count, and the
// strip never scrolls and never wraps. One Tab stop; arrows, Home and End move and activate. Middle click, the close
// button and Delete close; double click or F2 renames in place; Ctrl or Command Shift T asks to reopen; right click
// opens the `tab-menu` slot; Alt with an arrow moves a tab, and so does dragging it, or out of the strip altogether.
// `variant="text"` is the section-tab look: text only, selected by the raised fill and semibold, no ring.
import { injectTooltipProviderContext } from 'reka-ui'
import { Comment, computed, Fragment, getCurrentInstance, nextTick, onBeforeUnmount, onMounted, onUpdated, ref, TransitionGroup, useSlots, watch, type VNode, type VNodeChild } from 'vue'
import RooAnchoredMenu from './RooAnchoredMenu.vue'
import RooIcon from './RooIcon.vue'
import RooMenu from './RooMenu.vue'
import RooMenuItem from './RooMenuItem.vue'
import RooTooltip from './RooTooltip.vue'
import { useRovingTabindex } from '../composables/useRovingTabindex'
import type { RooIconName } from '../icons/paths'

// A stand-in for the tooltip when there is no provider: the tab goes through untouched.
const PassThrough = (_: unknown, { slots: passed }: { slots: { default?: () => VNodeChild } }): VNodeChild => passed.default?.()

/** True when a slot's vnodes draw something: comments and empty fragments do not count. */
function drawsSomething(nodes: VNode[]): boolean {
  return nodes.some((node) => {
    if (node.type === Comment) return false
    if (node.type === Fragment) return Array.isArray(node.children) && drawsSomething(node.children as VNode[])
    return true
  })
}

const slotsOfStrip = useSlots()
/** A tab gets a glyph span when its icon or terminal mark asks for one, or when the app's glyph slot draws something for it. */
function hasGlyph(tab: RooTabStripTab): boolean {
  if (tab.icon || tab.kind === 'terminal') return true
  const glyphSlot = slotsOfStrip.glyph
  return glyphSlot !== undefined && drawsSomething(glyphSlot({ tab }))
}

const props = withDefaults(
  defineProps<{
    tabs: RooTabStripTab[]
    label: string
    numbered?: boolean
    renamable?: boolean
    closable?: boolean
    variant?: 'tab' | 'text'
    /** `bar`: the strip sits inside the 44px title bar (RooBar): every item is centred on the bar's middle line, the active tab is a card joined to the page and the other tabs are small pills. Only with variant `tab`; the `text` variant ignores it. */
    placement?: 'default' | 'bar'
    /** The chevron tab list at the end of the strip. Unset: only while tabs are folded. True: always. False: never. */
    tabList?: boolean | undefined
    /** Opt-in built-in + button right after the last tab: this is its accessible name and tooltip text. Unset: no button. */
    addLabel?: string | undefined
    /** The keycap shown beside the + button's tooltip text, for example "Cmd T". Only used with `addLabel`. */
    addShortcut?: string | undefined
  }>(),
  { numbered: false, renamable: false, closable: true, variant: 'tab', placement: 'default', tabList: undefined, addLabel: undefined, addShortcut: undefined },
)
const active = defineModel<string>('active', { required: true })
const overflowOpen = defineModel<boolean>('overflowOpen', { default: false })
const emit = defineEmits<{
  close: [id: string]
  reorder: [move: { id: string; index: number }]
  'drag-out': [drop: { id: string; x: number; y: number }]
  rename: [change: { id: string; label: string }]
  reopen: []
  'context-menu': [at: { id: string; x: number; y: number }]
  add: []
}>()

const root = ref<HTMLElement | null>(null)
// Found by injection, never by catching: without a RooTooltipProvider the strip renders with no tooltips.
const hasTooltipProvider = injectTooltipProviderContext(null as never) !== null
const overflowButton = ref<HTMLElement | null>(null)
const afterSlot = ref<HTMLElement | null>(null)
const instance = getCurrentInstance()
const itemElements = new Map<string, HTMLElement>()

const ordered = computed(() => [...props.tabs.filter((tab) => tab.pinned), ...props.tabs.filter((tab) => !tab.pinned)])
const hiddenIds = ref<Set<string>>(new Set())
const showAll = ref(true)
const overflowTabs = computed(() => ordered.value.filter((tab) => hiddenIds.value.has(tab.id)))
const tabListShown = computed(() => props.tabList === true || (props.tabList !== false && overflowTabs.value.length > 0))
const widthCache = new Map<string, number>()
let reserve = TAB_OVERFLOW_RESERVE
let layoutRun = 0

function setItem(id: string, element: unknown): void {
  if (element instanceof HTMLElement) itemElements.set(id, element)
  else itemElements.delete(id)
}

async function relayout(): Promise<void> {
  if (root.value === null) return
  const run = (layoutRun += 1)
  showAll.value = true
  await nextTick()
  if (run !== layoutRun || root.value === null) return
  const tabsNow = ordered.value
  const widths = tabsNow.map((tab) => {
    const element = itemElements.get(tab.id)
    // A tab that is still opening reports a part width; its natural width was cached when it started.
    const width = element?.hasAttribute('data-entering') ? 0 : element?.offsetWidth ?? 0
    if (width > 0) widthCache.set(tab.id, width)
    return width > 0 ? width : widthCache.get(tab.id) ?? 0
  })
  const measuredButton = overflowButton.value?.offsetWidth ?? 0
  if (measuredButton > 0) reserve = measuredButton
  // The + slot is never folded, and a tab list that is always on is already in the strip, so neither is room for tabs.
  const afterWidth = afterSlot.value?.offsetWidth ?? 0
  const alwaysOnWidth = props.tabList === true ? measuredButton || reserve : 0
  const available = root.value.clientWidth - afterWidth - alwaysOnWidth
  if (root.value.clientWidth <= 0) {
    hiddenIds.value = new Set()
  } else {
    const split = splitOverflow({
      widths,
      pinned: tabsNow.map((tab) => Boolean(tab.pinned)),
      active: tabsNow.findIndex((tab) => tab.id === active.value),
      available,
      reserve: props.tabList === true ? 0 : reserve,
    })
    hiddenIds.value = new Set(split.hidden.map((index) => tabsNow[index]!.id))
  }
  showAll.value = false
  await nextTick()
  refreshFading()
}

/** A label wider than its box ends in a soft fade instead of a hard cut: it gets `data-fading`, which the style masks. */
function refreshFading(): void {
  for (const element of itemElements.values()) {
    const label = element.querySelector<HTMLElement>('.roo-tab-strip-label')
    if (label === null || element.hasAttribute('hidden') || element.hasAttribute('data-pinned')) continue
    label.toggleAttribute('data-fading', label.scrollWidth > label.clientWidth + 0.5)
  }
}

let observer: ResizeObserver | undefined
onMounted(() => {
  void relayout()
  if (typeof ResizeObserver !== 'undefined' && root.value) {
    observer = new ResizeObserver(() => void relayout())
    observer.observe(root.value)
  }
})
onBeforeUnmount(() => {
  observer?.disconnect()
  stopDrag()
})
watch(
  () => [ordered.value.map((tab) => `${tab.id}:${tab.label}:${tab.pinned ? 1 : 0}:${tab.dirty ? 1 : 0}`).join('|'), active.value, props.numbered, props.tabList],
  () => void relayout(),
  { flush: 'post' },
)

const roving = useRovingTabindex(root, {
  itemSelector: '.roo-tab-strip-item:not([hidden]) > .roo-tab-strip-body > [data-roving-item]',
  orientation: 'horizontal',
  onMove: (item) => {
    const id = item.getAttribute('data-id')
    if (id !== null) active.value = id
  },
})
onMounted(roving.sync)
onUpdated(() => {
  roving.sync()
  refreshFading()
})

const motionRuns = new WeakMap<HTMLElement, Animation>()

function animateWidth(element: HTMLElement, from: number, to: number, finish: () => void): void {
  motionRuns.get(element)?.cancel()
  element.style.overflow = 'hidden'
  // The tab's own minimum width would stop it growing from or shrinking to nothing.
  element.style.minWidth = '0px'
  const run = element.animate([{ maxWidth: `${from}px` }, { maxWidth: `${to}px` }], { duration: TAB_MOTION_MS, easing: TAB_MOTION_EASING })
  motionRuns.set(element, run)
  run.onfinish = () => {
    motionRuns.delete(element)
    element.style.overflow = ''
    element.style.minWidth = ''
    finish()
  }
  run.oncancel = () => {
    element.style.overflow = ''
    element.style.minWidth = ''
  }
}

function fadeLabel(element: HTMLElement, from: number, to: number, delay: number): void {
  const label = element.querySelector<HTMLElement>('.roo-tab-strip-label')
  label?.animate([{ opacity: from }, { opacity: to }], { duration: TAB_MOTION_MS - delay, delay, easing: 'ease-out', fill: 'both' })
}

function onTabEnter(element: Element, done: () => void): void {
  if (!(element instanceof HTMLElement) || !tabMotionAllowed() || typeof element.animate !== 'function') return done()
  const natural = element.offsetWidth
  const id = element.getAttribute('data-tab-id')
  if (natural <= 0) return done()
  if (id !== null) widthCache.set(id, natural)
  element.setAttribute('data-entering', '')
  fadeLabel(element, 0, 1, TAB_LABEL_DELAY_MS)
  animateWidth(element, 0, natural, () => {
    element.removeAttribute('data-entering')
    done()
    void relayout()
  })
}

function onTabLeave(element: Element, done: () => void): void {
  if (!(element instanceof HTMLElement) || !tabMotionAllowed() || typeof element.animate !== 'function') return done()
  const natural = element.offsetWidth
  if (natural <= 0) return done()
  element.setAttribute('inert', '')
  element.style.pointerEvents = 'none'
  fadeLabel(element, 1, 0, 0)
  animateWidth(element, natural, 0, done)
}

/** The tooltip's text: the full label, then the description in brackets when there is one. */
function tipText(tab: RooTabStripTab): string {
  return tab.description ? `${tab.label} (${tab.description})` : tab.label
}

/** A pinned tab shows no label, so a tab with no icon shows the label's first letter. */
function pinMark(tab: RooTabStripTab): string {
  return Array.from(tab.label.trim())[0]?.toUpperCase() ?? ''
}

function numberFor(index: number): number | undefined {
  return props.numbered && index < TAB_NUMBER_LIMIT ? index + 1 : undefined
}

function activate(id: string): void {
  if (suppressClick) return
  active.value = id
}

const renaming = ref<string | null>(null)
const draft = ref('')

/** Renaming is on with the `renamable` prop, or when the app listens to `rename`. */
function canRename(): boolean {
  return props.renamable || typeof instance?.vnode.props?.['onRename'] === 'function' || Array.isArray(instance?.vnode.props?.['onRename'])
}

function startRename(tab: RooTabStripTab): void {
  if (!canRename()) return
  renaming.value = tab.id
  draft.value = tab.label
  void nextTick(() => {
    const input = itemElements.get(tab.id)?.querySelector<HTMLInputElement>('input')
    input?.focus()
    input?.select()
  })
}

function commitRename(tab: RooTabStripTab): void {
  if (renaming.value !== tab.id) return
  renaming.value = null
  const label = draft.value.trim()
  if (label !== '' && label !== tab.label) emit('rename', { id: tab.id, label })
  void nextTick(() => itemElements.get(tab.id)?.querySelector<HTMLElement>('[role=tab]')?.focus())
}

function cancelRename(tab: RooTabStripTab): void {
  if (renaming.value !== tab.id) return
  renaming.value = null
  void nextTick(() => itemElements.get(tab.id)?.querySelector<HTMLElement>('[role=tab]')?.focus())
}

function onTabKeydown(event: KeyboardEvent, tab: RooTabStripTab, index: number, hasMenu: boolean): void {
  const withoutModifier = !event.ctrlKey && !event.metaKey && !event.shiftKey
  if (event.key === 'ContextMenu' || (event.key === 'F10' && event.shiftKey && !event.ctrlKey && !event.metaKey && !event.altKey)) {
    // The same menu a right click opens, under the tab the key was pressed on (the pointer is not where the person is looking).
    event.preventDefault()
    const box = (event.currentTarget as HTMLElement).getBoundingClientRect()
    openTabMenu(tab, box.left, box.bottom, hasMenu)
  } else if (event.altKey && withoutModifier && (event.key === 'ArrowLeft' || event.key === 'ArrowRight')) {
    event.preventDefault()
    const target = reorderIndex(ordered.value, index, event.key === 'ArrowLeft' ? -1 : 1)
    if (target !== index) emit('reorder', { id: tab.id, index: target })
  } else if ((event.ctrlKey || event.metaKey) && event.shiftKey && event.key.toLowerCase() === 't') {
    event.preventDefault()
    emit('reopen')
  } else if (event.key === 'Delete' && props.closable && !tab.pinned) {
    event.preventDefault()
    emit('close', tab.id)
  } else if (event.key === 'F2' && canRename()) {
    event.preventDefault()
    startRename(tab)
  }
}

function onAuxClick(event: MouseEvent, tab: RooTabStripTab): void {
  if (event.button !== 1 || !props.closable || tab.pinned) return
  event.preventDefault()
  emit('close', tab.id)
}

const contextOpen = ref(false)
const contextX = ref(0)
const contextY = ref(0)
const contextTab = ref<RooTabStripTab | null>(null)

function openTabMenu(tab: RooTabStripTab, x: number, y: number, hasMenu: boolean): void {
  emit('context-menu', { id: tab.id, x, y })
  if (!hasMenu) return
  contextTab.value = tab
  contextX.value = x
  contextY.value = y
  contextOpen.value = true
}

function onContextMenu(event: MouseEvent, tab: RooTabStripTab, hasMenu: boolean): void {
  event.preventDefault()
  openTabMenu(tab, event.clientX, event.clientY, hasMenu)
}

interface DragState {
  id: string
  start: { x: number; y: number }
}
let drag: DragState | null = null
let suppressClick = false
const dropLine = ref<{ x: number; index: number } | null>(null)

/** Where the dragged tab lands: its index among the other tabs, and the x of the gap between its new neighbours. */
function dropPlace(draggedId: string, pointerX: number): { index: number; x: number | null } {
  const others = ordered.value.filter((tab) => tab.id !== draggedId)
  const placed = others.flatMap((tab, position) => {
    const element = itemElements.get(tab.id)
    if (element === undefined || element.hasAttribute('hidden')) return []
    const box = element.getBoundingClientRect()
    return [{ position, left: box.left, right: box.right, centre: box.left + box.width / 2, pinned: Boolean(tab.pinned) }]
  })
  const passed = dropIndexAt(placed.map((entry) => entry.centre), pointerX)
  // A tab folded into the list has no centre, so the count is of the visible ones; the drop is just after the last one passed.
  let index = passed > 0 ? placed[passed - 1]!.position + 1 : 0
  const pinnedCount = others.filter((tab) => tab.pinned).length
  index = ordered.value.find((tab) => tab.id === draggedId)?.pinned ? Math.min(index, pinnedCount) : Math.max(index, pinnedCount)
  const before = placed.filter((entry) => entry.position < index).at(-1)
  const after = placed.find((entry) => entry.position >= index)
  const rootLeft = root.value?.getBoundingClientRect().left ?? 0
  const edge = before !== undefined && after !== undefined ? (before.right + after.left) / 2 : before?.right ?? after?.left ?? null
  return { index, x: edge === null ? null : edge - rootLeft }
}

function stopDrag(): void {
  drag = null
  dropLine.value = null
  window.removeEventListener('pointermove', onPointerMove)
  window.removeEventListener('pointerup', onPointerUp)
  window.removeEventListener('pointercancel', stopDrag)
}

function onPointerDown(event: PointerEvent, tab: RooTabStripTab): void {
  if (event.button !== 0 || renaming.value !== null) return
  drag = { id: tab.id, start: { x: event.clientX, y: event.clientY } }
  window.addEventListener('pointermove', onPointerMove)
  window.addEventListener('pointerup', onPointerUp)
  window.addEventListener('pointercancel', stopDrag)
}

function onPointerMove(event: PointerEvent): void {
  if (drag === null || root.value === null) return
  const intent = tabDragIntent({ start: drag.start, point: { x: event.clientX, y: event.clientY }, bounds: root.value.getBoundingClientRect() })
  root.value.setAttribute('data-dragging', intent)
  dropLine.value = null
  if (intent !== 'reorder') return
  const place = dropPlace(drag.id, event.clientX)
  const current = ordered.value.findIndex((tab) => tab.id === drag!.id)
  if (place.x !== null && place.index !== current) dropLine.value = { x: place.x, index: place.index }
}

function onPointerUp(event: PointerEvent): void {
  const finished = drag
  stopDrag()
  root.value?.removeAttribute('data-dragging')
  if (finished === null || root.value === null) return
  const point = { x: event.clientX, y: event.clientY }
  const intent = tabDragIntent({ start: finished.start, point, bounds: root.value.getBoundingClientRect() })
  if (intent === 'none') return
  suppressClick = true
  setTimeout(() => {
    suppressClick = false
  }, 0)
  if (intent === 'out') {
    emit('drag-out', { id: finished.id, x: point.x, y: point.y })
    return
  }
  const target = dropPlace(finished.id, point.x).index
  if (target !== ordered.value.findIndex((tab) => tab.id === finished.id)) emit('reorder', { id: finished.id, index: target })
}
</script>

<template>
  <div ref="root" class="roo-tab-strip" :data-variant="variant" :data-placement="placement" :data-empty="ordered.length === 0 ? 'true' : undefined" @keydown="roving.onKeydown" @focusin="roving.onFocusin">
    <TransitionGroup tag="div" class="roo-tab-strip-list" role="tablist" :aria-label="label" :css="false" @enter="onTabEnter" @leave="onTabLeave">
      <div
        v-for="(tab, index) in ordered"
        :key="tab.id"
        :ref="(element) => setItem(tab.id, element)"
        class="roo-tab-strip-item"
        role="presentation"
        :data-tab-id="tab.id"
        :data-active="tab.id === active ? 'true' : 'false'"
        :data-pinned="tab.pinned ? 'true' : undefined"
        :data-pin-edge="tab.pinned && ordered[index + 1] !== undefined && !ordered[index + 1]!.pinned ? 'true' : undefined"
        :data-kind="tab.kind ?? 'default'"
        :hidden="!showAll && hiddenIds.has(tab.id)"
      >
        <div class="roo-tab-strip-body">
          <component :is="hasTooltipProvider ? RooTooltip : PassThrough" v-if="renaming !== tab.id" v-bind="hasTooltipProvider ? { text: tipText(tab) } : {}">
          <button
            type="button"
            role="tab"
            class="roo-tab-strip-tab"
            data-roving-item
            :data-id="tab.id"
            :aria-selected="tab.id === active ? 'true' : 'false'"
            @click="activate(tab.id)"
            @auxclick="onAuxClick($event, tab)"
            @mousedown.middle.prevent
            @dblclick="startRename(tab)"
            @keydown="onTabKeydown($event, tab, index, Boolean($slots['tab-menu']))"
            @contextmenu="onContextMenu($event, tab, Boolean($slots['tab-menu']))"
            @pointerdown="onPointerDown($event, tab)"
          >
            <span v-if="hasGlyph(tab)" class="roo-tab-strip-glyph">
              <slot name="glyph" :tab="tab"><RooIcon :name="tab.icon ?? 'code'" :size="16" /></slot>
            </span>
            <span v-else-if="tab.pinned" class="roo-tab-strip-pin-mark" aria-hidden="true" :data-mark="pinMark(tab)" />
            <span class="roo-tab-strip-label" :class="{ 'roo-visually-hidden': tab.pinned }" :data-label="tab.label">{{ tab.label }}</span>
            <kbd v-if="numberFor(index)" class="roo-tab-strip-number">{{ numberFor(index) }}</kbd>
            <span v-if="$slots.marker || tab.dirty" class="roo-tab-strip-marker">
              <slot name="marker" :tab="tab"><span v-if="tab.dirty" class="roo-tab-strip-dirty" aria-hidden="true" /></slot>
              <span v-if="tab.dirty" class="roo-visually-hidden"> (unsaved)</span>
            </span>
          </button>
          </component>
          <input
            v-else
            v-model="draft"
            class="roo-tab-strip-rename"
            type="text"
            :aria-label="`Rename ${tab.label}`"
            @keydown.enter.prevent="commitRename(tab)"
            @keydown.esc.prevent="cancelRename(tab)"
            @blur="commitRename(tab)"
          />
          <template v-if="closable && !tab.pinned">
            <span v-if="$slots['close-button']" class="roo-tab-strip-close-host">
              <slot name="close-button" :tab="tab" :close="() => emit('close', tab.id)" />
            </span>
            <button v-else type="button" class="roo-tab-strip-close" tabindex="-1" :aria-label="`Close ${tab.label}`" @click.stop="emit('close', tab.id)">
              <RooIcon name="x" :size="18" />
            </button>
          </template>
        </div>
      </div>
    </TransitionGroup>

    <div v-if="$slots.after || addLabel" ref="afterSlot" class="roo-tab-strip-after">
      <component :is="hasTooltipProvider ? RooTooltip : PassThrough" v-if="addLabel" v-bind="hasTooltipProvider ? { text: addLabel, shortcut: addShortcut ?? '' } : {}">
        <button type="button" class="roo-tab-strip-add" :aria-label="addLabel" @click="emit('add')">
          <RooIcon name="plus" :size="16" />
        </button>
      </component>
      <slot name="after" />
    </div>

    <RooMenu v-if="tabListShown" v-model:open="overflowOpen" align="end">
      <template #trigger>
        <button ref="overflowButton" type="button" class="roo-tab-strip-overflow" :aria-label="overflowTabs.length > 0 ? `${overflowTabs.length} more tabs` : 'Tab list'">
          <span v-if="overflowTabs.length > 0" class="roo-tab-strip-overflow-count">{{ overflowTabs.length }}</span>
          <RooIcon name="chevron-down" :size="17" />
        </button>
      </template>
      <RooMenuItem
        v-for="(tab, position) in ordered"
        :key="tab.id"
        :checked="tab.id === active"
        :kbd="numberFor(position) ? String(numberFor(position)) : ''"
        @select="activate(tab.id)"
      >
        {{ tab.label }}<span v-if="tab.dirty" class="roo-tab-strip-menu-dirty" aria-hidden="true" /><span v-if="tab.dirty" class="roo-visually-hidden"> (unsaved)</span>
      </RooMenuItem>
    </RooMenu>

    <div v-if="dropLine" class="roo-tab-strip-drop-line" aria-hidden="true" :data-drop-index="dropLine.index" :style="{ left: `${dropLine.x}px` }" />

    <RooAnchoredMenu v-if="$slots['tab-menu']" v-model:open="contextOpen" :x="contextX" :y="contextY">
      <slot v-if="contextTab" name="tab-menu" :tab="contextTab" />
    </RooAnchoredMenu>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-tab-strip {
    position: relative;
    display: flex;
    height: var(--roo-tab-h);
    min-width: 0;
    box-sizing: border-box;
    align-items: stretch;
    overflow: hidden;
    background: var(--roo-x-tabstrip);
    padding-inline: 4px;
    color: var(--roo-muted);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
  }

  .roo-tab-strip-list {
    display: flex;
    min-width: 0;
    flex: 0 1 auto;
    flex-wrap: nowrap;
    align-items: stretch;
    overflow: hidden;
    contain: layout;
  }

  .roo-tab-strip-item {
    position: relative;
    display: flex;
    min-width: 0;
    flex: none;
    align-items: center;
    color: var(--roo-muted);
  }

  .roo-tab-strip-item[hidden] {
    display: none;
  }

  /* A pinned tab: a fixed narrow width, the icon or letter centred, no label (it stays for screen readers) and no number. A 1px
     separator, 15px high like the tab dividers, follows the last pinned tab. */
  .roo-tab-strip-item[data-pinned='true'],
  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-item[data-pinned='true'] {
    width: var(--roo-tab-pinned-w);
    min-width: var(--roo-tab-pinned-w);
    flex: none;
  }

  .roo-tab-strip-item[data-pinned='true'] .roo-tab-strip-tab,
  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-item[data-pinned='true'] .roo-tab-strip-tab {
    justify-content: center;
    padding-inline: 0;
  }

  .roo-tab-strip-item[data-pinned='true'] .roo-tab-strip-number {
    display: none;
  }

  .roo-tab-strip-pin-mark {
    display: inline-flex;
    flex: none;
    align-items: center;
    font-weight: 600;
    line-height: 1;
  }

  /* The letter is drawn from an attribute, so the tab's text stays its label alone. */
  .roo-tab-strip-pin-mark::before {
    content: attr(data-mark);
  }

  .roo-tab-strip-item[data-pin-edge='true']::after {
    content: '';
    position: absolute;
    top: calc(50% - 8px);
    inset-inline-end: -1px;
    width: 1px;
    height: 16px;
    background: var(--roo-border);
    pointer-events: none;
  }

  .roo-tab-strip-body {
    display: flex;
    min-width: 0;
    flex: 1 1 auto;
    align-self: stretch;
    align-items: center;
    color: inherit;
  }

  .roo-tab-strip-item[data-active='true'] {
    color: var(--roo-text);
  }

  /*
   * Connected tabs, measured from the Obsidian reference (10.png, 2x) and drawn from kit tokens. Geometry in css px:
   * the strip is 38 high plus a 1px line (the tab-height token plus 11), 13px labels (the 13px size primitive); a tab is a slot of 200px at most,
   * every tab the same width, sharing the pane (so a few tabs grow to fill it) and shrinking together to 96px when space runs out, and slots overlap by 2px;
   * the first tab starts 7px from the strip edge and 4px below its top. The active tab has the editor fill, a 1px edge
   * on top, left and right, an 8px top radius and 7px-radius flares at both bottom corners into the strip line, which it
   * breaks. An inactive tab has no fill; on hover a 6.5px-radius rectangle shows 5px in from each side, 2px below the
   * tab's top and 4px above its bottom (29px high), leaving a gap to the line and to its neighbours. The label sits 11.5px from the tab's outer edge, left aligned, and
   * the 18px close x is centred 18px from the right edge; its space is always reserved and it shows on hover and on
   * the active tab. The label keeps one weight in every state, as in the reference. Nothing moves between rest, hover and active.
   */
  .roo-tab-strip[data-variant='tab'] {
    height: calc(var(--roo-tab-h) + 12px - 1px);
    padding-inline: 8px;
    font-size: var(--roo-ui-size);
  }

  .roo-tab-strip[data-variant='tab']::after {
    content: '';
    position: absolute;
    inset-inline: 0;
    bottom: 0;
    z-index: 0;
    height: 1px;
    background: var(--roo-border);
    pointer-events: none;
  }

  /* The list is its own stacking layer above the strip line, so the active body paints over the line it breaks. */
  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-list {
    position: relative;
    z-index: 1;
    flex: 0 1 auto;
    margin-inline: -8px;
    padding: 4px 8px 0;
  }

  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-item {
    width: 200px;
    min-width: 96px;
    flex: 0 1 auto;
    margin-inline: -1px;
  }

  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-body {
    position: relative;
    isolation: isolate;
    border: 1px solid transparent;
    border-width: 1px 1px 0;
    border-radius: var(--roo-tab-radius) var(--roo-tab-radius) 0 0;
    /*
     * The content is centred above the line and a little under it, as in the reference: its centre is 1px above the body's.
     * Measured on the rendered capitals (not the line box): their ink centre is 20.1px below the strip top, the reference's 20.25.
     */
    padding-bottom: 2px;
  }

  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-item[data-active='true'] > .roo-tab-strip-body {
    z-index: 1;
    background: var(--roo-editor);
    border-color: var(--roo-border);
  }

  /* Inactive tabs: no fill at rest. Hover shows the reference's rounded rectangle, inset from the tab with a gap all round. Desktop hover is instant, so nothing transitions. */
  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-item[data-active='false'] > .roo-tab-strip-body::before {
    content: '';
    position: absolute;
    z-index: -1;
    inset: 1px 4px 4px;
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-raised);
    opacity: 0;
    pointer-events: none;
  }

  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-item[data-active='false']:hover > .roo-tab-strip-body::before {
    opacity: 1;
  }

  /* A 1px divider, 15px high, at the right of an inactive tab; gone beside the active tab and beside a hovered one. */
  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-item[data-active='false'] > .roo-tab-strip-body::after {
    content: '';
    position: absolute;
    top: 8px;
    height: calc(16px - 1px);
    inset-inline-end: -0.5px;
    width: 1px;
    background: var(--roo-border);
    opacity: 0;
    pointer-events: none;
  }

  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-item[data-active='false']:not(:hover):has(+ .roo-tab-strip-item[data-active='false']:not(:hover):not([hidden])) > .roo-tab-strip-body::after {
    opacity: 1;
  }

  /*
   * The flares: a quarter circle at each bottom corner, transparent inside (the strip shows), then the 1px edge, then the
   * editor fill. Fitted to the reference's edge row by row (10.png): a circle of radius 7px, tangent to the tab's edge and
   * to the strip line, so it shows about 5px of reach where it blends into the line.
   */
  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-item[data-active='true'] > .roo-tab-strip-body::before,
  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-item[data-active='true'] > .roo-tab-strip-body::after {
    content: '';
    position: absolute;
    bottom: 0;
    width: 7.75px;
    height: calc(5.75px + 1px);
    pointer-events: none;
  }

  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-item[data-active='true'] > .roo-tab-strip-body::before {
    left: -7.75px;
    background: radial-gradient(circle at 0 0, transparent 6.25px, var(--roo-border) 6.75px, var(--roo-border) 7.25px, var(--roo-editor) 7.75px);
  }

  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-item[data-active='true'] > .roo-tab-strip-body::after {
    right: -7.75px;
    background: radial-gradient(circle at 100% 0, transparent 6.25px, var(--roo-border) 6.75px, var(--roo-border) 7.25px, var(--roo-editor) 7.75px);
  }

  .roo-tab-strip-tab {
    display: inline-flex;
    height: 100%;
    min-width: 0;
    flex: 1 1 auto;
    align-items: center;
    justify-content: flex-start;
    gap: 4px;
    border: 0;
    border-radius: var(--roo-p-radius-medium);
    background: transparent;
    padding-inline: 8px;
    color: inherit;
    font: inherit;
    white-space: nowrap;
    cursor: default;
  }

  /* The label's left edge is 11.5px from the slot's edge in every state (the reference's), so no label moves when the active tab changes. */
  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-tab {
    padding-inline: calc(8px + 2.5px) 0;
  }

  .roo-tab-strip-tab:focus-visible,
  .roo-tab-strip-close:focus-visible,
  .roo-tab-strip-overflow:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: -2px;
  }

  .roo-tab-strip-item[data-kind='terminal'] .roo-tab-strip-label {
    font-family: var(--roo-font-mono);
  }

  .roo-tab-strip-dirty,
  .roo-tab-strip-menu-dirty {
    width: 8px;
    height: 8px;
    flex: none;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-accent);
  }

  .roo-tab-strip-dirty {
    display: block;
  }

  .roo-tab-strip-menu-dirty {
    display: inline-block;
    margin-inline-start: 8px;
    vertical-align: middle;
  }

  .roo-menu-item[data-highlighted] .roo-tab-strip-menu-dirty {
    background: currentcolor;
  }

  .roo-tab-strip-glyph,
  .roo-tab-strip-marker {
    display: inline-flex;
    flex: none;
    align-items: center;
  }

  /* The section-tab label is semibold when selected and reserves that width, so selecting never moves its neighbours. The label is left aligned. */
  .roo-tab-strip-label {
    display: flex;
    min-width: 0;
    flex-direction: column;
    align-items: flex-start;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  /* An overflowing label fades over its last 20px, a mask so it works over the hover fill and the active fill alike. */
  .roo-tab-strip-label[data-fading] {
    text-overflow: clip;
    -webkit-mask-image: linear-gradient(to right, #000 calc(100% - 20px), transparent);
    mask-image: linear-gradient(to right, #000 calc(100% - 20px), transparent);
  }

  .roo-tab-strip[data-variant='text'] .roo-tab-strip-label::after {
    content: attr(data-label);
    height: 0;
    overflow: hidden;
    font-weight: 600;
    visibility: hidden;
    user-select: none;
  }

  .roo-tab-strip-number {
    font: inherit;
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-tab-strip-close {
    display: inline-grid;
    width: 20px;
    height: 100%;
    flex: none;
    margin-inline: 4px;
    place-items: center;
    border: 0;
    background: transparent;
    padding: 0;
    color: var(--roo-muted);
    cursor: default;
    opacity: 0;
  }

  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-close {
    margin-inline: 4px calc(8px - 1px);
  }

  /* The close x shows on hover and on the active tab only; its space is always reserved. */
  .roo-tab-strip-item:hover .roo-tab-strip-close,
  .roo-tab-strip-item[data-active='true'] .roo-tab-strip-close {
    opacity: 1;
  }

  .roo-tab-strip-close:focus-visible {
    opacity: 1;
  }

  .roo-tab-strip-close:hover {
    align-self: center;
    height: 20px;
    border-radius: var(--roo-p-radius-checkbox);
    background: var(--roo-row-hover);
    color: var(--roo-text);
  }

  .roo-tab-strip-close:active {
    align-self: center;
    height: 20px;
    border-radius: var(--roo-p-radius-checkbox);
    background: color-mix(in srgb, var(--roo-text) 14%, transparent);
    color: var(--roo-text);
  }

  /* An app's own close button, in the same cell as the default one: same width, margins and reveal. */
  .roo-tab-strip-close-host {
    display: inline-grid;
    width: 20px;
    height: 100%;
    flex: none;
    margin-inline: 4px;
    place-items: stretch;
    color: var(--roo-muted);
    opacity: 0;
  }

  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-close-host {
    margin-inline: 4px calc(8px - 1px);
  }

  .roo-tab-strip-close-host :deep(button) {
    display: grid;
    width: 100%;
    height: 100%;
    place-items: center;
    border: 0;
    background: transparent;
    padding: 0;
    color: inherit;
    font: inherit;
    cursor: default;
  }

  .roo-tab-strip-item:hover .roo-tab-strip-close-host,
  .roo-tab-strip-item[data-active='true'] .roo-tab-strip-close-host,
  .roo-tab-strip-close-host:focus-within,
  .roo-tab-strip-close-host:has([aria-expanded='true']) {
    opacity: 1;
  }

  .roo-tab-strip-close-host:hover {
    color: var(--roo-text);
  }

  /* Right after the last tab, centred on the tab row above the strip line. */
  .roo-tab-strip-after {
    position: relative;
    z-index: 1;
    display: flex;
    flex: none;
    align-items: center;
    align-self: stretch;
    padding-inline-start: 8px;
    /* The tab body's content runs from 5px (tab top plus its edge) to 37px (the strip line less the 2px under the label), so 21px is the centre; 1px of margin, 4px of padding above and 2px below give the slot the same centre. */
    margin-block-start: 1px;
    padding-block: 4px 2px;
  }

  /* The built-in + button: a 24px box centred on the tab row (the slot centres its children), hovered with the inactive tab's rectangle fill and radius. */
  .roo-tab-strip-add {
    display: inline-flex;
    width: 24px;
    height: 24px;
    flex: none;
    align-items: center;
    justify-content: center;
    border: 0;
    border-radius: var(--roo-p-radius-small);
    background: transparent;
    padding: 0;
    color: var(--roo-muted);
    cursor: default;
  }

  .roo-tab-strip-add:hover {
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  .roo-tab-strip-add:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: -2px;
  }

  /* A 1px divider, 15px high, before the + slot, where Obsidian has one; 1.5px in from the last tab's slot edge. It goes beside an active last tab, as the tab dividers do. */
  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-after::before {
    content: '';
    position: absolute;
    top: calc(12px + 1px);
    left: -0.5px;
    width: 1px;
    height: calc(16px - 1px);
    background: var(--roo-border);
    pointer-events: none;
  }

  /* No divider when no tab shows before the + (Raja, 2026-11-17: "no tabs divider near + can be removed"). */
  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-list:has(> .roo-tab-strip-item[data-active='true']:nth-last-child(1 of :not([hidden]))) + .roo-tab-strip-after::before,
  .roo-tab-strip[data-variant='tab'] .roo-tab-strip-list:not(:has(> .roo-tab-strip-item:not([hidden]))) + .roo-tab-strip-after::before {
    opacity: 0;
  }

  /* No divider before the + when no tab is open (family rule c272933). data-empty comes from the tab count, not from :has(). */
  .roo-tab-strip[data-variant='tab'][data-empty='true'] .roo-tab-strip-after::before {
    opacity: 0;
  }

  /* Where a dragged tab will land: 2px, the full tab height from its top to the strip line. */
  .roo-tab-strip-drop-line {
    position: absolute;
    z-index: 2;
    top: 4px;
    bottom: 1px;
    width: 2px;
    margin-inline-start: -1px;
    border-radius: var(--roo-p-radius-hair);
    background: var(--roo-accent);
    pointer-events: none;
  }

  .roo-tab-strip[data-variant='text'] .roo-tab-strip-drop-line {
    top: 0;
    bottom: 0;
  }

  .roo-tab-strip-rename {
    height: 100%;
    min-width: 0;
    flex: 1 1 auto;
    box-sizing: border-box;
    border: 0;
    background: var(--roo-editor);
    padding-inline: 8px;
    color: var(--roo-text);
    font: inherit;
  }

  /* Focus is the caret, never an outline (family rule for text fields, Raja 2026-11-13; from Tableroo, 2026-11-15). */
  .roo-tab-strip-rename:focus,
  .roo-tab-strip-rename:focus-visible {
    outline: none;
  }

  /* The tab list sits at the strip's end, above the strip line like the tabs. */
  .roo-tab-strip-overflow {
    display: inline-flex;
    height: 100%;
    flex: none;
    margin-inline-start: auto;
    align-items: center;
    gap: 2px;
    border: 0;
    background: transparent;
    padding-inline: 8px;
    color: var(--roo-muted);
    font: inherit;
    font-variant-numeric: tabular-nums;
    white-space: nowrap;
    cursor: default;
  }

  .roo-tab-strip-overflow:hover {
    color: var(--roo-text);
  }

  /* The section-tab look: text only, selected by the raised fill and semibold, never a ring or an edge bar. */
  .roo-tab-strip[data-variant='text'] {
    background: transparent;
    gap: 4px;
  }

  .roo-tab-strip[data-variant='text'] .roo-tab-strip-item {
    border-radius: var(--roo-p-radius-card);
  }

  .roo-tab-strip[data-variant='text'] .roo-tab-strip-item:hover {
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  .roo-tab-strip[data-variant='text'] .roo-tab-strip-item[data-active='true'] {
    background: var(--roo-select);
    font-weight: 600;
  }

  .roo-tab-strip[data-variant='text'] .roo-tab-strip-item[data-active='true'] .roo-tab-strip-tab {
    font-weight: 600;
  }

  /*
   * Bar placement (Raja, 2026-11-18, option C "Obsidian style"): the strip is the 44px title bar's height and every item is
   * centred on the bar's middle line, y 22. Every tab is the same card from y 6 to the bar's bottom edge, 10px top corners
   * (the card radius), up to 200px wide, with 10px concave flares at the bottom corners when hovered or active. Only the fill
   * differs: none at rest, 14% of the text colour mixed into the bar on hover, the page colour when active (so it joins the
   * page with no seam). Labels are 13px, inactive ones in the muted text colour. No divider lines. Only with variant `tab`.
   */
  .roo-tab-strip[data-variant='tab'][data-placement='bar'] {
    height: var(--roo-bar-h);
    padding-inline: 0;
    font-size: var(--roo-ui-size);
  }

  .roo-tab-strip[data-variant='tab'][data-placement='bar']::after,
  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-item[data-pin-edge='true']::after,
  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-after::before {
    display: none;
  }

  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-list {
    margin-inline: 0;
    padding: 0 10px;
  }

  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-item {
    --roo-bar-tab-fill: transparent;
    max-width: 200px;
    margin-inline: 0;
    align-items: flex-start;
  }

  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-item[data-active='false']:hover {
    --roo-bar-tab-fill: color-mix(in srgb, var(--roo-x-tabstrip) 86%, var(--roo-text));
    color: var(--roo-text);
  }

  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-item[data-active='true'] {
    --roo-bar-tab-fill: var(--roo-editor);
  }

  /* Rest, hover and active share one shape: a card from y 6 to the bar's bottom edge. Only the fill differs. */
  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-body {
    box-sizing: border-box;
    height: calc(var(--roo-bar-h) - 6px);
    flex: 1 1 auto;
    align-self: flex-start;
    margin: 6px 0 0;
    border: 0;
    border-radius: var(--roo-p-radius-card) var(--roo-p-radius-card) 0 0;
    background: var(--roo-bar-tab-fill);
    padding-bottom: 6px;
  }

  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-item[data-active='false']:not(:hover) > .roo-tab-strip-body::before,
  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-item[data-active='false']:not(:hover) > .roo-tab-strip-body::after {
    display: none;
  }

  /* The concave flares at both bottom corners of a hovered or active tab, 10px quarter circles in the tab's own fill. */
  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-item[data-active='true'] > .roo-tab-strip-body::before,
  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-item[data-active='true'] > .roo-tab-strip-body::after,
  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-item[data-active='false']:hover > .roo-tab-strip-body::before,
  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-item[data-active='false']:hover > .roo-tab-strip-body::after {
    content: '';
    display: block;
    position: absolute;
    inset: auto;
    bottom: 0;
    z-index: -1;
    width: var(--roo-p-radius-card);
    height: var(--roo-p-radius-card);
    border: 0;
    border-radius: 0;
    opacity: 1;
    pointer-events: none;
  }

  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-item[data-active='true'] > .roo-tab-strip-body::before,
  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-item[data-active='false']:hover > .roo-tab-strip-body::before {
    left: calc(var(--roo-p-radius-card) * -1);
    background: radial-gradient(circle at 0 0, transparent 9.5px, var(--roo-bar-tab-fill) 10px);
  }

  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-item[data-active='true'] > .roo-tab-strip-body::after,
  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-item[data-active='false']:hover > .roo-tab-strip-body::after {
    right: calc(var(--roo-p-radius-card) * -1);
    background: radial-gradient(circle at 100% 0, transparent 9.5px, var(--roo-bar-tab-fill) 10px);
  }

  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-tab {
    border-radius: inherit;
  }

  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-after {
    margin-block: 0;
    padding-block: 0;
    padding-inline-start: 4px;
  }

  .roo-tab-strip[data-variant='tab'][data-placement='bar'] .roo-tab-strip-drop-line {
    top: 9px;
    bottom: 9px;
  }

  /* An invisible tap area of at least --roo-touch-target on a coarse pointer (family rule F6, Fable review). The drawn size never changes. */
  @media (pointer: coarse) {
    .roo-tab-strip-close {
      position: relative;
    }

    .roo-tab-strip-close::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2));
    }
  }
}
</style>
