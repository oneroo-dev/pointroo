<script setup lang="ts">
// A region that opens and closes with a height move (web only). It wraps reka's Collapsible and reads the measured height
// from --reka-collapsible-content-height, so the content can be any height. v-model:open drives it; the app keeps its own
// toggle button. Fall-through attributes (a class, an id) land on the content element. The two keyframes are timed by
// --roo-base, so reduced motion, data-motion="still" and the desktop surface make it instant, and the closed state drops
// its animation there so reka unmounts the content at once.
import { CollapsibleContent, CollapsibleRoot } from 'reka-ui'

defineOptions({ inheritAttrs: false })

withDefaults(defineProps<{ disabled?: boolean }>(), { disabled: false })
const open = defineModel<boolean>('open', { default: false })
</script>

<template>
  <CollapsibleRoot v-model:open="open" :disabled="disabled" class="roo-collapse-root">
    <CollapsibleContent v-bind="$attrs" class="roo-collapse"><slot /></CollapsibleContent>
  </CollapsibleRoot>
</template>

<!-- Not scoped: reka puts the content inside its own element. -->
<style>
@layer roo-components {
  .roo-collapse-root {
    display: block;
  }

  .roo-collapse {
    overflow: hidden;
  }

  .roo-collapse[data-state='open'] {
    animation: roo-collapse-down var(--roo-base) var(--roo-ease) both;
  }

  .roo-collapse[data-state='closed'] {
    animation: roo-collapse-up var(--roo-base) var(--roo-exit) both;
  }
}
</style>
