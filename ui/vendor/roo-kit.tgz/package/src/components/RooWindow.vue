<script lang="ts">
import { tagForEnvironment } from '../environment'
import type { RooEnvironment } from '../types/environment'

/** A part is `open`, `closed-by-user` (stays closed until the person opens it) or `closed-by-width` (comes back by itself). */
export type WindowPartState = 'open' | 'closed-by-user' | 'closed-by-width'

/** Below this window width the layout is the narrow tier. */
export const WINDOW_NARROW_BELOW = 960
export const WINDOW_MAIN_MIN = 400
/** A part closed by width needs this much more room than the minimum before it comes back, so a window sitting on the edge does not flicker. */
export const WINDOW_HYSTERESIS = 16
export const WINDOW_SIDEBAR_RANGE = { min: 180, max: 320 } as const
export const WINDOW_PANE_RANGE = { min: 216, max: 400 } as const

export type WindowTier = 'wide' | 'narrow'

/** What A2 (appearance layouts) will drive. */
export interface RooWindowParts {
  rail?: { show?: boolean; side?: 'start' | 'end'; home?: 'rail' | 'bar' }
  sidebar?: { show?: boolean; side?: 'start' | 'end' }
  tabs?: { show?: boolean }
  pane?: { show?: boolean; below?: boolean }
  /** Maximum width in px of the reading column inside the main area. Absent: the main area fills. */
  measure?: number
}

export function windowTier(width: number): WindowTier {
  return width > 0 && width < WINDOW_NARROW_BELOW ? 'narrow' : 'wide'
}

export interface WindowPartsInput {
  width: number
  railWidth: number
  sidebarWidth: number
  paneWidth: number
  sidebarWanted: boolean
  paneWanted: boolean
  /** The pane sits under the main area, so it takes no width. */
  paneBelow: boolean
  mainMin: number
  previous: { sidebar: WindowPartState; pane: WindowPartState }
}

/**
 * Which of the sidebar and the pane the window has room for. The main area keeps at least `mainMin`; the pane yields
 * first, then the sidebar. A part the person closed stays closed. A part that was closed for lack of width needs
 * `hysteresis` more room to return. An unmeasured window (width 0) honours every wish.
 */
export function resolveWindowParts(input: WindowPartsInput, hysteresis: number = WINDOW_HYSTERESIS): { sidebar: WindowPartState; pane: WindowPartState } {
  let sidebarShown = input.sidebarWanted
  let paneShown = input.paneWanted
  if (input.width > 0) {
    const margin = (state: WindowPartState): number => (state === 'closed-by-width' ? hysteresis : 0)
    const mainWidth = (): number =>
      input.width - input.railWidth - (sidebarShown ? input.sidebarWidth : 0) - (paneShown && !input.paneBelow ? input.paneWidth : 0)
    if (paneShown && !input.paneBelow && mainWidth() < input.mainMin + margin(input.previous.pane)) paneShown = false
    if (sidebarShown && mainWidth() < input.mainMin + margin(input.previous.sidebar)) sidebarShown = false
  }
  return {
    sidebar: input.sidebarWanted ? (sidebarShown ? 'open' : 'closed-by-width') : 'closed-by-user',
    pane: input.paneWanted ? (paneShown ? 'open' : 'closed-by-width') : 'closed-by-user',
  }
}

/** Production only. The old `unclassified` flag no longer counts: unclassified maps to no tag (family rules, 2026-11-17). */
export function isProdLike(environment: RooEnvironment | undefined, _deprecatedUnclassified = false): boolean {
  return environment !== undefined && tagForEnvironment(environment) === 'production'
}
</script>

<script setup lang="ts">
// The window grid: Bar and band on top, Ledge at the bottom, and between them the rail, the sidebar, the centre (tabs,
// the main area, the tray) and the pane. The window measures its own width, not the screen's, so a suite split and a
// 200 percent zoom reflow by the same rules. The main area never drops under `mainMin`: the pane closes first, then
// the sidebar, and both return with a little hysteresis. No frame is drawn round a production window (Raja,
// 2026-11-12: no prod window frame, no corner tag); the Pill, the band and the Ledge say production. The app fills
// the slots; the window sets no heights of its own beyond the anatomy tokens.
import { computed, onBeforeUnmount, onMounted, onUpdated, ref, useSlots, watch } from 'vue'
import RooDivider from './RooDivider.vue'

const props = withDefaults(
  defineProps<{
    environment?: RooEnvironment | undefined
    /** @deprecated Ignored. The production frame is gone (Raja, 2026-11-12). */
    drawKey?: string
    /** @deprecated Ignored. The production frame is gone (Raja, 2026-11-12). */
    unclassified?: boolean
    mainMin?: number
    parts?: RooWindowParts
    /** The accessible name of the sidebar landmark. */
    sidebarLabel?: string
  }>(),
  { environment: undefined, drawKey: '', unclassified: false, mainMin: WINDOW_MAIN_MIN, parts: () => ({}), sidebarLabel: 'Sidebar' },
)

const sidebarWidth = defineModel<number>('sidebarWidth', { default: 216 })
const paneWidth = defineModel<number>('paneWidth', { default: 216 })
const sidebarOpen = defineModel<boolean>('sidebarOpen', { default: true })
const paneOpen = defineModel<boolean>('paneOpen', { default: true })

const emit = defineEmits<{ 'toggle-sidebar': [open: boolean]; 'toggle-pane': [open: boolean]; 'collapse-sidebar': [] }>()

const slots = useSlots()
const root = ref<HTMLElement | null>(null)
const width = ref(0)
const railWidth = ref(56)
const sidebarState = ref<WindowPartState>(sidebarOpen.value ? 'open' : 'closed-by-user')
const paneState = ref<WindowPartState>(paneOpen.value ? 'open' : 'closed-by-user')
let observer: ResizeObserver | undefined

// Slots are not reactive, so presence is read when asked (every render and every update), never cached.
const railShown = (): boolean => slots.rail !== undefined && props.parts.rail?.show !== false
const sidebarPresent = (): boolean => slots.sidebar !== undefined && props.parts.sidebar?.show !== false
const tabsShown = (): boolean => slots.tabs !== undefined && props.parts.tabs?.show !== false
const panePresent = (): boolean => slots.pane !== undefined && props.parts.pane?.show !== false
const paneBelow = computed(() => props.parts.pane?.below === true)
const railSide = computed(() => props.parts.rail?.side ?? 'start')
const sidebarSide = computed(() => props.parts.sidebar?.side ?? 'start')
const tier = computed(() => windowTier(width.value))
const sidebarVisible = (): boolean => sidebarPresent() && sidebarState.value === 'open'
const paneVisible = (): boolean => panePresent() && paneState.value === 'open'

function readRailWidth(element: HTMLElement): number {
  const parsed = Number.parseFloat(getComputedStyle(element).getPropertyValue('--roo-rail-w'))
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 56
}

function recompute(): void {
  const next = resolveWindowParts({
    width: width.value,
    railWidth: railShown() ? railWidth.value : 0,
    sidebarWidth: sidebarWidth.value,
    paneWidth: paneWidth.value,
    sidebarWanted: sidebarPresent() && sidebarOpen.value,
    paneWanted: panePresent() && paneOpen.value,
    paneBelow: paneBelow.value,
    mainMin: props.mainMin,
    previous: { sidebar: sidebarState.value, pane: paneState.value },
  })
  const sidebarBefore = sidebarState.value
  sidebarState.value = next.sidebar
  paneState.value = next.pane
  if (next.sidebar === 'closed-by-width' && sidebarBefore !== 'closed-by-width') emit('collapse-sidebar')
}

watch([width, railWidth, sidebarWidth, paneWidth, sidebarOpen, paneOpen, paneBelow, () => props.mainMin], recompute, {
  immediate: true,
  flush: 'sync',
})

onMounted(() => {
  const element = root.value
  if (!element) return
  railWidth.value = readRailWidth(element)
  width.value = element.getBoundingClientRect().width
  if (typeof ResizeObserver === 'undefined') return
  observer = new ResizeObserver((entries) => {
    const box = entries[0]?.contentRect
    if (box) width.value = box.width
  })
  observer.observe(element)
})
onUpdated(recompute)
onBeforeUnmount(() => observer?.disconnect())

/** The person asked to open or close the sidebar (the Bar's toggle, a shortcut). */
function toggleSidebar(): void {
  sidebarOpen.value = !sidebarOpen.value
  emit('toggle-sidebar', sidebarOpen.value)
}

function togglePane(): void {
  paneOpen.value = !paneOpen.value
  emit('toggle-pane', paneOpen.value)
}

defineExpose({ toggleSidebar, togglePane, sidebarState, paneState, tier })
</script>

<template>
  <div class="roo-window-shell">
    <div
      ref="root"
      class="roo-window"
      :data-tier="tier"
      :data-environment="environment"
      :data-sidebar="sidebarState"
      :data-pane="paneState"
      :data-rail-home="parts.rail?.home ?? 'rail'"
    >
      <slot name="bar" />
      <div v-if="$slots.band" class="roo-window-band"><slot name="band" /></div>

      <div class="roo-window-body">
        <nav v-if="railShown()" class="roo-window-rail" :data-side="railSide" aria-label="Apps and contexts"><slot name="rail" /></nav>

        <!-- A closed sidebar stays mounted and is hidden with display none, so its contents keep their state. -->
        <div
          v-if="sidebarPresent()"
          v-show="sidebarVisible()"
          class="roo-window-sidebar-group"
          :data-side="sidebarSide"
          :style="{ width: `${sidebarWidth}px` }"
        >
          <aside class="roo-window-sidebar" :aria-label="sidebarLabel"><slot name="sidebar" /></aside>
          <RooDivider
            v-model="sidebarWidth"
            :min="WINDOW_SIDEBAR_RANGE.min"
            :max="WINDOW_SIDEBAR_RANGE.max"
            :invert="sidebarSide === 'end'"
            label="Resize sidebar"
            @reset="sidebarWidth = 216"
          />
        </div>

        <div class="roo-window-centre" :data-pane-below="paneBelow">
          <div v-if="tabsShown()" class="roo-window-tabs"><slot name="tabs" /></div>
          <div class="roo-window-work">
            <main class="roo-window-main" :style="parts.measure ? { '--roo-window-measure': `${parts.measure}px` } : undefined">
              <div v-if="parts.measure" class="roo-window-measure"><slot name="main" /></div>
              <slot v-else name="main" />
            </main>
            <template v-if="paneVisible() && paneBelow">
              <RooDivider
                v-model="paneWidth"
                orientation="horizontal"
                :min="WINDOW_PANE_RANGE.min"
                :max="WINDOW_PANE_RANGE.max"
                :invert="true"
                label="Resize pane"
                @reset="paneWidth = 216"
              />
              <section class="roo-window-pane" data-below="true" aria-label="Pane" :style="{ height: `${paneWidth}px` }"><slot name="pane" /></section>
            </template>
          </div>
          <div v-if="$slots.tray" class="roo-window-tray"><slot name="tray" /></div>
        </div>

        <div v-if="paneVisible() && !paneBelow" class="roo-window-pane-group" :style="{ width: `${paneWidth}px` }">
          <RooDivider
            v-model="paneWidth"
            :min="WINDOW_PANE_RANGE.min"
            :max="WINDOW_PANE_RANGE.max"
            :invert="true"
            label="Resize pane"
            @reset="paneWidth = 216"
          />
          <section class="roo-window-pane" aria-label="Pane"><slot name="pane" /></section>
        </div>
      </div>

      <slot name="ledge" />
    </div>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-window-shell {
    position: relative;
    display: flex;
    width: 100%;
    height: 100%;
    min-width: 0;
    min-height: 0;
    flex-direction: column;
  }

  .roo-window {
    display: flex;
    min-width: 0;
    min-height: 0;
    flex: 1 1 auto;
    flex-direction: column;
    background: var(--roo-bg);
    color: var(--roo-text);
  }

  .roo-window-band {
    flex: none;
  }

  .roo-window-body {
    display: flex;
    min-width: 0;
    min-height: 0;
    flex: 1 1 auto;
  }

  .roo-window-rail {
    display: flex;
    width: var(--roo-rail-w);
    flex: none;
    flex-direction: column;
    align-items: center;
    gap: var(--roo-gap);
    border-inline-end: 1px solid var(--roo-border);
    background: var(--roo-x-chrome);
    padding-block: 8px;
    order: 0;
  }

  .roo-window-rail[data-side='end'] {
    border-inline-end: 0;
    border-inline-start: 1px solid var(--roo-border);
    order: 9;
  }

  .roo-window-sidebar-group {
    display: flex;
    min-width: 0;
    flex: none;
    order: 1;
  }

  .roo-window-sidebar-group[data-side='end'] {
    flex-direction: row-reverse;
    order: 8;
  }

  .roo-window-sidebar {
    min-width: 0;
    flex: 1 1 auto;
    overflow: auto;
    background: var(--roo-x-side);
  }

  .roo-window-centre {
    display: flex;
    min-width: 0;
    min-height: 0;
    flex: 1 1 0;
    flex-direction: column;
    order: 5;
  }

  /* The strip behind the tabs. The active tab is a raised fill (--roo-editor) that joins the content below it. */
  .roo-window-tabs {
    flex: none;
    background: var(--roo-x-tabstrip);
  }

  .roo-window-work {
    display: flex;
    min-width: 0;
    min-height: 0;
    flex: 1 1 0;
    flex-direction: column;
  }

  .roo-window-main {
    min-width: 0;
    min-height: 0;
    flex: 1 1 0;
    overflow: auto;
    background: var(--roo-editor);
  }

  .roo-window-measure {
    box-sizing: border-box;
    max-width: var(--roo-window-measure);
    margin-inline: auto;
  }

  .roo-window-tray {
    flex: none;
  }

  .roo-window-pane-group {
    display: flex;
    min-width: 0;
    flex: none;
    order: 6;
  }

  .roo-window-pane {
    min-width: 0;
    min-height: 0;
    flex: 1 1 auto;
    overflow: auto;
    background: var(--roo-x-side);
  }

  .roo-window-pane[data-below='true'] {
    flex: none;
    border-top: 1px solid var(--roo-border);
  }
}
</style>
