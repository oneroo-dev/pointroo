<script setup lang="ts">
// The top of a feature page that needs explaining: the plain name of the feature as the title, the trade term second as muted
// text beside it, and one always-visible line of purpose under it, ending in a "How it works" link when the page has a
// RooHowItWorks panel. The link is a button: it sets aria-expanded and aria-controls and stays underlined while its panel is
// open. `howControls` is the id of the panel (give RooHowItWorks the same id); leave it out and there is no link.
const props = withDefaults(
  defineProps<{
    /** The plain name: what the feature does, in the user's words. */
    title: string
    /** The trade term, shown second ("SLOs"). Expanded once, in the How it works panel. */
    aka?: string | undefined
    /** One sentence on what the feature does for the user. */
    purpose: string
    /** The heading level of the title. */
    level?: 1 | 2
    /** The id of the How it works panel this page opens. Shows the link. */
    howControls?: string | undefined
    howLabel?: string
  }>(),
  { aka: undefined, level: 1, howControls: undefined, howLabel: 'How it works' },
)

const howOpen = defineModel<boolean>('howOpen', { default: false })
</script>

<template>
  <header class="roo-page-intro">
    <div class="roo-page-intro-head">
      <component :is="`h${level}`" class="roo-page-intro-title">{{ title }}</component>
      <span v-if="aka" class="roo-page-intro-aka">{{ aka }}</span>
      <div v-if="$slots.actions" class="roo-page-intro-actions"><slot name="actions" /></div>
    </div>
    <p class="roo-page-intro-purpose">
      {{ purpose }}
      <button
        v-if="props.howControls"
        class="roo-page-intro-how"
        type="button"
        :aria-expanded="howOpen"
        :aria-controls="props.howControls"
        @click="howOpen = !howOpen"
      >
        {{ howLabel }}
      </button>
    </p>
  </header>
</template>

<style scoped>
@layer roo-components {
  .roo-page-intro {
    font-family: var(--roo-font-ui);
    color: var(--roo-text);
  }

  .roo-page-intro-head {
    display: flex;
    align-items: baseline;
    gap: var(--roo-p-space-3);
  }

  .roo-page-intro-title {
    margin: 0;
    font-size: var(--roo-p-size-20);
    line-height: 28px;
    font-weight: 600;
    letter-spacing: var(--roo-p-tracking-heading);
  }

  .roo-page-intro-aka {
    padding-top: calc(var(--roo-p-space-2) - 2px);
    font-size: var(--roo-p-size-13);
    line-height: 18px;
    color: var(--roo-muted);
    white-space: nowrap;
  }

  .roo-page-intro-actions {
    display: flex;
    align-items: center;
    gap: var(--roo-gap);
    margin-left: auto;
  }

  .roo-page-intro-purpose {
    max-width: 640px;
    margin: var(--roo-p-space-1) 0 0;
    font-size: var(--roo-p-size-13);
    line-height: 18px;
    color: var(--roo-muted);
  }

  .roo-page-intro-how {
    display: inline;
    border: 0;
    border-radius: var(--roo-p-radius-small);
    background: transparent;
    padding: 0;
    font: inherit;
    font-weight: 500;
    color: var(--roo-accent-text);
    cursor: default;
    white-space: nowrap;
  }

  .roo-page-intro-how:hover,
  .roo-page-intro-how[aria-expanded='true'] {
    text-decoration: underline;
    text-underline-offset: 3px;
  }

  .roo-page-intro-how:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  /* An invisible tap area of at least --roo-touch-target on a coarse pointer (family rule F6, Fable review). The drawn size never changes. */
  @media (pointer: coarse) {
    .roo-page-intro-how {
      position: relative;
    }

    .roo-page-intro-how::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2));
    }
  }
}
</style>
