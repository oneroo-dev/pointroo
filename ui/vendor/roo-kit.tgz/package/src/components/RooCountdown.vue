<script setup lang="ts">
// Time left until an end time, as mm:ss ("14:32 left"), counting down once a second. Under `warnSeconds` (60 by default) it turns to
// the warn colour and heavier type, so the change is not colour alone, and it is announced once; at the end it reads "00:00 expired",
// announces once and emits `expired` once. A new `endsAt` (an extended session) starts it over.
// The clock reads Date.now() on every tick and the end time is absolute, so a slow tick never drifts. While the tab is hidden the
// tick stops (no timer work for a page nobody sees) and the figure is read fresh the moment the tab shows again, which is also
// when `expired` fires for an end that passed in the background; the server stays the authority on whether the time is really up.
// Accessibility: role="timer" (a timer never announces itself each second). The words that are spoken, "Less than N s left" at the
// threshold and "Time is up" at the end, go through the family announcer, so mount one RooLiveRegion (or pass `announcer`).
// Digits are tabular, so the width never jumps between 09:59 and 10:00.
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useAnnouncer, type Announcer } from '../composables/useAnnouncer'

const props = withDefaults(
  defineProps<{
    /** When time runs out: an ISO 8601 string or milliseconds since the epoch. */
    endsAt: string | number
    /** Seconds left at which it turns to the warn colour. */
    warnSeconds?: number
    /** The word after the figure while time remains. */
    suffix?: string
    /** The word after 00:00 when time is up. */
    expiredText?: string
    /** Defaults to the app-wide announcer. A test or an isolated surface passes its own. */
    announcer?: Announcer | undefined
  }>(),
  { warnSeconds: 60, suffix: 'left', expiredText: 'expired', announcer: undefined },
)

const emit = defineEmits<{ expired: [] }>()

const announcer = props.announcer ?? useAnnouncer()

const endMs = computed(() => (typeof props.endsAt === 'number' ? props.endsAt : Date.parse(props.endsAt)))
const valid = computed(() => Number.isFinite(endMs.value))
if (!valid.value) console.warn(`[RooCountdown] endsAt "${String(props.endsAt)}" is not a time. Pass an ISO string or milliseconds.`)

const secondsLeft = ref(valid.value ? Math.max(0, Math.ceil((endMs.value - Date.now()) / 1000)) : 0)
const warned = ref(false)
const expired = ref(false)
let timer: ReturnType<typeof setInterval> | undefined

function read(): void {
  if (!valid.value) return
  secondsLeft.value = Math.max(0, Math.ceil((endMs.value - Date.now()) / 1000))
  if (secondsLeft.value === 0) {
    stop()
    if (!expired.value) {
      expired.value = true
      announcer.announce('Time is up', { assertive: true })
      emit('expired')
    }
    return
  }
  if (secondsLeft.value <= props.warnSeconds && !warned.value) {
    warned.value = true
    announcer.announce(`Less than ${props.warnSeconds >= 60 && props.warnSeconds % 60 === 0 ? `${props.warnSeconds / 60} min` : `${props.warnSeconds} s`} left`)
  }
}

function start(): void {
  stop()
  if (!valid.value || expired.value) return
  timer = setInterval(read, 1000)
}

function stop(): void {
  clearInterval(timer)
  timer = undefined
}

function onVisibilityChange(): void {
  if (document.hidden) {
    stop()
    return
  }
  read()
  start()
}

onMounted(() => {
  read()
  if (!document.hidden) start()
  document.addEventListener('visibilitychange', onVisibilityChange)
})

onBeforeUnmount(() => {
  stop()
  document.removeEventListener('visibilitychange', onVisibilityChange)
})

watch(endMs, () => {
  warned.value = false
  expired.value = false
  read()
  if (!document.hidden) start()
})

const state = computed(() => (!valid.value ? 'unknown' : expired.value ? 'expired' : secondsLeft.value <= props.warnSeconds ? 'warn' : 'ok'))
const figure = computed(() => {
  if (!valid.value) return '--:--'
  const minutes = Math.floor(secondsLeft.value / 60)
  const seconds = secondsLeft.value % 60
  return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`
})
const trailing = computed(() => (expired.value ? props.expiredText : props.suffix))
</script>

<template>
  <span class="roo-countdown" role="timer" :data-state="state">
    <time class="roo-countdown-figure" :datetime="valid ? new Date(endMs).toISOString() : undefined">{{ figure }}</time>{{ ' ' }}<span v-if="trailing" class="roo-countdown-suffix">{{ trailing }}</span>
  </span>
</template>

<style scoped>
@layer roo-components {
  .roo-countdown {
    display: inline-flex;
    align-items: baseline;
    gap: var(--roo-p-space-1);
    color: var(--roo-text);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-ui-size);
    white-space: nowrap;
    transition: color var(--roo-fast) var(--roo-ease);
  }

  /* Tabular digits and a fixed-width figure: 09:59 to 10:00 never moves the words beside it. */
  .roo-countdown-figure {
    font-variant-numeric: tabular-nums;
    font-weight: var(--roo-p-weight-medium);
    letter-spacing: 0;
  }

  .roo-countdown-suffix {
    color: var(--roo-muted);
  }

  /* Warn: the warn colour and the heavier weight together, so a reader who cannot tell the colour still sees the change. */
  .roo-countdown[data-state='warn'],
  .roo-countdown[data-state='expired'] {
    color: var(--roo-warn);
  }

  .roo-countdown[data-state='warn'] .roo-countdown-figure,
  .roo-countdown[data-state='expired'] .roo-countdown-figure {
    font-weight: 700;
  }

  .roo-countdown[data-state='warn'] .roo-countdown-suffix,
  .roo-countdown[data-state='expired'] .roo-countdown-suffix {
    color: inherit;
  }
}
</style>
