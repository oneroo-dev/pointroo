<script setup lang="ts">
import { computed } from 'vue'

export type RooStateMarkState = 'ok' | 'warn' | 'err' | 'muted' | 'running'

const props = defineProps<{
  state: RooStateMarkState
  /** The word. Mandatory: a dot alone is colour alone. For `running` it defaults to "Running". */
  label?: string
}>()

const shownLabel = computed(() => props.label ?? (props.state === 'running' ? 'Running' : ''))

if (!shownLabel.value.trim()) {
  console.warn('[RooStateMark] label is empty. A state mark must say its state in words.')
}

// Each state has its own shape, so colour is never the only signal.
const shapes: Record<RooStateMarkState, string> = {
  ok: 'circle',
  warn: 'diamond',
  err: 'square',
  muted: 'ring',
  running: 'arc',
}
</script>

<template>
  <span class="roo-state-mark" :data-state="state">
    <span class="roo-state-mark-dot" :data-shape="shapes[state]" aria-hidden="true" />
    <span class="roo-state-mark-label">{{ shownLabel }}</span>
  </span>
</template>

<style scoped>
@layer roo-components {
  .roo-state-mark {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-1);
    font-size: var(--roo-p-size-12);
    white-space: nowrap;
  }

  .roo-state-mark-dot {
    flex: none;
    width: 8px;
    height: 8px;
    box-sizing: border-box;
    border-radius: var(--roo-p-radius-pill);
    background: currentColor;
  }

  .roo-state-mark-dot[data-shape='diamond'] {
    border-radius: var(--roo-p-radius-hair);
    transform: rotate(45deg) scale(0.875);
  }

  .roo-state-mark-dot[data-shape='square'] {
    border-radius: var(--roo-p-radius-hair);
  }

  .roo-state-mark-dot[data-shape='ring'] {
    background: transparent;
    border: 1.5px solid currentColor;
  }

  /* Running: an open ring with a gap, turning. It turns in the muted colour. */
  .roo-state-mark-dot[data-shape='arc'] {
    background: transparent;
    border: 1.5px solid currentColor;
    border-top-color: transparent;
    animation: roo-state-mark-spin 900ms linear infinite;
  }

  @media (prefers-reduced-motion: reduce) {
    .roo-state-mark-dot[data-shape='arc'] {
      animation: none;
    }
  }

  /* Running is neutral (Raja, 2026-11-21): the word is plain text colour and only the turning arc is muted. */
  .roo-state-mark[data-state='running'] {
    color: var(--roo-text);
  }

  .roo-state-mark[data-state='running'] .roo-state-mark-dot {
    color: var(--roo-muted);
  }

  .roo-state-mark[data-state='ok'] {
    color: var(--roo-ok-text);
  }

  .roo-state-mark[data-state='warn'] {
    color: var(--roo-warn);
  }

  .roo-state-mark[data-state='err'] {
    color: var(--roo-danger-text);
  }

  .roo-state-mark[data-state='muted'] {
    color: var(--roo-muted);
  }
}
</style>

<style>
@keyframes roo-state-mark-spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
