<script lang="ts">
export type RooSortDirection = 'ascending' | 'descending' | 'none'

/** The next direction a press asks for: none goes to ascending, ascending to descending, descending back to none. */
export function nextSortDirection(current: RooSortDirection): RooSortDirection {
  if (current === 'none') return 'ascending'
  return current === 'ascending' ? 'descending' : 'none'
}
</script>

<script setup lang="ts">
// A table header cell that sorts. The cell carries aria-sort, the button inside it is the keyboard target (Enter and
// Space work as on any button), and the arrow is always drawn: a pair of faint arrows when the column is not sorted, a
// single arrow when it is, so the state never rests on colour.
import { computed } from 'vue'
import RooIcon from './RooIcon.vue'

defineProps<{ label: string; align?: 'start' | 'end' }>()
const direction = defineModel<RooSortDirection>('direction', { default: 'none' })
const emit = defineEmits<{ sort: [direction: RooSortDirection] }>()

const icon = computed(() => (direction.value === 'ascending' ? 'arrow-up' : direction.value === 'descending' ? 'arrow-down' : 'chevrons-up-down'))
const nextWord = computed(() => {
  const next = nextSortDirection(direction.value)
  return next === 'none' ? 'Clear sort' : `Sort ${next}`
})

function press(): void {
  direction.value = nextSortDirection(direction.value)
  emit('sort', direction.value)
}
</script>

<template>
  <th class="roo-sort-header" scope="col" :aria-sort="direction" :data-align="align ?? 'start'">
    <button type="button" class="roo-sort-button" :data-direction="direction" :title="nextWord" @click="press">
      <span class="roo-sort-label">{{ label }}</span>
      <RooIcon class="roo-sort-arrow" :name="icon" :size="16" />
      <span class="roo-visually-hidden">{{ nextWord }}</span>
    </button>
  </th>
</template>

<style scoped>
@layer roo-components {
  .roo-sort-header {
    padding: 0;
    text-align: start;
    font-weight: 500;
  }

  .roo-sort-header[data-align='end'] {
    text-align: end;
  }

  .roo-sort-button {
    display: inline-flex;
    height: var(--roo-control-h);
    box-sizing: border-box;
    align-items: center;
    gap: 4px;
    border: 0;
    border-radius: var(--roo-p-radius-small);
    background: transparent;
    padding-inline: 8px;
    color: var(--roo-muted);
    font-family: inherit;
    font-size: var(--roo-p-size-12);
    font-weight: 500;
    cursor: default;
    user-select: none;
    transition:
      background-color var(--roo-fast) var(--roo-ease),
      color var(--roo-fast) var(--roo-ease),
      transform var(--roo-fast) var(--roo-spring);
  }

  .roo-sort-button:hover,
  .roo-sort-button[data-direction='ascending'],
  .roo-sort-button[data-direction='descending'] {
    color: var(--roo-text);
  }

  .roo-sort-button:hover {
    background: var(--roo-raised);
  }

  .roo-sort-button:active {
    transform: scale(0.98);
  }

  .roo-sort-button:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 1px;
  }

  .roo-sort-button[data-direction='none'] .roo-sort-arrow {
    opacity: 0.6;
  }

  /* An invisible tap area at least --roo-touch-target tall on a coarse pointer. The visible box and the layout do not change.
     Height only: the width stays the button's own, so the hit areas of neighbouring headers never overlap. */
  @media (pointer: coarse) {
    .roo-sort-button {
      position: relative;
    }

    .roo-sort-button::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2)) 0;
    }
  }
}
</style>
