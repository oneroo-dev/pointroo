<script lang="ts">
// How many skeletons sit in each region right now. The region is aria-busy while the count is above zero, and the
// attribute is only removed when this component was the one that set it.
const busyCounts = new WeakMap<Element, { count: number; setByKit: boolean }>()

function markBusy(region: Element): void {
  const entry = busyCounts.get(region) ?? { count: 0, setByKit: !region.hasAttribute('aria-busy') }
  entry.count += 1
  busyCounts.set(region, entry)
  if (entry.setByKit) region.setAttribute('aria-busy', 'true')
}

function clearBusy(region: Element): void {
  const entry = busyCounts.get(region)
  if (!entry) return
  entry.count -= 1
  if (entry.count > 0) return
  busyCounts.delete(region)
  if (entry.setByKit) region.removeAttribute('aria-busy')
}
</script>

<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'

const props = withDefaults(
  defineProps<{
    /** How many placeholder rows. Ignored by a block. */
    rows?: number
    /** Row pitch in px for a denser list (20 for Tableroo's grid). The default is the density row height token. */
    pitch?: number | undefined
    /** A list-row placeholder: an avatar circle, a title bar and a meta bar on one line, as tall as the list row token. `rows` repeats it. */
    row?: boolean
    /** Drop the row's side padding, so the leading bar starts on the container's own edge: for a table or list whose first column sits flush with it. */
    flush?: boolean
    /** One block placeholder (a card, a chart, an avatar) instead of rows of text bars. */
    block?: boolean
    /** A block's width, as a CSS length. Defaults to the full width of its container. */
    width?: string | undefined
    /** A block's height, as a CSS length. Defaults to the row height token. */
    height?: string | undefined
    /** A block's corner: a CSS length, or `round` for a circle (an avatar). */
    radius?: string | undefined
    /** Mark the parent region aria-busy while this is mounted. Turn it off when the region manages aria-busy itself. */
    markRegionBusy?: boolean
  }>(),
  { rows: 3, pitch: undefined, block: false, row: false, flush: false, width: undefined, height: undefined, radius: undefined, markRegionBusy: true },
)

const root = ref<HTMLElement | null>(null)
let busyRegion: Element | null = null

onMounted(() => {
  if (!props.markRegionBusy || !root.value?.parentElement) return
  busyRegion = root.value.parentElement
  markBusy(busyRegion)
})

onBeforeUnmount(() => {
  if (busyRegion) clearBusy(busyRegion)
  busyRegion = null
})

const rootStyle = computed(() => {
  const style: Record<string, string> = {}
  if (props.pitch !== undefined) style['--roo-skeleton-pitch'] = `${props.pitch}px`
  if (props.block) {
    if (props.width) style['--roo-skeleton-width'] = props.width
    if (props.height) style['--roo-skeleton-height'] = props.height
    if (props.radius) style['--roo-skeleton-radius'] = props.radius === 'round' ? '50%' : props.radius
  }
  return Object.keys(style).length > 0 ? style : undefined
})

// A varied width per row so a column of placeholders does not read as a block.
const widths = [92, 78, 86, 64, 90, 72]
</script>

<template>
  <div ref="root" class="roo-skeleton" :data-block="block ? 'true' : undefined" :data-flush="flush ? 'true' : undefined" aria-hidden="true" :style="rootStyle">
    <span v-if="block" class="roo-skeleton-bar roo-skeleton-block" />
    <template v-else-if="row">
      <div v-for="index in rows" :key="index" class="roo-skeleton-list-row">
        <span class="roo-skeleton-bar roo-skeleton-avatar" />
        <span class="roo-skeleton-list-text">
          <span class="roo-skeleton-bar" :style="{ width: `${widths[(index - 1) % widths.length]}%` }" />
          <span class="roo-skeleton-bar roo-skeleton-meta" :style="{ width: `${(widths[(index + 2) % widths.length] ?? 60) * 0.6}%` }" />
        </span>
      </div>
    </template>
    <template v-else>
      <div v-for="index in rows" :key="index" class="roo-skeleton-row">
        <span class="roo-skeleton-bar" :style="{ width: `${widths[(index - 1) % widths.length]}%` }" />
      </div>
    </template>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-skeleton {
    display: flex;
    flex-direction: column;
  }

  .roo-skeleton[data-block='true'] {
    width: var(--roo-skeleton-width, 100%);
    max-width: 100%;
  }

  .roo-skeleton-row {
    display: flex;
    height: var(--roo-skeleton-pitch, var(--roo-row-h));
    align-items: center;
    padding: 0 var(--roo-row-pad-inline);
  }

  .roo-skeleton-list-row {
    display: flex;
    height: var(--roo-list-row-h);
    align-items: center;
    gap: var(--roo-p-space-3);
    padding: 0 var(--roo-list-row-pad-inline);
  }

  .roo-skeleton[data-flush='true'] .roo-skeleton-row,
  .roo-skeleton[data-flush='true'] .roo-skeleton-list-row {
    padding-inline: 0;
  }

  /* Two classes, so the avatar keeps its tile size over the bar's own height whatever the order of the rules: a circle, not a pill. */
  .roo-skeleton-bar.roo-skeleton-avatar {
    flex: none;
    width: var(--roo-icon-tile);
    height: var(--roo-icon-tile);
    border-radius: 50%;
  }

  .roo-skeleton-list-text {
    display: flex;
    min-width: 0;
    flex: 1;
    flex-direction: column;
    gap: var(--roo-p-space-1);
  }

  .roo-skeleton-list-text .roo-skeleton-meta {
    height: var(--roo-p-space-2);
  }

  .roo-skeleton-bar {
    height: var(--roo-p-space-3);
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-skeleton);
    animation: roo-skeleton-fade 1600ms var(--roo-ease) infinite;
  }

  .roo-skeleton-block {
    display: block;
    width: 100%;
    height: var(--roo-skeleton-height, var(--roo-row-h));
    border-radius: var(--roo-skeleton-radius, var(--roo-p-radius-card));
  }

  /* The web draws a moving highlight instead of the pulse. :not([data-surface='desktop'] *) keeps it off the desktop surface,
     whether the attribute is on <html> or on a container, so the desktop bar keeps today's opacity pulse and the desktop
     functional list does not change. The highlight is also hidden under reduced motion and data-motion="still". */
  .roo-skeleton-bar:not([data-surface='desktop'] *) {
    position: relative;
    overflow: hidden;
    animation: none;
  }

  .roo-skeleton-bar:not([data-surface='desktop'] *)::after {
    content: '';
    position: absolute;
    inset: 0;
    background: linear-gradient(90deg, transparent, color-mix(in srgb, var(--roo-text) 9%, transparent), transparent);
    transform: translateX(-100%);
    animation: roo-skeleton-shimmer 1600ms var(--roo-ease) infinite;
  }

  @media (prefers-reduced-motion: reduce) {
    .roo-skeleton-bar::after {
      display: none;
    }
  }

  .roo-force-reduced .roo-skeleton-bar::after,
  [data-motion='still'] .roo-skeleton-bar::after {
    display: none;
  }

  @keyframes roo-skeleton-shimmer {
    from { transform: translateX(-100%); }
    to { transform: translateX(100%); }
  }

  /* Opacity only. The reduced-motion layer ends it after one pass, which leaves the bar still and solid. */
  @keyframes roo-skeleton-fade {
    0%, 100% { opacity: 1; }
    50% { opacity: 0.55; }
  }
}
</style>
