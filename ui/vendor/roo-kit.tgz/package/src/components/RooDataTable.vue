<script lang="ts">
export interface RooDataTableColumn {
  id: string
  label: string
  align?: 'start' | 'end'
  /** Draw the header and the cells in the muted colour (a dim column, such as a hidden attribute). */
  muted?: boolean
  /** A small word after the label, such as "hidden". */
  tag?: string
  /** Draw the cells in the mono font (ids, emails, keys). */
  mono?: boolean
  /** `fit` is as wide as its content and no wider than six control heights, so a stray long value cannot blow the table up; `grow` takes the slack
   *  and never gets narrower than three control heights. A column with no hint is `auto`: it shares the remaining width and ends in an ellipsis.
   *  When no column has a hint, the first text column (not `align: 'end'`) grows. Fit is a hint only when the column says so. */
  width?: 'fit' | 'grow'
  /** Server mode keeps a fixed layout, so a fit column is sized from this: the larger of the header length and `fitChars`, in ch, plus the cell padding. */
  fitChars?: number
}

/** Text longer than this gets the tooltip with the whole value. The CSS does the cutting; this only decides who needs a tooltip. */
export const DATA_TABLE_CUT_LENGTH = 40
</script>

<script setup lang="ts">
// A table for rows the app already holds. The app passes columns and rows; the table owns only what you see: the sort, the
// search text, the hidden columns and the page. Sort, search and hidden columns are v-models, so an app can keep them or
// let the table keep them. It draws one page at a time (50 rows), so it needs no virtual scrolling. Sorting and searching
// use sortRows and filterRows from RooDataTableRows, which an app can run itself for an export.
// The header is sticky and so is the first column. A selected row (when the app gives a `rowKey`) uses the kit selection
// mark, never a stripe. Long text is cut with an ellipsis and carries a tooltip when a RooTooltipProvider is above the table.
// Server mode (`mode="server"`): the app holds one page and the table draws exactly the rows it is given, with no filtering,
// sorting or slicing here. The pager is keyset: the table emits `next` and `previous` (with the cursor the app passed in
// `nextCursor` and `previousCursor`) and the app fetches. Loading, empty and error (with retry) all keep the box the same
// height. `selectable="multi"` adds a checkbox column, a tri-state header checkbox for the rows on screen, and a selection
// that is kept across pages by row key. Density is the page's: the table follows
// data-density on <html> through --roo-row-h and the other density tokens, and never sets it for its own subtree.
// In server mode the scroll box has a minimum height of 8 rows plus the header, so loading, empty and error keep the box
// of a page of up to 8 rows (a longer page grows past it).
// A `row-actions` button must fit the row (RooIconButton size xxs, 20px): a taller one makes its rows taller than the loading rows.
// Keys: ArrowUp, ArrowDown, Home and End move the row focus; Enter opens the row of a table with `rowClick="open"`, else presses the row's actions button; Space selects the row.
// Selectable tables: by default (`rowClick="select"`) a row click toggles the checkbox. `rowClick="open"` is the opt-in where a row click opens the row (`update:selected`) and only the checkbox selects.
import { injectTooltipProviderContext } from 'reka-ui'
import { computed, onBeforeUnmount, onMounted, ref, watch, type VNodeChild } from 'vue'
import RooButton from './RooButton.vue'
import RooIcon from './RooIcon.vue'
import RooIconButton from './RooIconButton.vue'
import RooInput from './RooInput.vue'
import RooMenu from './RooMenu.vue'
import RooMenuItem from './RooMenuItem.vue'
import RooPopover from './RooPopover.vue'
import RooTooltip from './RooTooltip.vue'
import RooCheckbox from './RooCheckbox.vue'
import RooSkeleton from './RooSkeleton.vue'
import {
  cellText,
  cycleSort,
  filterRows,
  pageCount,
  pageSlice,
  selectionState,
  serverRangeText,
  sortRows,
  toggleKey,
  togglePageSelection,
  type RooDataTableKey,
  type RooDataTableRow,
  type RooDataTableSort,
} from './RooDataTableRows'

const props = withDefaults(
  defineProps<{
    columns: RooDataTableColumn[]
    rows: RooDataTableRow[]
    pageSize?: number
    /** The real number of rows when the app only holds the first part of them: "First 500 of 12,340 rows". */
    total?: number | undefined
    pinFirstColumn?: boolean
    /** What the filters do when the toolbar is narrow (520 px or less). `wrap` (default) lets them wrap onto their own rows beside Columns; `popover` keeps the toolbar on one row: search, a Filters button and Columns, with the filters in a panel under the button. */
    narrowFilters?: 'wrap' | 'popover'
    /** How many filters are set, shown on the Filters button of the `popover` form. The table does not know the filters, so the app says. */
    activeFilterCount?: number
    emptyText?: string
    /** The column that tells rows apart. Give it to make rows selectable. */
    rowKey?: string | undefined
    /** `client` (the default) sorts, filters and pages the rows here; `server` draws the rows as given and asks the app for more. */
    mode?: 'client' | 'server'
    /** Server mode: a page follows this one. */
    hasNext?: boolean
    /** Server mode: a page comes before this one. */
    hasPrevious?: boolean
    /** Server mode: the number of the page on screen, from 1. Only for the foot line; there is no jump to a page. */
    page?: number
    /** Server mode: the cursor sent with `next`. */
    nextCursor?: string | null | undefined
    /** Server mode: the cursor sent with `previous`. */
    previousCursor?: string | null | undefined
    /** Server mode: wait this long after typing before the search model changes. */
    searchDebounceMs?: number
    /** Server mode: the rows are on their way. Skeleton rows fill the same box. */
    loading?: boolean
    /** Server mode: the load failed. The message shows in the same box with a retry button. */
    error?: string | undefined
    /** `multi` adds a checkbox column and a header checkbox; needs `rowKey`. */
    selectable?: 'none' | 'multi'
    /** What a click on a row of a `selectable="multi"` table does. `select` (default) toggles the row's checkbox and nothing opens. `open` is the opt-in: the row click opens the row (`update:selected` carries its key), only the checkbox selects, and Enter opens the focused row. */
    rowClick?: 'open' | 'select'
    /** `false` drops the toolbar (search, filters, Columns) for a short read-only list such as an invoice history. Default true. */
    toolbar?: boolean
  }>(),
  {
    pageSize: 50,
    total: undefined,
    pinFirstColumn: true,
    narrowFilters: 'wrap',
    activeFilterCount: 0,
    emptyText: 'No rows',
    rowKey: undefined,
    mode: 'client',
    hasNext: false,
    hasPrevious: false,
    page: 1,
    nextCursor: undefined,
    previousCursor: undefined,
    searchDebounceMs: 300,
    loading: false,
    error: undefined,
    selectable: 'none',
    rowClick: 'select',
    toolbar: true,
  },
)

const emit = defineEmits<{
  next: [cursor: string | null | undefined]
  previous: [cursor: string | null | undefined]
  retry: []
}>()

const search = defineModel<string>('search', { default: '' })
const sort = defineModel<RooDataTableSort | null>('sort', { default: null })
const hiddenColumns = defineModel<string[]>('hiddenColumns', { default: () => [] })
/** The `rowKey` value of the selected row. */
const selected = defineModel<string | number | undefined>('selected')
/** Multi-select: the `rowKey` values of every checked row, across pages. */
const selection = defineModel<RooDataTableKey[]>('selection', { default: () => [] })

const slots = defineSlots<{
  cell?: (scope: { column: RooDataTableColumn; row: RooDataTableRow; value: unknown }) => unknown
  'row-actions'?: (scope: { row: RooDataTableRow }) => unknown
  'toolbar-end'?: () => unknown
  /** Between the search field and the Columns menu. */
  filters?: () => unknown
  /** Replaces the toolbar's left side while rows are checked. */
  'bulk-actions'?: (scope: { selection: RooDataTableKey[]; count: number; clear: () => void }) => unknown
}>()

// A stand-in for the tooltip when there is no provider: the cell goes through untouched.
const PassThrough = (_: unknown, { slots }: { slots: { default?: () => VNodeChild } }): VNodeChild => slots.default?.()
const hasTooltipProvider = injectTooltipProviderContext(null as never) !== null

const shownColumns = computed(() => props.columns.filter((column) => !hiddenColumns.value.includes(column.id)))
const shownIds = computed(() => shownColumns.value.map((column) => column.id))
const effectiveSort = computed(() => (sort.value !== null && shownIds.value.includes(sort.value.column) ? sort.value : null))

const server = computed(() => props.mode === 'server')

// The toolbar's own width decides the `popover` form of the filters, the same 520 px the narrow CSS below asks (the table can sit in a narrow pane).
const NARROW_TOOLBAR = 520
const toolbarBox = ref<HTMLElement | null>(null)
const toolbarNarrow = ref(false)
let toolbarObserver: ResizeObserver | undefined
onMounted(() => {
  if (!toolbarBox.value || typeof ResizeObserver === 'undefined') return
  toolbarObserver = new ResizeObserver(([entry]) => {
    toolbarNarrow.value = (entry?.contentRect.width ?? Infinity) <= NARROW_TOOLBAR
  })
  toolbarObserver.observe(toolbarBox.value)
})
onBeforeUnmount(() => toolbarObserver?.disconnect())
const multi = computed(() => props.selectable === 'multi' && props.rowKey !== undefined)

const matching = computed(() => (server.value ? props.rows : filterRows(props.rows, search.value, shownIds.value)))
const ordered = computed(() => (server.value ? props.rows : sortRows(matching.value, effectiveSort.value)))

const clientPage = ref(1)
const pages = computed(() => pageCount(ordered.value.length, props.pageSize))
const visibleRows = computed(() => (server.value ? props.rows : pageSlice(ordered.value, clientPage.value, props.pageSize)))
watch([() => search.value, () => sort.value], () => {
  clientPage.value = 1
})
watch(pages, (count) => {
  if (clientPage.value > count) clientPage.value = count
})

// Server mode types into a draft and only changes the search model once typing has paused.
const draft = ref(search.value)
let debounceTimer: ReturnType<typeof setTimeout> | undefined
watch(search, (value) => {
  if (value !== draft.value) draft.value = value
})
const searchText = computed<string>({
  get: () => (server.value ? draft.value : search.value),
  set: (value) => {
    if (!server.value) {
      search.value = value
      return
    }
    draft.value = value
    clearTimeout(debounceTimer)
    if (props.searchDebounceMs <= 0) search.value = value
    else debounceTimer = setTimeout(() => (search.value = value), props.searchDebounceMs)
  },
})
onBeforeUnmount(() => clearTimeout(debounceTimer))

const searching = computed(() => search.value.trim() !== '')
function numberText(value: number): string {
  return value.toLocaleString('en-US')
}
// Server foot: the range of the last page that loaded stays through loading and error, and the foot is empty until a page has loaded.
const lastRange = ref('')
watch(
  [server, () => props.loading, () => props.error, () => props.rows, () => props.page, () => props.pageSize, () => props.total],
  () => {
    if (server.value && !props.loading && !props.error) lastRange.value = serverRangeText(props.page, props.pageSize, props.rows.length, props.total)
  },
  { immediate: true },
)
const countLine = computed(() => {
  if (showEmpty.value && !searching.value) return '0 rows'
  if (server.value) return props.loading || props.error ? lastRange.value : serverRangeText(props.page, props.pageSize, props.rows.length, props.total)
  if (searching.value) return `${numberText(matching.value.length)} of ${numberText(props.rows.length)} rows match`
  if (props.total !== undefined && props.total > props.rows.length) return `First ${numberText(props.rows.length)} of ${numberText(props.total)} rows`
  return props.rows.length === 1 ? '1 row' : `${numberText(props.rows.length)} rows`
})

function sortState(column: RooDataTableColumn): 'ascending' | 'descending' | 'none' {
  if (effectiveSort.value?.column !== column.id) return 'none'
  return effectiveSort.value.direction === 'asc' ? 'ascending' : 'descending'
}

function toggleSort(column: RooDataTableColumn): void {
  sort.value = cycleSort(effectiveSort.value, column.id)
}

function toggleColumn(columnId: string): void {
  if (hiddenColumns.value.includes(columnId)) hiddenColumns.value = hiddenColumns.value.filter((id) => id !== columnId)
  else if (shownColumns.value.length > 1) hiddenColumns.value = [...hiddenColumns.value, columnId]
}

function isCut(value: unknown): boolean {
  return typeof value === 'string' && value.length > DATA_TABLE_CUT_LENGTH
}

function keyOf(row: RooDataTableRow): unknown {
  return props.rowKey === undefined ? undefined : row[props.rowKey]
}

function isChecked(row: RooDataTableRow): boolean {
  return multi.value && selection.value.includes(keyOf(row) as RooDataTableKey)
}

function isSelected(row: RooDataTableRow): boolean {
  if (multi.value) return isChecked(row)
  return props.rowKey !== undefined && selected.value !== undefined && keyOf(row) === selected.value
}

/** The row a click opened in a `rowClick="open"` table. It wears the selection look (roo-selected-row) plus its own roo-opened-row and aria-current; aria-selected still follows the checkbox. */
function isOpened(row: RooDataTableRow): boolean {
  return multi.value && props.rowClick === 'open' && props.rowKey !== undefined && selected.value !== undefined && keyOf(row) === selected.value
}

const pageKeys = computed(() => (multi.value ? visibleRows.value.map((row) => keyOf(row) as RooDataTableKey) : []))
const headerState = computed(() => selectionState(pageKeys.value, selection.value))
const selectionCount = computed(() => selection.value.length)
const bulking = computed(() => multi.value && selectionCount.value > 0 && !!slots['bulk-actions'])

function toggleHeader(): void {
  selection.value = togglePageSelection(pageKeys.value, selection.value)
}

function toggleRow(row: RooDataTableRow): void {
  selection.value = toggleKey(keyOf(row) as RooDataTableKey, selection.value)
}

function clearSelection(): void {
  selection.value = []
}

const SKELETON_ROWS = 8
const skeletonCount = computed(() => Math.min(10, Math.max(SKELETON_ROWS, visibleRows.value.length)))
const showEmpty = computed(() => !props.loading && !props.error && visibleRows.value.length === 0)
const columnSizing = computed(() => {
  const anyHint = props.columns.some((column) => column.width !== undefined)
  const firstText = shownColumns.value.find((column) => column.align !== 'end')
  return new Map(shownColumns.value.map((column) => [column.id, column.width ?? (!anyHint && column === firstText ? 'grow' : 'auto')] as const))
})
// Every shown column fit (either mode): the last one takes the leftover, so the table never spreads it over the checkbox column.
const leftoverColumnId = computed(() => {
  if (shownColumns.value.length === 0) return undefined
  const sizes = [...columnSizing.value.values()]
  return sizes.some((size) => size === 'grow' || size === 'auto') ? undefined : shownColumns.value[shownColumns.value.length - 1]!.id
})
// A fit column of a fixed layout (server mode) is as wide as the larger of its header and fitChars, in ch.
function fitCharacters(column: RooDataTableColumn): number {
  const header = column.label.length + (column.tag ? column.tag.length + 1 : 0) + 3
  return Math.max(header, column.fitChars ?? 0)
}
function fitStyle(column: RooDataTableColumn): Record<string, string> | undefined {
  return server.value && columnSizing.value.get(column.id) === 'fit' ? { '--roo-data-table-fit-chars': String(fitCharacters(column)) } : undefined
}
// Server mode keeps a fixed layout, which ignores a cell's min-width, so a table wider than its pane gave the grow column nothing (it drew 0 px wide, and
// the pinned first column vanished). The table's own minimum is the sum of what each column needs, and the pane then scrolls sideways under the pinned column.
const tableStyle = computed(() => {
  if (!server.value) return undefined
  const parts: string[] = []
  if (multi.value) parts.push('var(--roo-data-table-check-w)')
  for (const column of shownColumns.value) {
    parts.push(columnSizing.value.get(column.id) === 'fit' ? `(${fitCharacters(column)} * 1.1 * 1ch + 2 * var(--roo-row-pad-inline))` : '(var(--roo-control-h) * 3)')
  }
  if (slots['row-actions']) parts.push('(var(--roo-icon-button) + var(--roo-row-pad-inline) * 2)')
  return parts.length > 0 ? { minWidth: `calc(${parts.join(' + ')})` } : undefined
})
// The `popover` form keeps one toolbar row on a narrow toolbar even when there are no filters (search and Columns then share the row).
const oneRowToolbar = computed(() => props.narrowFilters === 'popover' && toolbarNarrow.value)
const filtersInPopover = computed(() => props.narrowFilters === 'popover' && toolbarNarrow.value && slots.filters !== undefined)
const showRows = computed(() => !props.loading && !props.error)
// A page count is shown only when it is true: a server total gives ceil(total / page size); client rows that are only a first
// slice of a larger total, or a cursor with no total, give no count, so the label reads "Page 1" and never "Page 1 of 1".
const pageLabel = computed(() => {
  if (server.value) return props.total === undefined ? `Page ${props.page}` : `Page ${props.page} of ${Math.max(1, pageCount(props.total, props.pageSize))}`
  if (props.total !== undefined && props.total > props.rows.length) return `Page ${clientPage.value}`
  return `Page ${clientPage.value} of ${pages.value}`
})
const hasPrevPage = computed(() => (server.value ? props.hasPrevious : clientPage.value > 1))
const hasNextPage = computed(() => (server.value ? props.hasNext : clientPage.value < pages.value))

function previousPage(): void {
  if (server.value) emit('previous', props.previousCursor)
  else clientPage.value -= 1
}

function nextPage(): void {
  if (server.value) emit('next', props.nextCursor)
  else clientPage.value += 1
}

const body = ref<HTMLElement | null>(null)
const focusedRow = ref(0)
watch(visibleRows, () => {
  if (focusedRow.value >= visibleRows.value.length) focusedRow.value = Math.max(0, visibleRows.value.length - 1)
})

function focusRow(index: number): void {
  const rowElements = body.value?.querySelectorAll<HTMLElement>(':scope > tr') ?? []
  const target = Math.min(Math.max(0, index), rowElements.length - 1)
  focusedRow.value = target
  rowElements[target]?.focus()
}

function openRow(row: RooDataTableRow): void {
  if (props.rowKey !== undefined) selected.value = keyOf(row) as string | number
}

function selectRow(row: RooDataTableRow): void {
  if (multi.value && props.rowClick === 'select') toggleRow(row)
  else if (multi.value) openRow(row)
  else if (props.rowKey !== undefined) selected.value = keyOf(row) as string | number
}

const ROW_CLICK_IGNORED = 'button, a, input, select, textarea, [role=menuitem]'
// Opening rows: the whole check cell belongs to the checkbox, so its padding and label never open the row.
const rowClickIgnoredSelector = computed(() => (multi.value && props.rowClick === 'open' ? `${ROW_CLICK_IGNORED}, .roo-data-table-check` : ROW_CLICK_IGNORED))

function onRowClick(event: MouseEvent, row: RooDataTableRow, index: number): void {
  focusedRow.value = index
  if ((event.target as Element | null)?.closest(rowClickIgnoredSelector.value)) return
  selectRow(row)
}

function onRowKeydown(event: KeyboardEvent, row: RooDataTableRow, index: number): void {
  if (event.target !== event.currentTarget) return
  if (event.key === 'ArrowDown') focusRow(index + 1)
  else if (event.key === 'ArrowUp') focusRow(index - 1)
  else if (event.key === 'Home') focusRow(0)
  else if (event.key === 'End') focusRow(visibleRows.value.length - 1)
  else if (event.key === ' ' && multi.value) toggleRow(row)
  else if (event.key === ' ' && props.rowKey !== undefined) selectRow(row)
  else if (event.key === 'Enter' && multi.value && props.rowClick === 'open') openRow(row)
  else if (event.key === 'Enter') {
    const rowElement = event.currentTarget as HTMLElement
    const button = rowElement.querySelector<HTMLElement>('[data-row-actions], .roo-data-table-actions button')
    if (!button) return
    button.click()
  } else return
  event.preventDefault()
}
</script>

<template>
  <div
    class="roo-data-table-root"
    :data-mode="server ? 'server' : undefined"
    :aria-busy="loading ? 'true' : undefined"
  >
    <div v-if="toolbar" ref="toolbarBox" class="roo-data-table-toolbar-box">
    <div class="roo-data-table-toolbar" :data-filters-popover="oneRowToolbar ? 'true' : undefined">
      <div v-if="bulking" class="roo-data-table-bulk" role="toolbar" aria-label="Bulk actions">
        <slot name="bulk-actions" :selection="selection" :count="selectionCount" :clear="clearSelection" />
      </div>
      <template v-else>
      <RooInput v-model="searchText" class="roo-data-table-search" data-align-box size="md" aria-label="Search rows" placeholder="Search rows">
        <template #leading><RooIcon name="search" :size="16" /></template>
        <template v-if="searchText !== ''" #trailing>
          <RooIconButton icon="x" label="Clear search" size="xs" @click="searchText = ''" />
        </template>
      </RooInput>
      <RooPopover v-if="filtersInPopover" label="Filters" align="end" :width="280">
        <template #trigger>
          <RooButton class="roo-data-table-filters-button" size="sm" :aria-label="activeFilterCount > 0 ? `Filters, ${activeFilterCount} set` : 'Filters'">
            <template #icon><RooIcon name="filter" :size="16" /></template>
            <span v-if="activeFilterCount > 0" class="roo-data-table-columns-count">{{ activeFilterCount }}</span>
          </RooButton>
        </template>
        <div class="roo-data-table-filters-panel"><slot name="filters" /></div>
      </RooPopover>
      <span v-else class="roo-data-table-filters"><slot name="filters" /></span>
      <RooMenu align="start">
        <template #trigger>
          <RooButton class="roo-data-table-columns" size="sm" :aria-label="`Columns, ${shownColumns.length} of ${columns.length} shown`">
            <template #icon><RooIcon name="columns" :size="16" /></template>
            <span class="roo-data-table-columns-label">Columns</span>
            <span class="roo-data-table-columns-count">{{ shownColumns.length }} of {{ columns.length }}</span>
          </RooButton>
        </template>
        <RooMenuItem
          v-for="column in columns"
          :key="column.id"
          :checked="!hiddenColumns.includes(column.id)"
          :disabled="!hiddenColumns.includes(column.id) && shownColumns.length === 1"
          @select.prevent="toggleColumn(column.id)"
        >
          {{ column.label }}
        </RooMenuItem>
      </RooMenu>
      </template>
      <span class="roo-data-table-toolbar-end"><slot name="toolbar-end" /></span>
    </div>
    </div>

    <div class="roo-data-table-scroll" :data-mode="server ? 'server' : undefined">
      <table class="roo-data-table" :data-mode="server ? 'server' : undefined" :data-selectable="multi ? 'true' : undefined" :data-row-click="multi && rowClick === 'open' ? 'open' : undefined" :style="tableStyle">
        <thead>
          <tr>
            <th v-if="multi" class="roo-data-table-check" scope="col" data-pinned="true">
              <RooCheckbox
                :model-value="headerState === 'all'"
                :indeterminate="headerState === 'some'"
                label="Select all rows on this page"
                hide-label
                :disabled="loading || pageKeys.length === 0"
                @update:model-value="toggleHeader"
              />
            </th>
            <th
              v-for="(column, columnIndex) in shownColumns"
              :key="column.id"
              scope="col"
              :aria-sort="sortState(column)"
              :data-align="column.align === 'end' ? 'end' : undefined"
              :data-muted="column.muted ? 'true' : undefined"
              :data-pinned="pinFirstColumn && columnIndex === 0 ? 'true' : undefined"
              :data-width="columnSizing.get(column.id)"
              :data-leftover="column.id === leftoverColumnId ? 'true' : undefined"
              :style="fitStyle(column)"
            >
              <button type="button" class="roo-data-table-sort" @click="toggleSort(column)">
                <span class="roo-data-table-label" :title="column.label">{{ column.label }}</span>
                <span v-if="column.tag" class="roo-data-table-tag">{{ column.tag }}</span>
                <RooIcon v-if="sortState(column) !== 'none'" :name="sortState(column) === 'ascending' ? 'arrow-up' : 'arrow-down'" :size="12" />
              </button>
            </th>
            <th v-if="$slots['row-actions']" class="roo-data-table-actions-head" scope="col"><span class="roo-visually-hidden">Actions</span></th>
          </tr>
        </thead>
        <tbody v-if="showRows" ref="body">
          <tr
            v-for="(row, rowIndex) in visibleRows"
            :key="rowKey !== undefined ? String(keyOf(row)) : rowIndex"
            class="roo-data-table-row"
            :class="{ 'roo-selected-row': isSelected(row) || isOpened(row), 'roo-opened-row': isOpened(row) }"
            :tabindex="rowIndex === focusedRow ? 0 : -1"
            :aria-selected="rowKey === undefined ? undefined : isSelected(row) ? 'true' : 'false'"
            :aria-current="isOpened(row) ? 'true' : undefined"
            @click="onRowClick($event, row, rowIndex)"
            @keydown="onRowKeydown($event, row, rowIndex)"
          >
            <td v-if="multi" class="roo-data-table-check" data-pinned="true">
              <RooCheckbox :model-value="isChecked(row)" :label="`Select row ${String(keyOf(row))}`" hide-label @update:model-value="toggleRow(row)" />
            </td>
            <td
              v-for="(column, columnIndex) in shownColumns"
              :key="column.id"
              :data-align="column.align === 'end' ? 'end' : undefined"
              :data-muted="column.muted ? 'true' : undefined"
              :data-mono="column.mono ? 'true' : undefined"
              :data-pinned="pinFirstColumn && columnIndex === 0 ? 'true' : undefined"
              :data-width="columnSizing.get(column.id)"
              :data-leftover="column.id === leftoverColumnId ? 'true' : undefined"
              :style="fitStyle(column)"
            >
              <slot name="cell" :column="column" :row="row" :value="row[column.id]">
                <span v-if="row[column.id] === null || row[column.id] === undefined" class="roo-data-table-null">null</span>
                <component :is="hasTooltipProvider && isCut(row[column.id]) ? RooTooltip : PassThrough" v-else v-bind="hasTooltipProvider && isCut(row[column.id]) ? { text: cellText(row[column.id]) } : {}">
                  <span class="roo-data-table-text" :data-cut="isCut(row[column.id]) ? 'true' : undefined">{{ cellText(row[column.id]) }}</span>
                </component>
              </slot>
            </td>
            <td v-if="$slots['row-actions']" class="roo-data-table-actions"><slot name="row-actions" :row="row" /></td>
          </tr>
        </tbody>
        <tbody v-else-if="loading" class="roo-data-table-loading">
          <tr v-for="index in skeletonCount" :key="index" class="roo-data-table-skeleton-row">
            <td v-if="multi" class="roo-data-table-check" data-pinned="true" />
            <td v-for="column in shownColumns" :key="column.id" :data-align="column.align === 'end' ? 'end' : undefined" :data-pinned="pinFirstColumn && column === shownColumns[0] ? 'true' : undefined"><RooSkeleton :rows="1" :mark-region-busy="false" /></td>
            <td v-if="$slots['row-actions']" class="roo-data-table-actions" />
          </tr>
        </tbody>
      </table>
      <div v-if="error && !loading" class="roo-data-table-state roo-data-table-error" role="alert">
        <span class="roo-data-table-state-text">{{ error }}</span>
        <RooButton size="sm" @click="emit('retry')">Retry</RooButton>
      </div>
      <p v-else-if="showEmpty" class="roo-data-table-state roo-data-table-empty">{{ emptyText }}</p>
    </div>

    <div class="roo-data-table-foot">
      <span class="roo-data-table-count" role="status">{{ countLine }}</span>
      <span class="roo-data-table-pager" :data-empty="showEmpty ? 'true' : undefined">
        <RooIconButton icon="chevron-left" label="Previous page" variant="ghost" size="xs" :disabled="!hasPrevPage || loading" @click="previousPage" />
        <span class="roo-data-table-page">{{ pageLabel }}</span>
        <RooIconButton icon="chevron" label="Next page" variant="ghost" size="xs" :disabled="!hasNextPage || loading" @click="nextPage" />
      </span>
    </div>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-data-table-root {
    display: flex;
    min-height: 0;
    flex-direction: column;
    gap: var(--roo-p-space-2);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-13);
    color: var(--roo-text);
  }

  .roo-data-table-toolbar-box {
    min-width: 0;
    container-type: inline-size;
    container-name: roo-data-table-toolbar;
  }

  .roo-data-table-toolbar {
    display: flex;
    align-items: center;
    gap: var(--roo-p-space-2);
  }

  /* Wide form: the filters are the toolbar's own children. */
  .roo-data-table-filters {
    display: contents;
  }

  /* One control height in the toolbar, wide and narrow: the search and Columns are --roo-control-h, so a slotted filter select is too. */
  .roo-data-table-columns {
    height: var(--roo-control-h);
    flex-shrink: 0;
  }

  .roo-data-table-filters > :deep(*) .roo-field-control {
    height: var(--roo-control-h);
  }

  .roo-data-table-bulk {
    display: flex;
    min-width: 0;
    min-height: var(--roo-control-h);
    flex: 1;
    align-items: center;
    gap: var(--roo-p-space-2);
  }

  .roo-data-table-search {
    min-width: 0;
    flex: 0 1 280px;
  }

  /* An invisible tap area at least --roo-touch-target tall on a coarse pointer; the search box keeps its size. Height only, so it
     never reaches the Columns button beside it. */
  @media (pointer: coarse) {
    .roo-data-table-search :deep(.roo-field-box) {
      position: relative;
    }

    .roo-data-table-search :deep(.roo-field-box)::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2)) 0;
    }
  }

  /* Narrow toolbar (the table can sit in a narrow pane, so this asks the toolbar, not the viewport): the search takes
     row 1 at full width; the filters share row 2 with Columns, which never shrinks or clips. */
  @container roo-data-table-toolbar (max-width: 520px) {
    .roo-data-table-toolbar {
      flex-wrap: wrap;
    }

    .roo-data-table-search {
      flex: 1 1 100%;
    }

    .roo-data-table-toolbar {
      --roo-data-table-filter-min: calc(var(--roo-control-h) * 3);
      align-items: flex-start;
    }

    /* The filters are the toolbar's own items here, so they wrap with Columns. A control with fixed choices (RooSegmented, RooTabs)
       keeps its natural width and its labels never truncate. A field (RooSelect) shares the slack and truncates down to a readable
       minimum; a field alone on a wrapped line fills it. */
    .roo-data-table-filters {
      display: contents;
    }

    .roo-data-table-filters > :deep(*) {
      flex: 0 0 auto;
    }

    .roo-data-table-filters > :deep(.roo-field) {
      min-width: 0;
      flex: 1 1 var(--roo-data-table-filter-min);
    }

    /* Columns keeps its icon and the count; its accessible name stays "Columns, N of M shown". */
    .roo-data-table-columns-label {
      display: none;
    }
  }

  /* The `popover` form of the narrow toolbar: one row (search, Filters, Columns). The search takes the room; both buttons keep their size. */
  @container roo-data-table-toolbar (max-width: 520px) {
    .roo-data-table-toolbar[data-filters-popover='true'] {
      flex-wrap: nowrap;
      align-items: center;
    }

    .roo-data-table-toolbar[data-filters-popover='true'] .roo-data-table-search {
      flex: 1 1 0;
    }

    .roo-data-table-toolbar[data-filters-popover='true'] > .roo-data-table-columns {
      order: 0;
      margin-left: 0;
    }
  }

  .roo-data-table-filters-button {
    height: var(--roo-control-h);
    flex-shrink: 0;
  }

  .roo-data-table-columns-count {
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-data-table-toolbar-end {
    display: inline-flex;
    margin-left: auto;
    align-items: center;
    gap: var(--roo-p-space-2);
  }

  .roo-data-table-scroll {
    min-height: 0;
    flex: 1;
    overflow: auto;
    border: 1px solid transparent;
    border-radius: var(--roo-p-radius-card);
    background: var(--roo-surface);
    box-shadow: var(--roo-shadow-card);
  }

  .roo-data-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0;
  }

  .roo-data-table th {
    position: sticky;
    top: 0;
    z-index: 2;
    height: var(--roo-row-h);
    box-sizing: border-box;
    border-bottom: 1px solid var(--roo-border);
    background: var(--roo-raised);
    padding: 0 var(--roo-row-pad-inline);
    text-align: left;
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
    font-weight: var(--roo-x-grid-header-weight);
    white-space: nowrap;
  }

  .roo-data-table td {
    height: var(--roo-row-h);
    box-sizing: border-box;
    max-width: 320px;
    overflow: hidden;
    border-bottom: 1px solid var(--roo-line);
    padding: 0 var(--roo-row-pad-inline);
    white-space: nowrap;
  }

  .roo-data-table tr:last-child > td {
    border-bottom: 0;
  }

  /* Column sizing. fit: as wide as the content, up to six control heights, then an ellipsis. grow: takes the slack, at least three control
     heights. auto (no hint): shares what is left, at least three control heights, and ends in an ellipsis. max-width 0 lets a
     grow or auto cell shrink to its minimum, so its text is cut with an ellipsis instead of widening the table. */
  .roo-data-table th[data-width='fit'],
  .roo-data-table td[data-width='fit'] {
    width: 1%;
    white-space: nowrap;
  }

  .roo-data-table td[data-width='fit'] {
    max-width: calc(var(--roo-control-h) * 6);
  }

  .roo-data-table th[data-width='grow'],
  .roo-data-table th[data-width='auto'],
  .roo-data-table td[data-width='grow'],
  .roo-data-table td[data-width='auto'] {
    min-width: calc(var(--roo-control-h) * 3);
  }

  .roo-data-table td[data-width='grow'],
  .roo-data-table td[data-width='auto'] {
    max-width: 0;
  }

  /* Text a cell slot puts straight in the cell (no kit text span) is cut with an ellipsis too, never run into the next column's chip. */
  .roo-data-table td[data-width] {
    text-overflow: ellipsis;
  }

  .roo-data-table th[data-width='grow'],
  .roo-data-table td[data-width='grow'] {
    width: 50%;
  }

  /* In the fixed layout a percentage width is a fixed share, and when the widths set add up to less than the table, the leftover is spread
     over EVERY column, the checkbox column too. A lone grow column at 50% therefore widened the checkbox column and pushed the header
     label to the middle. Grow is plain auto in server mode, so it absorbs the leftover and the checkbox column keeps its width. */
  .roo-data-table th[data-width='grow'],
  .roo-data-table td[data-width='grow'] {
    width: auto;
  }

  .roo-data-table th[data-width][data-leftover='true'],
  .roo-data-table td[data-width][data-leftover='true'] {
    width: auto;
  }

  /* Server mode keeps its fixed layout so widths hold across pages: a fit column is its ch count plus the cell padding. */
  .roo-data-table[data-mode='server'] th[data-width='fit'],
  .roo-data-table[data-mode='server'] td[data-width='fit'] {
    /* The header is mono 12; cell text is the UI face at 13, a little wider than one header ch per character, so the count is scaled. */
    --roo-data-table-ch-scale: 1.1;
    width: calc(var(--roo-data-table-fit-chars, 8) * var(--roo-data-table-ch-scale) * 1ch + 2 * var(--roo-row-pad-inline));
    max-width: none;
  }

  .roo-data-table-pager[data-empty='true'] {
    visibility: hidden;
  }

  .roo-data-table [data-align='end'] {
    text-align: right;
  }

  .roo-data-table [data-align='end'] .roo-data-table-sort {
    flex-direction: row-reverse;
  }

  .roo-data-table [data-muted='true'] {
    color: var(--roo-muted);
  }

  .roo-data-table td[data-mono='true'] {
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
  }

  .roo-data-table [data-pinned='true'] {
    position: sticky;
    left: 0;
    background: var(--roo-surface);
  }

  .roo-data-table th[data-pinned='true'] {
    z-index: 3;
    background: var(--roo-raised);
  }

  .roo-data-table tr.roo-selected-row > [data-pinned='true'] {
    background: var(--roo-select);
  }

  .roo-data-table-sort {
    display: inline-flex;
    min-width: 0;
    max-width: 100%;
    align-items: center;
    gap: var(--roo-p-space-1);
    border: 0;
    background: transparent;
    padding: 0;
    font: inherit;
    color: inherit;
    cursor: default;
  }

  .roo-data-table-sort:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
    border-radius: var(--roo-p-radius-small);
  }

  .roo-data-table th[aria-sort='ascending'],
  .roo-data-table th[aria-sort='descending'] {
    color: var(--roo-text);
    font-weight: 600;
  }

  /* A long header label is cut with an ellipsis (its full text is the title), never over the next column. */
  .roo-data-table th {
    overflow: hidden;
  }

  .roo-data-table-label {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-data-table-sort > :not(.roo-data-table-label) {
    flex-shrink: 0;
  }

  .roo-data-table-tag {
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-p-radius-small);
    padding: 0 var(--roo-p-space-1);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-data-table-row {
    outline: none;
  }

  /* Open mode: the accent bar means "the row the sheet shows". A checked row keeps the tint and draws no bar; only the opened row draws it. */
  .roo-data-table[data-row-click='open'] tr.roo-selected-row:not(.roo-opened-row) > :first-child::before {
    content: none;
  }

  .roo-data-table-row:hover:not(.roo-selected-row) {
    background: var(--roo-raised);
  }

  /* Light look (Raja chose D, 2026-11-21): hover is a faint neutral, no hue, and the pinned cell takes it too, so it never reads as the selected row. Dark keeps raised. */
  .roo-data-table-row:hover:not(.roo-selected-row):not(:root[data-appearance='dark'] *, .dark *) {
    background: color-mix(in srgb, var(--roo-text) 5%, transparent);
  }

  .roo-data-table-row:hover:not(.roo-selected-row):not(:root[data-appearance='dark'] *, .dark *) > [data-pinned='true'] {
    background: color-mix(in srgb, var(--roo-text) 5%, var(--roo-surface));
  }

  .roo-data-table-row.roo-selected-row:hover {
    background: var(--roo-select-hover);
  }

  .roo-data-table-row.roo-selected-row:hover > [data-pinned='true'] {
    background: var(--roo-select-hover);
  }

  .roo-data-table-row:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: -2px;
  }

  .roo-data-table-text {
    display: block;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .roo-data-table-null {
    font-style: italic;
    color: var(--roo-faint);
  }

  .roo-data-table-actions {
    width: 1%;
    text-align: right;
  }

  .roo-data-table-actions-head {
    width: 1%;
  }

  /* A baseline-aligned inline button in a cell adds descender space under it, which made a compact row 22 against the 21 of --roo-row-h and of the loading rows. Middle alignment keeps the row at --roo-row-h. */
  .roo-data-table-actions > :deep(*) {
    vertical-align: middle;
  }

  .roo-data-table-empty {
    margin: 0;
    padding: var(--roo-space-section);
    text-align: center;
    color: var(--roo-muted);
  }

  /* Server mode keeps one box: the scroll area never shrinks below the header and eight rows, so loading, empty and error
     swap their content without moving the foot. */
  .roo-data-table-scroll[data-mode='server'] {
    min-height: calc(var(--roo-row-h) + (var(--roo-row-h) + 1px) * 8 + 1px);
  }

  .roo-data-table-scroll[data-mode='server'] .roo-data-table-state {
    display: flex;
    min-height: calc((var(--roo-row-h) + 1px) * 8 - 1px);
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: var(--roo-p-space-2);
    margin: 0;
    padding: 0 var(--roo-space-section);
    box-sizing: border-box;
  }

  .roo-data-table-error {
    margin: 0;
    padding: var(--roo-space-section);
    color: var(--roo-muted);
  }

  .roo-data-table-state-text {
    text-align: center;
  }

  /* Fixed columns in server mode, so the header does not shift between loading, empty, error and rows. */
  .roo-data-table[data-mode='server'] {
    table-layout: fixed;
  }

  .roo-data-table[data-mode='server'] .roo-data-table-actions,
  .roo-data-table[data-mode='server'] .roo-data-table-actions-head {
    width: calc(var(--roo-icon-button) + var(--roo-row-pad-inline) * 2);
  }

  .roo-data-table-skeleton-row td {
    padding: 0 var(--roo-row-pad-inline);
  }

  /* A skeleton bar takes its column's alignment: in a right-aligned column it ends where the values end. */
  .roo-data-table-skeleton-row td[data-align='end'] :deep(.roo-skeleton-row) {
    justify-content: flex-end;
  }

  /* The skeleton bar row fits inside the cell's own row height, border included, so a loading row is as tall as a real one. */
  .roo-data-table-skeleton-row td :deep(.roo-skeleton-row) {
    height: calc(var(--roo-row-h) - 1px);
    padding: 0;
  }

  /* The checkbox column is pinned at the left edge; the first data column then pins just after it. */
  .roo-data-table {
    --roo-data-table-check-w: calc(var(--roo-row-pad-inline) * 2 + var(--roo-checkbox));
  }

  .roo-data-table .roo-data-table-check {
    width: var(--roo-data-table-check-w);
    min-width: var(--roo-data-table-check-w);
    max-width: var(--roo-data-table-check-w);
    padding: 0 var(--roo-row-pad-inline);
  }

  .roo-data-table-check :deep(.roo-checkbox) {
    justify-content: center;
  }

  .roo-data-table[data-selectable='true'] th[data-pinned='true']:not(.roo-data-table-check),
  .roo-data-table[data-selectable='true'] td[data-pinned='true']:not(.roo-data-table-check) {
    left: var(--roo-data-table-check-w);
  }

  .roo-data-table-foot {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: var(--roo-p-space-2);
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-data-table-pager {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-2);
  }

  @media (prefers-reduced-motion: no-preference) {
    .roo-data-table-row {
      transition: background-color var(--roo-fast) var(--roo-ease);
    }
  }
}
</style>

<style>
@layer roo-components {
  /* The filters panel of the `popover` form stacks the app's filters. Unscoped because the slotted children are the app's. */
  .roo-data-table-filters-panel {
    display: flex;
    flex-direction: column;
    align-items: stretch;
    gap: var(--roo-p-space-2);
  }

  .roo-data-table-filters-panel > * {
    flex-direction: column;
    align-items: stretch;
  }

  .roo-data-table-filters-panel .roo-field {
    width: 100%;
  }

  /* With a fixed-choice control in the filters, the narrow toolbar keeps it on the first line with Columns at the right edge,
     and each field (RooSelect) takes the next line, filling it when alone. Unscoped because the slotted children are the app's. */
  @container roo-data-table-toolbar (max-width: 520px) {
    .roo-data-table-toolbar:not([data-filters-popover]):has(> .roo-data-table-filters > :not(.roo-field)) > .roo-data-table-columns {
      order: 1;
      margin-left: auto;
    }

    .roo-data-table-toolbar:not([data-filters-popover]):has(> .roo-data-table-filters > :not(.roo-field)) > .roo-data-table-filters > .roo-field {
      order: 2;
      flex: 1 1 calc(50% - var(--roo-p-space-1));
    }
  }

  /* An invisible tap area of at least --roo-touch-target on a coarse pointer (family rule F6, Fable review). The drawn size never changes. */
  @media (pointer: coarse) {
    .roo-data-table-sort {
      position: relative;
    }

    .roo-data-table-sort::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2)) 0;
    }
  }
}
</style>
