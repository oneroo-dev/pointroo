<script lang="ts">
import type { RooIconName } from '../icons/paths'

export type RooScrubberMarkerKind = 'error' | 'rage-click' | 'dead-click' | 'page-change'

export interface RooScrubberMarker {
  /** Where it happened, in seconds from the start. */
  time: number
  kind: RooScrubberMarkerKind
  /** The words for the tooltip and the accessible name, such as `TypeError on checkout`. Defaults to the kind. */
  label?: string
}

export interface RooScrubberRange {
  start: number
  end: number
}

/** One arrow press moves this many seconds, and Page Up or Page Down moves the second. */
export const SCRUBBER_ARROW_SECONDS = 5
export const SCRUBBER_PAGE_SECONDS = 30

export const SCRUBBER_MARKER_ICONS: Record<RooScrubberMarkerKind, RooIconName> = {
  error: 'circle-alert',
  'rage-click': 'mouse-pointer-click',
  'dead-click': 'mouse-pointer-ban',
  'page-change': 'file',
}

export const SCRUBBER_MARKER_WORDS: Record<RooScrubberMarkerKind, string> = {
  error: 'Error',
  'rage-click': 'Rage click',
  'dead-click': 'Dead click',
  'page-change': 'Page change',
}

/** Seconds as `0:41`, `3:12` or, from an hour up, `1:02:03`. Fractions are dropped, never rounded up past the real time. */
export function formatTimecode(seconds: number): string {
  const whole = Math.max(0, Math.floor(Number.isFinite(seconds) ? seconds : 0))
  const hours = Math.floor(whole / 3600)
  const minutes = Math.floor((whole % 3600) / 60)
  const rest = String(whole % 60).padStart(2, '0')
  return hours > 0 ? `${hours}:${String(minutes).padStart(2, '0')}:${rest}` : `${minutes}:${rest}`
}

const TICK_STEPS = [1, 2, 5, 10, 15, 30, 60, 120, 300, 600, 900, 1800, 3600, 7200, 14400, 28800]

/** The gap in seconds between tick labels: the smallest round step that leaves no more than `maxTicks` labels. */
export function scrubberTickInterval(duration: number, maxTicks = 8): number {
  for (const step of TICK_STEPS) {
    if (duration / step <= maxTicks) return step
  }
  return TICK_STEPS[TICK_STEPS.length - 1] ?? 1
}

/** The time a key press lands on, or undefined for a key the scrubber ignores. Always inside 0 and the duration. */
export function scrubberKeyTarget(key: string, current: number, duration: number): number | undefined {
  const clamp = (time: number): number => Math.min(Math.max(time, 0), duration)
  switch (key) {
    case 'ArrowRight':
    case 'ArrowUp':
      return clamp(current + SCRUBBER_ARROW_SECONDS)
    case 'ArrowLeft':
    case 'ArrowDown':
      return clamp(current - SCRUBBER_ARROW_SECONDS)
    case 'PageUp':
      return clamp(current + SCRUBBER_PAGE_SECONDS)
    case 'PageDown':
      return clamp(current - SCRUBBER_PAGE_SECONDS)
    case 'Home':
      return 0
    case 'End':
      return duration
    default:
      return undefined
  }
}
</script>

<script setup lang="ts">
import { computed, onBeforeUnmount, ref } from 'vue'
import RooIcon from './RooIcon.vue'
import RooTooltip from './RooTooltip.vue'

// Needs one RooTooltipProvider above it, for the marker tooltips.
const model = defineModel<number>({ default: 0 })

const props = withDefaults(
  defineProps<{
    /** The length of the recording, in seconds. */
    duration: number
    /** Stretches loaded so far, drawn as a lighter fill under the played part. */
    buffered?: RooScrubberRange[]
    /** Stretches the player skips, such as inactivity, drawn as a hatched segment. */
    skipped?: RooScrubberRange[]
    /** Things that happened, drawn above the track as small icons. A click seeks to the time. */
    markers?: RooScrubberMarker[]
    disabled?: boolean
    ariaLabel?: string
  }>(),
  { buffered: () => [], skipped: () => [], markers: () => [], disabled: false, ariaLabel: 'Playback position' },
)

const emit = defineEmits<{
  /** A marker was clicked, or the track was pressed or keyed. The model has already moved to this time. */
  seek: [time: number]
}>()

const track = ref<HTMLElement | null>(null)
const hoverTime = ref<number | undefined>(undefined)
const dragging = ref(false)
// Set for the one move a key or a marker makes, so the thumb glides there; playback ticks and drags never glide.
const gliding = ref(false)

const safeDuration = computed(() => Math.max(props.duration, 0))
const clampedTime = computed(() => Math.min(Math.max(model.value, 0), safeDuration.value))

function percentOf(time: number): number {
  return safeDuration.value === 0 ? 0 : (Math.min(Math.max(time, 0), safeDuration.value) / safeDuration.value) * 100
}

const valueText = computed(() => `${formatTimecode(clampedTime.value)} of ${formatTimecode(safeDuration.value)}`)

const ticks = computed(() => {
  if (safeDuration.value === 0) return []
  const step = scrubberTickInterval(safeDuration.value)
  const times: number[] = []
  for (let time = 0; time <= safeDuration.value; time += step) times.push(time)
  return times
})

function segment(range: RooScrubberRange): Record<string, string> {
  const start = percentOf(Math.min(range.start, range.end))
  const end = percentOf(Math.max(range.start, range.end))
  return { left: `${start}%`, width: `${end - start}%` }
}

function seekTo(time: number, glide: boolean): void {
  if (props.disabled) return
  const next = Math.min(Math.max(time, 0), safeDuration.value)
  gliding.value = glide
  if (next !== model.value) model.value = next
  emit('seek', next)
}

function timeAtPointer(event: PointerEvent): number {
  const box = track.value?.getBoundingClientRect()
  if (!box || box.width === 0) return 0
  return (Math.min(Math.max(event.clientX - box.left, 0), box.width) / box.width) * safeDuration.value
}

function onPointerDown(event: PointerEvent): void {
  if (props.disabled || event.button !== 0) return
  dragging.value = true
  ;(event.currentTarget as HTMLElement).setPointerCapture?.(event.pointerId)
  seekTo(timeAtPointer(event), false)
}

function onPointerMove(event: PointerEvent): void {
  hoverTime.value = timeAtPointer(event)
  if (dragging.value) seekTo(hoverTime.value, false)
}

function endDrag(): void {
  dragging.value = false
}

function onPointerLeave(): void {
  if (!dragging.value) hoverTime.value = undefined
}

function onKeyDown(event: KeyboardEvent): void {
  if (props.disabled) return
  const target = scrubberKeyTarget(event.key, clampedTime.value, safeDuration.value)
  if (target === undefined) return
  event.preventDefault()
  seekTo(target, true)
}

onBeforeUnmount(endDrag)

function markerWords(marker: RooScrubberMarker): string {
  return `${marker.label ?? SCRUBBER_MARKER_WORDS[marker.kind]} at ${formatTimecode(marker.time)}`
}

const bubbleStyle = computed(() => (hoverTime.value === undefined ? undefined : { left: `${percentOf(hoverTime.value)}%` }))
</script>

<template>
  <div class="roo-scrubber" :data-disabled="disabled ? 'true' : undefined" :data-dragging="dragging ? 'true' : undefined">
    <div v-if="markers.length > 0" class="roo-scrubber-markers">
      <RooTooltip v-for="(marker, index) in markers" :key="`${marker.kind}-${marker.time}-${index}`" :text="markerWords(marker)" side="top">
        <button
          type="button"
          class="roo-scrubber-marker"
          :data-kind="marker.kind"
          :style="{ left: `${percentOf(marker.time)}%` }"
          :aria-label="markerWords(marker)"
          :disabled="disabled"
          @click="seekTo(marker.time, true)"
        >
          <RooIcon :name="SCRUBBER_MARKER_ICONS[marker.kind]" :size="12" />
        </button>
      </RooTooltip>
    </div>
    <div
      class="roo-scrubber-hit"
      role="slider"
      :tabindex="disabled ? -1 : 0"
      :aria-label="ariaLabel"
      aria-orientation="horizontal"
      :aria-valuemin="0"
      :aria-valuemax="safeDuration"
      :aria-valuenow="clampedTime"
      :aria-valuetext="valueText"
      :aria-disabled="disabled ? 'true' : undefined"
      @pointerdown="onPointerDown"
      @pointermove="onPointerMove"
      @pointerup="endDrag"
      @pointercancel="endDrag"
      @pointerleave="onPointerLeave"
      @keydown="onKeyDown"
    >
      <div ref="track" class="roo-scrubber-track">
        <span v-for="(range, index) in buffered" :key="`buffered-${index}`" class="roo-scrubber-buffered" :style="segment(range)" />
        <span class="roo-scrubber-range" :data-glide="gliding ? 'true' : undefined" :style="{ width: `${percentOf(clampedTime)}%` }" />
        <span v-for="(range, index) in skipped" :key="`skipped-${index}`" class="roo-scrubber-skipped" :style="segment(range)" />
      </div>
      <span class="roo-scrubber-thumb" :data-glide="gliding ? 'true' : undefined" :style="{ left: `${percentOf(clampedTime)}%` }" />
      <span v-if="hoverTime !== undefined && !disabled" class="roo-scrubber-bubble" :style="bubbleStyle" aria-hidden="true">
        {{ formatTimecode(hoverTime) }}
      </span>
    </div>
    <div class="roo-scrubber-ticks" aria-hidden="true">
      <span v-for="time in ticks" :key="time" class="roo-scrubber-tick" :data-edge="time === 0 ? 'start' : time / safeDuration > 0.97 ? 'end' : undefined" :style="{ left: `${percentOf(time)}%` }">
        {{ formatTimecode(time) }}
      </span>
    </div>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-scrubber {
    --roo-scrubber-thumb: 14px;
    --roo-scrubber-track: 4px;

    display: flex;
    width: 100%;
    flex-direction: column;
    gap: var(--roo-p-space-1);
  }

  .roo-scrubber-markers {
    position: relative;
    height: 20px;
  }

  .roo-scrubber-marker {
    position: absolute;
    top: 0;
    display: inline-flex;
    width: 20px;
    height: 20px;
    align-items: center;
    justify-content: center;
    border: 0;
    border-radius: var(--roo-p-radius-small);
    background: transparent;
    padding: 0;
    color: var(--roo-muted);
    cursor: default;
    transform: translateX(-50%);
    transition:
      background-color var(--roo-fast) var(--roo-ease),
      color var(--roo-fast) var(--roo-ease);
  }

  .roo-scrubber-marker[data-kind='error'] {
    color: var(--roo-danger-text);
  }

  .roo-scrubber-marker:hover:not(:disabled) {
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  .roo-scrubber-marker:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: var(--roo-focus-offset);
  }

  .roo-scrubber-hit {
    position: relative;
    display: flex;
    height: var(--roo-scrubber-thumb);
    align-items: center;
    touch-action: none;
    user-select: none;
    cursor: default;
  }

  .roo-scrubber-hit:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: var(--roo-focus-offset);
    border-radius: var(--roo-p-radius-pill);
  }

  .roo-scrubber-track {
    position: relative;
    height: var(--roo-scrubber-track);
    flex: 1;
    overflow: hidden;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-border);
  }

  .roo-scrubber-buffered {
    position: absolute;
    top: 0;
    bottom: 0;
    background: var(--roo-control-edge);
  }

  .roo-scrubber-range {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    background: var(--roo-accent-fill);
  }

  /* A skipped stretch: diagonal hatching in the muted colour over the track, so it reads as time the player jumps over. */
  .roo-scrubber-skipped {
    position: absolute;
    top: 0;
    bottom: 0;
    background: repeating-linear-gradient(
      -45deg,
      var(--roo-muted) 0,
      var(--roo-muted) 1px,
      transparent 1px,
      transparent 4px
    );
    opacity: 0.7;
  }

  .roo-scrubber-thumb {
    position: absolute;
    top: 50%;
    width: var(--roo-scrubber-thumb);
    height: var(--roo-scrubber-thumb);
    box-sizing: border-box;
    border: 2px solid var(--roo-accent-fill);
    border-radius: 50%;
    background: var(--roo-surface);
    box-shadow: var(--roo-shadow-thumb);
    pointer-events: none;
    transform: translate(-50%, -50%);
    transition: box-shadow var(--roo-fast) var(--roo-ease);
  }

  /* The thumb only glides after a key or a marker click. The motion tokens go to 0ms under reduced motion, so it jumps. */
  .roo-scrubber-thumb[data-glide='true'] {
    transition:
      box-shadow var(--roo-fast) var(--roo-ease),
      left var(--roo-fast) var(--roo-ease);
  }

  .roo-scrubber-range[data-glide='true'] {
    transition: width var(--roo-fast) var(--roo-ease);
  }

  .roo-scrubber-hit:hover .roo-scrubber-thumb {
    box-shadow: var(--roo-shadow-thumb), 0 0 0 4px var(--roo-accent-bg);
  }

  .roo-scrubber[data-dragging='true'] .roo-scrubber-thumb {
    background: var(--roo-accent-bg);
    box-shadow: var(--roo-shadow-thumb), 0 0 0 5px var(--roo-accent-ring);
  }

  .roo-scrubber-bubble {
    position: absolute;
    bottom: calc(100% + 2px);
    padding: 0 var(--roo-p-space-2);
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-text);
    color: var(--roo-bg);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
    line-height: 18px;
    pointer-events: none;
    transform: translateX(-50%);
    white-space: nowrap;
  }

  .roo-scrubber[data-disabled='true'] .roo-scrubber-range {
    background: var(--roo-control-edge);
  }

  .roo-scrubber[data-disabled='true'] .roo-scrubber-thumb {
    border-color: var(--roo-control-edge);
    background: var(--roo-bg);
    box-shadow: none;
  }

  .roo-scrubber-ticks {
    position: relative;
    height: calc(var(--roo-p-size-12) * 1.4);
  }

  .roo-scrubber-tick {
    position: absolute;
    top: 0;
    color: var(--roo-muted);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
    line-height: 1.4;
    transform: translateX(-50%);
    white-space: nowrap;
  }

  .roo-scrubber-tick[data-edge='start'] {
    transform: none;
  }

  .roo-scrubber-tick[data-edge='end'] {
    transform: translateX(-100%);
  }

  /* An invisible tap area of at least --roo-touch-target on a coarse pointer (family rule F6, Fable review). The drawn size never changes. */
  @media (pointer: coarse) {
    .roo-scrubber-marker::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2));
    }
  }
}
</style>
