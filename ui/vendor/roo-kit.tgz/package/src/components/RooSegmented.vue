<script lang="ts">
export interface RooSegmentedOption {
  value: string
  label: string
  icon?: RooIconName
  /** A tone dot before the label. The tone is also spoken, so colour is never the only signal. */
  dot?: 'ok' | 'warn' | 'danger' | 'muted'
  count?: number
  /** The environment dot, drawn in its own shape. */
  environment?: RooEnvironment
  /** Shown with a lock and not selectable. Pressing it says `locked`. */
  locked?: boolean
  /** Dimmed and not selectable by click or keyboard, with no lock glyph (a view that does not exist yet). */
  disabled?: boolean
}
</script>

<script setup lang="ts">
// A segmented control as a radiogroup: one Tab stop on the checked radio, arrows select as they move (a locked or disabled option is
// skipped), Home and End jump. One thumb glides under the checked option through two custom properties; the thumb is
// the raised fill with no ring, and the checked label is also semibold, so the choice never rests on
// colour. It replaces the environment select and the "Treat as" control the apps drew themselves.
import { computed, onMounted, onUpdated, ref } from 'vue'
import RooEnvDot from './RooEnvDot.vue'
import RooIcon from './RooIcon.vue'
import { useRovingTabindex } from '../composables/useRovingTabindex'
import type { RooIconName } from '../icons/paths'
import type { RooEnvironment } from '../types/environment'

const props = withDefaults(defineProps<{ options: RooSegmentedOption[]; label: string; hideWhenSingle?: boolean; size?: 'compact' | 'md' | 'lg' | 'search' }>(), { hideWhenSingle: false, size: 'md' })
const model = defineModel<string>({ required: true })
const emit = defineEmits<{ locked: [value: string] }>()

const root = ref<HTMLElement | null>(null)
const roving = useRovingTabindex(root, {
  itemSelector: '[data-roving-item]',
  orientation: 'horizontal',
  onMove: (item) => {
    const value = item.getAttribute('data-value')
    if (value !== null) model.value = value
  },
})
onMounted(roving.sync)
onUpdated(roving.sync)

const shown = computed(() => !(props.hideWhenSingle && props.options.length <= 1))
const index = computed(() => Math.max(0, props.options.findIndex((option) => option.value === model.value)))

const dotWords: Record<NonNullable<RooSegmentedOption['dot']>, string> = { ok: 'ok', warn: 'warning', danger: 'problem', muted: 'inactive' }

function choose(option: RooSegmentedOption): void {
  if (option.disabled) return
  if (option.locked) {
    emit('locked', option.value)
    return
  }
  model.value = option.value
}
</script>

<template>
  <div
    v-if="shown"
    ref="root"
    class="roo-segmented"
    :data-size="size"
    role="radiogroup"
    :aria-label="label"
    :data-all-disabled="options.length > 0 && options.every((option) => option.disabled) ? 'true' : undefined"
    :style="{ '--roo-segmented-count': String(options.length) }"
    @keydown="roving.onKeydown"
    @focusin="roving.onFocusin"
  >
    <span class="roo-segmented-thumb" aria-hidden="true" :style="{ '--roo-segmented-index': String(index) }" />
    <button
      v-for="option in options"
      :key="option.value"
      type="button"
      role="radio"
      class="roo-segmented-option"
      data-roving-item
      :data-value="option.value"
      :aria-checked="option.value === model ? 'true' : 'false'"
      :aria-disabled="option.locked || option.disabled ? 'true' : undefined"
      :data-disabled="option.disabled ? 'true' : undefined"
      :data-selected="option.value === model ? 'true' : 'false'"
      @click="choose(option)"
    >
      <RooIcon v-if="option.icon" class="roo-segmented-icon" :name="option.icon" size="token" />
      <RooEnvDot v-if="option.environment" :environment="option.environment" />
      <span v-if="option.dot" class="roo-segmented-dot" :data-tone="option.dot"><span class="roo-visually-hidden">{{ dotWords[option.dot] }}</span></span>
      <span class="roo-segmented-label">{{ option.label }}</span>
      <span v-if="option.count !== undefined" class="roo-segmented-count">{{ option.count }}</span>
      <RooIcon v-if="option.locked" class="roo-segmented-lock" name="lock" :size="12" />
    </button>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-segmented {
    position: relative;
    display: inline-grid;
    height: var(--roo-segmented-h);
    box-sizing: border-box;
    grid-auto-columns: 1fr;
    grid-auto-flow: column;
    align-items: stretch;
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-radius-control);
    background: var(--roo-bg);
    /* The pill inset is measured from the outer edge (3 comfortable, 1 compact), so the padding is the inset less the 1px border. */
    --roo-segmented-pad: calc(var(--roo-segmented-pill-inset) - 1px);
    padding: var(--roo-segmented-pad);
  }

  /* The height of a compact button (--roo-compact-control-h), so the two share one row at one height. */
  .roo-segmented[data-size='compact'] {
    height: var(--roo-compact-control-h);
  }

  .roo-segmented[data-size='lg'] {
    height: var(--roo-control-h-large);
  }

  /* Beside a search field in one column: the search field's own height step, in every tier. */
  .roo-segmented[data-size='search'] {
    height: var(--roo-search-h);
  }

  /* One thumb for the whole control. Every option has the same column width, so its place is a multiple of its own width. */
  .roo-segmented-thumb {
    position: absolute;
    inset-block: var(--roo-segmented-pad);
    inset-inline-start: var(--roo-segmented-pad);
    width: calc((100% - 2 * var(--roo-segmented-pad)) / var(--roo-segmented-count));
    transform: translateX(calc(var(--roo-segmented-index) * 100%));
    border-radius: var(--roo-radius-inner);
    /* The selected segment is the clearest thing in the control (T9): the surface in light, one step brighter in dark, with the control shadow. */
    background: var(--roo-segment-thumb);
    box-shadow: var(--roo-shadow-control);
    transition: transform var(--roo-base) var(--roo-ease);
  }

  /* Every option disabled: no selected thumb, only an outline, so the control does not look live (F1). */
  .roo-segmented[data-all-disabled='true'] > span[aria-hidden='true'] {
    background: transparent;
    box-shadow: inset 0 0 0 1px var(--roo-border);
  }

  .roo-segmented-option {
    position: relative;
    z-index: 1;
    display: inline-flex;
    min-width: 0;
    align-items: center;
    justify-content: center;
    gap: 4px;
    border: 0;
    border-radius: var(--roo-radius-inner);
    background: transparent;
    padding-inline: var(--roo-segment-pad-x);
    color: var(--roo-muted);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    white-space: nowrap;
    cursor: default;
    transition:
      color var(--roo-fast) var(--roo-ease),
      background-color var(--roo-fast) var(--roo-ease);
  }

  /* Under compact density a whole-pixel line box keeps the label on a whole pixel. */
  :root[data-density='compact'] .roo-segmented-option {
    line-height: var(--roo-control-line);
  }

  .roo-segmented-option:hover,
  .roo-segmented-option[aria-checked='true'] {
    color: var(--roo-text);
  }

  .roo-segmented-option[aria-checked='true'] {
    font-weight: 600;
  }

  /* Pressed, as RooIconButton: the raised fill and the text colour while the pointer is down (a colour step, never a movement). The
     checked option already sits on the thumb, so it only takes the text colour. */
  .roo-segmented-option:active:not([aria-disabled='true']) {
    color: var(--roo-text);
  }

  .roo-segmented-option:active:not([aria-disabled='true']):not([aria-checked='true']) {
    background: var(--roo-raised);
  }

  .roo-segmented-option[aria-disabled='true'] {
    color: var(--roo-faint);
  }

  .roo-segmented-option[data-disabled='true'] {
    color: var(--roo-faint);
    opacity: 1;
  }

  .roo-segmented-option:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: var(--roo-focus-offset);
  }

  /* The leading glyph keeps the button's icon gap (the flex gap supplies 4 of it); it takes the segment's text colour in every state. */
  .roo-segmented-icon {
    flex: none;
    margin-inline-end: calc(var(--roo-control-icon-gap) - 4px);
  }

  .roo-segmented-label {
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .roo-segmented-count {
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
    color: var(--roo-muted);
  }

  .roo-segmented-dot {
    width: 8px;
    height: 8px;
    flex: none;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-muted);
  }

  .roo-segmented-dot[data-tone='ok'] {
    background: var(--roo-ok);
  }

  .roo-segmented-dot[data-tone='warn'] {
    background: var(--roo-warn);
  }

  .roo-segmented-dot[data-tone='danger'] {
    background: var(--roo-danger);
  }
}
</style>
