<script setup lang="ts">
// An info circle after a jargon term. A click (never hover) opens a short explanation: the term as its heading, at most two
// short sentences, and one example in muted 12 px. It sets aria-expanded and aria-controls, closes on Esc and on a pointer
// press outside (so only one is open at a time), and returns focus to the circle. On a phone width the explanation is a
// bottom sheet over a scrim, never a popover. Use it on jargon only: prefer renaming a word to plain English over circling it.
// Variant "compare": a price (the default slot) that opens a native popover comparing it with others (rows of figures, a summary
// per competitor, a verdict, a bar and a basis line, one dated source link per competitor). It renders the same on the server and needs no script, so a static
// page can use it: a popovertarget button, a popover="auto" panel, CSS anchor positioning.
import { computed, ref, useId } from 'vue'
import { PopoverContent, PopoverPortal, PopoverRoot, PopoverTrigger } from 'reka-ui'
import { useEscapeLayer } from '../composables/useEscapeLayer'
import { useCollisionPadding } from '../composables/useWindowControlPadding'
import { useIsPhone } from '../composables/useIsPhone'
import RooIcon from './RooIcon.vue'
import RooSheet from './RooSheet.vue'

export interface RooInfoTipCompareRow {
  competitor: string
  /** "Europe", "the US"; empty for a global figure. */
  region?: string | undefined
  /** The figure as shown, "$0.23", or the whole range "$150 to $362.50". */
  amount: string
  /** Ours against this competitor's LOWEST figure of the row: "the same price", "34% cheaper", "25% more". */
  verdict: string
  kind: 'less' | 'same' | 'more'
  /** Plan and retention, "Pay as you go, above the included 100,000; 90 days kept". */
  detail: string
  /** What the reader must know to compare fairly: scope mismatch, how it is sold, yearly billing. */
  note?: string | undefined
  /** The bar, 0 to 100: ours as a share of their lowest figure. */
  fill: number
  /** For a range, 0 to 100: ours as a share of their dearest end, drawn as a tick on the same bar. */
  tick?: number | undefined
}

/** One clause of a summary sentence. The verdict words are the coloured part: "34% cheaper" then " than Better Stack in Europe". */
export interface RooInfoTipCompareSummaryPart {
  verdict: string
  kind: 'less' | 'same' | 'more'
  rest: string
}

export interface RooInfoTipCompareSummary {
  competitor: string
  /** The clauses of one sentence with Bugroo as the subject, no name prefix: "Same price as Better Stack in Europe, 34% cheaper in the US." */
  parts: RooInfoTipCompareSummaryPart[]
  /** Appended before the full stop, " (billed yearly)", or empty. */
  suffix?: string | undefined
}

export interface RooInfoTipCompareSource {
  /** One link per competitor, named by the competitor: "Better Stack pricing, read 21 Nov 2026". */
  label: string
  sourceUrl: string
}

export interface RooInfoTipCompareData {
  /** Their unit, for the column head: "per GB". */
  unit: string
  rows: RooInfoTipCompareRow[]
  /** One summary per competitor compared, never a combined headline. */
  summaries: RooInfoTipCompareSummary[]
  sources: RooInfoTipCompareSource[]
  /** What the figures are compared on. */
  basis: string
  /** Optional line between the rows and the basis. */
  note?: string | undefined
  /** The short comparison line, always visible; the panel holds the detail. Plain text; the line is drawn from the summaries (coloured verdicts) whenever this is set. */
  visible?: string | undefined
}

const props = withDefaults(
  defineProps<{
    /** The jargon term. It is the heading of the explanation and names the circle. */
    term: string
    /** The circle's accessible name. Left out it reads "What is <term>?". */
    label?: string | undefined
    /** One example, shown muted under the explanation. The `example` slot replaces it. */
    example?: string | undefined
    /** Which side of the circle the popover opens on. */
    side?: 'top' | 'bottom'
    align?: 'start' | 'center' | 'end'
    /** "compare" is the scriptless price comparison (needs `compare` and `id`; `term` is its heading). */
    variant?: 'explain' | 'compare'
    compare?: RooInfoTipCompareData | undefined
    /** What the panel is about, appended to its dialog name: "Compared with, Logs and traces". */
    subject?: string | undefined
    /** The host places the visible line itself (after the enclosing block in prose); the component then leaves it out. */
    lineOutside?: boolean
    /** The compare panel's id; also names its anchor. Unique on the page. */
    id?: string | undefined
  }>(),
  { label: undefined, example: undefined, side: 'bottom', align: 'start', variant: 'explain', compare: undefined, subject: undefined, lineOutside: false, id: undefined },
)

const open = defineModel<boolean>('open', { default: false })
const triggerReference = ref<unknown>(null)
const collisionPadding = useCollisionPadding(open, triggerReference)
useEscapeLayer(() => open.value)

const isPhone = useIsPhone()
// The popover's own id is set by reka, which also writes the circle's aria-controls; only the sheet needs one of ours.
const contentId = useId()
const accessibleName = computed(() => props.label ?? `What is ${props.term}?`)
const compareId = computed(() => props.id ?? `tip-${contentId}`)
const panelName = computed(() => (props.subject ? `${props.term}, ${props.subject}` : props.term))

function onEscapeKeyDown(event: KeyboardEvent): void {
  event.preventDefault()
  open.value = false
}
</script>

<template>
  <span v-if="variant === 'compare' && compare" class="roo-info-tip-compare" :style="{ '--roo-tip-anchor': `--${compareId}` }">
    <button
      class="roo-info-tip-trigger"
      type="button"
      :popovertarget="compareId"
      :aria-label="label ?? term"
      :style="{ anchorName: `--${compareId}` }"
    ><span class="roo-info-tip-price"><slot /></span><RooIcon name="info" :size="14" /></button>
    <span :id="compareId" popover="auto" class="roo-info-tip-compare-panel" role="dialog" :aria-label="panelName">
      <span class="roo-info-tip-compare-head">
        <span class="roo-info-tip-compare-title">{{ term }}</span>
        <button class="roo-info-tip-close" type="button" :popovertarget="compareId" popovertargetaction="hide" aria-label="Close"><RooIcon name="x" :size="16" /></button>
      </span>
      <span class="roo-info-tip-sums">
        <span v-for="summary in compare.summaries" :key="summary.competitor" class="roo-info-tip-sum"><template v-for="(part, index) in summary.parts" :key="index"><span class="roo-info-tip-cmp" :data-kind="part.kind">{{ part.verdict }}</span>{{ part.rest }}{{ index < summary.parts.length - 1 ? ', ' : `${summary.suffix ?? ''}.` }}</template></span>
      </span>
      <span class="roo-info-tip-columns"><span>Elsewhere, {{ compare.unit }}</span><span>Their price</span><span>Bugroo is</span></span>
      <span class="roo-info-tip-rows" role="list">
        <span v-for="row in compare.rows" :key="`${row.competitor}-${row.region}-${row.amount}`" class="roo-info-tip-row" role="listitem" :data-kind="row.kind">
          <span class="roo-info-tip-who"><b>{{ row.competitor }}</b><span v-if="row.region" class="roo-info-tip-region">{{ row.region }}</span></span>
          <span class="roo-info-tip-amount">{{ row.amount }}</span>
          <span class="roo-info-tip-verdict">{{ row.verdict }}</span>
          <span class="roo-info-tip-detail">{{ row.detail }}</span>
          <span v-if="row.note" class="roo-info-tip-note">{{ row.note }}</span>
          <span class="roo-info-tip-meter" aria-hidden="true"><i class="roo-info-tip-meter-fill" :style="{ '--roo-fill': `${row.fill}%` }"></i><i v-if="row.tick !== undefined" class="roo-info-tip-meter-tick" :style="{ '--roo-tick': `${row.tick}%` }"></i></span>
        </span>
      </span>
      <span v-if="compare.note" class="roo-info-tip-note">{{ compare.note }}</span>
      <span class="roo-info-tip-basis">{{ compare.basis }}</span>
      <span class="roo-info-tip-foot"><a v-for="source in compare.sources" :key="source.sourceUrl" class="roo-info-tip-source" :href="source.sourceUrl" rel="noopener">{{ source.label }}<RooIcon name="external-link" :size="12" /></a></span>
    </span>
    <span v-if="compare.visible && !lineOutside" class="roo-info-tip-line"><template v-for="(summary, position) in compare.summaries" :key="summary.competitor"><template v-if="position > 0">{{ ' ' }}</template><template v-for="(part, index) in summary.parts" :key="index"><span class="roo-info-tip-cmp" :data-kind="part.kind">{{ part.verdict }}</span>{{ part.rest }}{{ index < summary.parts.length - 1 ? ', ' : `${summary.suffix ?? ''}.` }}</template></template></span>
  </span>
  <span v-else class="roo-info-tip">
    <template v-if="isPhone">
      <button
        class="roo-info-tip-button"
        type="button"
        :aria-label="accessibleName"
        :aria-expanded="open"
        :aria-controls="contentId"
        @click="open = !open"
      >
        <RooIcon name="info" :size="14" />
      </button>
      <RooSheet :id="contentId" v-model:open="open" :title="term" side="bottom" modal>
        <p class="roo-info-tip-body"><slot /></p>
        <p v-if="example || $slots.example" class="roo-info-tip-example"><slot name="example">{{ example }}</slot></p>
      </RooSheet>
    </template>
    <PopoverRoot v-else v-model:open="open">
      <PopoverTrigger ref="triggerReference" as-child>
        <button class="roo-info-tip-button" type="button" :aria-label="accessibleName">
          <RooIcon name="info" :size="14" />
        </button>
      </PopoverTrigger>
      <PopoverPortal>
        <PopoverContent
          class="roo-info-tip-popover"
          :side="side"
          :align="align"
          :side-offset="8"
          :align-offset="-16"
          :collision-padding="collisionPadding"
          @escape-key-down="onEscapeKeyDown"
        >
          <p class="roo-info-tip-term">{{ term }}</p>
          <p class="roo-info-tip-body"><slot /></p>
          <p v-if="example || $slots.example" class="roo-info-tip-example"><slot name="example">{{ example }}</slot></p>
        </PopoverContent>
      </PopoverPortal>
    </PopoverRoot>
  </span>
</template>

<style scoped>
@layer roo-components {
  .roo-info-tip {
    display: inline;
    white-space: nowrap;
  }

  /* 16 px circle, 6 px after the term so the focus ring has room, a 24 px hit area. */
  .roo-info-tip-button {
    position: relative;
    display: inline-grid;
    width: var(--roo-p-space-4);
    height: var(--roo-p-space-4);
    place-items: center;
    margin: 0 0 0 calc(var(--roo-p-space-2) - 2px);
    border: 0;
    border-radius: var(--roo-p-radius-pill);
    background: transparent;
    padding: 0;
    vertical-align: -3px;
    color: var(--roo-faint);
    cursor: default;
    transition:
      background-color var(--roo-fast) var(--roo-ease),
      color var(--roo-fast) var(--roo-ease);
  }

  .roo-info-tip-button::after {
    content: '';
    position: absolute;
    inset: calc(var(--roo-p-space-1) * -1);
  }

  .roo-info-tip-button:hover,
  .roo-info-tip-button[aria-expanded='true'] {
    background: var(--roo-raised);
    color: var(--roo-text);
  }

  .roo-info-tip-button:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  .roo-info-tip-term {
    margin: 0 0 var(--roo-p-space-1);
    font-size: var(--roo-p-size-13);
    line-height: 18px;
    font-weight: 600;
    color: var(--roo-text);
  }

  .roo-info-tip-body {
    margin: 0;
    font-size: var(--roo-p-size-13);
    line-height: 18px;
    color: var(--roo-text);
  }

  .roo-info-tip-example {
    margin: var(--roo-p-space-2) 0 0;
    font-size: var(--roo-p-size-12);
    line-height: 16px;
    color: var(--roo-muted);
  }
}
</style>

<!-- Not scoped: reka puts the panel inside its own popper div. -->
<style>
@layer roo-components {
  .roo-info-tip-popover {
    z-index: 80;
    box-sizing: border-box;
    width: 300px;
    max-width: calc(100vw - var(--roo-p-space-8) - var(--roo-p-space-2));
    border: 1px solid transparent;
    border-radius: var(--roo-radius-popover);
    background: var(--roo-surface);
    padding: calc(var(--roo-p-space-4) - 2px) var(--roo-p-space-4);
    white-space: normal;
    text-align: left;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-13);
    line-height: 18px;
    color: var(--roo-text);
    box-shadow: var(--roo-shadow-popover);
    animation: roo-pop var(--roo-fast) var(--roo-ease) both;
    transform-origin: var(--reka-popover-content-transform-origin, var(--reka-popper-transform-origin, center));
  }

  .roo-info-tip-popover[data-state='closed'] {
    animation: roo-pop-out calc(var(--roo-fast) * 0.625) var(--roo-exit) both;
  }
}
</style>

<style src="./roo-info-tip-compare.css"></style>
