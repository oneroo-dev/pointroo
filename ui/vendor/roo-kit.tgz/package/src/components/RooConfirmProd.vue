<script lang="ts">
import type { InjectionKey, Ref } from 'vue'
import type { ConfirmMethod } from '../confirm-requirement'
import dangerRules from '../data/danger-rules.json'

export {
  BULK_WRITE_ROW_LIMIT,
  BULK_WRITE_TABLE_SHARE,
  DEFAULT_CONFIRM_METHOD,
  PLAIN_CONFIRM_MAX_COUNT,
  chooseConfirmRequirement,
  isDestructiveConfirmKind,
} from '../confirm-requirement'
export type {
  ConfirmActionKind,
  ConfirmMethod,
  ConfirmRequirement,
  EnvironmentConfirmInput,
  GuardConfirmInput,
  GuardRequirement,
} from '../confirm-requirement'

/** What `confirmed` reports: the typed name when one was required, otherwise the gesture. */
export type ConfirmedMethod = 'hold' | 'two_press' | 'typed_name' | 'press'

/** A preference the app provides so the person's chosen method is remembered. The confirm reads it and writes it. */
export const ROO_CONFIRM_METHOD: InjectionKey<Ref<ConfirmMethod | undefined>> = Symbol('roo-confirm-method')

/** The confirm words, read from the contract's copy data (danger-rules.json, node C1). The app supplies the verb. */
const copyData = dangerRules.copy

function fillCopy(template: string, values: Record<string, string>): string {
  return template.replace(/\{(verb|seconds|label|server)\}/g, (whole, name: string) => values[name] ?? whole)
}

export const CONFIRM_COPY = {
  holdLink: copyData.methods.hold.switchLink,
  pressAndHoldLink: copyData.methods['two-step'].switchLink,
  armedLabel: (verb: string): string => fillCopy(copyData.methods['two-step'].armedLabel, { verb }),
  holdCountdown: (seconds: string): string => fillCopy(copyData.methods.hold.countdown, { seconds }),
  typedNamePrefix: copyData.typedName.prefix,
  typedNameSuffix: copyData.typedName.suffix,
  listLabel: copyData.listLabel,
  holdHint: copyData.methods.hold.hint,
  twoStepHint: copyData.methods['two-step'].hint,
  pressHint: copyData.methods.press.hint,
  holdName: (label: string, server: string): string => fillCopy(copyData.methods.hold.name, { label, server }),
  twoStepName: (label: string, server: string): string => fillCopy(copyData.methods['two-step'].name, { label, server }),
  armedName: (verb: string, server: string): string => fillCopy(copyData.methods['two-step'].armedName, { verb, server }),
  pressName: (label: string, server: string): string => fillCopy(copyData.methods.press.name, { label, server }),
  confirmedStatus: (server: string): string => fillCopy(copyData.confirmedStatus, { server }),
  armedStatus: (verb: string, server: string): string => fillCopy(copyData.methods['two-step'].armedStatus, { verb, server }),
  holdingStatus: (server: string): string => fillCopy(copyData.methods.hold.holdingStatus, { server }),
} as const
</script>

<script setup lang="ts">
import { computed, inject, onBeforeUnmount, onMounted, ref, useId, useSlots, watch } from 'vue'
import { ARM_DELAY_MS, useArmDelay } from '../composables/useArmDelay'
import { MINIMUM_HOLD_MS, useHoldToConfirm } from '../composables/useHoldToConfirm'
// Imported here too: some vue-tsc versions do not let script setup see a value imported only in the plain script block.
import { DEFAULT_CONFIRM_METHOD as defaultConfirmMethod, type ConfirmMethod as ChosenConfirmMethod } from '../confirm-requirement'

/** Two-step: a second press sooner than this after arming is ignored, so a double click is one press. */
const TWO_STEP_MINIMUM_GAP_MS = 500

const props = withDefaults(
  defineProps<{
    serverName: string
    /** Ask for the exact server name before the button works (DELETE, DROP, TRUNCATE). */
    typeToConfirm?: boolean
    label?: string
    durationMs?: number
    /**
     * How the person confirms. 'hold' is press and hold. 'two-step' is for people who cannot sustain a press: one press
     * arms the button, a second confirms. 'press' is one press after the arm delay. The type-the-name guard applies to
     * all three. Left out, it follows the app's remembered preference and then the family default.
     */
    method?: ChosenConfirmMethod | undefined
    /** Show a small button under the control that switches between hold and two presses. */
    offerAlternative?: boolean
    /** Two-step: how long the armed state lasts before it falls back. */
    armWindowMs?: number
    /** Press: how long the button stays locked after it appears. */
    armDelayMs?: number
    /** The app's verb in the armed label ("Press again to commit"). */
    verb?: string
    /** What is about to happen, in the app's words (a statement, a command). Shown in a mono block above the button. */
    preview?: string
    /** The id of a live region outside this card that should read the status words; the card's own region steps aside. */
    statusTarget?: string
  }>(),
  {
    typeToConfirm: false,
    label: 'Confirm on production',
    durationMs: 1500,
    method: undefined,
    offerAlternative: false,
    armWindowMs: 5000,
    armDelayMs: ARM_DELAY_MS,
    verb: 'confirm',
    preview: '',
    statusTarget: '',
  },
)

const emit = defineEmits<{
  confirm: []
  confirmed: [payload: { method: ConfirmedMethod }]
  'update:method': [method: ChosenConfirmMethod]
}>()

/** The typed server name. Cleared after each confirm and when the card goes away; never logged. */
const typedName = defineModel<string>('typedName', { default: '' })
const preference = inject(ROO_CONFIRM_METHOD, null)

const buttonElement = ref<HTMLButtonElement | null>(null)
const chosenMethod = ref<ChosenConfirmMethod>(props.method ?? preference?.value ?? defaultConfirmMethod)
const twoStep = computed(() => chosenMethod.value === 'two-step')
const press = computed(() => chosenMethod.value === 'press')
const armed = ref(false)
const twoStepConfirmed = ref(false)
const pressConfirmed = ref(false)
let armedAt = 0
let armTimer: ReturnType<typeof setTimeout> | undefined
const inputId = useId()
const reasonId = useId()

const armDelay = useArmDelay(
  () => props.armDelayMs,
  () => props.serverName,
)

const hold = useHoldToConfirm(() => props.durationMs, { canConfirm: () => enabled.value })
hold.onConfirm(() => {
  report(props.typeToConfirm ? 'typed_name' : 'hold')
  // Each destructive action needs its own retype.
  typedName.value = ''
})

function report(method: ConfirmedMethod): void {
  emit('confirm')
  emit('confirmed', { method })
}

// Reduced motion: the OS setting or a page that forces it (the kit's .roo-force-reduced class).
function pageForcesReducedMotion(): boolean {
  return typeof document !== 'undefined' && document.documentElement.classList.contains('roo-force-reduced')
}
function systemPrefersReducedMotion(): boolean {
  return typeof window !== 'undefined' && typeof window.matchMedia === 'function'
    ? window.matchMedia('(prefers-reduced-motion: reduce)').matches
    : false
}
const reducedMotion = ref(systemPrefersReducedMotion() || pageForcesReducedMotion())
function readMotionPreference(): void {
  reducedMotion.value = systemPrefersReducedMotion() || pageForcesReducedMotion()
}

function outsideRegion(): HTMLElement | null {
  return props.statusTarget === '' || typeof document === 'undefined' ? null : document.getElementById(props.statusTarget)
}
let wroteOutside = false
const statusFoundOutside = ref(false)

let motionQuery: MediaQueryList | undefined
let classObserver: MutationObserver | undefined
onMounted(() => {
  motionQuery = typeof window.matchMedia === 'function' ? window.matchMedia('(prefers-reduced-motion: reduce)') : undefined
  motionQuery?.addEventListener('change', readMotionPreference)
  classObserver = new MutationObserver(readMotionPreference)
  classObserver.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] })
  statusFoundOutside.value = outsideRegion() !== null
})
onBeforeUnmount(() => {
  motionQuery?.removeEventListener('change', readMotionPreference)
  classObserver?.disconnect()
  clearTimeout(armTimer)
  // The typed name does not outlive the card.
  typedName.value = ''
  const region = outsideRegion()
  if (region && wroteOutside) region.textContent = ''
})

// The fill follows the hold through a custom property written with the CSSOM. A style attribute in the
// template would need style-src 'unsafe-inline' in the app's CSP; CSSOM writes do not.
watch(
  () => hold.progress.value,
  (progress) => buttonElement.value?.style.setProperty('--roo-confirm-progress', String(progress)),
  { flush: 'sync' },
)

const enabled = computed(() => !props.typeToConfirm || typedName.value === props.serverName)
// A plain press is also locked while the arm delay runs.
const unlocked = computed(() => enabled.value && (!press.value || armDelay.ready.value))

// The guard must hold for the whole press, not only when it starts: if the typed name stops
// matching or the target server changes mid-hold, the hold is cancelled and nothing confirms.
watch(enabled, (isEnabled) => {
  if (!isEnabled) {
    hold.cancel()
    disarm()
  }
})
watch(
  () => props.serverName,
  () => {
    hold.cancel()
    disarm()
    twoStepConfirmed.value = false
    pressConfirmed.value = false
    typedName.value = ''
  },
)
watch(
  () => props.method,
  (method) => {
    if (method !== undefined) chooseMethod(method, false)
  },
)

function chooseMethod(method: ChosenConfirmMethod, announce: boolean): void {
  hold.cancel()
  disarm()
  twoStepConfirmed.value = false
  pressConfirmed.value = false
  chosenMethod.value = method
  if (method === 'press') armDelay.restart()
  if (announce) {
    emit('update:method', method)
    if (preference) preference.value = method
  }
}

function disarm(): void {
  clearTimeout(armTimer)
  armed.value = false
}

function arm(): void {
  twoStepConfirmed.value = false
  armed.value = true
  armedAt = performance.now()
  clearTimeout(armTimer)
  armTimer = setTimeout(disarm, props.armWindowMs)
}

function onClick(): void {
  if (press.value) {
    if (!unlocked.value) return
    pressConfirmed.value = true
    report(props.typeToConfirm ? 'typed_name' : 'press')
    typedName.value = ''
    return
  }
  if (!twoStep.value || !enabled.value) return
  if (!armed.value) {
    arm()
    return
  }
  if (performance.now() - armedAt < TWO_STEP_MINIMUM_GAP_MS) return
  disarm()
  twoStepConfirmed.value = true
  report(props.typeToConfirm ? 'typed_name' : 'two_press')
  typedName.value = ''
}

function onBlur(): void {
  hold.cancel()
  disarm()
  pressConfirmed.value = false
}
// An app that fills footer-start gets one row: its actions on the left, the hold button on the right.
const slots = useSlots()
const hasFooterStart = computed(() => slots['footer-start'] !== undefined)
const holding = computed(() => hold.holding.value)
const ringCircumference = 2 * Math.PI * 9
const ringOffset = computed(() => ringCircumference * (1 - hold.progress.value))
const countdown = computed(() => {
  const remainingMs = Math.max(props.durationMs, MINIMUM_HOLD_MS) * (1 - hold.progress.value)
  return CONFIRM_COPY.holdCountdown((Math.round(remainingMs / 100) / 10).toFixed(1))
})
const visibleLabel = computed(() => (twoStep.value && armed.value ? CONFIRM_COPY.armedLabel(props.verb) : props.label))
const accessibleName = computed(() => {
  if (press.value) return CONFIRM_COPY.pressName(props.label, props.serverName)
  if (!twoStep.value) return CONFIRM_COPY.holdName(props.label, props.serverName)
  if (armed.value) return CONFIRM_COPY.armedName(props.verb, props.serverName)
  return CONFIRM_COPY.twoStepName(props.label, props.serverName)
})
const statusMessage = computed(() => {
  if (hold.confirmed.value || twoStepConfirmed.value || pressConfirmed.value) return CONFIRM_COPY.confirmedStatus(props.serverName)
  if (armed.value) return CONFIRM_COPY.armedStatus(props.verb, props.serverName)
  if (holding.value) return CONFIRM_COPY.holdingStatus(props.serverName)
  return ''
})

watch(
  statusMessage,
  (message) => {
    const region = outsideRegion()
    if (!region) return
    region.textContent = message
    wroteOutside = true
  },
  { flush: 'sync' },
)

function begin(): void {
  if (enabled.value) hold.start()
}

function onPointerDown(event: PointerEvent): void {
  if (twoStep.value || press.value) return
  // Only the primary pointer and the main button; a second finger or right click never confirms.
  if (event.isPrimary === false || event.button !== 0) return
  begin()
}

function onKeydown(event: KeyboardEvent): void {
  if (press.value) {
    // A key that was already down when the card appeared repeats here; it must not click the button again and again.
    if (event.repeat && (event.key === ' ' || event.key === 'Enter')) event.preventDefault()
    return
  }
  if (twoStep.value) return
  if (event.key !== ' ' && event.key !== 'Enter') return
  event.preventDefault()
  if (!event.repeat) begin()
}

function onKeyup(event: KeyboardEvent): void {
  if (event.key === ' ' || event.key === 'Enter') hold.cancel()
}
</script>

<template>
  <div class="roo-confirm-prod" :data-method="chosenMethod">
    <div v-if="$slots.prelude" class="roo-confirm-prod-prelude"><slot name="prelude" /></div>
    <div v-if="$slots.mode" class="roo-confirm-prod-mode"><slot name="mode" /></div>
    <pre v-if="preview" class="roo-confirm-prod-preview">{{ preview }}</pre>
    <div v-if="$slots.list" class="roo-confirm-prod-list" role="region" :aria-label="CONFIRM_COPY.listLabel" tabindex="0">
      <slot name="list" />
    </div>

    <label v-if="typeToConfirm" class="roo-confirm-prod-field" :for="inputId">
      <span :id="reasonId">{{ CONFIRM_COPY.typedNamePrefix }} <code>{{ serverName }}</code> {{ CONFIRM_COPY.typedNameSuffix }}</span>
      <input
        :id="inputId"
        v-model="typedName"
        class="roo-confirm-prod-input"
        type="text"
        autocomplete="off"
        spellcheck="false"
        :data-match="enabled"
      />
    </label>

    <div class="roo-confirm-prod-actions" :data-row="hasFooterStart">
      <div v-if="hasFooterStart" class="roo-confirm-prod-footer-start"><slot name="footer-start" /></div>
    <button
      ref="buttonElement"
      type="button"
      class="roo-confirm-prod-button"
      :aria-disabled="!unlocked"
      :aria-describedby="typeToConfirm && !enabled ? reasonId : undefined"
      :aria-label="accessibleName"
      :data-holding="holding"
      :data-confirmed="hold.confirmed.value || twoStepConfirmed || pressConfirmed"
      :data-armed="armed"
      @pointerdown="onPointerDown"
      @pointerup="hold.cancel"
      @pointerleave="hold.cancel"
      @pointercancel="hold.cancel"
      @keydown="onKeydown"
      @keyup="onKeyup"
      @blur="onBlur"
      @click="onClick"
    >
      <span v-if="!reducedMotion && !twoStep && !press" class="roo-confirm-prod-fill" aria-hidden="true" />
      <svg v-if="!reducedMotion && !twoStep && !press" class="roo-confirm-prod-ring" viewBox="0 0 22 22" aria-hidden="true">
        <circle cx="11" cy="11" r="9" class="roo-confirm-prod-ring-track" />
        <circle
          cx="11"
          cy="11"
          r="9"
          class="roo-confirm-prod-ring-progress"
          :stroke-dasharray="ringCircumference"
          :stroke-dashoffset="ringOffset"
        />
      </svg>
      <span class="roo-confirm-prod-label" aria-hidden="true">{{ visibleLabel }}</span>
      <span v-if="reducedMotion && !twoStep && !press" class="roo-confirm-prod-countdown" aria-hidden="true">{{ countdown }}</span>
    </button>
    </div>

    <button
      v-if="offerAlternative && !press"
      type="button"
      class="roo-confirm-prod-alternative"
      @click="chooseMethod(twoStep ? 'hold' : 'two-step', true)"
    >
      {{ twoStep ? CONFIRM_COPY.pressAndHoldLink : CONFIRM_COPY.holdLink }}
    </button>

    <p v-if="!statusFoundOutside" class="roo-confirm-prod-status roo-visually-hidden" role="status">{{ statusMessage }}</p>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-confirm-prod {
    display: inline-grid;
    gap: 8px;
  }

  .roo-confirm-prod-prelude,
  .roo-confirm-prod-mode {
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-confirm-prod-preview {
    margin: 0;
    padding: 8px 12px;
    border-radius: var(--roo-p-radius-medium);
    border: 1px solid var(--roo-border);
    background: var(--roo-editor);
    color: var(--roo-text);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
    white-space: pre-wrap;
    overflow-wrap: anywhere;
  }

  /* The list scrolls on its own, so the typed name and the button never leave the card. */
  .roo-confirm-prod-list {
    max-height: 160px;
    overflow-y: auto;
    font-size: var(--roo-p-size-12);
    color: var(--roo-text);
  }

  .roo-confirm-prod-list:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  .roo-confirm-prod-field {
    display: grid;
    gap: 4px;
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-confirm-prod-field code {
    font-family: var(--roo-font-mono);
    color: var(--roo-text);
  }

  .roo-confirm-prod-input {
    height: var(--roo-field-h);
    padding: 0 10px;
    border-radius: var(--roo-p-radius-medium);
    border: 1px solid var(--roo-control-edge);
    background: var(--roo-editor);
    color: var(--roo-text);
    font: inherit;
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-13);
    transition: border-color var(--roo-fast) var(--roo-ease), box-shadow var(--roo-fast) var(--roo-ease);
  }

  .roo-confirm-prod-input:focus-visible {
    outline: none;
    border-color: var(--roo-env-prod);
    box-shadow: 0 0 0 3px var(--roo-prod-fill);
  }

  .roo-confirm-prod-input[data-match='true'] {
    border-color: var(--roo-env-prod);
  }

  /* Without footer-start the wrapper adds no box, so the button sits in the card grid as before. */
  .roo-confirm-prod-actions {
    display: contents;
  }

  /* With footer-start: one row, secondary actions first, the hold button last; wraps only when too narrow. */
  .roo-confirm-prod-actions[data-row='true'] {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    gap: var(--roo-space-item);
    min-width: 0;
  }

  .roo-confirm-prod-footer-start {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--roo-space-item);
    min-width: 0;
  }

  .roo-confirm-prod-actions[data-row='true'] .roo-confirm-prod-button {
    margin-inline-start: auto;
  }

  .roo-confirm-prod-button {
    position: relative;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    height: var(--roo-control-h);
    padding: 0 16px 0 12px;
    border: 0;
    border-radius: var(--roo-p-radius-medium);
    background: var(--roo-prod-button);
    color: var(--roo-on-prod);
    font: inherit;
    font-size: var(--roo-p-size-13);
    font-weight: 650;
    cursor: default;
    overflow: hidden;
    isolation: isolate;
    user-select: none;
    touch-action: none;
    transition: transform var(--roo-fast) var(--roo-spring), filter var(--roo-fast) var(--roo-ease),
      opacity var(--roo-base) var(--roo-ease);
  }

  .roo-confirm-prod-button:hover {
    filter: brightness(1.06);
  }

  .roo-confirm-prod-button[data-holding='true'] {
    transform: scale(0.98);
  }

  .roo-confirm-prod-button[aria-disabled='true'] {
    opacity: 0.55;
    cursor: default;
    filter: none;
  }

  .roo-confirm-prod-button:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  /* W3: the fill runs left to right while held (driven by progress) and drains back in 150ms. */
  .roo-confirm-prod-fill {
    position: absolute;
    inset: 0;
    z-index: -1;
    background: color-mix(in srgb, var(--roo-on-prod) 18%, transparent);
    transform-origin: left center;
    transform: scaleX(var(--roo-confirm-progress, 0));
    transition: transform 150ms cubic-bezier(.4,0,1,1);
  }

  .roo-confirm-prod-button[data-holding='true'] .roo-confirm-prod-fill {
    transition: none;
  }

  .roo-confirm-prod-ring {
    width: 18px;
    height: 18px;
    transform: rotate(-90deg);
  }

  .roo-confirm-prod-ring circle {
    fill: none;
    stroke-width: 2.5;
  }

  .roo-confirm-prod-ring-track {
    stroke: color-mix(in srgb, var(--roo-on-prod) 30%, transparent);
  }

  .roo-confirm-prod-ring-progress {
    stroke: var(--roo-on-prod);
    stroke-linecap: round;
  }

  .roo-confirm-prod-button[data-armed='true'] {
    box-shadow: 0 0 0 2px var(--roo-bg), 0 0 0 4px var(--roo-env-prod);
  }

  .roo-confirm-prod-alternative {
    justify-self: start;
    padding: 2px 0;
    border: 0;
    background: none;
    color: var(--roo-muted);
    font: inherit;
    font-size: var(--roo-p-size-12);
    text-decoration: underline;
    cursor: default;
  }

  .roo-confirm-prod-alternative:hover {
    color: var(--roo-text);
  }

  .roo-confirm-prod-alternative:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  .roo-confirm-prod-countdown {
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
    font-weight: 600;
  }
}
</style>
