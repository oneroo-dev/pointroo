// The arithmetic of RooOverflowBar, with no DOM: which controls stay in the bar when the width runs out.

export interface OverflowFitItem {
  /** The control's measured width. */
  width: number
  /** Higher stays visible longer. */
  priority: number
  /** A pinned control never folds. */
  pinned: boolean
}

export interface OverflowFitInput {
  items: readonly OverflowFitItem[]
  /** The room the bar may use. */
  containerWidth: number
  /** The space between two neighbours. */
  gap: number
  /** The width of the "More" button, reserved only when at least one control folds. */
  moreWidth: number
}

function spanOf(widths: readonly number[], gap: number): number {
  if (widths.length === 0) return 0
  return widths.reduce((total, width) => total + width, 0) + gap * (widths.length - 1)
}

/**
 * Which controls stay visible, as one boolean per item in the original order. Every control stays when they all fit. Otherwise
 * controls fold one at a time, lowest priority first (a tie folds the right-most first, never a pinned one), until the rest fit
 * beside the "More" button. When the pinned controls alone do not fit, they all stay and everything else folds.
 */
export function visibleItems(input: OverflowFitInput): boolean[] {
  const { items, containerWidth, gap, moreWidth } = input
  const visible = items.map(() => true)
  const keptWidths = (extra: number[]): number[] => [...items.filter((_, index) => visible[index]).map((item) => item.width), ...extra]
  if (spanOf(keptWidths([]), gap) <= containerWidth) return visible
  const foldOrder = items
    .map((item, index) => ({ item, index }))
    .filter(({ item }) => !item.pinned)
    .sort((left, right) => left.item.priority - right.item.priority || right.index - left.index)
  for (const { index } of foldOrder) {
    visible[index] = false
    if (spanOf(keptWidths([moreWidth]), gap) <= containerWidth) break
  }
  return visible
}
