<script setup lang="ts">
// Two or more toolbar actions (RooIconButton or RooButton size="capsule") in one 1px hairline container. A group of one button draws no
// container, so that button looks like any other lone action (Raja 2026-11-22, option 1 "quiet" picked).
defineProps<{
  /** The group's accessible name ("View"). */
  label: string
}>()
</script>

<template>
  <div class="roo-capsule-group" role="group" :aria-label="label"><slot /></div>
</template>

<style scoped>
@layer roo-components {
  .roo-capsule-group {
    /* The toolbar keeps the default control size in every density (Raja 2026-11-23: "for toolbar, it always the current default for any layout"): the buttons and capsules read the comfortable steps, in every layout. */
    --roo-control-h: calc(32px + var(--roo-scale) * 2px);
    --roo-control-h-large: calc(36px + var(--roo-scale) * 2px);
    --roo-icon-button: calc(32px + var(--roo-scale) * 2px);
    --roo-icon: calc(16px + var(--roo-scale) * 1px);
    /* Its width follows its height: a 32 high toolbar control keeps the comfortable insets and gaps (Raja 2026-11-23, compact width). */
    --roo-control-pad-x: 14px;
    --roo-control-pad-x-sm: 10px;
    --roo-control-icon-gap: 8px;
    --roo-control-icon-trim: 0px;
    --roo-control-pad-chevron: 6px;
    --roo-trigger-pad-start: 10px;
    --roo-trigger-pad-end: 6px;
    box-sizing: border-box;
    display: inline-flex;
    flex-shrink: 0;
    align-items: center;
  }

  /* Two or more buttons: one container at the control height with one hairline, the buttons 1px in. */
  .roo-capsule-group:has(> :nth-child(2)) {
    height: var(--roo-control-h);
    padding: 1px;
    border-radius: var(--roo-radius-control);
    box-shadow: inset 0 0 0 1px var(--roo-border);
  }

  /* The buttons' corner is the inner control corner token (6px comfortable, 5px compact), the one the segmented pill and the other compact controls use (Raja 2026-11-21: "the compact's button's roundedness, not matching other elements"). */
  .roo-capsule-group:has(> :nth-child(2)) :deep(.roo-icon-button[data-size='capsule']),
  .roo-capsule-group:has(> :nth-child(2)) :deep(.roo-button[data-size='capsule']) {
    height: calc(var(--roo-control-h) - 2px);
    border: 0;
    border-radius: var(--roo-radius-inner);
  }

  .roo-capsule-group:has(> :nth-child(2)) :deep(.roo-icon-button[data-size='capsule']) {
    width: calc(var(--roo-control-h) - 2px);
  }
}
</style>
