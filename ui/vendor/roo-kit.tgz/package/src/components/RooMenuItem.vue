<script setup lang="ts">
// A row of a RooMenu. With a `submenu` slot it opens a submenu (ArrowRight or Enter, ArrowLeft or Escape to go back);
// with `checked` it is a checkable row (role menuitemcheckbox). `destructive` is the new name for `danger`; `kbd` is the
// new name for `shortcut`. The row height is --roo-menu-row-h (today's 32 until an app opts in to a density).
import { computed, inject, ref } from 'vue'
import { ROO_MENU_DESTRUCTIVE_GROUP } from '../composables/menuGroup'
import { useShortcuts } from '../composables/useShortcuts'
import {
  DropdownMenuCheckboxItem,
  DropdownMenuItem,
  DropdownMenuPortal,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
} from 'reka-ui'
import RooIcon from './RooIcon.vue'
import RooKeyGlyphs from './RooKeyGlyphs.vue'
import type { RooIconName } from '../icons/paths'

const props = withDefaults(
  defineProps<{
    icon?: RooIconName | undefined
    danger?: boolean
    destructive?: boolean
    disabled?: boolean
    shortcut?: string
    kbd?: string
    /** A faint right-aligned note after the label, before any shortcut. */
    hint?: string
    checked?: boolean | undefined
    /** Where a checkable row draws its check: before the icon ('start', the default) or just before the hint ('end'). */
    checkPlacement?: 'start' | 'end'
    /** A registered command (useShortcuts): its label is the default text, its key is shown, and selecting runs it. */
    command?: string | undefined
  }>(),
  { icon: undefined, danger: false, destructive: false, disabled: false, shortcut: '', kbd: '', hint: '', checked: undefined, checkPlacement: 'start', command: undefined },
)

const registry = useShortcuts()
const inDestructiveGroup = inject(ROO_MENU_DESTRUCTIVE_GROUP, false)
const tone = computed(() => (props.danger || props.destructive || inDestructiveGroup ? 'danger' : undefined))
// The registry is plain data, not reactive, so these are read on every render rather than cached.
const keysText = () => props.kbd || props.shortcut || (props.command ? registry.kbdFor(props.command) : '')
const commandLabel = () => (props.command ? registry.labelFor(props.command) : '')
const unavailable = () => props.disabled || (props.command !== undefined && !registry.enabled(props.command))

// Esc inside a submenu closes only the submenu. reka's own handler would close the whole menu, so the key is consumed here
// (preventDefault, and it goes no further) and focus goes back to the trigger row.
const subOpen = ref(false)
const subTrigger = ref<{ $el?: HTMLElement } | null>(null)
function onSubKeydown(event: KeyboardEvent): void {
  if (event.key !== 'Escape') return
  event.preventDefault()
  event.stopPropagation()
  subOpen.value = false
  subTrigger.value?.$el?.focus()
}

function onSelect(): void {
  if (props.command) registry.run(props.command)
}
</script>

<template>
  <DropdownMenuSub v-if="$slots.submenu" v-model:open="subOpen">
    <DropdownMenuSubTrigger ref="subTrigger" class="roo-menu-item" :disabled="unavailable()" :data-tone="tone">
      <RooIcon v-if="icon" class="roo-menu-item-icon" :name="icon" :size="16" />
      <span class="roo-menu-item-label"><slot>{{ commandLabel() }}</slot></span>
      <span v-if="hint" class="roo-menu-item-hint">{{ hint }}</span>
      <kbd v-if="keysText()" class="roo-menu-item-shortcut"><RooKeyGlyphs :text="keysText()" /></kbd>
      <RooIcon class="roo-menu-item-chevron" name="chevron" :size="16" />
    </DropdownMenuSubTrigger>
    <DropdownMenuPortal>
      <DropdownMenuSubContent class="roo-menu" :side-offset="4" @keydown="onSubKeydown">
        <slot name="submenu" />
      </DropdownMenuSubContent>
    </DropdownMenuPortal>
  </DropdownMenuSub>

  <DropdownMenuCheckboxItem
    v-else-if="checked !== undefined"
    class="roo-menu-item"
    :model-value="checked"
    :disabled="unavailable()"
    :data-tone="tone"
    @select="onSelect"
  >
    <span v-if="checkPlacement !== 'end'" class="roo-menu-item-check" aria-hidden="true"><RooIcon v-if="checked" name="check" :size="16" /></span>
    <RooIcon v-if="icon" class="roo-menu-item-icon" :name="icon" :size="16" />
    <span class="roo-menu-item-label"><slot>{{ commandLabel() }}</slot></span>
    <span v-if="checkPlacement === 'end'" class="roo-menu-item-check roo-menu-item-check-end" aria-hidden="true"><RooIcon v-if="checked" name="check" :size="16" /></span>
    <span v-if="hint" class="roo-menu-item-hint">{{ hint }}</span>
    <kbd v-if="keysText()" class="roo-menu-item-shortcut"><RooKeyGlyphs :text="keysText()" /></kbd>
  </DropdownMenuCheckboxItem>

  <DropdownMenuItem v-else class="roo-menu-item" :disabled="unavailable()" :data-tone="tone" @select="onSelect">
    <RooIcon v-if="icon" class="roo-menu-item-icon" :name="icon" :size="16" />
    <span class="roo-menu-item-label"><slot>{{ commandLabel() }}</slot></span>
    <span v-if="hint" class="roo-menu-item-hint">{{ hint }}</span>
    <kbd v-if="keysText()" class="roo-menu-item-shortcut"><RooKeyGlyphs :text="keysText()" /></kbd>
  </DropdownMenuItem>
</template>

<style scoped>
@layer roo-components {
  .roo-menu-item {
    display: flex;
    height: var(--roo-menu-row-h);
    cursor: default;
    user-select: none;
    align-items: center;
    gap: var(--roo-control-icon-gap);
    border-radius: var(--roo-p-radius-small);
    padding: 0 var(--roo-menu-item-pad-x);
    color: var(--roo-text);
    outline: none;
    transition: background-color var(--roo-fast) var(--roo-ease);
  }

  .roo-menu-item[data-highlighted] {
    background: var(--roo-accent-fill);
    color: var(--roo-on-accent-fill);
  }

  .roo-menu-item[data-highlighted] .roo-menu-item-icon,
  .roo-menu-item[data-highlighted] .roo-menu-item-check,
  .roo-menu-item[data-highlighted] .roo-menu-item-chevron {
    color: var(--roo-on-accent-fill);
  }

  .roo-menu-item:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: -2px;
  }

  .roo-menu-item[data-disabled] {
    opacity: 0.4;
  }

  .roo-menu-item[data-tone='danger'] {
    color: var(--roo-prod-text);
  }

  .roo-menu-item-icon {
    width: var(--roo-menu-icon);
    height: var(--roo-menu-icon);
    color: var(--roo-muted);
  }

  .roo-menu-item-check :deep(svg),
  .roo-menu-item-chevron {
    width: var(--roo-menu-icon);
    height: var(--roo-menu-icon);
  }

  .roo-menu-item[data-tone='danger'] .roo-menu-item-icon {
    color: inherit;
  }

  .roo-menu-item-check {
    display: inline-flex;
    flex: none;
    width: var(--roo-menu-icon);
    height: var(--roo-menu-icon);
    color: var(--roo-text);
  }

  .roo-menu-item-check-end + .roo-menu-item-hint {
    margin-inline-start: 0;
  }

  .roo-menu-item[data-highlighted] .roo-menu-item-hint {
    color: var(--roo-on-accent-fill);
  }

  .roo-menu-item-chevron {
    flex: none;
    color: var(--roo-muted);
  }

  .roo-menu-item-label {
    flex: 1;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-menu-item-hint {
    flex: none;
    margin-inline-start: auto;
    color: var(--roo-faint);
    font-size: var(--roo-p-size-12);
  }

  .roo-menu-item-shortcut {
    /* The system face, as in RooKbd: Geist Mono has no key symbols, and a fallback glyph sat small beside the letter. */
    font-family: -apple-system, system-ui, var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    color: var(--roo-faint);
  }

  .roo-menu-item[data-highlighted] .roo-menu-item-shortcut {
    color: var(--roo-on-accent-fill);
  }
  /* On the solid accent highlight everything reads in on-accent-fill (white), a destructive row included, because crimson on orange fails.
     Only where an app has opted in, so an app that has not adopted v2 keeps today's rows. */
  :root[data-density] .roo-menu-item[data-tone='danger'][data-highlighted] {
    color: var(--roo-on-accent-fill);
  }

  :root[data-density] .roo-menu-item[data-tone='danger'][data-highlighted] .roo-menu-item-icon {
    color: var(--roo-on-accent-fill);
  }
}
</style>
