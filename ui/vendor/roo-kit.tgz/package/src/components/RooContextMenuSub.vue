<script setup lang="ts">
// A submenu row for RooContextMenu (or any RooMenu), usable inside any of its group slots. The row shows a chevron and opens
// the items in the default slot on ArrowRight, Enter or hover after a short delay; ArrowLeft or Esc closes only the submenu.
import type { RooIconName } from '../icons/paths'
import RooMenuItem from './RooMenuItem.vue'

withDefaults(defineProps<{ label: string; icon?: RooIconName | undefined; disabled?: boolean }>(), { icon: undefined, disabled: false })
</script>

<template>
  <RooMenuItem :icon="icon" :disabled="disabled">
    {{ label }}
    <template #submenu><slot /></template>
  </RooMenuItem>
</template>
