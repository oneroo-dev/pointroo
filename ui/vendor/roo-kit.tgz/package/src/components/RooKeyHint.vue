<script setup lang="ts">
// A short instruction with its key inline: the words first, then the keycap, so the line reads left to right.
import type { ShortcutPlatform } from '../composables/useShortcuts'
import RooKbd from './RooKbd.vue'

withDefaults(defineProps<{ keys: string; platform?: ShortcutPlatform | undefined }>(), { platform: undefined })
</script>

<template>
  <span class="roo-key-hint">
    <span class="roo-key-hint-label"><slot /></span>
    <RooKbd :keys="keys" :platform="platform" />
  </span>
</template>

<style scoped>
@layer roo-components {
  .roo-key-hint {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-2);
    color: var(--roo-muted);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-11);
    white-space: nowrap;
  }
}
</style>
