<script setup lang="ts">
// The bar at the foot of a settings form. A status note on the left, the actions on the right (usually a secondary Cancel and a primary
// Save). It sticks to the bottom of its scroll container: the background and the top hairline run across the whole pane, while the content
// sits on RooFormSection's column, from the form's left edge to the card's right edge, so the note lines up with the section titles.
// The default slot gets { saveDisabled, saving }: bind them to Save (`:disabled="saveDisabled"`, `:busy="saving"`). Clean turns Save off,
// saving keeps it off while the kit's busy state shows on it, dirty and error leave it on (an error stays retryable).
// Height and centring are the button's, so every state has the same box. Under 600 px of bar width the note and the actions follow the
// single column the form sections stack into.
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    /** `clean` nothing to save, `dirty` changes waiting, `saving` a save in flight, `error` the last save failed. */
    state?: 'clean' | 'dirty' | 'saving' | 'error'
    /** The note text. Defaults to the state's own words; for `error` give the reason. The `note` slot replaces it. */
    note?: string | undefined
    /** The region's accessible name. */
    label?: string
  }>(),
  { state: 'clean', note: undefined, label: 'Save changes' },
)

const stateWords = { clean: 'All changes saved', dirty: 'Unsaved changes', saving: 'Saving changes', error: 'Could not save changes' } as const
const noteText = computed(() => props.note ?? stateWords[props.state])
const saveDisabled = computed(() => props.state === 'clean' || props.state === 'saving')
const saving = computed(() => props.state === 'saving')
</script>

<template>
  <div class="roo-save-bar" role="region" :aria-label="label" :data-state="state">
    <div class="roo-save-bar-column">
      <span class="roo-save-bar-note" aria-live="polite"><slot name="note">{{ noteText }}</slot></span>
      <div class="roo-save-bar-actions"><slot :save-disabled="saveDisabled" :saving="saving" /></div>
    </div>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-save-bar {
    position: sticky;
    bottom: 0;
    z-index: 1;
    flex: none;
    container-type: inline-size;
    container-name: roo-save-bar;
    border-top: 1px solid var(--roo-border);
    background: var(--roo-surface);
    padding: var(--roo-p-space-3) var(--roo-space-page);
    font-family: var(--roo-font-ui);
    color: var(--roo-text);
  }

  .roo-save-bar-column {
    display: flex;
    max-width: calc(var(--roo-form-title-w) + var(--roo-space-section) + var(--roo-form-card-max-w));
    align-items: center;
    justify-content: flex-end;
    gap: var(--roo-space-item);
  }

  .roo-save-bar-note {
    min-width: 0;
    margin-right: auto;
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-save-bar[data-state='error'] .roo-save-bar-note {
    color: var(--roo-danger-text);
  }

  .roo-save-bar-actions {
    display: flex;
    flex: none;
    align-items: center;
    gap: var(--roo-space-item);
  }

  @container roo-save-bar (max-width: 599px) {
    .roo-save-bar-column {
      max-width: none;
    }
  }
}
</style>
