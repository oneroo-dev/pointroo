<script setup lang="ts">
import RooIcon from './RooIcon.vue'

// A busy indicator: the kit's turning `loader` icon (lucide loader-circle) in a status region. RooIcon turns it, and under
// prefers-reduced-motion or the kit's still switches it shows the still form instead of spinning.
withDefaults(defineProps<{ ariaLabel?: string; size?: number | 'token' }>(), { ariaLabel: 'Loading', size: 'token' })
</script>

<template>
  <span class="roo-spinner-status" role="status" :aria-label="ariaLabel">
    <RooIcon name="loader" :size="size" />
  </span>
</template>

<style scoped>
@layer roo-components {
  .roo-spinner-status {
    display: inline-flex;
    align-items: center;
    color: currentColor;
  }
}
</style>
