// The arithmetic of RooChipGroup, with no DOM: how many chips stay in view, and what the "+N" is called. Ported from
// Bellroo's approved chip-group.js, whose cases it keeps.

/**
 * How many chips stay in view. `widths` are the chips' widths in order, `available` is the room the chips may use, `gap` is the
 * space between two items, and `moreWidth(hiddenCount)` is the width of the "+N" chip for that count. Every chip stays when they
 * fit without a "+N". Otherwise the most chips that fit beside the "+N" stay, and never fewer than one, so the first chip always shows.
 */
export function visibleCount(widths: readonly number[], available: number, gap: number, moreWidth: (hiddenCount: number) => number): number {
  function span(count: number): number {
    let total = 0
    for (let index = 0; index < count; index++) total += widths[index] ?? 0
    return total + gap * Math.max(0, count - 1)
  }
  if (widths.length === 0 || span(widths.length) <= available) return widths.length
  for (let kept = widths.length - 1; kept > 1; kept--) {
    if (span(kept) + gap + moreWidth(widths.length - kept) <= available) return kept
  }
  return 1
}

export interface RooChipGroupWords {
  /** The word after the count: "2 more: Urgent, Email". */
  more: string
}

const defaultWords: RooChipGroupWords = { more: 'more' }

/** The accessible name of the "+N" chip: how many are folded, and which, in order. */
export function moreLabel(hiddenNames: readonly string[], words: Partial<RooChipGroupWords> = {}): string {
  const word = words.more ?? defaultWords.more
  return `${hiddenNames.length} ${word}: ${hiddenNames.join(', ')}`
}
