<script lang="ts">
export const SPLIT_MIN_PANE = 360
export const SPLIT_SHEET_AT = 1024
export const SPLIT_KEY_STEP = 8

/**
 * The ratio (the first pane's share of the room) that keeps both panes at least `minPane` wide. When the room cannot
 * hold two minimum panes the split is even, because there is no ratio that honours both.
 */
export function clampRatio(ratio: number, total: number, minPane: number): number {
  if (!(total > 0)) return Math.min(1, Math.max(0, ratio))
  if (total < minPane * 2) return 0.5
  const low = minPane / total
  const high = 1 - low
  return Math.min(high, Math.max(low, ratio))
}

/** Side by side while there is room; under the sheet width the second pane becomes a sheet over the first. */
export function splitLayout(width: number, sheetAt: number = SPLIT_SHEET_AT): 'split' | 'sheet' {
  return width < sheetAt ? 'sheet' : 'split'
}
</script>

<script setup lang="ts">
// Two panes with a draggable edge. The ratio is the first pane's share; neither pane drops under `minPane`
// (360), so a narrow window cannot squeeze a pane into an unreadable strip. Alt with an arrow key, pressed from
// inside either pane, moves the edge 8 px. The second pane can be collapsed to a one-line summary with a Show
// button, and in a window under 1024 wide it becomes a sheet over the first pane (no scrim) instead.
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import RooDivider from './RooDivider.vue'

const props = withDefaults(
  defineProps<{
    /** `beside` puts the second pane at the end; `below` puts it under the first. */
    orientation?: 'beside' | 'below'
    minPane?: number
    /** Show the second pane as its one-line summary only. */
    collapsed?: boolean
    sheetAt?: number
    /** Name for the divider, read aloud. */
    label?: string
    revealLabel?: string
    /** Force the sheet (true) or the side-by-side split (false) whatever the width. Unset follows the width. */
    sheet?: boolean | undefined
    /** Whether the second pane shows as a sheet; the same as `sheetOpen`, under the name Stackroo's mail detail uses. */
    secondOpen?: boolean
    /** Name for the sheet, read aloud. Falls back to `label`. */
    sheetLabel?: string | undefined
  }>(),
  {
    orientation: 'beside',
    minPane: SPLIT_MIN_PANE,
    collapsed: false,
    sheetAt: SPLIT_SHEET_AT,
    label: 'Resize panes',
    revealLabel: 'Show',
    sheet: undefined,
    secondOpen: false,
    sheetLabel: undefined,
  },
)

const ratio = defineModel<number>('ratio', { default: 0.5 })
const sheetOpen = defineModel<boolean>('sheetOpen', { default: false })
const emit = defineEmits<{ reveal: []; reset: [] }>()

const root = ref<HTMLElement | null>(null)
const total = ref(0)
const width = ref(0)
let observer: ResizeObserver | undefined

function measure(): void {
  const box = root.value?.getBoundingClientRect()
  if (!box) return
  width.value = box.width
  total.value = props.orientation === 'beside' ? box.width : box.height
}

onMounted(() => {
  measure()
  if (typeof ResizeObserver === 'undefined' || !root.value) return
  observer = new ResizeObserver((entries) => {
    const box = entries[0]?.contentRect
    if (!box) return
    width.value = box.width
    total.value = props.orientation === 'beside' ? box.width : box.height
  })
  observer.observe(root.value)
})
onBeforeUnmount(() => observer?.disconnect())

const layout = computed(() => {
  if (props.sheet !== undefined) return props.sheet ? 'sheet' : 'split'
  return props.orientation === 'beside' ? splitLayout(width.value, props.sheetAt) : 'split'
})
const sheetShown = computed(() => sheetOpen.value || props.secondOpen)
const effectiveRatio = computed(() => clampRatio(ratio.value, total.value, props.minPane))
const firstSize = computed(() => Math.round(effectiveRatio.value * total.value))
const dividerMin = computed(() => (total.value < props.minPane * 2 ? Math.round(total.value / 2) : props.minPane))
const dividerMax = computed(() => (total.value < props.minPane * 2 ? Math.round(total.value / 2) : total.value - props.minPane))

const firstStyle = computed(() => {
  if (props.collapsed || layout.value === 'sheet') return { flex: '1 1 0' }
  return { flex: `0 0 ${effectiveRatio.value * 100}%` }
})

function onDividerUpdate(size: number): void {
  if (total.value > 0) ratio.value = clampRatio(size / total.value, total.value, props.minPane)
}

function onKeyDown(event: KeyboardEvent): void {
  if (!event.altKey || total.value <= 0 || props.collapsed || layout.value === 'sheet') return
  const grow = props.orientation === 'beside' ? 'ArrowRight' : 'ArrowDown'
  const shrink = props.orientation === 'beside' ? 'ArrowLeft' : 'ArrowUp'
  if (event.key !== grow && event.key !== shrink) return
  event.preventDefault()
  const step = event.key === grow ? SPLIT_KEY_STEP : -SPLIT_KEY_STEP
  onDividerUpdate(firstSize.value + step)
}

defineExpose({ effectiveRatio })
</script>

<template>
  <div ref="root" class="roo-split" :data-orientation="orientation" :data-layout="layout" :data-collapsed="collapsed" @keydown="onKeyDown">
    <div class="roo-split-first" :style="firstStyle">
      <slot name="first" />
    </div>

    <template v-if="collapsed">
      <div class="roo-split-summary">
        <span class="roo-split-summary-text"><slot name="summary" /></span>
        <button type="button" class="roo-split-reveal" @click="emit('reveal')">{{ revealLabel }}</button>
      </div>
    </template>

    <template v-else-if="layout === 'split'">
      <RooDivider
        :model-value="firstSize"
        :orientation="orientation === 'beside' ? 'vertical' : 'horizontal'"
        :min="dividerMin"
        :max="dividerMax"
        :label="label"
        @update:model-value="onDividerUpdate"
        @reset="emit('reset')"
      >
        <template v-if="$slots.readout" #readout="{ size }"><slot name="readout" :size="size" /></template>
      </RooDivider>
      <div class="roo-split-second">
        <div v-if="$slots.head" class="roo-split-head"><slot name="head" /></div>
        <div class="roo-split-body"><slot name="second" /></div>
      </div>
    </template>

    <aside v-else-if="sheetShown" class="roo-split-sheet" role="complementary" :aria-label="sheetLabel ?? label">
      <div v-if="$slots.head" class="roo-split-head"><slot name="head" /></div>
      <div class="roo-split-body"><slot name="second" /></div>
    </aside>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-split {
    position: relative;
    display: flex;
    min-width: 0;
    min-height: 0;
    width: 100%;
    height: 100%;
  }

  .roo-split[data-orientation='beside'] {
    flex-direction: row;
  }

  .roo-split[data-orientation='below'] {
    flex-direction: column;
  }

  .roo-split-first,
  .roo-split-second {
    display: flex;
    min-width: 0;
    min-height: 0;
    flex-direction: column;
    overflow: hidden;
  }

  .roo-split-second {
    flex: 1 1 0;
  }

  .roo-split-body {
    min-height: 0;
    flex: 1 1 auto;
    overflow: auto;
  }

  .roo-split-head {
    display: flex;
    height: var(--roo-pane-head-h);
    flex: none;
    align-items: center;
    gap: var(--roo-gap);
    border-bottom: 1px solid var(--roo-border);
    padding-inline: 8px;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    white-space: nowrap;
  }

  .roo-split-summary {
    display: flex;
    flex: none;
    align-items: center;
    gap: var(--roo-gap);
    border-inline-start: 1px solid var(--roo-border);
    padding-inline: 8px;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    white-space: nowrap;
  }

  .roo-split[data-orientation='below'] .roo-split-summary {
    border-inline-start: 0;
    border-top: 1px solid var(--roo-border);
    height: var(--roo-pane-head-h);
  }

  .roo-split-summary-text {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .roo-split-reveal {
    height: var(--roo-pane-head-h);
    border: 0;
    background: transparent;
    padding-inline: 8px;
    color: var(--roo-text);
    font: inherit;
    white-space: nowrap;
    cursor: default;
  }

  .roo-split-reveal:hover {
    background: var(--roo-raised);
  }

  /* Under the sheet width the second pane covers the first. No scrim: the window stays usable behind it. */
  .roo-split-sheet {
    position: absolute;
    inset-block: 0;
    inset-inline-end: 0;
    z-index: 3;
    display: flex;
    width: min(100%, 480px);
    flex-direction: column;
    border-inline-start: 1px solid transparent;
    background: var(--roo-surface);
    box-shadow: var(--roo-shadow-panel);
    animation: roo-settle var(--roo-base) var(--roo-ease) both;
  }
}
</style>
