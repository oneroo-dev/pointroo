export const ROO_OWNER_NAME = 'Oneroo'
export const ROO_FAMILY_URL = 'https://oneroo.dev'
