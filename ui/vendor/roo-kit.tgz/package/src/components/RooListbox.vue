<script lang="ts">
export interface RooListboxOption<V> {
  value: V
  label: string
  caption?: string
  /** A short muted note at the end of the row. */
  hint?: string
  disabled?: boolean
}

export interface RooListboxSeparator {
  separator: true
}
</script>

<script setup lang="ts" generic="T extends string | number | boolean">
// A list of choices with one active row, used inside RooSelect's popover and anywhere a short pick-one list is needed.
// The listbox itself holds focus and points at the active row with aria-activedescendant. Rows can carry a caption
// (a second line), a `dot` slot, separators between groups and a `footer` slot. The selected row shows the kit's
// selection outline, never a stripe.
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { useId } from 'reka-ui'

type Item = RooListboxOption<T> | RooListboxSeparator

const model = defineModel<T | undefined>()

const props = withDefaults(defineProps<{ options: Item[]; label?: string }>(), { label: '' })

const emit = defineEmits<{ select: [value: T]; escape: [] }>()

defineSlots<{
  dot?: (scope: { option: RooListboxOption<T> }) => unknown
  footer?: () => unknown
}>()

const id = useId(undefined, 'roo-listbox')
const root = ref<HTMLElement | null>(null)

const rows = computed(() => {
  const found: Array<{ option: RooListboxOption<T>; index: number }> = []
  props.options.forEach((item, index) => {
    if (!('separator' in item)) found.push({ option: item, index })
  })
  return found
})

const rowOfItem = computed(() => new Map(rows.value.map((row, position) => [row.index, position])))

function firstEnabled(from: number, step: 1 | -1): number {
  for (let position = from; position >= 0 && position < rows.value.length; position += step) {
    if (!rows.value[position]!.option.disabled) return position
  }
  return -1
}

function startingRow(): number {
  const selected = rows.value.findIndex((row) => row.option.value === model.value && !row.option.disabled)
  return selected >= 0 ? selected : firstEnabled(0, 1)
}

const activeRow = ref(startingRow())

watch(
  () => props.options,
  () => {
    if (activeRow.value >= rows.value.length || rows.value[activeRow.value]?.option.disabled) activeRow.value = startingRow()
  },
)

const activeId = computed(() => (activeRow.value >= 0 ? `${id}-option-${activeRow.value}` : undefined))

function move(step: 1 | -1): void {
  const next = firstEnabled(activeRow.value + step, step)
  if (next >= 0) activeRow.value = next
  scrollActiveIntoView()
}

function jump(to: 'first' | 'last'): void {
  const target = to === 'first' ? firstEnabled(0, 1) : firstEnabled(rows.value.length - 1, -1)
  if (target >= 0) activeRow.value = target
  scrollActiveIntoView()
}

function scrollActiveIntoView(): void {
  const element = activeId.value ? root.value?.querySelector(`#${CSS.escape(activeId.value)}`) : null
  if (element && 'scrollIntoView' in element) (element as HTMLElement).scrollIntoView({ block: 'nearest' })
}

function choose(row: number): void {
  const entry = rows.value[row]
  if (!entry || entry.option.disabled) return
  activeRow.value = row
  model.value = entry.option.value
  emit('select', entry.option.value)
}

let typed = ''
let typedTimer: ReturnType<typeof setTimeout> | undefined

function typeAhead(character: string): void {
  typed += character.toLowerCase()
  clearTimeout(typedTimer)
  typedTimer = setTimeout(() => {
    typed = ''
  }, 500)
  const cycling = [...typed].every((letter) => letter === typed[0])
  const query = cycling ? typed[0]! : typed
  const start = cycling ? activeRow.value + 1 : Math.max(activeRow.value, 0)
  for (let offset = 0; offset < rows.value.length; offset += 1) {
    const position = (start + offset) % rows.value.length
    const option = rows.value[position]!.option
    if (!option.disabled && option.label.toLowerCase().startsWith(query)) {
      activeRow.value = position
      scrollActiveIntoView()
      return
    }
  }
}

function onKeydown(event: KeyboardEvent): void {
  if (event.key === 'ArrowDown') move(1)
  else if (event.key === 'ArrowUp') move(-1)
  else if (event.key === 'Home') jump('first')
  else if (event.key === 'End') jump('last')
  else if (event.key === 'Enter' || event.key === ' ') choose(activeRow.value)
  else if (event.key === 'Escape') {
    emit('escape')
    return
  } else if (event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) typeAhead(event.key)
  else return
  event.preventDefault()
}

onBeforeUnmount(() => clearTimeout(typedTimer))

defineExpose({ focus: () => root.value?.focus() })
</script>

<template>
  <div class="roo-listbox-wrap">
    <div
      ref="root"
      class="roo-listbox"
      role="listbox"
      tabindex="0"
      :aria-label="label || undefined"
      :aria-activedescendant="activeId"
      @keydown="onKeydown"
    >
      <template v-for="(item, index) in options" :key="index">
        <div v-if="'separator' in item" class="roo-listbox-separator" role="separator"></div>
        <div
          v-else
          :id="`${id}-option-${rowOfItem.get(index)}`"
          class="roo-listbox-option"
          :class="{ 'roo-selected-row': item.value === model || rows[activeRow]?.index === index }"
          role="option"
          :aria-selected="item.value === model"
          :aria-disabled="item.disabled || undefined"
          :data-active="rows[activeRow]?.index === index || undefined"
          :data-two-line="item.caption ? 'true' : undefined"
          @click="choose(rowOfItem.get(index)!)"
          @pointermove="!item.disabled && (activeRow = rowOfItem.get(index)!)"
        >
          <span v-if="$slots.dot" class="roo-listbox-dot"><slot name="dot" :option="item" /></span>
          <span class="roo-listbox-text">
            <span class="roo-listbox-label">{{ item.label }}</span>
            <span v-if="item.caption" class="roo-listbox-caption">{{ item.caption }}</span>
          </span>
          <span v-if="item.hint" class="roo-listbox-hint">{{ item.hint }}</span>
        </div>
      </template>
    </div>
    <div v-if="$slots.footer" class="roo-listbox-footer"><slot name="footer" /></div>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-listbox-wrap {
    display: flex;
    flex-direction: column;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-13);
    color: var(--roo-text);
  }

  .roo-listbox {
    display: flex;
    max-height: 280px;
    flex-direction: column;
    gap: 1px;
    overflow-y: auto;
    padding: var(--roo-p-space-1);
    outline: none;
  }

  .roo-listbox:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: -2px;
    border-radius: var(--roo-radius-popover);
  }

  .roo-listbox-option {
    display: flex;
    min-height: var(--roo-menu-row-h);
    box-sizing: border-box;
    align-items: center;
    gap: var(--roo-gap);
    border-radius: var(--roo-p-radius-medium);
    padding: 0 var(--roo-p-space-2);
    cursor: default;
    user-select: none;
  }

  .roo-listbox-option[data-two-line='true'] {
    padding-block: var(--roo-p-space-1);
  }

  .roo-listbox-option[aria-disabled='true'] {
    color: var(--roo-faint);
  }

  .roo-listbox-option.roo-selected-row[aria-disabled='true'] {
    color: var(--roo-muted);
  }

  .roo-listbox-dot {
    display: inline-flex;
    flex-shrink: 0;
    align-items: center;
  }

  .roo-listbox-text {
    display: flex;
    min-width: 0;
    flex-direction: column;
  }

  .roo-listbox-label,
  .roo-listbox-caption {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-listbox-caption {
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-listbox-hint {
    margin-left: auto;
    flex-shrink: 0;
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-listbox-separator {
    margin: var(--roo-p-space-1) var(--roo-p-space-2);
    border-top: 1px solid var(--roo-border);
  }

  .roo-listbox-footer {
    border-top: 1px solid var(--roo-border);
    padding: var(--roo-p-space-1);
  }
}
</style>
