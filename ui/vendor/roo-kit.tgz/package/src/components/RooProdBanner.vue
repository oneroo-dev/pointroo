<script setup lang="ts">
// The band under the Bar. With a `reason` it is one 22 px line on the chrome surface (the tall `first-prod` form is 64 px
// and three lines): the env dot's shape, the words, one outlined action that is a Tab stop, and "and N more · Show" when
// several reasons apply. `view-as` is the one tall, tinted form besides first-prod: a staff member looking at a customer's screens
// ("Viewing as <subject>", the `organization`, a read-only note, the time left from `endsAt` and a Stop action). It is tinted with the
// accent, never the error red, because it is a mode, not a fault; it wraps at a phone width and keeps the Stop action whole.
// With only the old props (`compact`, `serverName`, `unclassified`) it renders today's words and
// layout on the chrome look and warns in development; K8 makes `reason` required.
import { computed, onBeforeUnmount, onMounted, ref } from 'vue'
import { PopoverContent, PopoverPortal, PopoverRoot, PopoverTrigger } from 'reka-ui'
import { isBandReason } from '../band'
import type { BandReason } from '../types/environment'
import RooCountdown from './RooCountdown.vue'
import RooEnvDot from './RooEnvDot.vue'
import RooIcon from './RooIcon.vue'
import { useEscapeLayer } from '../composables/useEscapeLayer'
import { useCollisionPadding } from '../composables/useWindowControlPadding'

/** The copy of the `staff-prod` reason: the staff panel of a production environment. */
const STAFF_PROD_COPY = 'Production staff panel: changes affect real customers.'

/** The read-only note of the `view-as` reason, when the app passes no words of its own. */
const VIEW_AS_NOTE = 'Read-only: nothing you do here changes their account.'

const props = withDefaults(
  defineProps<{
    /** Why the band shows. A closed set; anything else is refused with a warning. */
    reason?: BandReason | undefined
    serverName?: string
    /** Older prop: 22px tall, 180ms slide (Tableroo W9). */
    compact?: boolean
    /** Older prop: unclassified connection, the same prod banner titled by what it is. */
    unclassified?: boolean
    /** How many more reasons apply besides this one. Opens a popover (the `more` slot) so the band never wraps. */
    more?: number
    /** `first-connect` clears itself after this many ms (the app's timeout), or at the first action. */
    timeoutMs?: number
    /** `view-as`: who is being viewed. */
    subject?: string
    /** `view-as`: the account or organization the subject belongs to, shown after the name. */
    organization?: string
    /** `view-as`: when the view ends (ISO or ms). A RooCountdown shows the time left and `expired` is emitted at the end. */
    endsAt?: string | number | undefined
    /** `view-as`: seconds left at which the countdown turns to the warn colour. */
    warnSeconds?: number
  }>(),
  { reason: undefined, serverName: '', compact: false, unclassified: false, more: 0, timeoutMs: 0, subject: '', organization: '', endsAt: undefined, warnSeconds: 60 },
)

const emit = defineEmits<{ clear: []; expired: [] }>()

function developmentBuild(): boolean {
  const environment = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env
  return environment !== undefined && environment.NODE_ENV !== 'production'
}

const reasonRefused = props.reason !== undefined && !isBandReason(props.reason)
const usesOldProps = props.reason === undefined || reasonRefused

if (reasonRefused) {
  console.warn(`[RooProdBanner] reason "${String(props.reason)}" is not one of unclassified, guards-off, first-connect, first-prod, staff-prod, view-as. Showing the plain production band.`)
} else if (props.reason === undefined && developmentBuild()) {
  console.warn('[RooProdBanner] compact, serverName and unclassified without a reason are deprecated. Pass a reason.')
}

// Screen readers skip a live region that arrives already filled, so the text goes in after mount.
const moreOpen = ref(false)
const moreTriggerReference = ref<unknown>(null)
const collisionPadding = useCollisionPadding(moreOpen, moreTriggerReference)
useEscapeLayer(() => moreOpen.value)

// Esc is consumed here and marked handled (preventDefault), so a window-level Esc action knows the popover already took it.
// reka dismisses without preventing the default, and a prevented default would stop its own dismissal, so we close it.
function onEscapeKeyDown(event: KeyboardEvent): void {
  event.preventDefault()
  moreOpen.value = false
}

const announced = ref(false)
const cleared = ref(false)
let clearTimer: ReturnType<typeof setTimeout> | undefined

function clear(): void {
  if (cleared.value) return
  cleared.value = true
  emit('clear')
}

onMounted(() => {
  announced.value = true
  if (props.reason === 'first-connect' && props.timeoutMs > 0) clearTimer = setTimeout(clear, props.timeoutMs)
})
onBeforeUnmount(() => clearTimeout(clearTimer))

function onAction(): void {
  if (props.reason === 'first-connect') clear()
}

const isUnclassified = computed(() => props.reason === 'unclassified' || (usesOldProps && props.unclassified))
const word = computed(() => (isUnclassified.value ? 'unclassified' : 'prod'))
const environment = computed(() => (isUnclassified.value ? 'unclassified' : 'prod'))
const staffProd = computed(() => !usesOldProps && props.reason === 'staff-prod')
const viewAs = computed(() => !usesOldProps && props.reason === 'view-as')
const moreText = computed(() => `and ${props.more} more · Show`)
</script>

<template>
  <div
    v-if="!cleared"
    class="roo-prod-banner"
    :data-compact="compact"
    :data-layout="usesOldProps ? 'legacy' : 'band'"
    :data-reason="usesOldProps ? undefined : reason"
    :role="usesOldProps ? 'status' : undefined"
    :aria-live="usesOldProps ? 'polite' : undefined"
  >
    <template v-if="usesOldProps">
      <template v-if="announced">
        <svg class="roo-prod-banner-icon" viewBox="0 0 16 16" aria-hidden="true">
          <path d="M8 1.5 15 14H1L8 1.5Z" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" />
          <path d="M8 6v3.5M8 11.6v.4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />
        </svg>
        <strong class="roo-prod-banner-title">{{ unclassified ? 'Unclassified' : 'Production' }}</strong>
        <span v-if="serverName" class="roo-prod-banner-server">{{ serverName }}</span>
        <span v-if="unclassified" class="roo-prod-banner-text">treated as production until you classify it.</span>
        <span class="roo-prod-banner-text"><slot /></span>
      </template>
    </template>

    <template v-else-if="viewAs">
      <RooIcon class="roo-prod-banner-eye" name="eye" :size="16" />
      <div class="roo-prod-banner-live roo-prod-banner-viewing" role="status" aria-live="polite">
        <template v-if="announced">
          <slot name="text">
            <span class="roo-prod-banner-who">
              <span class="roo-prod-banner-viewing-label">Viewing as</span>
              <strong class="roo-prod-banner-subject">{{ subject }}</strong>
              <span v-if="organization" class="roo-prod-banner-org"><span aria-hidden="true"> · </span>{{ organization }}</span>
            </span>
          </slot>
          <span class="roo-prod-banner-note"><slot>{{ VIEW_AS_NOTE }}</slot></span>
        </template>
      </div>
      <div v-if="endsAt !== undefined || $slots.action" class="roo-prod-banner-end">
        <RooCountdown v-if="endsAt !== undefined" :ends-at="endsAt" :warn-seconds="warnSeconds" @expired="emit('expired')" />
        <span v-if="$slots.action" class="roo-prod-banner-action"><slot name="action" /></span>
      </div>
    </template>

    <template v-else>
      <span class="roo-prod-banner-dot" aria-hidden="true"><RooEnvDot :environment="environment" /></span>
      <div class="roo-prod-banner-live" role="status" aria-live="polite">
        <template v-if="announced">
          <slot name="text">
            <span v-if="staffProd" class="roo-prod-banner-text">{{ STAFF_PROD_COPY }}</span>
            <strong v-else class="roo-prod-banner-word">{{ word }}</strong>
            <span v-if="serverName" class="roo-prod-banner-server"><span aria-hidden="true"> · </span>{{ serverName }}</span>
          </slot>
          <span class="roo-prod-banner-text"><slot /></span>
        </template>
      </div>
      <PopoverRoot v-if="more > 0" v-model:open="moreOpen">
        <PopoverTrigger ref="moreTriggerReference" class="roo-prod-banner-more" type="button">{{ moreText }}</PopoverTrigger>
        <PopoverPortal>
          <PopoverContent class="roo-prod-banner-popover" side="bottom" align="end" :side-offset="4" :collision-padding="collisionPadding" @escape-key-down="onEscapeKeyDown">
            <slot name="more" />
          </PopoverContent>
        </PopoverPortal>
      </PopoverRoot>
      <span v-if="$slots.action" class="roo-prod-banner-action" @click="onAction"><slot name="action" /></span>
    </template>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-prod-banner {
    box-sizing: border-box;
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 8px;
    min-height: 28px;
    padding: 4px 12px;
    background: var(--roo-prod-band);
    color: var(--roo-prod-band-text);
    font-size: var(--roo-p-size-12);
    overflow: hidden;
    animation: roo-prod-banner-in var(--roo-slow) var(--roo-spring) both;
  }

  .roo-prod-banner[data-compact='true'] {
    gap: 6px;
    min-height: 22px;
    padding: 2px 10px;
    font-size: var(--roo-p-size-12);
    animation: roo-prod-banner-in 180ms cubic-bezier(.2,.8,.2,1) both;
  }

  /* The band: 22 px on one line, a hairline below. Its copy wraps onto more lines at a narrow width and the band grows with it;
     nothing is clipped or ellipsized, so the reason text and the action stay whole. */
  .roo-prod-banner[data-layout='band'] {
    --roo-band-pad: 2px;
    flex-wrap: nowrap;
    height: auto;
    min-height: var(--roo-band-h);
    padding: var(--roo-band-pad) 12px;
    gap: 8px;
    border-bottom: 1px solid var(--roo-border);
    line-height: calc(var(--roo-band-h) - 1px - 2 * var(--roo-band-pad));
    white-space: normal;
  }

  /* The view-as band: the accent tint (a mode, not a fault, so never the error red), a 2 px accent rule under it and 36 px of height,
     so a staff member cannot miss it. The copy and the end group wrap: on a phone the words take the first lines and the time and Stop
     sit together on their own line, Stop always whole and at the end. */
  .roo-prod-banner[data-reason='view-as'] {
    --roo-view-as-ink: var(--roo-text);
    flex-wrap: wrap;
    min-height: calc(var(--roo-band-h) + var(--roo-p-space-3));
    padding: var(--roo-p-space-2) var(--roo-p-space-3);
    gap: var(--roo-p-space-2) var(--roo-p-space-3);
    border-bottom: 2px solid var(--roo-accent);
    background: color-mix(in srgb, var(--roo-accent) 10%, var(--roo-surface));
    color: var(--roo-view-as-ink);
    font-size: var(--roo-ui-size);
    line-height: 1.4;
  }

  .roo-prod-banner[data-reason='view-as'][data-layout='band'] .roo-prod-banner-live {
    flex: 1 1 var(--roo-p-space-8);
    min-width: min(100%, calc(var(--roo-p-space-8) * 10));
    display: flex;
    flex-wrap: wrap;
    align-items: baseline;
    gap: 0 var(--roo-p-space-3);
  }

  .roo-prod-banner-eye {
    flex: none;
    color: var(--roo-accent-text);
  }

  .roo-prod-banner-subject {
    font-weight: 700;
  }

  .roo-prod-banner-viewing-label {
    margin-inline-end: var(--roo-p-space-1);
  }

  .roo-prod-banner-org {
    color: var(--roo-muted);
  }

  .roo-prod-banner-note {
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }

  .roo-prod-banner-end {
    display: inline-flex;
    flex: none;
    flex-wrap: wrap;
    align-items: center;
    gap: var(--roo-p-space-2) var(--roo-p-space-3);
    margin-inline-start: auto;
  }

  /* Stop is a real button, not the 18 px outline of the other bands: this band is the one place the action must be easy to hit. */
  .roo-prod-banner[data-reason='view-as'] .roo-prod-banner-action :slotted(button) {
    --roo-band-action-h: var(--roo-control-h);
    border-color: var(--roo-accent-text);
    background: var(--roo-surface);
    color: var(--roo-text);
    font-size: var(--roo-ui-size);
    font-weight: 600;
    padding: 0 var(--roo-p-space-3);
  }

  /* The one tall form, once ever: 64 px and three lines. */
  .roo-prod-banner[data-reason='first-prod'] {
    align-items: flex-start;
    height: auto;
    min-height: 64px;
    padding: 8px 12px;
    white-space: normal;
    animation-name: roo-prod-banner-in-tall;
  }

  .roo-prod-banner[data-layout='band'] .roo-prod-banner-live {
    flex: 1 1 0;
    min-width: 0;
    overflow: visible;
    overflow-wrap: anywhere;
  }

  .roo-prod-banner[data-reason='first-prod'] .roo-prod-banner-live {
    overflow: visible;
    text-overflow: clip;
  }

  .roo-prod-banner-dot {
    display: inline-flex;
    flex: none;
  }

  .roo-prod-banner-icon {
    flex: none;
    width: 14px;
    height: 14px;
  }

  .roo-prod-banner[data-compact='true'] .roo-prod-banner-icon {
    width: 12px;
    height: 12px;
  }

  .roo-prod-banner-title,
  .roo-prod-banner-word {
    font-size: var(--roo-p-size-12);
    font-weight: 700;
  }

  .roo-prod-banner-server {
    font-family: var(--roo-font-mono);
    font-weight: 600;
    overflow-wrap: anywhere;
  }

  .roo-prod-banner-text {
    opacity: 0.92;
  }

  .roo-prod-banner-more {
    flex: none;
    padding: 0;
    border: 0;
    background: none;
    color: inherit;
    font: inherit;
    text-decoration: underline;
    cursor: default;
  }

  .roo-prod-banner-more:focus-visible,
  .roo-prod-banner-action :slotted(button):focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  .roo-prod-banner-action {
    display: inline-flex;
    flex: none;
  }

  /* The action: one outlined button, 18 px tall, reached with Tab. */
  .roo-prod-banner-action :slotted(button) {
    --roo-band-action-h: 18px;
    height: var(--roo-band-action-h);
    padding: 0 8px;
    border: 1px solid currentColor;
    border-radius: var(--roo-p-radius-small);
    background: transparent;
    color: inherit;
    font: inherit;
    font-size: var(--roo-p-size-12);
    line-height: 1;
    cursor: default;
  }

  /* No max-height in the keyframes: the end frame is held, and a cap there clipped any banner that wraps taller than it. */
  @keyframes roo-prod-banner-in {
    from {
      opacity: 0;
      transform: translateY(-6px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @keyframes roo-prod-banner-in-tall {
    from {
      opacity: 0;
      transform: translateY(-6px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
}
</style>

<style>
@layer roo-components {
  .roo-prod-banner-popover {
    z-index: 80;
    max-width: 320px;
    box-sizing: border-box;
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-radius-popover);
    background: var(--roo-surface);
    padding: var(--roo-p-space-2) var(--roo-p-space-3);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    color: var(--roo-text);
    box-shadow: var(--roo-shadow-popover);
  }
}
</style>
