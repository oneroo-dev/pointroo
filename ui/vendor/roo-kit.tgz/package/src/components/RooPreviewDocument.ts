// The document RooPreviewFrame puts in its iframe. Kept as plain functions so the policy can be tested and read on its own.

/** The width of the mobile preview, in css px. */
export const PREVIEW_MOBILE_WIDTH = 375

/**
 * The content security policy of the preview document. Nothing loads by default; styles may be inline; images may come from
 * data: and, once the person allowed it, from https:. There is no script-src, because the iframe sandbox already runs no scripts.
 */
export function previewPolicy(imagesBlocked: boolean): string {
  return `default-src 'none'; img-src ${imagesBlocked ? 'data:' : 'data: https:'}; style-src 'unsafe-inline'`
}

/**
 * The full document for the iframe's srcdoc. The policy meta comes first, so it is in force before the app's html is read.
 * The html is the app's own, already cleaned: it is put in as it is. A light colour scheme and a canvas background make the
 * mail draw on white in a dark theme too, as a real mail client does. The base target and the empty sandbox make a link do nothing.
 */
export function buildPreviewDocument(html: string, imagesBlocked: boolean): string {
  return [
    '<!doctype html><html><head><meta charset="utf-8">',
    `<meta http-equiv="Content-Security-Policy" content="${previewPolicy(imagesBlocked)}">`,
    '<meta name="color-scheme" content="light">',
    '<base target="_blank">',
    '<style>html{background:Canvas;color:CanvasText}body{margin:0;overflow-wrap:anywhere}</style>',
    '</head><body>',
    html,
    '</body></html>',
  ].join('')
}
