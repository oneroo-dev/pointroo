<script setup lang="ts">
// Internal: the full label of a row (a tree row today) in a RooTooltip, for a row whose own element has to stay the one root
// element and the focus target. The row drives it: `enter` and `leave` for the pointer, `show` and `hide` for focus. It
// goes through the tooltip's own open logic, so the provider's delay applies and moving between rows skips it. It anchors
// to a box that covers the row (the row must be positioned) and never takes the pointer. Without a RooTooltipProvider above
// it renders nothing and every call does nothing.
import { computed, defineComponent, ref } from 'vue'
import { injectTooltipProviderContext, injectTooltipRootContext } from 'reka-ui'
import RooTooltip from './RooTooltip.vue'

const props = defineProps<{ text: string }>()

// A long identifier wraps at its own separators (after _ / . - and :), never one stray character on a line of its own.
const wrappableText = computed(() => props.text.replace(/([_/.:-])/g, '$1\u200B'))

const hasTooltipProvider = injectTooltipProviderContext(null as never) !== null

const Driver = defineComponent({
  name: 'RooRowTipDriver',
  setup(_, { expose }) {
    const context = injectTooltipRootContext()
    expose({
      enter: () => context.onTriggerEnter(),
      show: () => context.onOpen(),
      hide: () => context.onClose(),
    })
    return () => null
  },
})

const driver = ref<{ enter: () => void; show: () => void; hide: () => void } | null>(null)

defineExpose({
  enter: () => driver.value?.enter(),
  leave: () => driver.value?.hide(),
  show: () => driver.value?.show(),
  hide: () => driver.value?.hide(),
})
</script>

<template>
  <RooTooltip v-if="hasTooltipProvider" :text="wrappableText">
    <span class="roo-row-tip-anchor" aria-hidden="true"><Driver ref="driver" /></span>
  </RooTooltip>
</template>

<style scoped>
@layer roo-components {
  .roo-row-tip-anchor {
    position: absolute;
    inset: 0;
    pointer-events: none;
  }
}
</style>
