<script setup lang="ts">
import { computed, ref, useAttrs, useSlots } from 'vue'
import { useId } from 'reka-ui'
import RooIcon from './RooIcon.vue'

defineOptions({ inheritAttrs: false })

const model = defineModel<string | number>()

const props = withDefaults(
  defineProps<{
    label?: string
    hint?: string
    error?: string
    type?: string
    placeholder?: string
    disabled?: boolean
    mono?: boolean
    /** `lg` is the form field height (--roo-control-h-large); `md` is the toolbar control height (--roo-control-h); `xl` is 44px (--roo-control-h-xl) for sign-in screens; `sm` and `compact` are the same height, --roo-compact-control-h, for grid filter rows; `cozy` is 24px (--roo-cozy-control-h), between compact and md, with the compact corner and padding; `xs` and `xxs` match the RooIconButton sizes of the same name (--roo-icon-button, --roo-icon-button-xxs), so a search field beside an icon button is exactly as tall, border included. A search field with no size is `md`, the height of the `md` icon button. */
    size?: 'compact' | 'cozy' | 'sm' | 'md' | 'lg' | 'xl' | 'xs' | 'xxs'
    /** `quiet` drops the border and draws the field on --roo-raised like the quiet buttons; focus moves it to --roo-x-field-quiet-focus, and nothing else changes. Independent of size. */
    variant?: 'default' | 'quiet'
    required?: boolean
    /** The accessible name for a field with no visible label. */
    ariaLabel?: string
    /** The id of an element that describes the field; joined with the hint or error note when both exist. */
    ariaDescribedby?: string
    /** Where the `count` slot sits: `below` (default) under the field at its end; `inside` in the field at its end. */
    countPlacement?: 'below' | 'inside'
  }>(),
  {
    label: '',
    hint: '',
    error: '',
    type: 'text',
    placeholder: '',
    disabled: false,
    mono: false,
    variant: 'default',
    required: false,
    countPlacement: 'below',
  },
)

// type="search" draws the search glyph in the leading position unless the caller supplies its own leading slot.
const slots = useSlots()
const resolvedSize = computed(() => props.size ?? (props.type === 'search' ? 'md' : 'lg'))
const showsSearchIcon = computed(() => props.type === 'search' && !slots.leading)
const countInside = computed(() => Boolean(slots.count) && props.countPlacement === 'inside')
const adorned = computed(() => Boolean(slots.leading || slots.trailing || showsSearchIcon.value || countInside.value))

const attributes = useAttrs()
const generatedId = useId(undefined, 'roo-input')
const id = computed(() => (typeof attributes.id === 'string' && attributes.id ? attributes.id : generatedId))
// class, style and data-* stay on the field, so a parent's layout and selectors such as [data-field] input keep working;
// native input attributes, aria-* and listeners go to the input itself.
function staysOnField(name: string): boolean {
  return name === 'class' || name === 'style' || name.startsWith('data-')
}
const rootAttributes = computed(() => Object.fromEntries(Object.entries(attributes).filter(([name]) => staysOnField(name))))
const inputAttributes = computed(() => Object.fromEntries(Object.entries(attributes).filter(([name]) => !staysOnField(name) && name !== 'id')))
const inputElement = ref<HTMLInputElement>()

function focusFromBox(event: MouseEvent) {
  const target = event.target as Element | null
  if (!inputElement.value || !target || target === inputElement.value) return
  if (target.closest('button, a, input, select, textarea, [tabindex], [contenteditable]')) return
  event.preventDefault()
  inputElement.value.focus()
}

defineExpose({ focus: () => inputElement.value?.focus(), inputElement })

function describedBy(noteExists: boolean, extraId: string | undefined): string | undefined {
  const ids = [noteExists ? `${id.value}-note` : undefined, slots.count ? `${id.value}-count` : undefined, extraId].filter((value) => value)
  return ids.length > 0 ? ids.join(' ') : undefined
}
</script>

<template>
  <div class="roo-field" v-bind="rootAttributes">
    <label v-if="label" class="roo-field-label" :for="id">
      {{ label }}<span v-if="required" class="roo-field-required" aria-hidden="true">*</span>
    </label>
    <div class="roo-field-box" :data-size="resolvedSize" :data-variant="variant" :data-adorned="adorned ? 'true' : undefined" :data-search="showsSearchIcon ? 'true' : undefined" @mousedown="focusFromBox">
      <span v-if="$slots.leading || showsSearchIcon" class="roo-field-leading">
        <slot name="leading"><RooIcon name="search" :size="14" /></slot>
      </span>
    <input
      v-bind="inputAttributes"
      :id="id"
      ref="inputElement"
      v-model="model"
      class="roo-field-control roo-input"
      :class="{ 'is-mono': mono }"
      :data-size="resolvedSize"
      :data-variant="variant"
      :type="type"
      :placeholder="placeholder"
      :disabled="disabled"
      :aria-invalid="error ? 'true' : undefined"
      :aria-required="required ? 'true' : undefined"
      :aria-label="ariaLabel"
      :aria-describedby="describedBy(Boolean(error || hint), ariaDescribedby)"
    />
      <span v-if="countInside" :id="`${id}-count`" class="roo-field-count" data-placement="inside"><slot name="count" /></span>
      <span v-if="$slots.trailing" class="roo-field-trailing"><slot name="trailing" /></span>
    </div>
    <p
      v-if="error || hint"
      :id="`${id}-note`"
      class="roo-field-note"
      :data-error="error ? 'true' : undefined"
      :role="error ? 'alert' : undefined"
    >
      {{ error || hint }}
    </p>
    <!-- The count slot: a short figure such as a character count, right under the field at its end. -->
    <div v-if="$slots.count && !countInside" :id="`${id}-count`" class="roo-field-count"><slot name="count" /></div>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-field {
    display: flex;
    flex-direction: column;
    gap: 6px;
  }

  .roo-field-label {
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    font-weight: 500;
    color: var(--roo-muted);
  }

  .roo-field-required {
    margin-left: 2px;
    color: var(--roo-danger-text);
  }

  .roo-field-control {
    width: 100%;
    box-sizing: border-box;
    border: 1px solid var(--roo-field-edge);
    border-radius: var(--roo-radius-control);
    background: var(--roo-surface);
    padding: 0 var(--roo-field-pad-x);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-ui-size);
    color: var(--roo-text);
    transition:
      border-color var(--roo-fast) var(--roo-ease),
      box-shadow var(--roo-fast) var(--roo-ease);
  }

  .roo-field-control.is-mono {
    font-family: var(--roo-font-mono);
  }

  .roo-field-control::placeholder {
    color: var(--roo-faint);
  }

  .roo-field-control:hover:not(:disabled) {
    border-color: var(--roo-text);
  }

  /* Focus is the caret, a brighter fill and the border in the focus colour, never an outline or a ring (family rule, Raja 2026-11-13; border added 2026-11-25). */
  .roo-field-control:focus {
    outline: none;
    background: var(--roo-raised);
  }

  .roo-field-control:focus:not(:disabled):not([aria-invalid='true']) {
    border-color: var(--roo-focus);
  }

  /* On a popover, menu, palette or dialog surface the plain raised fill is too far from the surface; use the matched step. */
  :is(.roo-popover, .roo-select-popover, .roo-menu, .roo-palette, .roo-dialog) .roo-field-control:focus {
    background: var(--roo-raised-on-raised);
  }

  .roo-field-control:disabled {
    opacity: 0.4;
  }

  .roo-field-control[aria-invalid='true'] {
    border-color: var(--roo-danger);
  }

  .roo-input {
    height: var(--roo-field-h);
  }

  /* Under compact density a whole-pixel line box keeps the value on a whole pixel: (height minus border minus line) is even. */
  :root[data-density='compact'] .roo-field-control:not([data-size='xl']) {
    line-height: var(--roo-control-line);
  }

  .roo-input[data-size='md'] {
    height: var(--roo-control-h);
  }

  .roo-input[data-size='xs'] {
    height: var(--roo-icon-button);
  }

  .roo-input[data-size='xxs'] {
    height: var(--roo-icon-button-xxs);
  }

  /* Sign-in screens: 44px, 14px text, 16px side padding. Density never changes it. */
  .roo-input[data-size='xl'] {
    height: var(--roo-control-h-xl);
    padding: 0 16px;
    font-size: var(--roo-p-size-14);
  }

  /* With no leading or trailing slot the box has no box: it vanishes and the input draws itself exactly as before. With one,
     the box takes the field's border, fill and height, and the input inside goes bare. */
  .roo-field-box {
    display: contents;
  }

  .roo-field-box[data-adorned='true'] {
    display: flex;
    align-items: center;
    gap: var(--roo-p-space-2);
    box-sizing: border-box;
    width: 100%;
    height: var(--roo-field-h);
    padding: 0 var(--roo-field-pad-x);
    border: 1px solid var(--roo-field-edge);
    border-radius: var(--roo-radius-control);
    background: var(--roo-surface);
    transition:
      border-color var(--roo-fast) var(--roo-ease),
      background-color var(--roo-fast) var(--roo-ease);
  }

  .roo-field-box[data-adorned='true'][data-size='md'] {
    height: var(--roo-control-h);
  }

  .roo-field-box[data-adorned='true'][data-size='xs'] {
    height: var(--roo-icon-button);
  }

  /* A search field: its own height step (22 in compact, a step above the chrome control; a RooSegmented with size="search" matches it), and its glyph follows the density. */
  .roo-field-box[data-adorned='true'][data-search='true'][data-size='md'] {
    height: var(--roo-search-h);
  }

  .roo-field-box[data-search='true'] .roo-field-leading :deep(svg) {
    width: var(--roo-search-glyph);
    height: var(--roo-search-glyph);
  }

  .roo-field-box[data-adorned='true'][data-size='xxs'] {
    height: var(--roo-icon-button-xxs);
  }

  .roo-field-box[data-adorned='true'][data-size='xl'] {
    height: var(--roo-control-h-xl);
    padding: 0 var(--roo-p-space-4);
  }

  .roo-field-box[data-adorned='true']:hover:not(:has(:disabled)) {
    border-color: var(--roo-text);
  }

  .roo-field-box[data-adorned='true']:focus-within {
    background: var(--roo-raised);
  }

  .roo-field-box[data-adorned='true']:focus-within:not(:has(:disabled)):not(:has([aria-invalid='true'])) {
    border-color: var(--roo-focus);
  }

  :is(.roo-popover, .roo-select-popover, .roo-menu, .roo-palette, .roo-dialog) .roo-field-box[data-adorned='true']:focus-within {
    background: var(--roo-raised-on-raised);
  }

  .roo-field-box[data-adorned='true']:has(:disabled) {
    opacity: 0.4;
  }

  .roo-field-box[data-adorned='true']:has([aria-invalid='true']) {
    border-color: var(--roo-danger);
  }

  .roo-field-box[data-adorned='true'] .roo-input {
    flex: 1;
    min-width: 0;
    height: 100%;
    padding: 0;
    border: 0;
    background: transparent;
  }

  .roo-field-box[data-adorned='true'] .roo-input:focus {
    background: transparent;
  }

  /* Compact grid filter field: chip height, item padding, small radius, and the row's 12px value text (the default field stays 13). */
  .roo-input[data-size='sm'],
  .roo-input[data-size='compact'] {
    height: var(--roo-compact-control-h);
    padding: 0 var(--roo-space-item);
    border-radius: var(--roo-p-radius-small);
    font-size: var(--roo-p-size-12);
  }

  /* Cozy: 24px (the border is inside), item padding, the small corner and 12px text. */
  .roo-input[data-size='cozy'] {
    height: var(--roo-cozy-control-h);
    padding: 0 var(--roo-space-item);
    border-radius: var(--roo-p-radius-small);
    font-size: var(--roo-p-size-12);
  }

  .roo-field-box[data-adorned='true'][data-size='cozy'] {
    height: var(--roo-cozy-control-h);
    padding: 0 var(--roo-space-item);
    border-radius: var(--roo-p-radius-small);
  }

  .roo-field-box[data-adorned='true'][data-size='sm'],
  .roo-field-box[data-adorned='true'][data-size='compact'] {
    height: var(--roo-compact-control-h);
    padding: 0 var(--roo-space-item);
    border-radius: var(--roo-p-radius-small);
  }

  /* Quiet: no visible border (a transparent one keeps the box size, and an invalid field still turns it to the danger colour), the
     fill is the only edge, and focus changes the fill only. */
  .roo-field-control[data-variant='quiet'] {
    border-color: transparent;
    transition: background-color var(--roo-fast) var(--roo-ease);
  }

  .roo-field-control[data-variant='quiet']:not(:focus) {
    background: var(--roo-raised);
  }

  .roo-field-control[data-variant='quiet']:focus,
  :is(.roo-popover, .roo-select-popover, .roo-menu, .roo-palette, .roo-dialog) .roo-field-control[data-variant='quiet']:focus {
    background: var(--roo-x-field-quiet-focus);
  }

  .roo-field-control[data-variant='quiet']:hover:not(:disabled):not([aria-invalid='true']) {
    border-color: transparent;
  }

  .roo-field-control[data-variant='quiet'][aria-invalid='true'],
  .roo-field-control[data-variant='quiet'][aria-invalid='true']:hover:not(:disabled) {
    border-color: var(--roo-danger);
  }

  .roo-field-box[data-adorned='true'][data-variant='quiet'] {
    border-color: transparent;
  }

  .roo-field-box[data-adorned='true'][data-variant='quiet']:not(:focus-within) {
    background: var(--roo-raised);
  }

  .roo-field-box[data-adorned='true'][data-variant='quiet']:focus-within,
  :is(.roo-popover, .roo-select-popover, .roo-menu, .roo-palette, .roo-dialog) .roo-field-box[data-adorned='true'][data-variant='quiet']:focus-within {
    background: var(--roo-x-field-quiet-focus);
  }

  .roo-field-box[data-adorned='true'][data-variant='quiet']:hover:not(:has(:disabled)):not(:has([aria-invalid='true'])) {
    border-color: transparent;
  }

  .roo-field-box[data-adorned='true'][data-variant='quiet'] .roo-input,
  .roo-field-box[data-adorned='true'][data-variant='quiet'] .roo-input:focus {
    background: transparent;
  }

  /* A search field in a sidebar: the glyph starts where the tree row's leading column starts, --roo-tree-text-line from the sidebar
     edge, less the tree's own inset (the field sits in the same inset column as the rows) and less the 1px border the box keeps.
     The glyph takes the tree's chevron cell (--roo-tree-indent minus --roo-gap) and the box gap is --roo-gap, so the typed text
     starts --roo-tree-indent after the row start: the same x as a tree row's label. */
  .roo-field-box[data-adorned='true'][data-search='true'] {
    gap: var(--roo-gap);
    padding-inline-start: calc(var(--roo-tree-text-line) - var(--roo-tree-inset) - 1px);
  }

  .roo-field-box[data-search='true'] .roo-field-leading {
    width: calc(var(--roo-tree-indent) - var(--roo-gap));
    justify-content: center;
  }

  .roo-field-control[type='search']::-webkit-search-decoration,
  .roo-field-control[type='search']::-webkit-search-cancel-button {
    appearance: none;
  }

  .roo-field-count {
    align-self: flex-end;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
    color: var(--roo-muted);
  }

  .roo-field-count[data-placement='inside'] {
    display: inline-flex;
    flex: none;
    align-items: center;
    align-self: center;
  }

  .roo-field-leading,
  .roo-field-trailing {
    display: inline-flex;
    flex: none;
    align-items: center;
    color: var(--roo-muted);
  }

  .roo-field-note {
    margin: 0;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    color: var(--roo-faint);
  }

  .roo-field-note[data-error='true'] {
    color: var(--roo-danger-text);
  }
}
</style>
