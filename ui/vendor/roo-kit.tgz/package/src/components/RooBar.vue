<script lang="ts">
import { detectPlatform } from '../composables/useShortcuts'

/** The window chrome the bar makes room for. 'web' is a browser-hosted app (the staff admin panel): no window buttons, so no
 *  traffic-light inset, no titleBarOverlay spacer and no drag region. It is never detected; an app opts in with platform="web". */
export type RooBarPlatform = 'mac' | 'windows' | 'linux' | 'web'

/** The window's platform, reusing the shortcut platform check for macOS and telling Windows from Linux the same way. */
export function detectBarPlatform(): RooBarPlatform {
  if (detectPlatform() === 'mac') return 'mac'
  if (typeof navigator === 'undefined') return 'linux'
  return /win/i.test(navigator.platform || navigator.userAgent) ? 'windows' : 'linux'
}
</script>

<script setup lang="ts">
// The top bar of the window. It is the window's drag handle: the background drags, and every control inside it opts
// out automatically (button, link, field, anything with a role of button or tab, anything focusable), so an app
// never writes `no-drag` itself. Slots run in a fixed order: leading, pill, tabs, crumb, lead, jump, tools,
// window-controls, menu. The crumb takes the spare room and truncates; the other slots keep their size, so a
// label in the bar never wraps. The optional tabs slot holds a RooTabStrip standing on the bar's bottom line, as
// Markroo's bar does (Raja 2026-11-17): it is then the only part that grows, so the crumb is not drawn (it belongs in
// the app's document header row) and on a narrow window the strip folds into its tab list before any control is
// squeezed. Its strip line covers the bar border so the line never doubles, and the space after the last tab still
// drags the window. The strip passes through untouched: pinned tabs and its `after` slot work as anywhere else. A bar without tabs renders exactly as it did before the slot existed.
// Window chrome follows the platform (family rule): the traffic-light inset is macOS only, and on Windows the bar ends
// with a spacer the width of the titleBarOverlay buttons (env(titlebar-area-*)), so no control sits under them.
// The leading slot starts with the app's mark (RooAppMark, a bare 26px glyph set 1px low, no box; Raja 2026-11-19), right after the window buttons, then the sidebar toggle, then the pill comes in its own slot. The apps fill the slot, so the order is theirs to keep. Everything in the bar shares one
// vertical centre: the bar is --roo-bar-h (44px) tall and the bar and each slot use align-items: center (the tabs slot
// stands on the bar line on purpose). For the macOS traffic lights (12px) to sit on that centre too, the app sets
// Electron's trafficLightPosition y to (barHeight - 12) / 2 = 16 at the 44px bar.
// The platform is detected the way the shortcut labels detect it (mac, windows or linux, never web); an app may pass `platform` to override.
// A browser-hosted app passes platform="web": the page is not a window, so the bar has no inset, no spacer and does not drag.
import { computed, inject, useSlots } from 'vue'
import { ROO_WINDOW_SHELL } from '../composables/windowShell'

const props = defineProps<{ label?: string; platform?: RooBarPlatform }>()

const resolvedPlatform = computed(() => props.platform ?? detectBarPlatform())

const slots = useSlots()
// Inside a RooWindow the leading and pill slots share one box (display: contents unless the roomy web shell makes it the header's first column).
const inWindow = inject(ROO_WINDOW_SHELL, false)
if (slots.tabs && slots.crumb) {
  console.warn('[RooBar] tabs and crumb are both filled. With tabs in the Bar the crumb is not drawn; put it in the document header row.')
}
</script>

<template>
  <header class="roo-bar" data-roo-region="bar" :data-platform="resolvedPlatform" :aria-label="label">
    <div v-if="inWindow && ($slots.leading || $slots.pill)" class="roo-bar-start">
      <div v-if="$slots.leading" class="roo-bar-slot" data-slot="leading"><slot name="leading" /></div>
      <div v-if="$slots.pill" class="roo-bar-slot" data-slot="pill"><slot name="pill" /></div>
    </div>
    <template v-else>
      <div v-if="$slots.leading" class="roo-bar-slot" data-slot="leading"><slot name="leading" /></div>
      <div v-if="$slots.pill" class="roo-bar-slot" data-slot="pill"><slot name="pill" /></div>
    </template>
    <div v-if="$slots.tabs" class="roo-bar-slot roo-bar-grow" data-slot="tabs"><slot name="tabs" /></div>
    <div v-if="$slots.crumb && !$slots.tabs" class="roo-bar-slot roo-bar-grow" data-slot="crumb"><slot name="crumb" /></div>
    <div v-if="$slots.lead" class="roo-bar-slot" data-slot="lead"><slot name="lead" /></div>
    <div v-if="$slots.jump" class="roo-bar-slot" data-slot="jump"><slot name="jump" /></div>
    <span v-if="!$slots.crumb && !$slots.tabs" class="roo-bar-spacer" aria-hidden="true" />
    <div v-if="$slots.tools" class="roo-bar-slot roo-bar-tools" data-slot="tools"><slot name="tools" /></div>
    <div v-if="$slots['window-controls']" class="roo-bar-slot roo-bar-window-controls" data-slot="window-controls">
      <slot name="window-controls" />
    </div>
    <div v-if="$slots.menu" class="roo-bar-slot" data-slot="menu"><slot name="menu" /></div>
    <span v-if="resolvedPlatform === 'windows'" class="roo-bar-overlay-end" aria-hidden="true" />
  </header>
</template>

<style scoped>
@layer roo-components {
  .roo-bar {
    display: flex;
    height: var(--roo-bar-h);
    flex: none;
    box-sizing: border-box;
    align-items: center;
    gap: var(--roo-gap);
    box-shadow: inset 0 -1px 0 var(--roo-border);
    background: var(--roo-x-chrome);
    padding-inline: var(--roo-space-group);
    color: var(--roo-text);
    white-space: nowrap;
    -webkit-app-region: drag;
    app-region: drag;
  }

  .roo-bar {
    /* The toolbar keeps the default control size in every density (Raja 2026-11-23: "for toolbar, it always the current default for any layout"): the buttons and capsules read the comfortable steps, in every layout. */
    --roo-control-h: calc(32px + var(--roo-scale) * 2px);
    --roo-control-h-large: calc(36px + var(--roo-scale) * 2px);
    --roo-icon-button: calc(32px + var(--roo-scale) * 2px);
    --roo-icon: calc(16px + var(--roo-scale) * 1px);
    /* Its width follows its height: a 32 high toolbar control keeps the comfortable insets and gaps (Raja 2026-11-23, compact width). */
    --roo-control-pad-x: 14px;
    --roo-control-pad-x-sm: 10px;
    --roo-control-icon-gap: 8px;
    --roo-control-icon-trim: 0px;
    --roo-control-pad-chevron: 6px;
    --roo-trigger-pad-start: 10px;
    --roo-trigger-pad-end: 6px;
  }

  /* A browser page has no window to drag and no window buttons: the bar is plain chrome. */
  .roo-bar[data-platform='web'] {
    -webkit-app-region: no-drag;
    app-region: no-drag;
  }

  /* The traffic lights are macOS only; Windows and Linux start at the plain side padding. */
  .roo-bar[data-platform='mac'] {
    padding-inline-start: max(var(--roo-space-group), var(--roo-traffic-inset));
  }

  /* Off macOS, a bar that opens with the crumb puts the crumb's text on the sidebar's text line (--roo-tree-text-line), the one inset
     of the column, instead of at the bar padding plus the crumb's own padding. On macOS the traffic-light rule above stands. */
  .roo-bar:not([data-platform='mac']):has(> [data-slot='crumb']:first-child) {
    padding-inline-start: calc(var(--roo-tree-text-line) - var(--roo-crumb-pad-inline));
  }

  /* The leading and pill slots. Everywhere but the roomy web shell this box draws nothing and the slots lay out as the bar's own. */
  .roo-bar-start {
    display: contents;
  }

  /* The roomy web shell with its sidebar open at the start (Raja, 2026-11-28: the header's divider and the sidebar's edge must line up):
     the leading and pill slots become the header's first column, exactly as wide as the sidebar column below it, ending in a 1px line on
     the sidebar divider's own pixel. The first icon sits on the shell line, sidebar open or closed, (its 32px box is centred round an 18px glyph), and the crumb's
     text starts the shell line past the column edge, where the main area's content starts. macOS keeps its traffic-light inset.
     The glyph is --roo-icon wide: RooIconButton's own size rule draws it at --roo-icon, ahead of the bar's 18px icon rule. */
  [data-sidebar-density='roomy'] .roo-bar:not([data-platform='mac']) {
    padding-inline-start: calc(var(--roo-shell-line) - (var(--roo-bar-control-h) - var(--roo-icon)) / 2);
  }

  [data-sidebar-density='roomy'] .roo-bar:not([data-platform='mac']):has(> [data-slot='crumb']:first-child) {
    padding-inline-start: calc(var(--roo-shell-line) - var(--roo-crumb-pad-inline));
  }

  [data-sidebar-density='roomy'] .roo-window[data-sidebar-edge='start'] .roo-bar:not([data-platform='mac']) .roo-bar-start {
    position: relative;
    display: flex;
    flex: none;
    align-self: stretch;
    align-items: center;
    gap: var(--roo-gap);
    box-sizing: border-box;
    width: calc(var(--roo-window-sidebar-edge) - var(--roo-shell-line) + (var(--roo-bar-control-h) - var(--roo-icon)) / 2);
    min-width: 0;
    margin-inline-end: calc(var(--roo-shell-line) - var(--roo-crumb-pad-inline) - var(--roo-gap));
    padding-inline-end: var(--roo-shell-inset);
  }

  [data-sidebar-density='roomy'] .roo-window[data-sidebar-edge='start'] .roo-bar:not([data-platform='mac']) .roo-bar-start::after {
    content: '';
    position: absolute;
    inset-block: 0;
    inset-inline-end: -1px;
    width: 1px;
    background: var(--roo-border);
  }

  [data-sidebar-density='roomy'] .roo-window[data-sidebar-edge='start'] .roo-bar:not([data-platform='mac']) .roo-bar-start > [data-slot='pill'] {
    flex: 0 1 auto;
    overflow: hidden;
  }

  /* The Windows titleBarOverlay buttons sit over the window's end; keep clear of them. Zero when no overlay is drawn, and
     no gap either: a negative start margin takes back the flex gap the spacer would otherwise add. */
  .roo-bar-overlay-end {
    flex: none;
    width: calc(100vw - env(titlebar-area-x, 0px) - env(titlebar-area-width, 100vw));
    margin-inline-start: calc(-1 * var(--roo-gap));
  }

  /* Bar controls are --roo-bar-control-h and bar icons are --roo-bar-icon (Raja, 2026-11-17: "go with proposed"); only
     inside the bar, so the same button elsewhere keeps its 16px icon. */
  .roo-bar :deep(.roo-icon-button) {
    width: var(--roo-bar-control-h);
    height: var(--roo-bar-control-h);
  }

  .roo-bar :deep(.roo-icon-button svg) {
    width: var(--roo-bar-icon);
    height: var(--roo-bar-icon);
  }

  /* Everything a person can press opts out of the drag, at any depth, without the app asking. */
  .roo-bar :deep(button),
  .roo-bar :deep(a),
  .roo-bar :deep(input),
  .roo-bar :deep(select),
  .roo-bar :deep(textarea),
  .roo-bar :deep([role='button']),
  .roo-bar :deep([role='tab']),
  .roo-bar :deep([tabindex]) {
    -webkit-app-region: no-drag;
    app-region: no-drag;
  }

  .roo-bar :deep(button),
  .roo-bar :deep([role='button']),
  .roo-bar :deep([role='tab']) {
    cursor: default;
  }

  .roo-bar-slot {
    display: flex;
    flex: none;
    min-width: 0;
    align-items: center;
    gap: var(--roo-gap);
  }

  .roo-bar-grow {
    flex: 1 1 0;
    overflow: hidden;
  }

  /* The tab strip stands on the bar's bottom line: the slot sits at the bottom and ends on the bar's bottom edge, over the
     bar line (an inset shadow that takes no layout space),
     so the strip's own line is the bar's line and the active tab breaks it. The strip takes the bar's chrome fill. */
  .roo-bar-slot[data-slot='tabs'] {
    --roo-x-tabstrip: var(--roo-x-chrome);
    align-self: flex-end;
    align-items: flex-end;
  }

  /* The strip fills the slot and shrinks with it, so on a narrow window the tabs fold into the strip's tab list and the
     end controls keep their room. */
  .roo-bar-slot[data-slot='tabs'] > * {
    flex: 1 1 0;
    min-width: 0;
  }

  .roo-bar-spacer {
    flex: 1 1 0;
  }

  .roo-bar-tools {
    gap: 4px;
  }

  /* Windows and Linux draw their own window buttons: 46 wide, the Bar's height. They sit the bar's start padding
     (--roo-space-group, the padding used when there are no traffic lights) after the last bar item, and flush with the end
     edge: the end padding is taken back and the flex gap before the slot is replaced by that padding (Raja, 2026-11-17,
     even gap rule). */
  .roo-bar-window-controls {
    gap: 0;
    margin-inline-start: calc(var(--roo-space-group) - var(--roo-gap));
    margin-inline-end: calc(-1 * var(--roo-space-group));
  }

  .roo-bar-window-controls > :deep(*) {
    display: inline-flex;
    width: 46px;
    height: var(--roo-bar-h);
    align-items: center;
    justify-content: center;
  }

  /* A phone is touched, not pointed at: an icon button in the bar gets a 44 px tall hit area (Apple's HIG height) while the
     glyph box stays --roo-bar-control-h. Sideways the transparent ::after grows by half of the tools gap only, so
     neighbouring hit areas meet edge to edge and never overlap, and the bar looks exactly as it does today (36 wide, well
     past WCAG 2.5.8's 24). Widening the gap to give a full 44 by 44 is a visible change and waits on Raja. 719 is
     PHONE_MAX_WIDTH. */
  @media (max-width: 719px) {
    .roo-bar :deep(.roo-icon-button) {
      position: relative;
    }

    .roo-bar :deep(.roo-icon-button::after) {
      content: '';
      position: absolute;
      inset: calc((var(--roo-bar-control-h) - 44px) / 2) -2px;
    }
  }
}
</style>
