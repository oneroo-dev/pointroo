<script setup lang="ts">
// A panel anchored to an edge of the window: a bottom sheet on a phone, a side sheet on a desktop width. `side` left as
// 'auto' picks between them from the viewport. Modal by default (a scrim, focus held inside, outside click and Esc close it);
// `modal` false makes it a non-modal side panel that leaves the page usable, closes only on its Close button and Esc, and
// does not take the scrim. `side="top"` drops from under an anchor (an app's toolbar), macOS style: the anchor's bottom edge is the
// sheet's top and the scrim starts there; it is content width and centred, or full width with `fullWidth`; on a phone it is a bottom sheet.
// Focus moves into the sheet (to its Close button) on open and returns to the opener on close.
// Motion follows the tokens, so the desktop surface (data-surface="desktop") makes it instant.
import { computed, onScopeDispose, ref, useAttrs, watch } from 'vue'
import {
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogOverlay,
  DialogPortal,
  DialogRoot,
  DialogTitle,
  DialogTrigger,
} from 'reka-ui'
import type { FocusOutsideEvent, PointerDownOutsideEvent } from 'reka-ui'
import { useEscapeLayer } from '../composables/useEscapeLayer'
import { useIsPhone } from '../composables/useIsPhone'
import { useToastClearance } from '../composables/useToastClearance'
import RooIconButton from './RooIconButton.vue'

// The root is renderless, so attributes passed to <RooSheet> (id, data-testid, class) land on the visible panel.
defineOptions({ inheritAttrs: false })

export type RooSheetSide = 'auto' | 'bottom' | 'right' | 'left' | 'top'
export type RooSheetAnchor = HTMLElement | (() => HTMLElement | null | undefined)

const props = withDefaults(
  defineProps<{
    /** The sheet's name, shown as its heading and read as its accessible name. */
    title: string
    description?: string
    /** 'auto' is the bottom on a phone and the right on a wider window. */
    side?: RooSheetSide
    /** Only for `side="top"`: the element (or a getter for it) whose bottom edge is the sheet's top, read when the sheet opens and on resize. Left out, the sheet starts at --roo-bar-h. */
    anchor?: RooSheetAnchor | undefined
    /** Only for `side="top"`: span the whole window width instead of the content width. */
    fullWidth?: boolean
    /** Modal draws the scrim and holds focus. Left out it is true. */
    modal?: boolean
    /** Width of a side sheet in px or any CSS length. */
    width?: number | string | undefined
    showCloseButton?: boolean
    /** The title starts on the sidebar's text line (--roo-tree-text-line) instead of the sheet's edge, for a sheet that holds a sidebar or tree: the title and the row labels then share one left edge. */
    textLine?: boolean
    /** Show the "Esc" hint beside Close (hidden on a phone, which has no Esc). */
    escHint?: boolean
    /** An outside click closes it. Left out: true when modal, false when not. */
    closeOnOutsideClick?: boolean | undefined
  }>(),
  {
    description: '',
    side: 'auto',
    anchor: undefined,
    fullWidth: false,
    modal: true,
    width: undefined,
    showCloseButton: true,
    textLine: false,
    escHint: false,
    closeOnOutsideClick: undefined,
  },
)

const emit = defineEmits<{
  open: []
  close: []
}>()

const attrs = useAttrs()
const open = defineModel<boolean>('open', { default: false })
useEscapeLayer(() => open.value)

// The footer exists only while the sheet is open, so its clearance registers on open and withdraws on close.
const footerElement = ref<HTMLElement | null>(null)
useToastClearance(footerElement)

const isPhone = useIsPhone()
const resolvedSide = computed(() => {
  if (props.side === 'auto') return isPhone.value ? 'bottom' : 'right'
  if (props.side === 'top' && isPhone.value) return 'bottom'
  return props.side
})

// The top sheet starts at the anchor's bottom edge. It is measured when the sheet opens (before the panel renders) and again
// on resize while it is open, so a toolbar that changes height keeps the sheet and its scrim under it.
const anchorBottom = ref<number | null>(null)
function measureAnchor(): void {
  const element = typeof props.anchor === 'function' ? props.anchor() : props.anchor
  anchorBottom.value = element ? Math.round(element.getBoundingClientRect().bottom) : null
}
watch(
  () => open.value && resolvedSide.value === 'top',
  (tracking) => {
    if (tracking) {
      measureAnchor()
      window.addEventListener('resize', measureAnchor)
    } else {
      window.removeEventListener('resize', measureAnchor)
    }
  },
  { immediate: true, flush: 'sync' },
)
onScopeDispose(() => window.removeEventListener('resize', measureAnchor))
const topStyle = computed(() => (resolvedSide.value === 'top' && anchorBottom.value !== null ? { '--roo-sheet-top': `${anchorBottom.value}px` } : undefined))
const dismissesOutside = computed(() => props.closeOnOutsideClick ?? props.modal)
const widthStyle = computed(() => {
  if (props.width === undefined) return undefined
  return { '--roo-sheet-width': typeof props.width === 'number' ? `${props.width}px` : props.width }
})
const contentStyle = computed(() => ({ ...widthStyle.value, ...topStyle.value }))

// Without a description there is nothing for aria-describedby to point at, so the attribute is left off.
const contentAttributes = computed(() => (props.description ? attrs : { ...attrs, 'aria-describedby': undefined }))

function setOpen(next: boolean): void {
  if (next === open.value) return
  open.value = next
  if (next) emit('open')
  else emit('close')
}

function onEscapeKeyDown(event: KeyboardEvent): void {
  event.preventDefault()
  setOpen(false)
}

function keepOnOutside(event: PointerDownOutsideEvent | FocusOutsideEvent): void {
  if (!dismissesOutside.value) event.preventDefault()
}
</script>

<template>
  <DialogRoot :open="open" :modal="modal" @update:open="setOpen">
    <DialogTrigger v-if="$slots.trigger" as-child><slot name="trigger" /></DialogTrigger>
    <DialogPortal>
      <DialogOverlay v-if="modal" class="roo-sheet-scrim" :data-side="resolvedSide" :style="topStyle" />
      <DialogContent
        v-bind="contentAttributes"
        class="roo-sheet"
        :data-side="resolvedSide"
        :data-modal="modal ? 'true' : 'false'"
        :data-full-width="resolvedSide === 'top' && fullWidth ? 'true' : undefined"
        :style="contentStyle"
        @escape-key-down="onEscapeKeyDown"
        @pointer-down-outside="keepOnOutside"
        @focus-outside="keepOnOutside"
        @interact-outside="keepOnOutside"
      >
        <div class="roo-sheet-head" :data-text-line="textLine ? 'true' : undefined">
          <DialogTitle class="roo-sheet-title">{{ title }}</DialogTitle>
          <span v-if="escHint && showCloseButton" class="roo-sheet-esc" aria-hidden="true">Esc</span>
          <DialogClose v-if="showCloseButton" as-child>
            <RooIconButton class="roo-sheet-close" icon="x" label="Close" size="sm" />
          </DialogClose>
        </div>
        <DialogDescription v-if="description" class="roo-sheet-description">{{ description }}</DialogDescription>
        <div class="roo-sheet-body"><slot /></div>
        <div v-if="$slots.footer" ref="footerElement" class="roo-sheet-footer"><slot name="footer" /></div>
      </DialogContent>
    </DialogPortal>
  </DialogRoot>
</template>

<style scoped>
@layer roo-components {
  .roo-sheet-scrim {
    position: fixed;
    inset: 0;
    z-index: 70;
    background: var(--roo-scrim);
    animation: roo-fade var(--roo-base) var(--roo-ease) both;
  }

  .roo-sheet {
    position: fixed;
    z-index: 71;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    overflow: auto;
    border: 1px solid var(--roo-border);
    background: var(--roo-surface);
    padding: var(--roo-space-card) var(--roo-space-page) var(--roo-p-space-8);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-ui-size);
    line-height: 20px;
    color: var(--roo-text);
    box-shadow: var(--roo-shadow-panel);
    outline: none;
  }

  /* The form tier (TablePlus: dialogs and sheets are one step roomier than workspace chrome): under compact density the controls inside
     are 22 tall with 13px type, where the chrome around them is 20 and 12. Custom properties inherit, so no component takes a prop. */
  :root[data-density='compact'] .roo-sheet {
    --roo-control-h: calc(26px + var(--roo-scale) * 2px);
    --roo-control-h-large: calc(26px + var(--roo-scale) * 2px);
    --roo-field-h: calc(26px + var(--roo-scale) * 2px);
    --roo-search-h: calc(26px + var(--roo-scale) * 2px);
    --roo-segmented-h: calc(26px + var(--roo-scale) * 2px);
    --roo-ui-size: calc(13px + var(--roo-scale) * 1px);
    --roo-control-line: 16px;
  }

  /* A panel that leaves the page usable sits under the scrim layer and the dialogs. */
  .roo-sheet[data-modal='false'] {
    z-index: 50;
  }

  .roo-sheet[data-side='right'],
  .roo-sheet[data-side='left'] {
    top: var(--roo-bar-h);
    bottom: 0;
    width: var(--roo-sheet-width, 400px);
    max-width: 100%;
  }

  .roo-sheet[data-side='right'] {
    right: 0;
    border-width: 0 0 0 1px;
    animation: roo-sheet-in-right var(--roo-base) var(--roo-ease) both;
  }

  .roo-sheet[data-side='left'] {
    left: 0;
    border-width: 0 1px 0 0;
    animation: roo-sheet-in-left var(--roo-base) var(--roo-ease) both;
  }

  .roo-sheet[data-side='bottom'] {
    right: 0;
    bottom: 0;
    left: 0;
    max-height: calc(100% - var(--roo-p-space-6));
    border-width: 1px 0 0;
    border-radius: var(--roo-p-radius-large) var(--roo-p-radius-large) 0 0;
    padding: var(--roo-space-card) var(--roo-space-card) var(--roo-p-space-8);
    animation: roo-sheet-in-bottom var(--roo-base) var(--roo-ease) both;
  }

  /* Closing runs the slide backwards, all the way off its edge. The scrim fades with it. */
  .roo-sheet[data-state='closed'][data-side='right'] {
    animation: roo-sheet-out-right var(--roo-base) var(--roo-exit) both;
  }

  .roo-sheet[data-state='closed'][data-side='left'] {
    animation: roo-sheet-out-left var(--roo-base) var(--roo-exit) both;
  }

  .roo-sheet[data-state='closed'][data-side='bottom'] {
    animation: roo-sheet-out-bottom var(--roo-base) var(--roo-exit) both;
  }

  .roo-sheet-scrim[data-side='top'] {
    top: var(--roo-sheet-top, var(--roo-bar-h));
  }

  /* Dropped from under the anchor: content width and centred, never wider than the window less the page inset on each side. */
  .roo-sheet[data-side='top'] {
    top: var(--roo-sheet-top, var(--roo-bar-h));
    right: 0;
    left: 0;
    width: fit-content;
    margin-inline: auto;
    max-width: calc(100% - 2 * var(--roo-space-page));
    max-height: calc(100% - var(--roo-sheet-top, var(--roo-bar-h)) - var(--roo-space-page));
    border-width: 0 1px 1px;
    border-radius: 0 0 var(--roo-p-radius-large) var(--roo-p-radius-large);
    animation: roo-sheet-in-top var(--roo-base) var(--roo-ease) both;
  }

  .roo-sheet[data-side='top'][data-full-width='true'] {
    width: auto;
    max-width: none;
    border-width: 0 0 1px;
    border-radius: 0;
  }

  .roo-sheet[data-state='closed'][data-side='top'] {
    animation: roo-sheet-out-top var(--roo-base) var(--roo-exit) both;
  }

  .roo-sheet-scrim[data-state='closed'] {
    animation: roo-clear var(--roo-base) var(--roo-exit) both;
  }

  .roo-sheet-head {
    display: flex;
    min-height: var(--roo-p-space-8);
    align-items: center;
    gap: var(--roo-p-space-2);
  }

  .roo-sheet-head[data-text-line='true'] {
    padding-inline-start: var(--roo-tree-text-line);
  }

  .roo-sheet-title {
    flex: 1;
    margin: 0;
    font-size: var(--roo-p-size-15);
    line-height: 20px;
    font-weight: 600;
  }

  .roo-sheet-esc {
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  .roo-sheet-close {
    margin-right: calc(var(--roo-p-space-2) * -1);
  }

  .roo-sheet-description {
    margin: 0 0 var(--roo-p-space-2);
    font-size: var(--roo-p-size-12);
    line-height: 16px;
    color: var(--roo-muted);
  }

  .roo-sheet-body {
    flex: 1;
    min-height: 0;
  }

  .roo-sheet-footer {
    display: flex;
    justify-content: flex-end;
    gap: var(--roo-gap);
    margin-top: var(--roo-p-space-4);
  }

  @media (max-width: 719px) {
    .roo-sheet-esc {
      display: none;
    }
  }

  @keyframes roo-sheet-in-right {
    from { opacity: 0; transform: translateX(var(--roo-p-space-6)); }
    to { opacity: 1; transform: translateX(0); }
  }

  @keyframes roo-sheet-in-left {
    from { opacity: 0; transform: translateX(calc(var(--roo-p-space-6) * -1)); }
    to { opacity: 1; transform: translateX(0); }
  }

  @keyframes roo-sheet-in-bottom {
    from { opacity: 0; transform: translateY(var(--roo-p-space-6)); }
    to { opacity: 1; transform: translateY(0); }
  }

  @keyframes roo-sheet-in-top {
    from { opacity: 0; transform: translateY(calc(var(--roo-p-space-6) * -1)); }
    to { opacity: 1; transform: translateY(0); }
  }

  @keyframes roo-sheet-out-top {
    from { opacity: 1; transform: translateY(0); }
    to { opacity: 0; transform: translateY(calc(var(--roo-p-space-6) * -1)); }
  }

  @keyframes roo-sheet-out-right {
    from { transform: translateX(0); }
    to { transform: translateX(100%); }
  }

  @keyframes roo-sheet-out-left {
    from { transform: translateX(0); }
    to { transform: translateX(-100%); }
  }

  @keyframes roo-sheet-out-bottom {
    from { transform: translateY(0); }
    to { transform: translateY(100%); }
  }
}
</style>
