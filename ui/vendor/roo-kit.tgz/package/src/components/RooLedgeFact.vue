<script lang="ts">
export type LedgeFactTone = 'default' | 'warn' | 'danger' | 'identity'
export type LedgeFactForm = 'text' | 'menu' | 'popover'

const SPOKEN_TONE: Record<LedgeFactTone, string> = { default: '', warn: 'Warning: ', danger: 'Problem: ', identity: '' }

/** The words a screen reader gets before a toned fact, so the colour is never the only signal. */
export function spokenTone(tone: LedgeFactTone): string {
  return SPOKEN_TONE[tone]
}

/** The meter fill as a percentage, kept inside 0 to 100. */
export function meterPercent(meter: number): number {
  if (!Number.isFinite(meter)) return 0
  return Math.round(Math.min(1, Math.max(0, meter)) * 100)
}
</script>

<script setup lang="ts">
// One fact in the Ledge. The default slot replaces the plain label and value with composed content (a coloured head word plus
// parts); then `value` is only the spoken text, hidden visually, and may be left short. Three forms: plain text, a `menu` button (put it in a RooMenu trigger slot; it carries
// aria-haspopup and aria-expanded), and a `popover` button that owns its popover content in the `popover` slot. A
// `live` value (a counter, a timer) never replays the Settle when it changes, so it does not shimmer every second.
// It sits in the Ledge's facts region, which is not a live region: tell the announcer when a change should be heard.
import { computed, ref, useAttrs } from 'vue'
import { PopoverContent, PopoverPortal, PopoverRoot, PopoverTrigger } from 'reka-ui'
import type { RooIconName } from '../icons/paths'
import RooIcon from './RooIcon.vue'
import { useEscapeLayer } from '../composables/useEscapeLayer'
import { useCollisionPadding } from '../composables/useWindowControlPadding'

const props = withDefaults(
  defineProps<{
    label?: string
    /** The value. When the default slot is given it is drawn instead, and `value` is left to the slot. */
    value?: string
    tone?: LedgeFactTone
    /** Say the tone in words before the value ("Problem: "). Turn it off when the value already says it; the colour stays. */
    tonePrefix?: boolean
    icon?: RooIconName | undefined
    /** A small bar after the value, 0 to 1. */
    meter?: number | undefined
    /** The value changes often; do not replay the Settle on each change. */
    live?: boolean
    form?: LedgeFactForm
    /** Menu form: whether the menu it opens is open. */
    expanded?: boolean
  }>(),
  { label: '', value: '', tone: 'default', tonePrefix: true, icon: undefined, meter: undefined, live: false, form: 'text', expanded: false },
)

const attributes = useAttrs()
// A text fact with a click listener is a real button, so it takes focus and Enter or Space.
const asButton = computed(() => props.form === 'menu' || (props.form === 'text' && typeof attributes.onClick === 'function'))
const percent = computed(() => (props.meter === undefined ? null : meterPercent(props.meter)))
const spoken = computed(() => (props.tonePrefix ? spokenTone(props.tone) : ''))
const valueKey = computed(() => (props.live ? 'live' : props.value))
const popoverOpen = ref(false)
const triggerReference = ref<unknown>(null)
const collisionPadding = useCollisionPadding(popoverOpen, triggerReference)
useEscapeLayer(() => popoverOpen.value)

// Esc is consumed here and marked handled (preventDefault), so a window-level Esc action knows the popover already took it.
// reka dismisses without preventing the default, and a prevented default would stop its own dismissal, so we close it.
function onEscapeKeyDown(event: KeyboardEvent): void {
  event.preventDefault()
  popoverOpen.value = false
}
</script>

<template>
  <PopoverRoot v-if="form === 'popover'" v-model:open="popoverOpen">
    <PopoverTrigger ref="triggerReference" as-child>
      <button type="button" class="roo-ledge-fact" :data-tone="tone" data-form="popover" aria-haspopup="dialog">
        <RooIcon v-if="icon" :name="icon" :size="14" />
        <slot v-if="$slots.default" />
        <template v-else>
          <span v-if="label" class="roo-ledge-fact-label">{{ label }}</span>
          <span :key="valueKey" class="roo-ledge-fact-value" :class="{ 'roo-move-settle': !live }"
            ><span v-if="spoken" class="roo-visually-hidden">{{ spoken }}</span>{{ value }}</span
          >
        </template>
        <span v-if="percent !== null" class="roo-ledge-fact-meter" aria-hidden="true"
          ><span class="roo-ledge-fact-meter-fill" :style="{ width: `${percent}%` }"
        /></span>
      </button>
    </PopoverTrigger>
    <PopoverPortal>
      <PopoverContent class="roo-ledge-fact-popover" side="top" align="start" :side-offset="4" :collision-padding="collisionPadding" @escape-key-down="onEscapeKeyDown">
        <slot name="popover" />
      </PopoverContent>
    </PopoverPortal>
  </PopoverRoot>

  <component
    :is="asButton ? 'button' : 'span'"
    v-else
    class="roo-ledge-fact"
    :type="asButton ? 'button' : undefined"
    :data-tone="tone"
    :data-form="form"
    :aria-haspopup="form === 'menu' ? 'menu' : undefined"
    :aria-expanded="form === 'menu' ? expanded : undefined"
  >
    <RooIcon v-if="icon" :name="icon" :size="14" />
    <slot v-if="$slots.default" />
    <template v-else>
      <span v-if="label" class="roo-ledge-fact-label">{{ label }}</span>
      <span :key="valueKey" class="roo-ledge-fact-value" :class="{ 'roo-move-settle': !live }"
        ><span v-if="spoken" class="roo-visually-hidden">{{ spoken }}</span>{{ value }}</span
      >
    </template>
    <span v-if="percent !== null" class="roo-ledge-fact-meter" aria-hidden="true"
      ><span class="roo-ledge-fact-meter-fill" :style="{ width: `${percent}%` }"
    /></span>
  </component>
</template>

<style scoped>
@layer roo-components {
  .roo-ledge-fact {
    display: inline-flex;
    height: var(--roo-bar-fact-h);
    flex: none;
    box-sizing: border-box;
    align-items: center;
    gap: 4px;
    border: 0;
    border-radius: var(--roo-p-radius-small);
    background: transparent;
    padding: 0;
    color: var(--roo-text);
    font: inherit;
    white-space: nowrap;
    cursor: default;
  }

  button.roo-ledge-fact {
    padding-inline: 4px;
  }

  button.roo-ledge-fact:hover,
  button.roo-ledge-fact[aria-expanded='true'] {
    background: var(--roo-raised);
  }

  /* On a raised strip (an ancestor carries data-on-raised="true") the raised fill would show nothing, so the matched step. */
  [data-on-raised='true'] button.roo-ledge-fact:hover,
  [data-on-raised='true'] button.roo-ledge-fact[aria-expanded='true'] {
    background: var(--roo-raised-hover);
  }

  button.roo-ledge-fact:active {
    background: var(--roo-raised-hover);
  }

  [data-on-raised='true'] button.roo-ledge-fact:active {
    background: color-mix(in srgb, var(--roo-raised-hover) 90%, var(--roo-text));
  }

  button.roo-ledge-fact:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: var(--roo-focus-offset);
  }

  .roo-ledge-fact-label {
    color: var(--roo-muted);
  }

  .roo-ledge-fact[data-tone='warn'] .roo-ledge-fact-value {
    color: var(--roo-warn);
  }

  .roo-ledge-fact[data-tone='danger'] .roo-ledge-fact-value {
    color: var(--roo-danger-text);
  }

  .roo-ledge-fact[data-tone='identity'] .roo-ledge-fact-value {
    color: var(--roo-accent-text);
  }

  .roo-ledge-fact-meter {
    display: inline-block;
    width: 24px;
    height: 4px;
    overflow: hidden;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-border);
  }

  .roo-ledge-fact-meter-fill {
    display: block;
    height: 100%;
    background: var(--roo-muted);
  }

  .roo-ledge-fact[data-tone='warn'] .roo-ledge-fact-meter-fill {
    background: var(--roo-warn);
  }

  .roo-ledge-fact[data-tone='danger'] .roo-ledge-fact-meter-fill {
    background: var(--roo-danger-text);
  }

  .roo-ledge-fact[data-tone='identity'] .roo-ledge-fact-meter-fill {
    background: var(--roo-accent-text);
  }
}
</style>

<!-- Not scoped: reka renders the popover in a portal. -->
<style>
@layer roo-components {
  .roo-ledge-fact-popover {
    z-index: 80;
    box-sizing: border-box;
    border: 1px solid transparent;
    border-radius: var(--roo-radius-popover);
    background: var(--roo-surface);
    padding: 8px;
    color: var(--roo-text);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    box-shadow: var(--roo-shadow-menu);
    animation: roo-pop var(--roo-fast) var(--roo-ease) both;
  }

  .roo-ledge-fact-popover[data-state='closed'] {
    animation: roo-clear calc(var(--roo-fast) * 0.625) var(--roo-exit) both;
  }
}
</style>
