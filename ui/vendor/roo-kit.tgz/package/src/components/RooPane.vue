<script lang="ts">
export const PANE_MAX_VIEWS = 4
export const PANE_SHEET_AT = 1024

export interface RooPaneView {
  value: string
  label: string
  icon?: RooIconName
}

/** True when the window is too narrow to hold the pane beside the content: it then floats over it as a sheet. */
export function paneIsSheet(windowWidth: number, sheetAt: number = PANE_SHEET_AT): boolean {
  return windowWidth < sheetAt
}
</script>

<script setup lang="ts">
// The inspector pane. Up to four views switch through a segmented control; the app drives which one opens by changing
// `defaultView` (for example when the selection changes kind), and the person can still choose another. The header
// shows an optional icon, the title and an actions slot, or the whole header is replaced by the `header` slot.
// Under 1024 wide (the window, not the pane) it becomes a non-modal sheet: no scrim, role complementary, the panel
// shadow, so the content behind stays usable.
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import RooSegmented from './RooSegmented.vue'
import type { RooIconName } from '../icons/paths'

const props = withDefaults(
  defineProps<{
    title?: string
    label: string
    views?: RooPaneView[]
    defaultView?: string | undefined
    minWidth?: number | undefined
    /** Force the sheet (true) or the pane (false). Unset follows the window width. */
    sheet?: boolean | undefined
    sheetBelow?: number
    open?: boolean
  }>(),
  { title: '', views: () => [], defaultView: undefined, minWidth: undefined, sheet: undefined, sheetBelow: PANE_SHEET_AT, open: true },
)
const view = defineModel<string>('view')

const shownViews = computed(() => {
  if (props.views.length > PANE_MAX_VIEWS && typeof console !== 'undefined') {
    console.warn(`RooPane: ${props.views.length} views given; it shows the first ${PANE_MAX_VIEWS}.`)
  }
  return props.views.slice(0, PANE_MAX_VIEWS)
})
const current = computed(() => view.value ?? props.defaultView ?? shownViews.value[0]?.value ?? '')
watch(
  () => props.defaultView,
  (next) => {
    if (next !== undefined) view.value = next
  },
)

const root = ref<HTMLElement | null>(null)
const windowWidth = ref(typeof window === 'undefined' ? PANE_SHEET_AT : window.innerWidth)
let observer: ResizeObserver | undefined

// The pane docks to the nearest .roo-window; outside one it docks to its own parent element.
function dockingFrame(): HTMLElement | null {
  return root.value?.closest<HTMLElement>('.roo-window') ?? root.value?.parentElement ?? null
}

function measure(): void {
  const frame = dockingFrame()
  windowWidth.value = frame && frame.clientWidth > 0 ? frame.clientWidth : window.innerWidth
}

onMounted(() => {
  measure()
  window.addEventListener('resize', measure)
  const frame = dockingFrame()
  if (frame && typeof ResizeObserver !== 'undefined') {
    observer = new ResizeObserver(measure)
    observer.observe(frame)
  }
})
onBeforeUnmount(() => {
  window.removeEventListener('resize', measure)
  observer?.disconnect()
})

const asSheet = computed(() => props.sheet ?? paneIsSheet(windowWidth.value, props.sheetBelow))
</script>

<template>
  <div
    v-if="open"
    ref="root"
    class="roo-pane"
    :data-mode="asSheet ? 'sheet' : 'pane'"
    :role="asSheet ? 'complementary' : 'region'"
    :aria-label="label"
    :style="{ minWidth: minWidth === undefined ? undefined : `${minWidth}px` }"
  >
    <slot v-if="$slots.header" name="header" />
    <header v-else class="roo-pane-header">
      <span v-if="$slots.icon" class="roo-pane-icon"><slot name="icon" /></span>
      <span class="roo-pane-title">{{ title }}</span>
      <span v-if="$slots.actions" class="roo-pane-actions"><slot name="actions" /></span>
    </header>
    <div v-if="!$slots.header && shownViews.length > 1" class="roo-pane-views">
      <RooSegmented data-align-box :model-value="current" :options="shownViews" :label="`${label} views`" @update:model-value="view = $event" />
    </div>
    <div class="roo-pane-body"><slot :view="current" /></div>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-pane {
    display: flex;
    min-width: 0;
    min-height: 0;
    flex-direction: column;
    box-sizing: border-box;
    background: var(--roo-surface);
    color: var(--roo-text);
  }

  .roo-pane[data-mode='sheet'] {
    position: absolute;
    inset-block: 0;
    inset-inline-end: 0;
    z-index: 3;
    width: min(100%, calc(var(--roo-pane-w) * 2));
    border-inline-start: 1px solid var(--roo-border);
    box-shadow: var(--roo-shadow-panel);
    animation: roo-settle var(--roo-base) var(--roo-ease) both;
  }

  .roo-pane-header {
    display: flex;
    height: var(--roo-pane-head-h);
    flex: none;
    align-items: center;
    gap: var(--roo-gap);
    border-bottom: 1px solid var(--roo-border);
    padding-inline: 8px;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    white-space: nowrap;
  }

  .roo-pane-icon {
    display: inline-flex;
    flex: none;
    align-items: center;
  }

  .roo-pane-title {
    min-width: 0;
    flex: 1 1 auto;
    overflow: hidden;
    color: var(--roo-text);
    font-weight: 600;
    text-overflow: ellipsis;
  }

  .roo-pane-actions {
    display: inline-flex;
    flex: none;
    align-items: center;
    gap: 4px;
  }

  .roo-pane-views {
    display: flex;
    flex: none;
    padding: 8px;
  }

  .roo-pane-body {
    min-height: 0;
    flex: 1 1 auto;
    overflow: auto;
  }
}
</style>
