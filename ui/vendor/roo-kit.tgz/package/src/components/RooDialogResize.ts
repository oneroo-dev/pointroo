// The geometry of a resizable RooDialog. Pure functions, so the clamping is tested without a browser.

export interface DialogRectangle {
  left: number
  top: number
  width: number
  height: number
}

export interface DialogEdges {
  left?: boolean
  right?: boolean
  top?: boolean
  bottom?: boolean
}

export interface DialogBounds {
  left: number
  top: number
  right: number
  bottom: number
}

export interface DialogMinimum {
  width: number
  height: number
}

// The smallest size of each preset: the width is the preset's own width, the height is a layout size (enough for the head,
// a line of body and the footer).
export const dialogMinimumBySize: Record<string, DialogMinimum> = {
  sm: { width: 360, height: 160 }, // layout: the 'sm' preset width, and the least height that holds head, body and footer
  md: { width: 448, height: 200 }, // layout: the 'md' preset width
  lg: { width: 640, height: 240 }, // layout: the 'lg' preset width
  settings: { width: 900, height: 480 }, // layout: the settings window width and its least height
}

export const dialogFallbackMinimum: DialogMinimum = { width: 360, height: 160 } // layout: an alert or an unknown size

function clamp(value: number, lowest: number, highest: number): number {
  return Math.min(Math.max(value, lowest), Math.max(lowest, highest))
}

/**
 * Moves the dragged edges by (deltaX, deltaY) from the rectangle the drag began with. The opposite edges stay put, the
 * size never goes under the minimum (or over the bounds), and the rectangle never leaves the bounds.
 */
export function resizeRectangle(
  start: DialogRectangle,
  edges: DialogEdges,
  deltaX: number,
  deltaY: number,
  minimum: DialogMinimum,
  bounds: DialogBounds,
): DialogRectangle {
  const boundsWidth = bounds.right - bounds.left
  const boundsHeight = bounds.bottom - bounds.top
  const minimumWidth = Math.min(minimum.width, boundsWidth)
  const minimumHeight = Math.min(minimum.height, boundsHeight)

  let left = start.left
  let top = start.top
  let width = start.width
  let height = start.height

  if (edges.right) width = clamp(start.width + deltaX, minimumWidth, bounds.right - start.left)
  if (edges.left) {
    const rightEdge = start.left + start.width
    left = clamp(start.left + deltaX, bounds.left, rightEdge - minimumWidth)
    width = rightEdge - left
  }
  if (edges.bottom) height = clamp(start.height + deltaY, minimumHeight, bounds.bottom - start.top)
  if (edges.top) {
    const bottomEdge = start.top + start.height
    top = clamp(start.top + deltaY, bounds.top, bottomEdge - minimumHeight)
    height = bottomEdge - top
  }
  return { left, top, width, height }
}

/** Pulls a rectangle back into the bounds after the window shrank: shift first, shrink only when it cannot fit. */
export function keepInView(rectangle: DialogRectangle, minimum: DialogMinimum, bounds: DialogBounds): DialogRectangle {
  const boundsWidth = bounds.right - bounds.left
  const boundsHeight = bounds.bottom - bounds.top
  const width = clamp(rectangle.width, Math.min(minimum.width, boundsWidth), boundsWidth)
  const height = clamp(rectangle.height, Math.min(minimum.height, boundsHeight), boundsHeight)
  const left = clamp(rectangle.left, bounds.left, bounds.right - width)
  const top = clamp(rectangle.top, bounds.top, bounds.bottom - height)
  return { left, top, width, height }
}

/** A custom property holding a length in px (a token such as --roo-p-space-4), or the fallback when it cannot be read. */
export function readTokenPixels(name: string, fallback: number): number {
  if (typeof document === 'undefined') return fallback
  const parsed = Number.parseFloat(getComputedStyle(document.documentElement).getPropertyValue(name))
  return Number.isFinite(parsed) ? parsed : fallback
}
