// The switcher's search: which rows stay, and where the matched letters are (drawn in 600 weight, never a box).
import type { RooSwitcherRow } from './RooSwitcher.vue'

/** Rows whose name or meta contains the text, ignoring case. An empty text keeps every row. */
export function filterSwitcherRows(rows: readonly RooSwitcherRow[], text: string): RooSwitcherRow[] {
  const wanted = text.trim().toLowerCase()
  if (!wanted) return [...rows]
  return rows.filter((row) => row.name.toLowerCase().includes(wanted) || (row.meta ?? '').toLowerCase().includes(wanted))
}

/** The label cut into before, match and after. The match is empty when the text is not in the label. */
export function splitSwitcherMatch(label: string, text: string): [string, string, string] {
  const wanted = text.trim().toLowerCase()
  const at = wanted ? label.toLowerCase().indexOf(wanted) : -1
  if (at === -1) return [label, '', '']
  return [label.slice(0, at), label.slice(at, at + wanted.length), label.slice(at + wanted.length)]
}

/** The row a number key opens: 1 to 9 are the first nine rows, 0 is the tenth. Anything else is undefined. */
export function switcherShortcutIndex(key: string): number | undefined {
  if (!/^[0-9]$/.test(key)) return undefined
  return key === '0' ? 9 : Number(key) - 1
}
