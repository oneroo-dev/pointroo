<script setup lang="ts">
import { GUARD_ICONS, GUARD_LABELS, GUARD_LEVELS } from '../environment'
import type { RooGuardLevel } from '../types/environment'
import { useId } from 'reka-ui'
import RooIcon from './RooIcon.vue'
import RooSelect from './RooSelect.vue'
import RooSwitch from './RooSwitch.vue'

/**
 * The guard level and the separate read-only switch. Read-only is a hard block, not a sixth level.
 * `inline` puts the switch beside the select. `stacked` gives it its own row below, with an optional help line under it.
 * Each level carries its GUARD_ICONS icon as the option mark, so the listbox and the selected value show it. The native
 * select (no [data-density] above it) can hold text only, so there it shows the words alone.
 */
const guard = defineModel<RooGuardLevel>('guard')
const readOnly = defineModel<boolean>('readOnly', { default: false })

withDefaults(
  defineProps<{ label?: string; disabled?: boolean; size?: 'sm' | 'md' | 'lg'; layout?: 'inline' | 'stacked'; readOnlyHint?: string; hideLabel?: boolean }>(),
  { label: 'Safe mode', disabled: false, size: 'lg', layout: 'inline', readOnlyHint: '', hideLabel: false },
)

const hintId = useId(undefined, 'roo-guard-hint')
const options = GUARD_LEVELS.map((level) => ({ value: level as string, label: GUARD_LABELS[level], mark: level }))

function pick(value: string | undefined): void {
  if (value !== undefined) guard.value = value as RooGuardLevel
}
</script>

<template>
  <div class="roo-guard-select" :data-size="size" :data-layout="layout">
    <RooSelect :model-value="guard" :options="options" :label="label" :disabled="disabled" :size="size" :hide-label="hideLabel" @update:model-value="pick">
      <template #option-mark="{ option }">
        <RooIcon v-if="option.mark" :name="GUARD_ICONS[option.mark as RooGuardLevel]" :size="12" />
      </template>
    </RooSelect>
    <div v-if="layout === 'stacked'" class="roo-guard-switch-row">
      <RooSwitch v-model="readOnly" label="Read-only" :disabled="disabled" :aria-describedby="readOnlyHint ? hintId : undefined" />
      <p v-if="readOnlyHint" :id="hintId" class="roo-guard-hint">{{ readOnlyHint }}</p>
    </div>
    <RooSwitch v-else v-model="readOnly" label="Read-only" :disabled="disabled" />
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-guard-select {
    display: flex;
    align-items: flex-end;
    gap: var(--roo-p-space-3);
  }

  /* The switch sits on the select's centre line, not on its bottom edge. */
  .roo-guard-select > .roo-switch {
    min-height: var(--roo-control-h-large);
    align-items: center;
  }

  .roo-guard-select[data-size='md'] > .roo-switch {
    min-height: var(--roo-control-h);
  }

  .roo-guard-select[data-size='sm'] > .roo-switch {
    min-height: var(--roo-row-h-actions);
  }

  .roo-guard-select[data-layout='stacked'] {
    flex-direction: column;
    align-items: stretch;
    gap: var(--roo-p-space-2);
  }

  .roo-guard-switch-row {
    display: flex;
    flex-direction: column;
  }

  .roo-guard-switch-row > .roo-switch {
    min-height: var(--roo-control-h-large);
    align-items: center;
    justify-content: flex-start;
  }

  .roo-guard-select[data-layout='stacked'][data-size='md'] .roo-guard-switch-row > .roo-switch {
    min-height: var(--roo-control-h);
  }

  .roo-guard-select[data-layout='stacked'][data-size='sm'] .roo-guard-switch-row > .roo-switch {
    min-height: var(--roo-row-h-actions);
  }

  .roo-guard-hint {
    margin: 0;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }
}
</style>
