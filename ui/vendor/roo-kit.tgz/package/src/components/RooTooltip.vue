<script lang="ts">
// The root is a fragment, so a parent's as-child trigger (a RooMenu trigger slot holding this tooltip) puts its props
// and handlers on this component. They are forwarded to the tooltip's own trigger element below instead of dropped (`disabled` stays a prop, for the root).
export default { inheritAttrs: false }
</script>

<script setup lang="ts">
// Needs one RooTooltipProvider above it: a tooltip opens after 500 ms, and moving to a sibling skips the delay.
// Text wraps to two lines at most. The `kbd` slot (or the `shortcut` prop) sits beside it. Never use a title attribute.
import { TooltipContent, TooltipPortal, TooltipRoot, TooltipTrigger } from 'reka-ui'
import { ref } from 'vue'
import RooKeyGlyphs from './RooKeyGlyphs.vue'
import { useEscapeLayer } from '../composables/useEscapeLayer'
import { useCollisionPadding } from '../composables/useWindowControlPadding'

const props = withDefaults(
  defineProps<{
    text: string
    side?: 'top' | 'bottom' | 'left' | 'right'
    /** Where the tooltip sits along the side it opens on: its start edge, centred on the trigger, or its end edge. */
    align?: 'start' | 'center' | 'end'
    shortcut?: string
    /** Gap in px between the trigger and the tooltip. A menu row passes more so the tooltip clears the menu edge. */
    sideOffset?: number
    /** 'help' is for longer explanations: wider, up to 5 lines. */
    variant?: 'default' | 'help'
    /** No tooltip while true (the trigger still works). Declared so it reaches the tooltip root, not the trigger. */
    disabled?: boolean
  }>(),
  { disabled: false, side: 'bottom', align: 'center', shortcut: '', sideOffset: 6, variant: 'default' },
)

// Esc is consumed here and marked handled (preventDefault), so a window-level Esc action knows an overlay already took it.
// reka dismisses on Esc without preventing the default, and a prevented default would stop its own dismissal, so the
// tooltip closes itself.
const open = ref(false)
useEscapeLayer(() => open.value)
function onEscapeKeyDown(event: KeyboardEvent): void {
  event.preventDefault()
  held.value = false
  open.value = false
}

// A touch has no hover and a tap focuses nothing, so a caller can hold the tooltip open (RooButton does this for a disabled
// button's reason). While held, reka's own close requests are ignored: its trigger closes on the same tap's click, and the
// caller decides when the tip goes (a tap elsewhere, a timeout, Esc).
const held = ref(false)
function onUpdateOpen(value: boolean): void {
  if (!value && held.value) return
  open.value = value
}
function show(): void {
  held.value = true
  open.value = true
}
function hide(): void {
  held.value = false
  open.value = false
}
defineExpose({ show, hide, open })

// A tooltip never covers the window controls (family rule). Measured when it opens, so a token change or a resized window
// is read fresh: see windowControlPadding for why the exclusion depends on where the trigger sits.
const trigger = ref<{ $el: Element } | null>(null)
const collisionPadding = useCollisionPadding(open, trigger, () => props.side)
</script>

<template>
  <TooltipRoot :open="open" :disabled="disabled" @update:open="onUpdateOpen">
    <TooltipTrigger ref="trigger" as-child v-bind="$attrs">
      <slot />
    </TooltipTrigger>
    <TooltipPortal>
      <TooltipContent class="roo-tooltip" :data-variant="variant" :side="side" :align="align" :side-offset="sideOffset" :collision-padding="collisionPadding" @escape-key-down="onEscapeKeyDown">
        <span class="roo-tooltip-text">{{ text }}</span>
        <slot name="kbd">
          <kbd v-if="shortcut" class="roo-tooltip-shortcut"><RooKeyGlyphs :text="shortcut" /></kbd>
        </slot>
      </TooltipContent>
    </TooltipPortal>
  </TooltipRoot>
</template>

<!-- Not scoped: reka puts the scope id on its popper wrapper div, while the class lands on the inner content element. -->
<style>
@layer roo-components {
  .roo-tooltip {
    z-index: 90;
    display: flex;
    align-items: center;
    gap: var(--roo-p-space-2);
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-text);
    padding: var(--roo-p-space-1) var(--roo-p-space-2);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    color: var(--roo-bg);
    box-shadow: var(--roo-shadow-popover);
    animation: roo-pop var(--roo-fast) var(--roo-ease) both;
    transform-origin: var(--reka-tooltip-content-transform-origin, var(--reka-popper-transform-origin, center));
  }

  .roo-tooltip[data-state='closed'] {
    animation: roo-pop-out calc(var(--roo-fast) * 0.625) var(--roo-exit) both;
  }

  .roo-tooltip-text {
    display: -webkit-box;
    max-width: 240px;
    overflow: hidden;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow-wrap: anywhere;
    text-wrap: balance;
  }

  .roo-tooltip[data-variant='help'] .roo-tooltip-text {
    max-width: 260px;
    -webkit-line-clamp: 5;
    text-wrap: pretty;
  }

  .roo-tooltip-shortcut {
    font-family: -apple-system, system-ui, var(--roo-font-ui);
    opacity: 0.7;
  }
}
</style>
