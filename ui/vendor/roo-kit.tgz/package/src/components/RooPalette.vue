<script lang="ts">
export const PALETTE_SECTION_ORDER = ['suggested', 'jump', 'commands', 'ask', 'open-in'] as const
export const PALETTE_SECTION_WORDS: Record<string, string> = {
  suggested: 'Suggested',
  jump: 'Jump',
  commands: 'Commands',
  ask: 'Ask',
  'open-in': 'Open in',
}

/** A heading word made from a raw id: separators become spaces and the first letter is a capital. */
export function sentenceCaseWord(raw: string): string {
  const spaced = raw.replace(/[-_]+/g, ' ').trim()
  return spaced.charAt(0).toUpperCase() + spaced.slice(1)
}
/** Rows a section shows before "Show all". A provider may lower it, never raise it. */
export const PALETTE_ROW_LIMIT = 5
/** Pointer travel, in px, before a hover moves the highlight. */
export const PALETTE_HOVER_THRESHOLD = 4
/** The three family prefixes: commands, ask and contexts. A provider may declare one more. */
export const PALETTE_FAMILY_PREFIXES = ['>', '?', '@'] as const
</script>

<script setup lang="ts">
// The Jump palette. Providers answer for a section; the sections come in a fixed order, five rows each until the user
// types. Tab moves between sections, arrows within, Enter runs, Cmd Enter runs with alt, Cmd 1 to 5 run the first five.
// A hover moves the highlight only after 4 px of travel. The palette never confirms for the app: a prod row's `run`
// shows the app's own confirm. Esc closes it and prevents the default, so a window handler can tell it was consumed.
import { computed, nextTick, onBeforeUnmount, ref, useId, watch } from 'vue'
import { detectPlatform, type ShortcutPlatform } from '../composables/useShortcuts'
import type { JumpProvider, JumpRow } from '../types/jump'
import { useEscapeLayer } from '../composables/useEscapeLayer'
import RooIcon from './RooIcon.vue'
import RooKbd from './RooKbd.vue'
import RooKeyHint from './RooKeyHint.vue'
import type { RooIconName } from '../icons/paths'

const props = withDefaults(
  defineProps<{
    open: boolean
    providers: JumpProvider[]
    platform?: ShortcutPlatform | undefined
    /** The Jump field the palette sits under. Without it the palette is centred under the Bar. */
    anchor?: HTMLElement | null | undefined
    label?: string
    /** Extra attributes for the inner input, such as data-testid. */
    inputAttrs?: Record<string, string>
  }>(),
  { platform: undefined, anchor: undefined, label: 'Jump or ask', inputAttrs: () => ({}) },
)

const emit = defineEmits<{
  'update:open': [open: boolean]
  close: []
  run: [row: JumpRow, alt: boolean]
}>()
const query = defineModel<string>('query', { default: '' })

const baseId = useId()
const platform = computed(() => props.platform ?? detectPlatform())

// ---- Providers and the query ----------------------------------------------------------------------------------

type QueryMode = 'all' | 'commands' | 'ask' | 'contexts' | 'extra'
interface ParsedQuery {
  mode: QueryMode
  text: string
  extra?: JumpProvider
}

useEscapeLayer(() => props.open)

/** What a provider is called on screen: its own word, else the section word for its id, else the id in sentence case. */
function providerWord(provider: JumpProvider): string {
  if (provider.word !== undefined && provider.word !== '') return provider.word
  return PALETTE_SECTION_WORDS[provider.id] ?? sentenceCaseWord(provider.id)
}

function extraPrefixes(): JumpProvider[] {
  return props.providers.filter((provider) => provider.prefix !== undefined && provider.prefix !== '' && !(PALETTE_FAMILY_PREFIXES as readonly string[]).includes(provider.prefix))
}

function parseQuery(raw: string): ParsedQuery {
  const extra = extraPrefixes().find((provider) => raw.startsWith(provider.prefix!))
  if (extra) return { mode: 'extra', text: raw.slice(extra.prefix!.length).trimStart(), extra }
  if (raw.startsWith('>')) return { mode: 'commands', text: raw.slice(1).trimStart() }
  if (raw.startsWith('?')) return { mode: 'ask', text: raw.slice(1).trimStart() }
  if (raw.startsWith('@')) return { mode: 'contexts', text: raw.slice(1).trimStart() }
  return { mode: 'all', text: raw }
}

const mode = computed(() => parseQuery(query.value).mode)

interface Answer {
  provider: JumpProvider
  rows: JumpRow[]
}
const answers = ref<Answer[]>([])
const loading = ref(false)
let requestToken = 0

async function load(): Promise<void> {
  const token = ++requestToken
  const parsed = parseQuery(query.value)
  const asked = props.providers.filter((provider) => {
    if (parsed.mode === 'extra') return provider === parsed.extra
    if (parsed.mode === 'commands') return provider.section === 'commands'
    if (parsed.mode === 'ask') return provider.section === 'ask'
    return true
  })
  loading.value = true
  const settled = await Promise.all(
    asked.map(async (provider): Promise<Answer> => {
      try {
        return { provider, rows: await provider.query(parsed.text) }
      } catch (error) {
        console.warn(`[RooPalette] provider "${provider.id}" failed`, error)
        return { provider, rows: [] }
      }
    }),
  )
  if (token !== requestToken) return
  answers.value = parsed.mode === 'contexts' ? settled.map((answer) => ({ ...answer, rows: answer.rows.filter((row) => row.environment !== undefined) })) : settled
  loading.value = false
  highlightIndex.value = 0
  pointerAnchor = null
}

// ---- Sections and rows -----------------------------------------------------------------------------------------

const expandedSections = ref(new Set<string>())
const typed = computed(() => query.value.trim() !== '')

interface SectionView {
  id: string
  word: string
  rows: JumpRow[]
  total: number
}

const sections = computed<SectionView[]>(() => {
  const collected = new Map<string, SectionView>()
  for (const { provider, rows } of answers.value) {
    const cap = provider.limit !== undefined ? Math.min(Math.max(provider.limit, 0), PALETTE_ROW_LIMIT) : typed.value ? Number.POSITIVE_INFINITY : PALETTE_ROW_LIMIT
    const bySection = new Map<string, JumpRow[]>()
    for (const row of rows) {
      const id = row.section || provider.section
      bySection.set(id, [...(bySection.get(id) ?? []), row])
    }
    for (const [id, sectionRows] of bySection) {
      const view = collected.get(id) ?? { id, word: PALETTE_SECTION_WORDS[id] ?? sentenceCaseWord(id), rows: [], total: 0 }
      if (provider.word !== undefined && provider.word !== '' && provider.section === id) view.word = provider.word
      view.total += sectionRows.length
      view.rows.push(...(expandedSections.value.has(id) ? sectionRows : sectionRows.slice(0, cap)))
      collected.set(id, view)
    }
  }
  const known = PALETTE_SECTION_ORDER.filter((id) => collected.has(id))
  const others = [...collected.keys()].filter((id) => !(PALETTE_SECTION_ORDER as readonly string[]).includes(id))
  return [...known, ...others].map((id) => collected.get(id)!).filter((view) => view.rows.length > 0)
})

interface FlatRow {
  row: JumpRow
  section: string
  index: number
}
const flat = computed<FlatRow[]>(() => {
  const list: FlatRow[] = []
  for (const section of sections.value) for (const row of section.rows) list.push({ row, section: section.id, index: list.length })
  return list
})

function indexOfRow(sectionId: string, row: JumpRow): number {
  return flat.value.findIndex((entry) => entry.section === sectionId && entry.row === row)
}

function rowId(index: number): string {
  return `${baseId}-row-${index}`
}

const highlightIndex = ref(0)
const highlightedRow = computed(() => flat.value[highlightIndex.value]?.row)
const contextsMode = computed(() => mode.value === 'contexts')

function showsEnvironment(row: JumpRow): boolean {
  return row.environment !== undefined && (row.environment === 'prod' || row.environment === 'unclassified' || contextsMode.value)
}

function iconName(row: JumpRow): RooIconName | undefined {
  return row.icon as RooIconName | undefined
}

// ---- Keys and the pointer --------------------------------------------------------------------------------------

let pointerAnchor: { x: number; y: number } | null = null
const panel = ref<HTMLElement | null>(null)
const input = ref<HTMLInputElement | null>(null)
const numbersShown = ref(false)

function moveHighlight(index: number): void {
  const count = flat.value.length
  if (count === 0) return
  highlightIndex.value = (index + count) % count
  pointerAnchor = null
  void nextTick(() => document.getElementById(rowId(highlightIndex.value))?.scrollIntoView?.({ block: 'nearest' }))
}

function moveSection(step: 1 | -1): void {
  const ids = sections.value.map((section) => section.id)
  if (ids.length === 0) return
  const current = flat.value[highlightIndex.value]?.section ?? ids[0]!
  const target = ids[(ids.indexOf(current) + step + ids.length) % ids.length]!
  moveHighlight(flat.value.findIndex((entry) => entry.section === target))
}

function requestClose(): void {
  emit('update:open', false)
  emit('close')
}

function runAt(index: number, alt: boolean): void {
  const row = flat.value[index]?.row
  if (!row || row.disabled || row.busy) return
  emit('run', row, alt)
  row.run?.(alt)
  requestClose()
}

function onKeydown(event: KeyboardEvent): void {
  if (event.isComposing) return
  const numberKey = platform.value === 'mac' ? 'Meta' : 'Alt'
  if (event.key === numberKey) numbersShown.value = true
  if (event.key === 'Escape') {
    event.preventDefault()
    requestClose()
  } else if (event.key === 'Tab') {
    event.preventDefault()
    moveSection(event.shiftKey ? -1 : 1)
  } else if (event.key === 'ArrowDown') {
    event.preventDefault()
    moveHighlight(highlightIndex.value + 1)
  } else if (event.key === 'ArrowUp') {
    event.preventDefault()
    moveHighlight(highlightIndex.value - 1)
  } else if (event.key === 'Home' && !query.value) {
    event.preventDefault()
    moveHighlight(0)
  } else if (event.key === 'End' && !query.value) {
    event.preventDefault()
    moveHighlight(flat.value.length - 1)
  } else if (event.key === 'Enter') {
    event.preventDefault()
    runAt(highlightIndex.value, event.metaKey || event.ctrlKey)
  } else if (/^[1-5]$/.test(event.key) && (platform.value === 'mac' ? event.metaKey : event.altKey)) {
    event.preventDefault()
    runAt(Number(event.key) - 1, false)
  }
}

function onKeyup(event: KeyboardEvent): void {
  if (event.key === (platform.value === 'mac' ? 'Meta' : 'Alt')) numbersShown.value = false
}

// A hover moves the highlight only once the pointer has travelled 4 px from where it last moved it, so a row sliding
// under a resting pointer (a scroll, a list that re-sorts) never steals the highlight from the keyboard.
function onRowMove(event: MouseEvent, index: number): void {
  if (pointerAnchor === null) {
    pointerAnchor = { x: event.clientX, y: event.clientY }
    return
  }
  if (Math.hypot(event.clientX - pointerAnchor.x, event.clientY - pointerAnchor.y) < PALETTE_HOVER_THRESHOLD) return
  pointerAnchor = { x: event.clientX, y: event.clientY }
  highlightIndex.value = index
}

function showAll(sectionId: string): void {
  expandedSections.value = new Set([...expandedSections.value, sectionId])
}

// ---- Footer -----------------------------------------------------------------------------------------------------

const footerHints = computed(() => {
  const alternate = highlightedRow.value?.alternate
  return [
    { keys: 'Enter', words: 'Run' },
    alternate ? { keys: 'Mod+Enter', words: alternate.label } : { keys: 'Tab', words: 'Next section' },
    { keys: 'Escape', words: 'Close' },
  ]
})
const prefixHints = computed(() => extraPrefixes().map((provider) => ({ prefix: provider.prefix!, words: providerWord(provider) })))

// ---- Open, close, focus -----------------------------------------------------------------------------------------

let opener: HTMLElement | null = null

function onPointerDownOutside(event: Event): void {
  const target = event.target as Node | null
  if (!target || panel.value?.contains(target) || props.anchor?.contains(target)) return
  requestClose()
}

function stopListening(): void {
  document.removeEventListener('pointerdown', onPointerDownOutside, true)
}

function place(): void {
  const element = panel.value
  if (!element) return
  const rect = props.anchor?.getBoundingClientRect()
  if (rect) {
    element.style.setProperty('--roo-palette-left', `${rect.left}px`)
    element.style.setProperty('--roo-palette-top', `${rect.bottom + 6}px`)
    element.style.setProperty('--roo-palette-shift', '0px')
  } else {
    element.style.removeProperty('--roo-palette-left')
    element.style.removeProperty('--roo-palette-top')
    element.style.removeProperty('--roo-palette-shift')
  }
}

watch(
  () => props.open,
  async (isOpen, wasOpen) => {
    if (isOpen) {
      opener = typeof document === 'undefined' ? null : (document.activeElement as HTMLElement | null)
      query.value = ''
      expandedSections.value = new Set()
      highlightIndex.value = 0
      document.addEventListener('pointerdown', onPointerDownOutside, true)
      void load()
      await nextTick()
      place()
      input.value?.focus()
    } else {
      stopListening()
      numbersShown.value = false
      if (wasOpen && opener && opener !== document.body && opener.isConnected) {
        opener.dispatchEvent(new CustomEvent('roo-return-focus'))
        opener.focus()
      }
      opener = null
    }
  },
  { immediate: true },
)

watch([query, () => props.providers], () => {
  if (props.open) void load()
})

onBeforeUnmount(stopListening)
</script>

<template>
  <div v-if="open" ref="panel" class="roo-palette" role="dialog" :aria-label="label" @keydown="onKeydown" @keyup="onKeyup">
    <input
      ref="input"
      v-model="query"
      class="roo-palette-input"
      v-bind="inputAttrs"
      type="text"
      role="combobox"
      autocomplete="off"
      spellcheck="false"
      aria-expanded="true"
      aria-haspopup="listbox"
      :aria-controls="`${baseId}-list`"
      :aria-activedescendant="flat.length > 0 ? rowId(highlightIndex) : undefined"
      :aria-label="label"
      :placeholder="label"
    />
    <div :id="`${baseId}-list`" class="roo-palette-list" role="listbox" :aria-label="label">
      <p v-if="sections.length === 0 && !loading" class="roo-palette-empty">No matches</p>
      <div v-for="section in sections" :key="section.id" class="roo-palette-section" role="group" :aria-labelledby="`${baseId}-heading-${section.id}`">
        <div class="roo-palette-heading-row">
          <p :id="`${baseId}-heading-${section.id}`" class="roo-palette-heading">{{ section.word }}</p>
          <slot name="more" :section="section.id" />
          <button
            v-if="section.total > section.rows.length"
            class="roo-palette-more"
            type="button"
            tabindex="-1"
            @mousedown.prevent
            @click="showAll(section.id)"
          >
            Show all {{ section.total }}
          </button>
        </div>
        <div
          v-for="row in section.rows"
          :id="rowId(indexOfRow(section.id, row))"
          :key="row.id"
          class="roo-palette-row"
          :class="{ 'roo-selected-row': indexOfRow(section.id, row) === highlightIndex }"
          role="option"
          :data-section="section.id"
          :data-highlighted="indexOfRow(section.id, row) === highlightIndex ? '' : undefined"
          :aria-selected="indexOfRow(section.id, row) === highlightIndex"
          :aria-disabled="row.disabled ? 'true' : undefined"
          :aria-busy="row.busy ? 'true' : undefined"
          @mousedown.prevent
          @mousemove="onRowMove($event, indexOfRow(section.id, row))"
          @click="runAt(indexOfRow(section.id, row), $event.metaKey || $event.ctrlKey)"
        >
          <RooIcon v-if="iconName(row)" class="roo-palette-icon" :name="iconName(row)!" :size="16" />
          <span class="roo-palette-label">{{ row.label }}</span>
          <span v-if="showsEnvironment(row) || row.meta" class="roo-palette-meta" :data-tone="row.danger ? 'danger' : undefined">
            <span class="roo-palette-meta-separator" aria-hidden="true">·</span>
            <template v-if="showsEnvironment(row)">
              <span class="roo-palette-env-word" :data-env="row.environment" aria-hidden="true">{{ row.environment }}</span>
              <span v-if="row.environment === 'prod'" class="roo-palette-spoken">production</span>
              <template v-if="row.meta">{{ ' · ' }}</template>
            </template>
            <template v-if="row.meta">{{ row.meta }}</template>
          </span>
          <RooKbd v-if="row.keys" :keys="row.keys" :platform="platform" />
          <span v-if="numbersShown && indexOfRow(section.id, row) < 5" class="roo-palette-number">{{ indexOfRow(section.id, row) + 1 }}</span>
        </div>
      </div>
    </div>
    <div class="roo-palette-footer">
      <RooKeyHint v-for="hint in footerHints" :key="hint.keys" :keys="hint.keys" :platform="platform">{{ hint.words }}</RooKeyHint>
      <span v-for="hint in prefixHints" :key="hint.prefix" class="roo-palette-prefix-hint">
        <RooKbd>{{ hint.prefix }}</RooKbd>
        <span>{{ hint.words }}</span>
      </span>
    </div>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-palette {
    position: fixed;
    z-index: 60;
    top: var(--roo-palette-top, var(--roo-bar-h));
    left: var(--roo-palette-left, 50%);
    translate: var(--roo-palette-shift, -50%) 0;
    display: flex;
    width: 560px;
    min-width: 440px;
    max-width: calc(100vw - 2 * var(--roo-p-space-4));
    max-height: min(480px, 70vh);
    box-sizing: border-box;
    flex-direction: column;
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-radius-popover);
    background: var(--roo-surface);
    box-shadow: var(--roo-shadow-panel);
    color: var(--roo-text);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-13);
    animation: roo-settle var(--roo-base) var(--roo-ease) both;
  }

  .roo-palette-input {
    height: var(--roo-palette-field-h);
    flex: none;
    box-sizing: border-box;
    /* The typed text starts on the rows' text line: the list inset plus the row padding. */
    padding: 0 calc(var(--roo-p-space-2) + var(--roo-row-pad-inline));
    border: 0;
    border-bottom: 1px solid var(--roo-border);
    background: transparent;
    color: inherit;
    font: inherit;
    outline: none;
  }

  .roo-palette-input::placeholder {
    color: var(--roo-muted);
  }

  .roo-palette-list {
    min-height: 0;
    flex: 1;
    overflow: auto;
    /* Rows sit inset 8 on both sides, the family list inset. */
    padding: var(--roo-p-space-1) var(--roo-p-space-2);
  }

  .roo-palette-empty {
    margin: 0;
    padding: var(--roo-p-space-3);
    color: var(--roo-muted);
  }

  .roo-palette-heading-row {
    display: flex;
    align-items: center;
    gap: var(--roo-p-space-2);
    padding: var(--roo-p-space-2) var(--roo-row-pad-inline) var(--roo-p-space-1);
  }

  .roo-palette-heading {
    margin: 0;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    font-weight: 600;
    white-space: nowrap;
  }

  .roo-palette-more {
    margin-left: auto;
    padding: 0;
    border: 0;
    background: transparent;
    color: var(--roo-muted);
    cursor: default;
    font: inherit;
    font-size: var(--roo-p-size-12);
    white-space: nowrap;
  }

  .roo-palette-more:hover {
    color: var(--roo-text);
  }

  .roo-palette-row {
    display: flex;
    height: var(--roo-row-h);
    box-sizing: border-box;
    align-items: center;
    gap: var(--roo-p-space-2);
    /* The selection mark is centred in the leading padding; equal padding keeps the fill even on both sides. */
    padding: 0 var(--roo-row-pad-inline);
    border-radius: var(--roo-p-radius-medium);
    cursor: default;
    user-select: none;
  }

  .roo-palette-row[aria-disabled='true'] {
    color: var(--roo-faint);
  }

  .roo-palette-icon {
    flex: none;
    color: var(--roo-muted);
  }

  /* The meta follows the name on the same line (name · prod · read only), as in Tinkeroo's sidebar rows. */
  .roo-palette-label {
    min-width: 0;
    flex: 0 1 auto;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-palette-meta {
    min-width: 0;
    flex: 1 1 auto;
    /* Cancel the row gap so the separator's own spaces set the spacing: name · prod · read only. */
    margin-left: calc(var(--roo-p-space-2) * -1);
    overflow: hidden;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  /* A leading space would collapse at the start of a flex item, so the first separator carries its own spacing. */
  .roo-palette-meta-separator {
    margin: 0 0.3em;
  }

  /* The environment is a lowercase word in the meta line, crimson only for prod: no dot, no tag. */
  .roo-palette-env-word[data-env='prod'] {
    color: var(--roo-prod-text);
  }

  .roo-palette-spoken {
    position: absolute;
    width: 1px;
    height: 1px;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }

  .roo-palette-meta[data-tone='danger'] {
    color: var(--roo-prod-text);
  }

  .roo-palette-number {
    flex: none;
    color: var(--roo-text);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
  }

  .roo-palette-footer {
    display: flex;
    flex: none;
    flex-wrap: nowrap;
    align-items: center;
    gap: var(--roo-p-space-4);
    padding: var(--roo-p-space-2) var(--roo-p-space-3);
    border-top: 1px solid var(--roo-border);
    overflow: hidden;
  }

  .roo-palette-prefix-hint {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-2);
    margin-left: auto;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    white-space: nowrap;
  }
}
</style>
