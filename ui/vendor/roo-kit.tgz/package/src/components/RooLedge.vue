<script lang="ts">
/** How long the text badge from `hop` stays. */
export const LEDGE_HOP_BADGE_MS = 1000

/** The OS setting or a page that forces still motion (the kit's .roo-force-reduced class, or data-motion="still"). */
export function motionIsReduced(): boolean {
  if (typeof document === 'undefined') return false
  const root = document.documentElement
  if (root.classList.contains('roo-force-reduced') || root.getAttribute('data-motion') === 'still') return true
  return typeof window !== 'undefined' && typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
}
</script>

<script setup lang="ts">
// The strip along the bottom of the window. The order is fixed: environment and mode, then the facts, then the AI
// policy, then the one-second badge. The Ledge shows no logo: the kit ships no app artwork and no brand has a current mark in it (Raja 2026-11-21: "the logo on the footer, can put right logo or remove? whole family"), so the old `mark` slot is gone. The facts (RooLedgeFact, or a plain text button) are NEVER inside a live region, because a
// fact such as "Connecting, 12 s" changes every second and a screen reader would read each tick. A change worth
// hearing goes through the announcer. The family rule is one announcer per app, so the Ledge draws NO live region by
// default; `announcer="own"` makes it draw one polite region, filled with `announce(text)` or the `announcement` prop,
// and the `announcer` slot lets the app put its own in that place. Right click anywhere on the strip asks
// the app to open its "choose the facts" menu.
import { computed, onBeforeUnmount, ref, watch } from 'vue'
import { tagForEnvironment } from '../environment'
import type { RooEnvironment } from '../types/environment'
import RooEnvDot from './RooEnvDot.vue'

const props = withDefaults(
  defineProps<{
    environment?: RooEnvironment | undefined
    /** The mode beside the environment, lowercase ("read-only"). */
    mode?: string
    /** Text for the announcer. A new value is announced once. */
    announcement?: string
    /** `none` (default): the app owns the one announcer. `own`: the Ledge draws a polite status region. */
    announcer?: 'none' | 'own'
  }>(),
  { environment: undefined, mode: '', announcement: '', announcer: 'none' },
)

const emit = defineEmits<{ configure: [event: MouseEvent] }>()

const spoken = ref(props.announcement)
const hopText = ref('')
let badgeTimer: ReturnType<typeof setTimeout> | undefined

watch(
  () => props.announcement,
  (text) => {
    spoken.value = text
  },
)

const prodLike = computed(() => tagForEnvironment(props.environment) === 'production')

/** Say something once through the announcer. */
function announce(text: string): void {
  spoken.value = text
}

/**
 * A job over five seconds finished in the background: a text badge shows for a second. The text is also announced once.
 */
function hop(text: string): void {
  clearTimeout(badgeTimer)
  hopText.value = text
  announce(text)
  badgeTimer = setTimeout(() => {
    hopText.value = ''
  }, LEDGE_HOP_BADGE_MS)
}

onBeforeUnmount(() => clearTimeout(badgeTimer))

defineExpose({ hop, announce })
</script>

<template>
  <footer class="roo-ledge" data-roo-region="ledge" @contextmenu.prevent="emit('configure', $event)">
    <div v-if="environment" class="roo-ledge-group roo-ledge-env" data-group="env" :data-env="environment" :data-prod-like="prodLike">
      <span aria-hidden="true"><RooEnvDot :environment="environment" /></span>
      <span class="roo-ledge-env-word">{{ environment }}</span>
      <span v-if="mode" class="roo-ledge-mode">{{ mode }}</span>
    </div>

    <div class="roo-ledge-facts" data-group="facts"><slot /></div>

    <div v-if="$slots.ai" class="roo-ledge-group" data-group="ai"><slot name="ai" /></div>

    <div v-if="hopText" class="roo-ledge-group" data-group="badge">
      <span class="roo-ledge-badge" data-badge>{{ hopText }}</span>
    </div>

    <slot v-if="announcer === 'own'" name="announcer">
      <span class="roo-visually-hidden" role="status" aria-live="polite" aria-atomic="true">{{ spoken }}</span>
    </slot>
  </footer>
</template>

<style scoped>
@layer roo-components {
  .roo-ledge {
    display: flex;
    height: var(--roo-ledge-h);
    flex: none;
    box-sizing: border-box;
    align-items: center;
    gap: 12px;
    border-top: 1px solid var(--roo-border);
    background: var(--roo-x-chrome);
    padding-inline: 12px;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    white-space: nowrap;
    -webkit-app-region: drag;
    app-region: drag;
  }

  /* A text button in the facts, or any other control, is not part of the drag handle. */
  .roo-ledge :deep(button),
  .roo-ledge :deep(a),
  .roo-ledge :deep(input),
  .roo-ledge :deep(select),
  .roo-ledge :deep(textarea),
  .roo-ledge :deep([role='button']),
  .roo-ledge :deep([role='tab']),
  .roo-ledge :deep([tabindex]) {
    -webkit-app-region: no-drag;
    app-region: no-drag;
  }

  .roo-ledge :deep(button),
  .roo-ledge :deep([role='button']) {
    cursor: default;
  }

  .roo-ledge-group {
    display: flex;
    flex: none;
    align-items: center;
    gap: 4px;
  }

  .roo-ledge-facts {
    display: flex;
    min-width: 0;
    flex: 1 1 0;
    align-items: center;
    gap: 12px;
    overflow: hidden;
  }

  .roo-ledge-env-word {
    color: var(--roo-text);
    font-weight: 600;
  }

  .roo-ledge-env[data-prod-like='true'] .roo-ledge-env-word {
    color: var(--roo-prod-text);
  }

  .roo-ledge-badge {
    color: var(--roo-text);
    animation: roo-settle var(--roo-base) var(--roo-ease) both;
  }
}
</style>
