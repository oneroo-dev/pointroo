<script setup lang="ts">
// A labelled group of sidebar rows (an `actions` slot puts a control at the right end of the head, such as an add button). The label is sentence case, 12 px semibold and muted (Raja, 2026-11-15: no capitals, no tracking). `collapsible` turns the head into a button that opens and closes the group; `reorderable` lets Alt with Up
// or Down ask for a move of the whole group. A `count` names the group ("Tables, 2 items"); `hideCount` drops the visible number
// (a narrow sidebar) and keeps it in the name. `placement="sidebar"` is the RooTree option of the same name for a group used without a tree: rows stand on the sidebar field's edges and the head's chevron and text share a column with the rows' chevron and icon. The head is --roo-group-head-h (28px comfortable, 17px compact), centred by flex.
import { computed, useId } from 'vue'
import RooCollapse from './RooCollapse.vue'
import RooIcon from './RooIcon.vue'

const props = withDefaults(defineProps<{ label: string; count?: number; hideCount?: boolean; collapsible?: boolean; reorderable?: boolean; placement?: 'tree' | 'sidebar' }>(), { collapsible: false, reorderable: false, hideCount: false, placement: 'tree' })
const open = defineModel<boolean>('open', { default: true })
const emit = defineEmits<{ reorder: [move: { direction: 'up' | 'down' }] }>()

const headingId = useId()
const groupName = computed(() => (props.count === undefined ? undefined : `${props.label}, ${props.count} ${props.count === 1 ? 'item' : 'items'}`))

function onHeadKeydown(event: KeyboardEvent, reorderable: boolean): void {
  if (!reorderable || !event.altKey || (event.key !== 'ArrowUp' && event.key !== 'ArrowDown')) return
  event.preventDefault()
  emit('reorder', { direction: event.key === 'ArrowUp' ? 'up' : 'down' })
}
</script>

<template>
  <div class="roo-sidebar-group" :data-placement="placement === 'sidebar' ? 'sidebar' : undefined" role="group" :aria-label="groupName" :aria-labelledby="groupName === undefined ? headingId : undefined">
    <div class="roo-sidebar-group-head" role="presentation" @keydown="onHeadKeydown($event, reorderable)">
      <button v-if="collapsible" type="button" class="roo-sidebar-group-toggle" data-roving-item :aria-expanded="open ? 'true' : 'false'" @click="open = !open">
        <RooIcon class="roo-sidebar-group-chevron" :data-open="open" name="chevron" :size="12" />
        <span :id="headingId" class="roo-sidebar-group-label">{{ label }}</span>
      </button>
      <span v-else :id="headingId" class="roo-sidebar-group-label">{{ label }}</span>
      <span v-if="count !== undefined && !hideCount" class="roo-sidebar-group-count" aria-hidden="true">{{ count }}</span>
      <span v-if="$slots.actions" class="roo-sidebar-group-actions"><slot name="actions" /></span>
    </div>
    <RooCollapse :open="open" class="roo-sidebar-group-body"><slot /></RooCollapse>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-sidebar-group-head {
    display: flex;
    align-items: center;
    gap: var(--roo-gap);
    height: var(--roo-group-head-h);
    box-sizing: border-box;
    padding: 0 calc(var(--roo-tree-text-line) - var(--roo-tree-inset));
    color: var(--roo-muted);
  }

  .roo-sidebar-group[data-placement='sidebar'] {
    --roo-tree-inset: var(--roo-tree-sidebar-inset);
    --roo-tree-chevron-gap: var(--roo-sidebar-chevron-gap);
    --roo-tree-indent: calc(var(--roo-tree-chevron) + var(--roo-sidebar-chevron-gap));
  }

  .roo-sidebar-group + .roo-sidebar-group {
    margin-top: var(--roo-space-group);
  }

  .roo-sidebar-group-toggle {
    display: inline-flex;
    min-width: 0;
    align-items: center;
    gap: var(--roo-sidebar-chevron-gap);
    border: 0;
    border-radius: var(--roo-p-radius-small);
    background: transparent;
    padding: 0;
    color: inherit;
    font: inherit;
    cursor: default;
  }

  .roo-sidebar-group-toggle:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  .roo-sidebar-group-chevron {
    flex: none;
    transition: transform var(--roo-fast) var(--roo-ease);
  }

  .roo-sidebar-group-chevron[data-open='true'] {
    transform: rotate(90deg);
  }

  .roo-sidebar-group-label {
    overflow: hidden;
    font-size: var(--roo-p-size-12);
    font-weight: 600;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .roo-sidebar-group-count {
    margin-inline-start: auto;
    font-size: var(--roo-p-size-12);
    font-variant-numeric: tabular-nums;
  }

  /* A head control (an add button): at the right end of the head, after the count when there is one. */
  .roo-sidebar-group-actions {
    display: inline-flex;
    flex: none;
    align-items: center;
    margin-inline-start: auto;
  }

  .roo-sidebar-group-count + .roo-sidebar-group-actions {
    margin-inline-start: 0;
  }
}
</style>
