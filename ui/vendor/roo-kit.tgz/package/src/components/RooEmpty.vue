<script setup lang="ts">
import { computed, useSlots } from 'vue'
import RooIcon from './RooIcon.vue'
import type { RooIconName } from '../icons/paths'

const props = withDefaults(
  defineProps<{
    title: string
    description?: string
    icon?: RooIconName | undefined
    /** Density look; has an effect only where an app has set data-density on <html>. */
    size?: 'compact' | 'roomy' | undefined
    /** The list is empty because of a filter, not because it is new: no mark. */
    filtered?: boolean
  }>(),
  { description: '', icon: undefined, size: undefined, filtered: false },
)

const slots = useSlots()

const showMark = computed(() => !props.filtered && Boolean(slots.mark || slots.icon || props.icon))
const hasActions = computed(() => Boolean(slots.primary || slots.default))
const quietOnly = computed(() => Boolean(slots.quiet) && !hasActions.value)
</script>

<template>
  <div
    class="roo-empty"
    :class="{ 'roo-empty-quiet-only': quietOnly }"
    :data-size="size"
    :data-filtered="filtered ? 'true' : undefined"
  >
    <div v-if="showMark && $slots.mark" class="roo-empty-mark"><slot name="mark" /></div>
    <div v-else-if="showMark && ($slots.icon || icon)" class="roo-empty-icon">
      <slot name="icon"><RooIcon v-if="icon" :name="icon" :size="20" /></slot>
    </div>
    <p class="roo-empty-title">{{ title }}</p>
    <p v-if="description" class="roo-empty-description">{{ description }}</p>
    <div v-if="hasActions" class="roo-empty-actions"><slot name="primary" /><slot /></div>
    <div v-if="$slots.quiet" class="roo-empty-quiet"><slot name="quiet" /></div>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-empty {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: var(--roo-space-item);
    padding: var(--roo-space-section) var(--roo-space-page);
    text-align: center;
    font-family: var(--roo-font-ui);
    animation: roo-rise var(--roo-base) var(--roo-ease) both;
  }

  .roo-empty-icon {
    display: flex;
    width: 40px;
    height: 40px;
    align-items: center;
    justify-content: center;
    margin-bottom: 4px;
    border-radius: var(--roo-p-radius-card);
    background: var(--roo-raised);
    color: var(--roo-muted);
  }

  /* A 72px tile: a 48px mark has 11px inside the 1px border on every side (Raja, 2026-11-19: Proposal A). */
  .roo-empty-mark {
    display: flex;
    box-sizing: border-box;
    width: 72px;
    height: 72px;
    align-items: center;
    justify-content: center;
    margin-bottom: 4px;
    border: 1px solid var(--roo-bar-edge);
    border-radius: var(--roo-bar-radius);
    background: transparent;
    color: var(--roo-muted);
  }

  .roo-empty-title {
    margin: 0;
    font-size: var(--roo-p-size-15);
    font-weight: 600;
    color: var(--roo-text);
    letter-spacing: var(--roo-p-tracking-heading);
  }

  .roo-empty-description {
    max-width: 320px;
    margin: 0;
    font-size: var(--roo-p-size-12);
    color: var(--roo-accent-text);
    text-decoration: underline;
    text-underline-offset: 2px;
  }

  /* Its own 8 px gap until an app opts in; the density rule below then reads --roo-gap. */
  .roo-empty-actions {
    display: flex;
    gap: var(--roo-p-space-2);
    margin-top: var(--roo-p-space-2);
  }

  .roo-empty-quiet {
    display: flex;
    gap: var(--roo-p-space-2);
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
  }

  :where([data-density]) .roo-empty-actions {
    gap: var(--roo-gap);
  }

  :where([data-density]) .roo-empty[data-size='compact'] {
    padding: var(--roo-space-section) var(--roo-space-page);
  }

  :where([data-density]) .roo-empty[data-size='roomy'] {
    padding: var(--roo-space-section) var(--roo-space-page);
  }
}
</style>
