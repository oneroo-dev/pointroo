<script setup lang="ts">
// A list of rule rows with an add button. The rows are the v-model: a typed array of RooRuleRowValue. Add appends a row
// with a fresh key and puts focus in its first control; remove drops the row and moves focus to the add button (or to
// the next row). The lead word is `firstLead` on the first row and `lead` on the rest. Changes announce through a polite
// live region, so a screen reader hears "Condition added, 3 conditions".
import { computed, nextTick, ref } from 'vue'
import RooButton from './RooButton.vue'
import RooIcon from './RooIcon.vue'
import RooRuleRow, { type RooRuleOption, type RooRuleRowValue } from './RooRuleRow.vue'

const rows = defineModel<RooRuleRowValue[]>({ required: true })

const props = withDefaults(
  defineProps<{
    fieldOptions: RooRuleOption[]
    operatorOptions: RooRuleOption[]
    valueOptions?: Record<string, RooRuleOption[]>
    /** The lead word of the first row and of the later rows. */
    firstLead?: string
    lead?: string
    /** The label of the list group for assistive tech. */
    label?: string
    addLabel?: string
    removeLabel?: string
    valuePlaceholder?: string
    /** Fewest rows; the remove buttons are disabled at this count. */
    minimumRows?: number
    /** Most rows; the add button is disabled at this count. */
    maximumRows?: number
    /** The row a new rule starts as. Its `key` is replaced. */
    newRow?: Omit<RooRuleRowValue, 'key'> | undefined
    disabled?: boolean
    /** Draws the list in a bordered box with a head (the `title` slot or `title` prop, and the row count) above the rows. */
    boxed?: boolean
    title?: string
    /** The count in the head of a boxed list, such as "2 conditions". On by default for a boxed list. */
    showCount?: boolean
    /** The noun for the count and the announcements. */
    noun?: string
    nounPlural?: string
    /** `words` shows each operator as plain words instead of a select. */
    operatorDisplay?: 'select' | 'words'
  }>(),
  {
    valueOptions: () => ({}),
    firstLead: '',
    lead: '',
    label: 'Conditions',
    addLabel: 'Add a condition',
    removeLabel: 'Remove condition',
    valuePlaceholder: '',
    minimumRows: 0,
    maximumRows: Number.POSITIVE_INFINITY,
    newRow: undefined,
    disabled: false,
    boxed: false,
    title: '',
    showCount: true,
    noun: 'condition',
    nounPlural: 'conditions',
    operatorDisplay: 'select',
  },
)

const root = ref<HTMLElement | null>(null)
const addButton = ref<{ $el?: HTMLElement } | null>(null)
const announcement = ref('')
let keyCounter = 0

function nextKey(): string {
  keyCounter += 1
  let candidate = `rule-${keyCounter}`
  while (rows.value.some((row) => String(row.key) === candidate)) {
    keyCounter += 1
    candidate = `rule-${keyCounter}`
  }
  return candidate
}

const canAdd = computed(() => !props.disabled && rows.value.length < props.maximumRows)
const canRemove = computed(() => rows.value.length > props.minimumRows)

function countText(count: number): string {
  return `${count} ${count === 1 ? props.noun : props.nounPlural}`
}

function focusRow(index: number): void {
  const target = root.value?.querySelectorAll<HTMLElement>('.roo-rule-row')[index]
  target?.querySelector<HTMLElement>('button, input, select, [tabindex]')?.focus()
}

async function addRow(): Promise<void> {
  if (!canAdd.value) return
  const start = props.newRow ?? { field: props.fieldOptions[0]?.value ?? '', operator: props.operatorOptions[0]?.value ?? '', value: '' }
  const next = [...rows.value, { ...start, key: nextKey() }]
  rows.value = next
  announcement.value = `Condition added, ${countText(next.length)}`
  await nextTick()
  focusRow(next.length - 1)
}

async function removeRow(key: string | number): Promise<void> {
  const index = rows.value.findIndex((row) => row.key === key)
  if (index === -1 || !canRemove.value) return
  const remaining = rows.value.filter((row) => row.key !== key)
  rows.value = remaining
  announcement.value = `Condition removed, ${countText(remaining.length)}`
  await nextTick()
  if (remaining.length > 0) focusRow(Math.min(index, remaining.length - 1))
  else (addButton.value?.$el ?? root.value?.querySelector<HTMLElement>('.roo-rule-list-add'))?.focus()
}

function updateRow(index: number, next: RooRuleRowValue): void {
  rows.value = rows.value.map((row, position) => (position === index ? next : row))
}
</script>

<template>
  <div ref="root" class="roo-rule-list" role="group" :aria-label="label" :data-boxed="boxed ? '' : undefined">
    <div v-if="boxed && (title || $slots.title || showCount)" class="roo-rule-list-head">
      <span class="roo-rule-list-title"><slot name="title">{{ title }}</slot></span>
      <span v-if="showCount" class="roo-rule-list-count">{{ countText(rows.length) }}</span>
    </div>
    <div class="roo-rule-list-rows">
    <RooRuleRow
      v-for="(row, index) in rows"
      :key="row.key"
      :model-value="row"
      :field-options="fieldOptions"
      :operator-options="operatorOptions"
      :value-options="valueOptions"
      :lead="index === 0 ? firstLead : lead"
      :remove-label="removeLabel"
      :value-placeholder="valuePlaceholder"
      :remove-disabled="!canRemove"
      :disabled="disabled"
      :operator-display="operatorDisplay"
      @update:model-value="updateRow(index, $event)"
      @remove="removeRow"
    />
    </div>
    <div class="roo-rule-list-foot">
      <slot name="foot" />
      <RooButton ref="addButton" class="roo-rule-list-add" variant="ghost" size="sm" :disabled="!canAdd" @click="addRow">
        <RooIcon name="plus" :size="14" />{{ addLabel }}
      </RooButton>
    </div>
    <p class="roo-rule-list-live" role="status" aria-live="polite">{{ announcement }}</p>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-rule-list {
    display: grid;
    gap: var(--roo-p-space-2);
  }

  .roo-rule-list-rows {
    display: grid;
    gap: var(--roo-p-space-2);
  }

  .roo-rule-list[data-boxed] {
    gap: var(--roo-p-space-3);
    padding: var(--roo-p-space-3);
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-p-radius-medium);
    background: var(--roo-surface);
  }

  .roo-rule-list-head {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: var(--roo-p-space-2);
    font-size: var(--roo-p-size-12);
  }

  .roo-rule-list-title {
    font-weight: 600;
    color: var(--roo-text);
  }

  .roo-rule-list-count {
    margin-left: auto;
    color: var(--roo-muted);
    font-variant-numeric: tabular-nums;
  }

  .roo-rule-list-foot {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: flex-start;
    gap: var(--roo-p-space-2);
  }

  /* The foot slot (such as the match all or any control) sits at the left; the add button keeps the right edge, and wraps under it when the foot is narrow. */
  .roo-rule-list-add {
    margin-left: auto;
  }

  .roo-rule-list-live {
    position: absolute;
    width: 1px;
    height: 1px;
    margin: -1px;
    padding: 0;
    overflow: hidden;
    clip-path: inset(50%);
    white-space: nowrap;
  }
}
</style>
