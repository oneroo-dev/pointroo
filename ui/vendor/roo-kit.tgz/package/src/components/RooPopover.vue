<script setup lang="ts">
// A small panel anchored to a trigger, for content that is not a menu (a hover card opened with Space, a row's details, a
// short form). Radius is the popover radius. Esc closes it and marks the key handled (preventDefault), so a window-level
// Esc action does not also run. reka dismisses on Esc without preventing the default, and a prevented default would stop
// its own dismissal, so the popover closes itself.
// `width` sets the panel's own width (the padding is inside it, never added on top). Other attributes, data-* hooks
// included, land on the panel. `reference` anchors the panel to an element or a rect source when there is no trigger
// slot. `focus-outside` and `interact-outside` pass reka's events through, so a nested confirm popover can call
// preventDefault and keep this one open.
// `modal` is reka's own modal mode: aria-modal, Tab and Shift+Tab trapped inside, the page behind blocked (a press outside
// dismisses), the rest of the page hidden from assistive tech. `container-name` makes the panel a size container of that
// name, so the app's container queries (@container name (...)) answer to the panel's width, not the window's.
// On close, focus goes back to the trigger. When the trigger is gone or disabled it goes to `fallback-focus` (an element or
// a getter). When focus already moved to something outside the panel on purpose, it stays there.
import { computed, nextTick, ref, useAttrs, watchPostEffect, type ComponentPublicInstance, type CSSProperties } from 'vue'
import { PopoverAnchor, PopoverContent, PopoverPortal, PopoverRoot, PopoverTrigger } from 'reka-ui'
import { useEscapeLayer } from '../composables/useEscapeLayer'
import { useCollisionPadding } from '../composables/useWindowControlPadding'

defineOptions({ inheritAttrs: false })

const props = withDefaults(
  defineProps<{
    side?: 'top' | 'bottom' | 'left' | 'right'
    align?: 'start' | 'center' | 'end'
    /** The panel's accessible name. */
    label?: string | undefined
    /** The panel's width: a number is pixels, a string is any CSS length. Left out, the panel fits its content. */
    width?: number | string | undefined
    /** reka's modal mode: role dialog with aria-modal, focus trapped, the page behind blocked. */
    modal?: boolean
    /** Names the panel as a size container (`container-type: inline-size`) for the app's container queries. */
    containerName?: string | undefined
    /** Where focus goes on close when the trigger is gone or disabled: an element, or a getter run at close time. */
    fallbackFocus?: HTMLElement | (() => HTMLElement | null | undefined) | null | undefined
    /** Anchors the panel to this element (or anything with getBoundingClientRect) instead of a trigger. */
    reference?: { getBoundingClientRect(): DOMRect } | null | undefined
    /**
     * Asked for each Esc while this popover is the top kit layer. True leaves the popover open and lets that Esc through
     * unconsumed: `consumedByOverlay(event)` is false, so the app's own Esc action runs. Check `consumedByOverlay`, not
     * `defaultPrevented`, because reka's dismissal is held back with preventDefault inside its own handler.
     */
    passEscape?: ((event: KeyboardEvent) => boolean) | undefined
  }>(),
  { side: 'bottom', align: 'start', label: undefined, width: undefined, modal: false, containerName: undefined, fallbackFocus: undefined, reference: undefined, passEscape: undefined },
)
const emit = defineEmits<{
  'focus-outside': [event: Event]
  'interact-outside': [event: Event]
}>()
const panelStyle = computed<CSSProperties | undefined>(() => {
  const style: CSSProperties = {}
  if (props.width !== undefined) style.width = typeof props.width === 'number' ? `${props.width}px` : props.width
  if (props.containerName) {
    style.containerType = 'inline-size'
    style.containerName = props.containerName
  }
  return Object.keys(style).length === 0 ? undefined : style
})
const open = defineModel<boolean>('open', { default: false })
const triggerReference = ref<unknown>(null)
const collisionPadding = useCollisionPadding(open, triggerReference)
const escapeLayer = useEscapeLayer(() => open.value, undefined, { passEscape: (event) => props.passEscape?.(event) ?? false })

const attributes = useAttrs()
const contentReference = ref<ComponentPublicInstance | null>(null)

// reka points aria-labelledby at the trigger, and aria-labelledby outranks aria-label, so a named panel would be announced by
// its trigger's text. The caller's aria-labelledby wins; failing that a `label` does; otherwise reka's value stays.
watchPostEffect(() => {
  const element = contentReference.value?.$el
  if (!(element instanceof HTMLElement)) return
  const labelledBy = (attributes['aria-labelledby'] as string | undefined) ?? undefined
  if (labelledBy) element.setAttribute('aria-labelledby', labelledBy)
  else if (props.label) element.removeAttribute('aria-labelledby')
})

function isUsable(element: HTMLElement | null | undefined): element is HTMLElement {
  if (!element || !element.isConnected) return false
  if (element.hasAttribute('disabled') || element.getAttribute('aria-disabled') === 'true') return false
  return true
}

function onCloseAutoFocus(event: Event): void {
  // Stop reka's own restore (the non-modal and focus-scope paths); the modal path still focuses the trigger once, and the
  // step below runs after it, so the order of the three outcomes is the same in both modes.
  event.preventDefault()
  const panel = contentReference.value?.$el as HTMLElement | undefined
  const trigger = triggerReference.value ? ((triggerReference.value as ComponentPublicInstance).$el as HTMLElement) : null
  const active = document.activeElement
  const movedOnPurpose =
    active instanceof HTMLElement && active !== document.body && !panel?.contains(active) && !trigger?.contains(active) ? active : null
  void nextTick(() => {
    if (movedOnPurpose?.isConnected) {
      if (document.activeElement !== movedOnPurpose) movedOnPurpose.focus()
      return
    }
    if (isUsable(trigger)) {
      if (document.activeElement !== trigger) trigger.focus()
      return
    }
    const fallback = typeof props.fallbackFocus === 'function' ? props.fallbackFocus() : props.fallbackFocus
    if (isUsable(fallback)) fallback.focus()
  })
}

function onEscapeKeyDown(event: KeyboardEvent): void {
  event.preventDefault()
  // A passed Esc was never consumed by the kit; preventDefault here only stops reka's own dismissal.
  if (escapeLayer.passed(event)) return
  // An armed confirm (or any layer above) took this Esc first; it stays for that layer, and this popover stays open.
  if (!escapeLayer.isTop(event)) return
  open.value = false
}
</script>

<template>
  <PopoverRoot v-model:open="open" :modal="modal">
    <PopoverTrigger v-if="$slots.trigger" ref="triggerReference" as-child>
      <slot name="trigger" />
    </PopoverTrigger>
    <PopoverAnchor v-if="reference && !$slots.trigger" :reference="reference as HTMLElement" />
    <PopoverPortal>
      <PopoverContent
        v-bind="$attrs"
        ref="contentReference"
        class="roo-popover"
        :style="panelStyle"
        :side="side"
        :align="align"
        :side-offset="6"
        :collision-padding="collisionPadding"
        :aria-label="label"
        :aria-modal="modal ? 'true' : undefined"
        @close-auto-focus="onCloseAutoFocus"
        @escape-key-down="onEscapeKeyDown"
        @focus-outside="emit('focus-outside', $event)"
        @interact-outside="emit('interact-outside', $event)"
      >
        <slot />
      </PopoverContent>
    </PopoverPortal>
  </PopoverRoot>
</template>

<!-- Not scoped: reka puts the panel inside its own popper div, so a scoped id would land on that wrapper. -->
<style>
@layer roo-components {
  .roo-popover {
    z-index: 80;
    box-sizing: border-box;
    border: 1px solid transparent;
    border-radius: var(--roo-radius-popover);
    background: var(--roo-surface);
    padding: var(--roo-popover-pad);
    font-family: var(--roo-font-ui);
    font-size: var(--roo-ui-size);
    color: var(--roo-text);
    box-shadow: var(--roo-shadow-popover);
    animation: roo-pop var(--roo-fast) var(--roo-ease) both;
    transform-origin: var(--reka-popover-content-transform-origin, var(--reka-popper-transform-origin, center));
  }

  .roo-popover[data-state='closed'] {
    animation: roo-pop-out calc(var(--roo-fast) * 0.625) var(--roo-exit) both;
  }
}
</style>
