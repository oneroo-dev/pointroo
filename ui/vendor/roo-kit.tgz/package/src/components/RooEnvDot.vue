<script setup lang="ts">
import { computed } from 'vue'

import { TAG_LABELS, tagForEnvironment } from '../environment'
import type { RooEnvironment } from '../types/environment'
import type { RooEnvironmentWord } from '../types/environment'
import type { RooContextState, RooTag } from '../types/environment'

export type { RooEnvironment }

const props = defineProps<{
  /** The environment tag: colour and shape only, it says nothing about the guard. */
  tag?: RooTag | undefined
  /** @deprecated Pass `tag`. The old three environments and unclassified, kept so apps on the old call keep working. */
  environment?: RooEnvironmentWord | undefined
  /** A state other than connected draws the dashed ring. The ring is for states only, never for an environment. */
  state?: RooContextState | 'custom' | undefined
  /** Replaces the hidden word, so it never runs into the text next to the dot. */
  label?: string | undefined
}>()

const prodLike = computed(() => (props.tag !== undefined ? props.tag === 'production' : tagForEnvironment(props.environment) === 'production'))

// The two tags that also arrive as an environment word draw through the tag styles; neither is prod-like.
const shownTag = computed<RooTag | undefined>(() => props.tag ?? (props.environment === 'testing' || props.environment === 'development' ? props.environment : undefined))

const stateName = computed(() => (props.state && props.state !== 'connected' ? props.state : undefined))

// Connecting is the one state that moves: the Breathe class, which the motion layer stills or drops.
const markMove = computed(() => (stateName.value === 'connecting' ? 'roo-move-breathe' : undefined))

const hiddenWord = computed(() => {
  const base = props.label ?? (props.tag !== undefined ? TAG_LABELS[props.tag] : props.environment ?? '')
  if (props.label !== undefined || !stateName.value || stateName.value === 'custom') return base
  return `${base} ${stateName.value.replace('-', ' ')}`
})

// Colour is never the only signal: each environment also has its own shape.
const shapes: Record<RooEnvironmentWord | RooTag, string> = {
  local: 'circle',
  staging: 'diamond',
  prod: 'target',
  unclassified: 'ring',
  testing: 'square',
  development: 'triangle',
  production: 'target',
  none: 'dash',
}
const shape = computed(() => shapes[props.tag ?? props.environment ?? 'none'])
</script>

<template>
  <span
    class="roo-env-dot"
    :data-env="shownTag === undefined ? environment : undefined"
    :data-tag="shownTag"
    :data-shape="shape"
    :data-prod-like="prodLike"
    :data-state="stateName"
  >
    <span class="roo-env-dot-mark" :class="markMove" aria-hidden="true" />
    <span class="roo-visually-hidden">{{ hiddenWord }}</span>
  </span>
</template>

<style scoped>
@layer roo-components {
  .roo-env-dot {
    display: inline-grid;
    place-items: center;
    width: 12px;
    height: 12px;
  }

  .roo-env-dot-mark {
    width: 8px;
    height: 8px;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-env-local);
    transition: background-color var(--roo-base) var(--roo-ease), transform var(--roo-base) var(--roo-spring);
  }

  /* Staging is a diamond, so it differs from local by shape and not by hue alone. */
  .roo-env-dot[data-shape='diamond'] .roo-env-dot-mark {
    width: 7px;
    height: 7px;
    border-radius: var(--roo-p-radius-hair);
    background: var(--roo-env-staging);
    transform: rotate(45deg);
  }

  /* Prod also changes shape (a target), so colour is never the only signal. The whole target sits inside the 12px box: a
     1.5px ring, a 1.5px see-through gap and a 6px dot. A ring drawn as a shadow outside the box was cut off by any parent
     that clips (Pingroo's paste sheet, Raja 2026-11-17), and its gap painted the page colour on raised surfaces. */
  .roo-env-dot[data-prod-like='true'] .roo-env-dot-mark {
    box-sizing: border-box;
    width: 12px;
    height: 12px;
    padding: 1.5px;
    border: 1.5px solid var(--roo-env-prod);
    background: var(--roo-env-prod);
    background-clip: content-box;
  }

  /* Unclassified maps to no tag: a hollow ring in the no-tag colour, never crimson. */
  .roo-env-dot[data-env='unclassified'] .roo-env-dot-mark {
    background: var(--roo-bg);
    box-shadow: inset 0 0 0 2px var(--roo-env-none);
  }

  /* Testing, development and no tag (tag mode): each has its own shape and its own colour token. */
  .roo-env-dot[data-tag='testing'] .roo-env-dot-mark {
    border-radius: var(--roo-p-radius-hair);
    background: var(--roo-env-testing);
  }

  .roo-env-dot[data-tag='development'] .roo-env-dot-mark {
    border-radius: 0;
    background: var(--roo-env-development);
    clip-path: polygon(50% 0, 100% 100%, 0 100%);
  }

  .roo-env-dot[data-tag='none'] .roo-env-dot-mark {
    width: 8px;
    height: 2px;
    border-radius: var(--roo-p-radius-hair);
    background: var(--roo-env-none);
  }

  /* A state is a dashed ring in the environment's colour; the hollow ring above stays unclassified's alone. Connecting is the
     same ring with the Breathe class on the mark, which the motion layer stills or drops. */
  .roo-env-dot[data-state] .roo-env-dot-mark {
    box-sizing: border-box;
    background: transparent;
    border: 1.5px dashed var(--roo-env-local);
    box-shadow: none;
  }

  .roo-env-dot[data-state][data-shape='diamond'] .roo-env-dot-mark {
    border-color: var(--roo-env-staging);
  }

  .roo-env-dot[data-state][data-prod-like='true'] .roo-env-dot-mark {
    width: 8px;
    height: 8px;
    padding: 0;
    border-color: var(--roo-env-prod);
  }

  .roo-env-dot[data-state][data-tag='testing'] .roo-env-dot-mark {
    border-color: var(--roo-env-testing);
  }

  .roo-env-dot[data-state][data-tag='development'] .roo-env-dot-mark {
    border-color: var(--roo-env-development);
    clip-path: none;
    border-radius: var(--roo-p-radius-pill);
  }

  .roo-env-dot[data-state][data-tag='none'] .roo-env-dot-mark {
    height: 8px;
    border-color: var(--roo-env-none);
    border-radius: var(--roo-p-radius-pill);
  }
}
</style>
