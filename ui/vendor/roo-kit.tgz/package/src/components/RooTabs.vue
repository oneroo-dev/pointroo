<script setup lang="ts">
import { nextTick, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { TabsIndicator, TabsList, TabsRoot, TabsTrigger } from 'reka-ui'
import RooIcon from './RooIcon.vue'
import type { RooIconName } from '../icons/paths'

const model = defineModel<string>({ required: true })

const props = withDefaults(
  defineProps<{
    /** `tone: 'danger'` (a failed statement) colours the label with the danger text token and speaks `problem` after it; an app may also pass an `icon`. */
    tabs: { value: string; label: string; icon?: RooIconName; count?: number | string; tone?: 'danger' }[]
    label: string
    /** `boxed` is the pill look; `underline` is plain text tabs with a 2px accent line under the active one; `folder` is a 34px row on a 1px rule whose active tab opens into the page below. */
    variant?: 'boxed' | 'underline' | 'folder'
    /** `small` is the statement tab: --roo-tab-h-small (23 comfortable, 18 compact). Not for the folder look, which is a fixed 34. */
    size?: 'md' | 'small'
    /** Underline look only: the first label sits on the column's own text line, with no side padding, so a title above it and the tab row share one left edge. */
    flush?: boolean
  }>(),
  { variant: 'boxed', size: 'md', flush: false },
)

// The underline look scrolls sideways when its tabs do not fit (a narrow sheet), and says so: a fade on each edge that has more
// tabs past it, and the active tab is brought fully into view when it changes. Only this look gets the scroller; the pill and
// the folder look keep their fixed rows.
const scroller = ref<HTMLElement | null>(null)
const moreBefore = ref(false)
const moreAfter = ref(false)
let observer: ResizeObserver | null = null
let revealFrame = 0

function measure(): void {
  const element = scroller.value
  if (!element) return
  moreBefore.value = element.scrollLeft > 1
  moreAfter.value = element.scrollLeft + element.clientWidth < element.scrollWidth - 1
}

function revealActive(): void {
  const element = scroller.value
  const active = element?.querySelector<HTMLElement>('[data-state="active"]')
  if (!element || !active) return
  // Clear of the fade on the side the tab sits on, so the label is never under it.
  const fade = Number.parseFloat(getComputedStyle(element).getPropertyValue('--roo-tabs-fade')) || 0
  const left = active.offsetLeft - fade
  const right = active.offsetLeft + active.offsetWidth + fade
  let target = element.scrollLeft
  if (left < element.scrollLeft) target = Math.max(0, left)
  else if (right > element.scrollLeft + element.clientWidth) target = right - element.clientWidth
  if (target === element.scrollLeft) return
  const still = typeof matchMedia !== 'undefined' && matchMedia('(prefers-reduced-motion: reduce)').matches
  element.scrollTo({ left: target, behavior: still ? 'auto' : 'smooth' })
}

// The strip's widths can change after mount (a density switch, a font load, the container resizing). The cue is re-measured at
// once; the reveal runs once per animation frame, and revealActive itself does nothing when the active tab is already clear.
function onResize(): void {
  measure()
  if (revealFrame) return
  revealFrame = requestAnimationFrame(() => {
    revealFrame = 0
    revealActive()
  })
}

onMounted(() => {
  measure()
  revealActive()
  if (typeof ResizeObserver !== 'undefined' && scroller.value) {
    observer = new ResizeObserver(onResize)
    observer.observe(scroller.value)
    for (const strip of scroller.value.querySelectorAll<HTMLElement>('.roo-tabs, .roo-tab')) observer.observe(strip)
  }
})
onBeforeUnmount(() => {
  observer?.disconnect()
  if (revealFrame) cancelAnimationFrame(revealFrame)
  revealFrame = 0
})
watch(model, () => void nextTick(revealActive))
</script>

<template>
  <TabsRoot v-model="model" activation-mode="automatic">
    <div ref="scroller" class="roo-tabs-scroller" :data-variant="variant" :data-more-before="moreBefore || undefined" :data-more-after="moreAfter || undefined" @scroll.passive="measure">
      <TabsList class="roo-tabs" :data-variant="variant" :data-size="size" :data-flush="(flush && variant === 'underline') || undefined" :aria-label="label">
        <TabsIndicator class="roo-tabs-indicator" />
        <TabsTrigger v-for="tab in tabs" :key="tab.value" class="roo-tab" :value="tab.value" :data-tone="tab.tone">
          <RooIcon v-if="tab.icon" :name="tab.icon" :size="16" />
          {{ tab.label }}
          <span v-if="tab.count !== undefined" class="roo-tab-count">{{ tab.count }}</span>
          <span v-if="tab.tone === 'danger'" class="roo-visually-hidden">problem</span>
        </TabsTrigger>
      </TabsList>
    </div>
    <slot />
  </TabsRoot>
</template>

<style scoped>
@layer roo-components {
  /* Only the underline look scrolls; for the others the wrapper takes no box at all. */
  .roo-tabs-scroller {
    display: contents;
  }

  .roo-tabs-scroller[data-variant='underline'] {
    --roo-tabs-fade: var(--roo-p-space-6);
    display: block;
    overflow-x: auto;
    overscroll-behavior-x: contain;
    scrollbar-width: none;
  }

  .roo-tabs-scroller[data-variant='underline']::-webkit-scrollbar {
    display: none;
  }

  /* The cue: the tabs fade out on each edge that has more past it, so a cut label reads as "scroll", never as broken. */
  .roo-tabs-scroller[data-variant='underline'][data-more-after] {
    mask-image: linear-gradient(to right, #000 calc(100% - var(--roo-tabs-fade)), transparent);
  }

  .roo-tabs-scroller[data-variant='underline'][data-more-before] {
    mask-image: linear-gradient(to right, transparent, #000 var(--roo-tabs-fade));
  }

  .roo-tabs-scroller[data-variant='underline'][data-more-before][data-more-after] {
    mask-image: linear-gradient(to right, transparent, #000 var(--roo-tabs-fade), #000 calc(100% - var(--roo-tabs-fade)), transparent);
  }

  .roo-tabs-scroller[data-variant='underline'] > .roo-tabs {
    display: flex;
    width: max-content;
  }

  /* The scroller clips outside its box, so the ring sits inside the tab here. */
  .roo-tabs-scroller[data-variant='underline'] .roo-tab:focus-visible {
    outline-offset: -2px;
  }

  .roo-tabs {
    position: relative;
    display: inline-flex;
    height: var(--roo-control-h);
    box-sizing: border-box;
    align-items: center;
    gap: 2px;
    border: 1px solid var(--roo-border);
    border-radius: var(--roo-p-radius-medium);
    background: var(--roo-bg);
    padding: 2px;
  }

  .roo-tabs-indicator {
    position: absolute;
    top: 2px;
    left: 0;
    width: var(--reka-tabs-indicator-size);
    height: calc(100% - 4px);
    transform: translateX(var(--reka-tabs-indicator-position));
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-segment-thumb);
    box-shadow: var(--roo-shadow-control);
    transition:
      width var(--roo-base) var(--roo-ease),
      transform var(--roo-base) var(--roo-ease);
  }

  .roo-tab {
    position: relative;
    z-index: 1;
    display: inline-flex;
    white-space: nowrap;
    height: 100%;
    align-items: center;
    gap: 6px;
    border: 0;
    border-radius: var(--roo-radius-inner);
    background: transparent;
    padding: 0 10px;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    color: var(--roo-muted);
    cursor: default;
    transition:
      color var(--roo-fast) var(--roo-ease),
      background-color var(--roo-fast) var(--roo-ease);
  }

  .roo-tab:hover,
  .roo-tab[data-state='active'] {
    color: var(--roo-text);
  }

  /* Pressed, as RooIconButton: the raised fill and the text colour while the pointer is down (a colour step, never a movement). The
     doubled class lets it win over every variant's own rest fill; the active tab only takes the text colour. */
  .roo-tabs.roo-tabs .roo-tab:active:not([data-disabled]) {
    color: var(--roo-text);
  }

  .roo-tabs.roo-tabs .roo-tab:active:not([data-disabled]):not([data-state='active']) {
    background: var(--roo-raised);
  }

  .roo-tab:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: var(--roo-focus-offset);
  }

  /* Once an app sets data-density on <html>, the pill gives way to the text-tab look: plain text tabs, the selected one
     taking the raised fill and semibold, never a ring. Until then none of this applies. */
  :root[data-density] .roo-tabs {
    height: var(--roo-tab-h);
    gap: 4px;
    border: 0;
    background: transparent;
    padding: 0;
  }

  :root[data-density] .roo-tabs-indicator {
    display: none;
  }

  :root[data-density] .roo-tab {
    padding-inline: var(--roo-segment-pad-x);
  }

  /* Under compact density a whole-pixel line box keeps the label on a whole pixel (the tab has no border, so the height less the line is even). */
  :root[data-density] .roo-tabs:not([data-variant='folder']) .roo-tab {
    line-height: var(--roo-control-line);
  }

  :root[data-density] .roo-tab[data-state='active'] {
    background: var(--roo-select);
    color: var(--roo-text);
    font-weight: 600;
  }

  /* Small tabs (statement tabs): one step shorter on the density scale. Doubled class and :root so it beats the density and underline heights; the folder look keeps its 34. */
  :root .roo-tabs.roo-tabs[data-size='small']:not([data-variant='folder']) {
    height: var(--roo-tab-h-small);
  }

  /* The underline look wins over the density text-tab look by doubling the class, so it never needs a density selector. */
  .roo-tab-count {
    color: var(--roo-muted);
    font-variant-numeric: tabular-nums;
  }

  .roo-tabs.roo-tabs[data-variant='underline'] {
    height: var(--roo-tab-h);
    gap: 4px;
    border: 0;
    border-radius: 0;
    background: transparent;
    padding: 0;
  }

  .roo-tabs.roo-tabs[data-variant='underline'] .roo-tabs-indicator {
    display: block;
    top: auto;
    bottom: 0;
    height: 2px;
    border-radius: 0;
    background: var(--roo-accent);
    box-shadow: none;
  }

  .roo-tabs.roo-tabs[data-variant='underline'] .roo-tab {
    border-radius: 0;
    background: transparent;
    padding-inline: var(--roo-segment-pad-x);
    font-weight: 400;
  }

  .roo-tabs.roo-tabs[data-variant='underline'][data-flush='true'] .roo-tab:first-of-type {
    padding-inline-start: 0;
  }

  .roo-tabs.roo-tabs[data-variant='underline'] .roo-tab[data-state='active'] {
    background: transparent;
    font-weight: 500;
  }

  /* The folder look (the Bugroo shell frame): a 34px row on a 1px rule. Inactive tabs are 33px; the active tab is 34px
     with a border on three sides and the page fill, so it covers the rule and opens into the page. The rule is an inset
     shadow, not a border, and no tab has a negative margin: the tabs fit the row exactly, so a scroll container around
     the row (or scrollIntoView on focus) can never shift them 1px off the join (Bugroo measured this, ebc1743). */
  .roo-tabs.roo-tabs[data-variant='folder'] {
    display: flex;
    height: 34px;
    align-items: flex-end;
    gap: 2px;
    border: 0;
    box-shadow: inset 0 -1px 0 var(--roo-border);
    border-radius: 0;
    background: transparent;
    padding: 0;
  }

  .roo-tabs.roo-tabs[data-variant='folder'] .roo-tabs-indicator {
    display: none;
  }

  .roo-tabs.roo-tabs[data-variant='folder'] .roo-tab {
    height: 33px;
    box-sizing: border-box;
    border: 1px solid transparent;
    border-bottom: 0;
    border-radius: var(--roo-p-radius-medium) var(--roo-p-radius-medium) 0 0;
    background: transparent;
    padding: 0 11px;
    font-size: var(--roo-p-size-13);
    font-weight: 400;
    color: var(--roo-muted);
  }

  .roo-tabs.roo-tabs[data-variant='folder'] .roo-tab:hover {
    background: color-mix(in srgb, var(--roo-raised) 50%, transparent);
    color: var(--roo-text);
  }

  /* One px taller than the inactive tab so it covers the rule, so the label drops by that 1px of padding to keep every
     label on the inactive tabs' centre line (Bugroo measured it 0.5px high, 2026-11-17). */
  .roo-tabs.roo-tabs[data-variant='folder'] .roo-tab[data-state='active'] {
    height: 34px;
    padding-top: 1px;
    border-color: var(--roo-border);
    border-bottom: 0;
    background: var(--roo-bg);
    font-weight: 400;
    color: var(--roo-text);
  }

  .roo-tabs.roo-tabs[data-variant='folder'] .roo-tab-count {
    color: var(--roo-faint);
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-12);
  }

  /* Last, and tripled, so the danger label wins over hover, pressed, active and every variant's own text colour. */
  .roo-tabs.roo-tabs.roo-tabs .roo-tab[data-tone='danger'] {
    color: var(--roo-danger-text);
  }
}
</style>
