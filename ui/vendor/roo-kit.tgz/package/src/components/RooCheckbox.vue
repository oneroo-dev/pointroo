<script setup lang="ts">
import { useId } from 'reka-ui'

import { onMounted, ref, watch } from 'vue'

const model = defineModel<boolean>({ default: false })

const props = withDefaults(
  defineProps<{
    label: string
    disabled?: boolean
    /** Hide the label visually; it stays the accessible name. */
    hideLabel?: boolean
    /** Neither all nor none (a parent of a partly chosen set): draws a dash and reads as mixed. */
    indeterminate?: boolean
    /** `compact` draws the box at --roo-compact-checkbox (14px) for a dense filter row. */
    size?: 'compact' | 'md'
  }>(),
  { disabled: false, hideLabel: false, indeterminate: false, size: 'md' },
)

const id = useId(undefined, 'roo-checkbox')
const input = ref<HTMLInputElement | null>(null)

function syncIndeterminate(): void {
  if (input.value) input.value.indeterminate = props.indeterminate
}

onMounted(syncIndeterminate)
watch(() => props.indeterminate, syncIndeterminate)
</script>

<template>
  <div class="roo-checkbox">
    <span class="roo-checkbox-box" :data-size="size">
      <input
        :id="id"
        ref="input"
        v-model="model"
        class="roo-checkbox-input"
        type="checkbox"
        :disabled="disabled"
        :aria-checked="indeterminate ? 'mixed' : undefined"
      />
      <svg class="roo-checkbox-tick" viewBox="0 0 16 16" aria-hidden="true">
        <path d="M3.5 8.5l3 3 6-7" pathLength="1" />
      </svg>
      <svg class="roo-checkbox-dash" viewBox="0 0 16 16" aria-hidden="true">
        <path d="M4 8h8" pathLength="1" />
      </svg>
    </span>
    <label class="roo-checkbox-label" :class="{ 'roo-visually-hidden': hideLabel }" :for="id">{{ label }}</label>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-checkbox {
    display: flex;
    align-items: center;
    gap: var(--roo-checkbox-gap);
  }

  .roo-checkbox-box {
    position: relative;
    display: inline-flex;
    width: var(--roo-checkbox);
    height: var(--roo-checkbox);
    flex-shrink: 0;
  }

  .roo-checkbox-box[data-size='compact'],
  .roo-checkbox-box[data-size='compact'] .roo-checkbox-input,
  .roo-checkbox-box[data-size='compact'] .roo-checkbox-tick,
  .roo-checkbox-box[data-size='compact'] .roo-checkbox-dash {
    width: var(--roo-compact-checkbox);
    height: var(--roo-compact-checkbox);
  }

  .roo-checkbox-input {
    appearance: none;
    width: var(--roo-checkbox);
    height: var(--roo-checkbox);
    margin: 0;
    border: 1px solid var(--roo-control-edge);
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-surface);
    cursor: default;
    transition:
      background-color var(--roo-fast) var(--roo-ease),
      border-color var(--roo-fast) var(--roo-ease);
  }

  /* Only the empty box takes the text-coloured edge on hover. A filled box (checked or mixed) keeps its accent edge. */
  .roo-checkbox-input:hover:not(:disabled):not(:checked):not(:indeterminate) {
    border-color: var(--roo-text);
  }

  .roo-checkbox-input:checked {
    border-color: var(--roo-accent);
    background: var(--roo-accent);
  }

  .roo-checkbox-input:indeterminate {
    border-color: var(--roo-accent);
    background: var(--roo-accent);
  }

  /* The kit has no accent hover token; a filled box deepens the way the primary button does, with the same filter. */
  .roo-checkbox-input:hover:not(:disabled):checked,
  .roo-checkbox-input:hover:not(:disabled):indeterminate {
    filter: brightness(1.08);
  }

  /* Pressed is a colour step, never a squeeze (Fable review L6): no scale on press, the fill is the feedback. */
  .roo-checkbox-input:active:not(:disabled) {
    background: var(--roo-raised);
    border-color: var(--roo-text);
  }

  .roo-checkbox-input:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 2px;
  }

  /* Disabled is neutral grey, checked or not. */
  .roo-checkbox-input:disabled {
    background: var(--roo-raised);
    border-color: var(--roo-border);
    cursor: default;
  }

  .roo-checkbox-tick {
    position: absolute;
    inset: 0;
    width: var(--roo-checkbox);
    height: var(--roo-checkbox);
    pointer-events: none;
    fill: none;
    stroke: var(--roo-on-accent);
    stroke-width: 2;
    stroke-linecap: round;
    stroke-linejoin: round;
    stroke-dasharray: 1;
    stroke-dashoffset: 1;
    transition: stroke-dashoffset var(--roo-base) var(--roo-ease);
  }

  .roo-checkbox-input:checked + .roo-checkbox-tick {
    stroke-dashoffset: 0;
  }

  .roo-checkbox-dash {
    position: absolute;
    inset: 0;
    width: var(--roo-checkbox);
    height: var(--roo-checkbox);
    pointer-events: none;
    fill: none;
    stroke: var(--roo-on-accent);
    stroke-width: 2;
    stroke-linecap: round;
    opacity: 0;
  }

  .roo-checkbox-input:indeterminate ~ .roo-checkbox-dash {
    opacity: 1;
  }

  .roo-checkbox-input:indeterminate + .roo-checkbox-tick {
    stroke-dashoffset: 1;
  }

  .roo-checkbox-input:disabled ~ .roo-checkbox-dash {
    stroke: var(--roo-faint);
  }

  .roo-checkbox-input:disabled + .roo-checkbox-tick {
    stroke: var(--roo-faint);
  }

  /* Light look (Raja chose D, 2026-11-21): 4px corners, fill only when checked, accent fill with a white tick (the primary button pairing). Dark keeps the rules above. */
  .roo-checkbox-input:not(:root[data-appearance='dark'] *, .dark *) {
    border-radius: var(--roo-p-radius-checkbox);
  }

  .roo-checkbox-input:checked:not(:root[data-appearance='dark'] *, .dark *),
  .roo-checkbox-input:indeterminate:not(:root[data-appearance='dark'] *, .dark *) {
    border-color: var(--roo-accent-fill);
    background: var(--roo-accent-fill);
  }

  .roo-checkbox-input:checked + .roo-checkbox-tick:not(:root[data-appearance='dark'] *, .dark *),
  .roo-checkbox-input:indeterminate ~ .roo-checkbox-dash:not(:root[data-appearance='dark'] *, .dark *) {
    stroke: var(--roo-on-accent-fill);
    stroke-width: 1.75;
  }

  .roo-checkbox-tick:not(:root[data-appearance='dark'] *, .dark *),
  .roo-checkbox-dash:not(:root[data-appearance='dark'] *, .dark *) {
    stroke-width: 1.75;
  }

  .roo-checkbox-input:disabled:checked:not(:root[data-appearance='dark'] *, .dark *),
  .roo-checkbox-input:disabled:indeterminate:not(:root[data-appearance='dark'] *, .dark *) {
    background: var(--roo-raised);
    border-color: var(--roo-border);
    filter: none;
  }

  .roo-checkbox-input:disabled:checked + .roo-checkbox-tick:not(:root[data-appearance='dark'] *, .dark *),
  .roo-checkbox-input:disabled:indeterminate ~ .roo-checkbox-dash:not(:root[data-appearance='dark'] *, .dark *) {
    stroke: var(--roo-muted);
  }

  .roo-checkbox-label {
    font-family: var(--roo-font-ui);
    font-size: var(--roo-ui-size);
    color: var(--roo-text);
  }

  /* An invisible tap area of at least --roo-touch-target on a coarse pointer (family rule F6, Fable review). The drawn size never changes. */
  @media (pointer: coarse) {
    .roo-checkbox-box::before {
      content: '';
      position: absolute;
      inset: min(0px, calc((100% - var(--roo-touch-target)) / 2));
    }
  }
}
</style>
