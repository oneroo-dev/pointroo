// The plain functions behind RooDataTable. They hold no Vue state, so an app can run the same sort and search over
// its rows for an export and get the order and the matches the table shows.

export type RooDataTableRow = Record<string, unknown>

export interface RooDataTableSort {
  column: string
  direction: 'asc' | 'desc'
}

const collator = new Intl.Collator(undefined, { sensitivity: 'base' })

function isMissing(value: unknown): boolean {
  return value === null || value === undefined
}

/** The text of a cell for search and copy. Null and missing values are an empty string, so the word "null" never matches. */
export function cellText(value: unknown): string {
  if (isMissing(value)) return ''
  if (value instanceof Date) return Number.isNaN(value.getTime()) ? '' : value.toISOString()
  if (typeof value === 'object') return JSON.stringify(value) ?? ''
  return String(value)
}

/** 0 for numbers, 1 for everything else, so a column that mixes both lists the numbers first. */
function rank(value: unknown): number {
  return typeof value === 'number' || typeof value === 'bigint' ? 0 : 1
}

function compareValues(left: unknown, right: unknown): number {
  const leftRank = rank(left)
  const rightRank = rank(right)
  if (leftRank !== rightRank) return leftRank - rightRank
  if (leftRank === 0) {
    const difference = Number(left) - Number(right)
    return Number.isNaN(difference) ? 0 : difference
  }
  if (typeof left === 'boolean' && typeof right === 'boolean') return Number(left) - Number(right)
  if (left instanceof Date && right instanceof Date) return left.getTime() - right.getTime()
  return collator.compare(cellText(left), cellText(right))
}

/** A new list in sort order: numbers numeric, text without regard to case, null and missing values last in both directions. Rows that tie keep their first order. */
export function sortRows<Row extends RooDataTableRow>(rows: readonly Row[], sort: RooDataTableSort | null): Row[] {
  if (sort === null) return [...rows]
  const sign = sort.direction === 'asc' ? 1 : -1
  return rows
    .map((row, index) => ({ row, index }))
    .sort((left, right) => {
      const leftValue = left.row[sort.column]
      const rightValue = right.row[sort.column]
      const leftMissing = isMissing(leftValue)
      const rightMissing = isMissing(rightValue)
      if (leftMissing || rightMissing) return leftMissing === rightMissing ? left.index - right.index : leftMissing ? 1 : -1
      return compareValues(leftValue, rightValue) * sign || left.index - right.index
    })
    .map((entry) => entry.row)
}

/** The rows with a cell that contains the query, without regard to case. `columnIds` limits the search to those columns. */
export function filterRows<Row extends RooDataTableRow>(rows: readonly Row[], query: string, columnIds?: readonly string[]): Row[] {
  const needle = query.trim().toLowerCase()
  if (needle === '') return [...rows]
  return rows.filter((row) => (columnIds ?? Object.keys(row)).some((column) => cellText(row[column]).toLowerCase().includes(needle)))
}

/** What a click on a header does: a new column starts at asc, the same column goes asc, desc, off. */
export function cycleSort(current: RooDataTableSort | null, column: string): RooDataTableSort | null {
  if (current === null || current.column !== column) return { column, direction: 'asc' }
  return current.direction === 'asc' ? { column, direction: 'desc' } : null
}

export function pageCount(total: number, pageSize: number): number {
  return Math.max(1, Math.ceil(total / Math.max(1, pageSize)))
}

/** One page of a list. Pages count from 1 and a number out of range is moved to the nearest page. */
export function pageSlice<Item>(items: readonly Item[], page: number, pageSize: number): Item[] {
  const size = Math.max(1, pageSize)
  const clamped = Math.min(Math.max(1, page), pageCount(items.length, size))
  return items.slice((clamped - 1) * size, clamped * size)
}

export type RooDataTableKey = string | number

/** Where a page of rows stands against a selection kept by row key: none of them, some of them, or all of them (an empty page is none). */
export function selectionState(pageKeys: readonly RooDataTableKey[], selection: readonly RooDataTableKey[]): 'none' | 'some' | 'all' {
  if (pageKeys.length === 0) return 'none'
  const chosen = pageKeys.filter((key) => selection.includes(key)).length
  if (chosen === 0) return 'none'
  return chosen === pageKeys.length ? 'all' : 'some'
}

/** The header checkbox: a page that is not fully chosen becomes fully chosen; a fully chosen page is cleared. Keys chosen on other pages stay. */
export function togglePageSelection(pageKeys: readonly RooDataTableKey[], selection: readonly RooDataTableKey[]): RooDataTableKey[] {
  if (selectionState(pageKeys, selection) === 'all') return selection.filter((key) => !pageKeys.includes(key))
  return [...selection, ...pageKeys.filter((key) => !selection.includes(key))]
}

/** One row's checkbox: adds the key when it is missing, removes it when it is there. */
export function toggleKey(key: RooDataTableKey, selection: readonly RooDataTableKey[]): RooDataTableKey[] {
  return selection.includes(key) ? selection.filter((item) => item !== key) : [...selection, key]
}

/** The foot line of a server-paged table: "1 to 50 of 1,234", or "1 to 50" when the total is not known. `page` counts from 1 and is only for display. */
export function serverRangeText(page: number, pageSize: number, shown: number, total: number | null | undefined): string {
  if (shown === 0) return total === null || total === undefined ? '0 rows' : '0 of ' + total.toLocaleString('en-US')
  const first = (Math.max(1, page) - 1) * Math.max(1, pageSize) + 1
  const range = `${first.toLocaleString('en-US')} to ${(first + shown - 1).toLocaleString('en-US')}`
  return total === null || total === undefined ? range : `${range} of ${total.toLocaleString('en-US')}`
}
