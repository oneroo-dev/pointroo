<script setup lang="ts">
import { computed } from 'vue'

export type RooLiveDotState = 'live' | 'paused' | 'offline'

const props = withDefaults(
  defineProps<{
    state?: RooLiveDotState
    /** Replaces the default word with a free sentence-case phrase, such as "Live, 3 s ago". */
    word?: string
  }>(),
  { state: 'live', word: '' },
)

const defaultWords: Record<RooLiveDotState, string> = { live: 'Live', paused: 'Paused', offline: 'Offline' }

// Live is the one dot that moves: the Breathe class, which the motion layer stills or drops.
const markMove = computed(() => (props.state === 'live' ? 'roo-move-breathe' : undefined))

const text = computed(() => props.word || defaultWords[props.state])
</script>

<template>
  <span class="roo-live-dot" :data-state="state">
    <span class="roo-live-dot-mark" :class="markMove" aria-hidden="true" />
    <span class="roo-live-dot-word">{{ text }}</span>
    <span v-if="$slots.menu" class="roo-live-dot-menu"><slot name="menu" /></span>
  </span>
</template>

<style scoped>
@layer roo-components {
  .roo-live-dot {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-2);
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
    white-space: nowrap;
  }

  .roo-live-dot-mark {
    flex: none;
    width: 8px;
    height: 8px;
    box-sizing: border-box;
    border-radius: var(--roo-p-radius-pill);
    background: var(--roo-muted);
  }

  /* Live is the one filled, moving dot. */
  .roo-live-dot[data-state='live'] .roo-live-dot-mark {
    background: var(--roo-ok);
  }

  .roo-live-dot[data-state='live'] {
    color: var(--roo-ok-text);
  }

  /* Paused is a still solid dot. */
  .roo-live-dot[data-state='paused'] .roo-live-dot-mark {
    background: var(--roo-muted);
  }

  /* Offline is the dashed ring (conflict C5), never a hollow one. */
  .roo-live-dot[data-state='offline'] .roo-live-dot-mark {
    background: transparent;
    border: 1.5px dashed var(--roo-muted);
  }

  /* Sentence case from the source; the kit adds no capitals here. */
  .roo-live-dot-word {
    min-width: 0;
  }

  .roo-live-dot-menu {
    display: inline-flex;
    align-items: center;
  }
}
</style>
