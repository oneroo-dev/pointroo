<script setup lang="ts">
import { computed, inject, ref, watch } from 'vue'
import type { RooEnvironment, RooGuardLevel } from '../types/environment'
import RooButton from './RooButton.vue'
import RooConfirmProd, {
  CONFIRM_COPY,
  DEFAULT_CONFIRM_METHOD,
  ROO_CONFIRM_METHOD,
  chooseConfirmRequirement,
  type GuardRequirement,
  type ConfirmMethod,
  type ConfirmRequirement,
  isDestructiveConfirmKind,
  type ConfirmActionKind,
  type ConfirmedMethod,
} from './RooConfirmProd.vue'
import RooDialog from './RooDialog.vue'

const props = withDefaults(
  defineProps<{
    title: string
    description?: string
    /**
     * How hard the confirm is. 'plain-confirm' is a normal button, 'armed-press' is a button locked for 0.5 s,
     * 'hold' is press and hold, and 'hold-and-type' also asks for the server name first. Ignored when `environment`
     * or `guard` is given: the kit then picks it from `guard` (or the deprecated `environment`), `kind`, `itemCount`, `includesFolder`, `rowCount`, `tableRowCount` and `unbounded`.
     */
    requirement?: ConfirmRequirement
    /** Named on the hold button, and the text to type for 'hold-and-type'. */
    serverName?: string
    confirmLabel?: string
    cancelLabel?: string
    holdLabel?: string
    /** For 'hold' and 'hold-and-type': hold, two presses, or one press after the arm delay. Left out, the remembered preference, then the family default. */
    method?: ConfirmMethod | undefined
    /** Show the small switch between holding and two presses. */
    offerAlternative?: boolean
    /** 'danger' makes a plain confirm button the untinted danger button (non-prod destructive). Defaults to danger for a destructive `kind`. */
    tone?: 'default' | 'danger' | undefined
    /** The guard level. Given, the requirement is picked from it, `readOnly`, `isRead`, `kind`, `itemCount` and `includesFolder`. */
    guard?: RooGuardLevel | undefined
    /** The separate read-only switch. On, a write is blocked outright. */
    readOnly?: boolean
    /** The action is a read (SELECT, ls, and so on). */
    isRead?: boolean
    /** @deprecated Pass `guard`. Where the action runs, kept so apps on the old call keep working. */
    environment?: RooEnvironment | undefined
    kind?: ConfirmActionKind
    /** How many items the action touches. */
    itemCount?: number
    /** Any folder among them. */
    includesFolder?: boolean
    /** Rows a write or delete reaches. More than 10,000 is destructive in effect on prod and unclassified. */
    rowCount?: number | undefined
    /** Rows in the whole table, when known. More than 10% of it is destructive in effect on prod and unclassified. */
    tableRowCount?: number | undefined
    /** An UPDATE or DELETE with no WHERE: destructive in effect on prod and unclassified. */
    unbounded?: boolean
    /** The app's verb in the armed label ("Press again to commit"). */
    verb?: string
  }>(),
  {
    description: '',
    requirement: 'plain-confirm',
    serverName: '',
    confirmLabel: 'Confirm',
    cancelLabel: 'Cancel',
    holdLabel: 'Hold to confirm',
    method: undefined,
    offerAlternative: false,
    tone: undefined,
    guard: undefined,
    readOnly: false,
    isRead: false,
    environment: undefined,
    kind: 'write',
    itemCount: 1,
    includesFolder: false,
    rowCount: undefined,
    tableRowCount: undefined,
    unbounded: false,
    verb: 'confirm',
  },
)

const emit = defineEmits<{
  confirm: []
  confirmed: [payload: { method: ConfirmedMethod }]
  'update:method': [method: ConfirmMethod]
  /** Safe levels: the app asks for Touch ID or the system login, then runs the action and closes the dialog. The kit only reports. */
  'system-auth': []
}>()
const open = defineModel<boolean>('open', { default: false })

const preference = inject(ROO_CONFIRM_METHOD, null)
const chosenMethod = ref<ConfirmMethod>(props.method ?? preference?.value ?? DEFAULT_CONFIRM_METHOD)
watch(
  () => props.method,
  (method) => {
    if (method !== undefined) chosenMethod.value = method
  },
)

const effectiveRequirement = computed<GuardRequirement>(() => {
  const shared = {
    kind: props.kind,
    itemCount: props.itemCount,
    includesFolder: props.includesFolder,
    ...(props.rowCount === undefined ? {} : { rowCount: props.rowCount }),
    ...(props.tableRowCount === undefined ? {} : { tableRowCount: props.tableRowCount }),
    unbounded: props.unbounded,
  }
  if (props.guard !== undefined) return chooseConfirmRequirement({ ...shared, guard: props.guard, readOnly: props.readOnly, isRead: props.isRead })
  if (props.environment !== undefined) return chooseConfirmRequirement({ ...shared, environment: props.environment })
  return props.requirement
})
const needsHold = computed(() => ['armed-press', 'hold', 'hold-and-type'].includes(effectiveRequirement.value))
const blocked = computed(() => effectiveRequirement.value === 'blocked')
const systemAuth = computed(() => effectiveRequirement.value === 'system-auth')
const armedPress = computed(() => effectiveRequirement.value === 'armed-press')
const dangerous = computed(() => props.tone === 'danger' || (props.tone === undefined && isDestructiveConfirmKind(props.kind)))
const hint = computed(() => {
  if (armedPress.value) return CONFIRM_COPY.pressHint
  if (chosenMethod.value === 'two-step') return CONFIRM_COPY.twoStepHint
  if (chosenMethod.value === 'press') return CONFIRM_COPY.pressHint
  return CONFIRM_COPY.holdHint
})

function onMethod(method: ConfirmMethod): void {
  chosenMethod.value = method
  emit('update:method', method)
}

function confirm(): void {
  open.value = false
  emit('confirm')
}

function confirmPlain(): void {
  if (blocked.value) return
  if (systemAuth.value) {
    emit('system-auth')
    return
  }
  confirm()
  emit('confirmed', { method: 'press' })
}
</script>

<template>
  <RooDialog
    v-model:open="open"
    :title="title"
    :description="description"
    size="sm"
    :tone="needsHold ? 'prod' : 'default'"
    :destructive="dangerous"
  >
    <template #footer>
      <div class="roo-confirm">
        <p v-if="needsHold" class="roo-confirm-hint">{{ hint }}</p>
        <p v-else-if="blocked" class="roo-confirm-hint">Read-only is on, so this change is blocked.</p>
        <p v-else-if="systemAuth" class="roo-confirm-hint">This asks for your system login or Touch ID.</p>
        <div class="roo-confirm-footer" :data-requirement="effectiveRequirement">
          <RooButton class="roo-confirm-cancel" variant="secondary" data-dialog-cancel @click="open = false">{{ cancelLabel }}</RooButton>
          <RooConfirmProd
            v-if="needsHold"
            :server-name="serverName"
            :type-to-confirm="effectiveRequirement === 'hold-and-type'"
            :label="holdLabel"
            :method="armedPress ? 'press' : chosenMethod"
            :verb="verb"
            :offer-alternative="offerAlternative && !armedPress"
            @update:method="onMethod"
            @confirm="confirm"
            @confirmed="(payload) => emit('confirmed', payload)"
          />
          <RooButton v-else class="roo-confirm-action" :variant="dangerous ? 'danger' : 'primary'" :disabled="blocked" @click="confirmPlain">{{ confirmLabel }}</RooButton>
        </div>
      </div>
    </template>
  </RooDialog>
</template>

<style scoped>
@layer roo-components {
  .roo-confirm {
    display: grid;
    gap: var(--roo-p-space-2);
    justify-items: end;
  }

  .roo-confirm-hint {
    margin: 0;
    justify-self: stretch;
    color: var(--roo-muted);
    font-size: var(--roo-p-size-12);
  }

  .roo-confirm-footer {
    display: flex;
    align-items: flex-start;
    justify-content: flex-end;
    gap: var(--roo-p-space-2);
  }
}
</style>
