<script setup lang="ts">
// One control of a RooOverflowBar. It carries the control (a button, a tab, a select) in its slot, a priority, and what the
// "More" menu shows when the bar folds it. With no `onSelect` the menu entry clicks the control's own first button or link, so
// a folded control keeps the action it had in the bar.
import { inject, onBeforeUnmount, onMounted, onUpdated, ref } from 'vue'
import { ROO_OVERFLOW_BAR, type OverflowItemEntry } from '../composables/overflowBar'
import type { RooIconName } from '../icons/paths'

const props = withDefaults(
  defineProps<{
    /** Higher stays visible longer. */
    priority?: number
    /** A pinned control never folds. */
    pinned?: boolean
    /** The name in the "More" menu. */
    label: string
    /** The icon in the "More" menu. */
    icon?: RooIconName | undefined
    /** The menu entry is disabled. Set it with the control's own disabled state. */
    disabled?: boolean
    /** What the menu entry runs. Default: a click on the control's first button or link. */
    onSelect?: (() => void) | undefined
  }>(),
  { priority: 0, pinned: false, icon: undefined, disabled: false, onSelect: undefined },
)

const bar = inject(ROO_OVERFLOW_BAR, null)
const root = ref<HTMLElement | null>(null)
const identifier = bar ? bar.nextIdentifier() : 0

const entry: OverflowItemEntry = {
  identifier,
  get element() {
    return root.value
  },
  get priority() {
    return props.priority
  },
  get pinned() {
    return props.pinned
  },
  get label() {
    return props.label
  },
  get icon() {
    return props.icon
  },
  get disabled() {
    return props.disabled
  },
  run() {
    if (props.onSelect) props.onSelect()
    else root.value?.querySelector<HTMLElement>('button, a[href], [role="button"], [role="tab"]')?.click()
  },
}

onMounted(() => bar?.register(entry))
onBeforeUnmount(() => bar?.unregister(identifier))
onUpdated(() => bar?.invalidate())
</script>

<template>
  <span ref="root" class="roo-overflow-item" :hidden="bar?.isFolded(identifier) || undefined"><slot /></span>
</template>

<style scoped>
@layer roo-components {
  .roo-overflow-item {
    display: inline-flex;
    flex: none;
    align-items: center;
  }

  .roo-overflow-item[hidden] {
    display: none;
  }
}
</style>
