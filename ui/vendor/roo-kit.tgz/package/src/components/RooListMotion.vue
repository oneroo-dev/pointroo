<script setup lang="ts">
// A list whose rows fade in, fade out and slide to their new place (web only). It is Vue's TransitionGroup with the kit's
// .roo-list-* classes (src/tokens/motion.css). Each child needs a stable :key. Set `absolute` when the rows below should
// slide up while one leaves: the leaving row then drops out of the layout flow (so the list needs position: relative).
// Timed by --roo-base, so reduced motion, data-motion="still" and the desktop surface make it instant.
import { TransitionGroup } from 'vue'

withDefaults(defineProps<{ tag?: string; absolute?: boolean }>(), { tag: 'div', absolute: false })
</script>

<template>
  <TransitionGroup :tag="tag" name="roo-list" :leave-active-class="absolute ? 'roo-list-leave-active roo-list-absolute' : 'roo-list-leave-active'">
    <slot />
  </TransitionGroup>
</template>
