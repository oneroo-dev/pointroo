<script setup lang="ts">
// A line between rows of a RooMenu, or inside a RooContextMenu group slot. Same line as the one RooContextMenu draws between
// its four groups. Two in a row are the app's to avoid.
import { DropdownMenuSeparator } from 'reka-ui'
</script>

<template>
  <DropdownMenuSeparator class="roo-menu-separator" />
</template>

<style scoped>
@layer roo-components {
  .roo-menu-separator {
    height: 1px;
    margin: var(--roo-p-space-1) 0;
    background: var(--roo-border);
  }
}
</style>
