<script setup lang="ts">
import { computed, ref } from 'vue'
import { useId } from 'reka-ui'

const model = defineModel<string>({ default: '' })

const props = withDefaults(
  defineProps<{
    /** How many digits the code has. */
    length?: number
    /** How the boxes are grouped, for example [3, 3]; the sizes sum to `length`. */
    groups?: number[]
    /** Screen-reader only: names the group of boxes. */
    label: string
    error?: string
    disabled?: boolean
  }>(),
  { length: 6, groups: () => [3, 3], error: '', disabled: false },
)

const emit = defineEmits<{ complete: [code: string] }>()

const boxes = ref<HTMLInputElement[]>([])
const errorId = useId(undefined, 'roo-code-error')

// Each group lists the indexes of the boxes it holds.
const groupedIndexes = computed(() => {
  let start = 0
  return props.groups.map((size) => {
    const indexes = Array.from({ length: size }, (_, offset) => start + offset)
    start += size
    return indexes
  })
})

function digitsOf(text: string): string {
  return text.replace(/\D/g, '')
}

function focusBox(index: number): void {
  const clamped = Math.max(0, Math.min(index, props.length - 1))
  boxes.value[clamped]?.focus()
}

function commit(next: string): void {
  const code = next.slice(0, props.length)
  model.value = code
  if (code.length === props.length) emit('complete', code)
}

function onInput(index: number, event: Event): void {
  const input = event.target as HTMLInputElement
  const current = model.value
  let digits = digitsOf(input.value)
  // Typing over a filled box leaves the old digit beside the new one: keep the new one.
  if (digits.length === 2 && current[index] && digits.includes(current[index])) digits = digits.replace(current[index], '')
  input.value = current[index] ?? ''
  if (digits.length === 0) {
    commit(current.slice(0, index) + current.slice(index + 1))
    return
  }
  commit(current.slice(0, Math.min(index, current.length)) + digits)
  focusBox(Math.min(index, current.length) + digits.length)
}

function onPaste(event: ClipboardEvent): void {
  event.preventDefault()
  const digits = digitsOf(event.clipboardData?.getData('text') ?? '')
  if (digits.length === 0) return
  commit(digits)
  focusBox(Math.min(digits.length, props.length) - 1)
}

function onKeydown(index: number, event: KeyboardEvent): void {
  const current = model.value
  if (event.key === 'Backspace' && !current[index] && index > 0) {
    event.preventDefault()
    commit(current.slice(0, index - 1) + current.slice(index))
    focusBox(index - 1)
  } else if (event.key === 'ArrowLeft') {
    event.preventDefault()
    focusBox(index - 1)
  } else if (event.key === 'ArrowRight') {
    event.preventDefault()
    focusBox(index + 1)
  } else if (event.key === 'Home') {
    event.preventDefault()
    focusBox(0)
  } else if (event.key === 'End') {
    event.preventDefault()
    focusBox(props.length - 1)
  }
}
</script>

<template>
  <div class="roo-code-field">
    <div class="roo-code" role="group" :aria-label="label">
      <div v-for="(indexes, groupIndex) in groupedIndexes" :key="groupIndex" class="roo-code-group">
        <span v-for="index in indexes" :key="index" class="roo-code-cell" @mousedown.self.prevent="focusBox(index)">
          <input
            :ref="(element) => { if (element) boxes[index] = element as HTMLInputElement }"
            class="roo-code-box"
            type="text"
            inputmode="numeric"
            pattern="[0-9]*"
            :autocomplete="index === 0 ? 'one-time-code' : 'off'"
            :aria-label="`${label}, digit ${index + 1} of ${length}`"
            :aria-invalid="error ? 'true' : undefined"
            :aria-describedby="error ? errorId : undefined"
            :disabled="disabled"
            :value="model[index] ?? ''"
            @input="onInput(index, $event)"
            @keydown="onKeydown(index, $event)"
            @paste="onPaste"
          />
        </span>
      </div>
    </div>
    <p v-if="error" :id="errorId" class="roo-code-error" role="alert">{{ error }}</p>
  </div>
</template>

<style scoped>
@layer roo-components {
  .roo-code-field {
    display: flex;
    flex-direction: column;
    gap: var(--roo-p-space-2);
  }

  .roo-code {
    display: flex;
    gap: var(--roo-p-space-4);
    width: 100%;
  }

  .roo-code-group {
    display: flex;
    flex: 1 1 0;
    gap: var(--roo-p-space-2);
    min-width: 0;
  }

  /* The cell carries the tap target: the box is 44 tall already, and the cell keeps a --roo-tap-target hit area on any control height. */
  .roo-code-cell {
    position: relative;
    display: flex;
    flex: 1 1 0;
    min-width: 0;
  }

  .roo-code-cell::after {
    content: '';
    position: absolute;
    inset: 50% auto auto 50%;
    width: 100%;
    height: var(--roo-tap-target);
    transform: translate(-50%, -50%);
    pointer-events: none;
  }

  .roo-code-box {
    width: 100%;
    min-width: 0;
    height: var(--roo-control-h-xl);
    box-sizing: border-box;
    padding: 0;
    border: 1px solid var(--roo-field-edge);
    border-radius: var(--roo-radius-control);
    background: var(--roo-surface);
    color: var(--roo-text);
    text-align: center;
    font-family: var(--roo-font-mono);
    font-size: var(--roo-p-size-14);
    transition:
      border-color var(--roo-fast) var(--roo-ease),
      box-shadow var(--roo-fast) var(--roo-ease);
  }

  .roo-code-box:hover:not(:disabled) {
    border-color: var(--roo-text);
  }

  /* Focus is the caret plus a brighter fill, never an outline (family rule, Raja 2026-11-13). */
  .roo-code-box:focus {
    outline: none;
    background: var(--roo-raised);
  }

  .roo-code-box:disabled {
    opacity: 0.4;
  }

  .roo-code-box[aria-invalid='true'],
  .roo-code-box[aria-invalid='true']:hover:not(:disabled) {
    border-color: var(--roo-danger);
  }

  .roo-code-error {
    margin: 0;
    font-family: var(--roo-font-ui);
    font-size: var(--roo-p-size-12);
    color: var(--roo-danger-text);
  }
}
</style>
