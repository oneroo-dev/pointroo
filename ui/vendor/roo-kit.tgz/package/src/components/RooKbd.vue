<script setup lang="ts">
// A key as it is drawn in the Jump, menus and the key map: glyphs on macOS, words elsewhere, and the spoken names for a
// screen reader. With the default slot it shows plain text such as "Esc". `recording` is the state of a key capture field.
import { computed } from 'vue'
import RooKeyGlyphs from './RooKeyGlyphs.vue'
import { detectPlatform, keyParts, type ShortcutPlatform } from '../composables/useShortcuts'

const props = withDefaults(
  defineProps<{
    /** A chord such as 'Mod+Shift+K'. */
    keys?: string
    platform?: ShortcutPlatform | undefined
    /** Waiting for the user to press a chord. */
    recording?: boolean
    /** What joins the keys of a written chord off macOS: `plus` writes Ctrl+K, `space` writes Ctrl K. */
    joiner?: 'plus' | 'space'
  }>(),
  { keys: '', platform: undefined, recording: false, joiner: 'plus' },
)

const platform = computed(() => props.platform ?? detectPlatform())
const parts = computed(() => (props.keys === '' ? [] : keyParts(props.keys, platform.value)))
const separated = computed(() => platform.value !== 'mac')
const spoken = computed(() => parts.value.map((part) => part.spoken).join(' '))
</script>

<template>
  <kbd class="roo-kbd" :data-recording="recording ? '' : undefined" :aria-live="recording ? 'polite' : undefined">
    <template v-if="recording">Press keys</template>
    <template v-else-if="parts.length > 0">
      <span class="roo-kbd-keys" aria-hidden="true">
        <template v-for="(part, index) in parts" :key="index">
          <RooKeyGlyphs v-if="index > 0 && separated && joiner === 'plus'" class="roo-kbd-plus" text="+" />
          <span v-else-if="index > 0 && separated" class="roo-kbd-space" />
          <RooKeyGlyphs :text="part.text" />
        </template>
      </span>
      <span class="roo-visually-hidden">{{ spoken }}</span>
    </template>
    <slot v-else />
  </kbd>
</template>

<style scoped>
@layer roo-components {
  .roo-kbd {
    display: inline-flex;
    height: var(--roo-kbd-h);
    box-sizing: border-box;
    align-items: center;
    padding: 0 var(--roo-p-space-1);
    border-radius: var(--roo-p-radius-small);
    background: var(--roo-kbd-bg);
    color: var(--roo-kbd-text);
    /* Arrows are drawn as icons by RooKeyGlyphs, sized to the letter cap height (the system font draws them small). Key symbols (⌘ ⇧ ⌥ ⏎) come from the system font, as in native menus: Geist Mono has no ⌘, so it fell back to a small glyph
       beside full-size letters (Raja, 2026-11-16: "uneven icon heights"). */
    font-family: -apple-system, system-ui, var(--roo-font-ui);
    font-size: 11px;
    line-height: 1;
    white-space: nowrap;
  }

  .roo-kbd-keys {
    display: inline-flex;
    align-items: center;
  }

  /* The joining "+" of a written chord (Ctrl+K) is a separator, not a key: it reads one step quieter and stays tight, so the words are the cap's weight. */
  .roo-kbd-plus {
    opacity: 0.6;
  }

  .roo-kbd-space {
    width: 0.4em;
  }

  .roo-kbd[data-recording] {
    box-shadow: inset 0 0 0 1px var(--roo-select-outline);
  }
}
</style>
