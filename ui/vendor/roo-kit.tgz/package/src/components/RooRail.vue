<script setup lang="ts">
// The rail: a column of icon buttons at the window's edge. `navigation` lists the app's sections; `contexts` lists the
// connections the person works in, and it hides itself when the app runs inside the suite (data-host="suite" on
// <html>), because the suite draws its own. One Tab stop for the whole list; arrows, Home and End move it. The default
// slot is the scrolling list and the only part that fades. The `foot` slot sits below it, outside the scroll area and
// the mask, so what is pinned there (a workspace mark, Archive, Settings) never fades or scrolls. `size="card"` is the 108 px
// rail of A2 cards (RooRailItem size="card"): a raised rail whose selected card joins the panel beside it. `size="card-narrow"` is the 64 px rail of 52 px icon-only cards.
import { computed, onBeforeUnmount, onMounted, onUpdated, provide, ref } from 'vue'
import { useScrollFade } from '../composables/useScrollFade'
import { useRovingTabindex } from '../composables/useRovingTabindex'

const props = withDefaults(defineProps<{ kind?: 'navigation' | 'contexts'; label: string; size?: 'default' | 'card' | 'card-narrow' }>(), { kind: 'navigation', size: 'default' })

provide('roo-rail-kind', computed(() => props.kind))

const list = ref<HTMLElement | null>(null)
const roving = useRovingTabindex(list, { itemSelector: '[data-roving-item]', orientation: 'vertical' })

const inSuite = ref(typeof document !== 'undefined' && document.documentElement.getAttribute('data-host') === 'suite')
let observer: MutationObserver | undefined

// A long list ends in a soft fade on the side that has more to scroll (see useScrollFade). The style masks on the two
// data attributes.
const fade = useScrollFade(list)

onMounted(() => {
  roving.sync()
  if (typeof MutationObserver === 'undefined') return
  observer = new MutationObserver(() => {
    inSuite.value = document.documentElement.getAttribute('data-host') === 'suite'
  })
  observer.observe(document.documentElement, { attributes: true, attributeFilter: ['data-host'] })
})
onUpdated(() => {
  roving.sync()
  fade.update()
})
onBeforeUnmount(() => {
  observer?.disconnect()
})

const shown = computed(() => !(props.kind === 'contexts' && inSuite.value))
</script>

<template>
  <nav v-if="shown" class="roo-rail" :data-kind="kind" :data-size="size === 'default' ? undefined : size" :aria-label="label">
    <div ref="list" class="roo-rail-list" :data-fade-top="fade.top.value ? '' : undefined" :data-fade-bottom="fade.bottom.value ? '' : undefined" @scroll.passive="fade.update" @keydown="roving.onKeydown" @focusin="roving.onFocusin">
      <slot />
    </div>
    <div v-if="$slots.foot" class="roo-rail-foot"><slot name="foot" /></div>
  </nav>
</template>

<style scoped>
@layer roo-components {
  .roo-rail {
    display: flex;
    width: var(--roo-rail-w);
    min-height: 0;
    flex: none;
    flex-direction: column;
    align-items: center;
    box-sizing: border-box;
    padding-block: 8px;
    background: var(--roo-x-chrome);
    border-inline-end: 1px solid var(--roo-border);
  }

  /* The A2 card rail: wider, on the raised fill. The edge line is an inset shadow, not a border, so the joined selected card paints over it. */
  .roo-rail[data-size='card'] {
    width: var(--roo-rail-card-rail-w);
    padding-block: var(--roo-rail-card-inset) var(--roo-space-item);
    background: var(--roo-raised);
    border-inline-end: 0;
    box-shadow: inset -1px 0 0 var(--roo-border);
  }

  .roo-rail[data-size='card'] .roo-rail-list {
    gap: var(--roo-space-item);
  }

  /* The narrow card rail: the same raised rail and inset edge line at 64 wide. */
  .roo-rail[data-size='card-narrow'] {
    width: var(--roo-rail-card-narrow-rail-w);
    padding-block: var(--roo-rail-card-narrow-inset) var(--roo-space-item);
    background: var(--roo-raised);
    border-inline-end: 0;
    box-shadow: inset -1px 0 0 var(--roo-border);
  }

  .roo-rail[data-size='card-narrow'] .roo-rail-list {
    gap: var(--roo-space-item);
  }

  .roo-rail-list {
    display: flex;
    width: 100%;
    min-height: 0;
    flex: 1 1 auto;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    overflow-y: auto;
    scrollbar-width: none;
  }

  .roo-rail-list::-webkit-scrollbar {
    display: none;
  }

  /* The foot is pinned: it keeps its size and sits outside the scroll area and the mask. Its items are 8px apart. */
  .roo-rail-foot {
    display: flex;
    width: 100%;
    flex: none;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    padding-block-start: 8px;
  }

  /* The fade is a mask over the last --roo-scroll-fade of the edge that has more to scroll. */
  .roo-rail-list[data-fade-top] {
    -webkit-mask-image: linear-gradient(to bottom, transparent, #000 var(--roo-scroll-fade));
    mask-image: linear-gradient(to bottom, transparent, #000 var(--roo-scroll-fade));
  }

  .roo-rail-list[data-fade-bottom] {
    -webkit-mask-image: linear-gradient(to bottom, #000 calc(100% - var(--roo-scroll-fade)), transparent);
    mask-image: linear-gradient(to bottom, #000 calc(100% - var(--roo-scroll-fade)), transparent);
  }

  .roo-rail-list[data-fade-top][data-fade-bottom] {
    -webkit-mask-image: linear-gradient(to bottom, transparent, #000 var(--roo-scroll-fade), #000 calc(100% - var(--roo-scroll-fade)), transparent);
    mask-image: linear-gradient(to bottom, transparent, #000 var(--roo-scroll-fade), #000 calc(100% - var(--roo-scroll-fade)), transparent);
  }
}
</style>
