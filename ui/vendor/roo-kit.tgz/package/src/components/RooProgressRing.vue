<script setup lang="ts">
// A small circular progress mark, the round sibling of RooProgressLine. `value` is 0 to 100 like the line; leave it out for an
// indeterminate ring, a quarter arc that spins. Under reduced motion the indeterminate ring stops and shows that same arc still.
// `size` is in px and defaults to the dense-row icon box (14), so it sits in a job row or the Ledge where a RooIcon of that size would.
import { computed } from 'vue'
import { rooIconStrokeWidth } from '../icons/paths'

const props = withDefaults(
  defineProps<{
    /** 0 to 100 for a determinate ring; leave out for an indeterminate one. */
    value?: number | undefined
    /** The box in px, the same sizes as RooIcon (14 dense row, 16, 20). */
    size?: number
    label?: string
  }>(),
  { value: undefined, size: 14, label: 'Loading' },
)

const INDETERMINATE_SHARE = 0.25

const strokeWidth = computed(() => rooIconStrokeWidth(props.size))
const radius = computed(() => (props.size - strokeWidth.value) / 2)
const circumference = computed(() => 2 * Math.PI * radius.value)
const determinate = computed(() => props.value !== undefined && Number.isFinite(props.value))
const clamped = computed(() => (determinate.value ? Math.min(100, Math.max(0, props.value as number)) : 0))
const share = computed(() => (determinate.value ? clamped.value / 100 : INDETERMINATE_SHARE))
const dash = computed(() => `${share.value * circumference.value} ${circumference.value}`)
const center = computed(() => props.size / 2)
</script>

<template>
  <span
    class="roo-progress-ring"
    role="progressbar"
    :aria-label="label"
    aria-valuemin="0"
    aria-valuemax="100"
    :aria-valuenow="determinate ? clamped : undefined"
    :data-determinate="determinate ? 'true' : undefined"
    :style="{ width: `${size}px`, height: `${size}px` }"
  >
    <svg class="roo-progress-ring-svg" :width="size" :height="size" :viewBox="`0 0 ${size} ${size}`" aria-hidden="true" focusable="false">
      <circle class="roo-progress-ring-track" :cx="center" :cy="center" :r="radius" :stroke-width="strokeWidth" fill="none" />
      <circle
        class="roo-progress-ring-arc"
        :cx="center"
        :cy="center"
        :r="radius"
        :stroke-width="strokeWidth"
        :stroke-dasharray="dash"
        fill="none"
        :transform="`rotate(-90 ${center} ${center})`"
      />
    </svg>
  </span>
</template>

<style scoped>
@layer roo-components {
  .roo-progress-ring {
    display: inline-flex;
    flex: none;
    vertical-align: middle;
  }

  .roo-progress-ring-svg {
    display: block;
    overflow: visible;
  }

  /* A muted tint, so the track shows on the chrome, the surface and the raised fill in light and dark (--roo-border vanishes on raised). */
  .roo-progress-ring-track {
    stroke: color-mix(in srgb, var(--roo-muted) 35%, transparent);
  }

  .roo-progress-ring-arc {
    stroke: var(--roo-accent);
    stroke-linecap: round;
  }

  .roo-progress-ring[data-determinate='true'] .roo-progress-ring-arc {
    transition: stroke-dasharray var(--roo-base) var(--roo-ease);
  }

  .roo-progress-ring:not([data-determinate='true']) .roo-progress-ring-svg {
    animation: roo-progress-ring-spin 900ms linear infinite;
  }

  /* Reduced motion: no spinning. The indeterminate ring is the quarter arc, still, so it reads as work under way. */
  @media (prefers-reduced-motion: reduce) {
    .roo-progress-ring:not([data-determinate='true']) .roo-progress-ring-svg {
      animation: none;
    }
  }
}

:global(.roo-force-reduced) .roo-progress-ring:not([data-determinate='true']) .roo-progress-ring-svg,
:global([data-motion='still']) .roo-progress-ring:not([data-determinate='true']) .roo-progress-ring-svg {
  animation: none;
}

@keyframes roo-progress-ring-spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
