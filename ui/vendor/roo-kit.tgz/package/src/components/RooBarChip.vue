<script setup lang="ts">
// One chip shape for the Bar: the trail chip ("from Tableroo") and a one-off status ("Update ready") share it. The mark
// never badges for updates; a decision that waits is a chip like this one (conflict C15).
withDefaults(
  defineProps<{
    /** The words. A default slot replaces them. A `leading` slot (tile or icon) sits before them and a `trailing` slot (caret, branch) after. */
    label?: string
    /** A real button that emits `press`. Without it the chip is a plain status. */
    interactive?: boolean
    /** Only the leading part shows; the words stay for assistive tech and as the tooltip's text. */
    compact?: boolean
  }>(),
  { label: '', interactive: false, compact: false },
)

const emit = defineEmits<{ press: [] }>()
</script>

<template>
  <component
    :is="interactive ? 'button' : 'span'"
    class="roo-bar-chip"
    :type="interactive ? 'button' : undefined"
    :data-interactive="interactive"
    :data-compact="compact"
    @click="interactive && emit('press')"
  >
    <span v-if="$slots.leading" class="roo-bar-chip-leading"><slot name="leading" /></span>
    <span class="roo-bar-chip-label" :class="{ 'roo-visually-hidden': compact }"><slot>{{ label }}</slot></span>
    <span v-if="$slots.trailing" class="roo-bar-chip-trailing"><slot name="trailing" /></span>
  </component>
</template>

<style scoped>
@layer roo-components {
  .roo-bar-chip {
    display: inline-flex;
    align-items: center;
    gap: var(--roo-p-space-2);
    height: var(--roo-pill-h);
    padding: 0 var(--roo-p-space-3) 0 var(--roo-p-space-1);
    border-radius: var(--roo-p-radius-pill);
    border: 1px solid var(--roo-bar-edge);
    background: var(--roo-surface);
    color: var(--roo-text);
    font: inherit;
    font-size: var(--roo-p-size-12);
    font-weight: 500;
    white-space: nowrap;
    cursor: default;
    transition: background-color var(--roo-base) var(--roo-ease), border-color var(--roo-base) var(--roo-ease);
  }

  .roo-bar-chip:not(:has(.roo-bar-chip-leading)) {
    padding-inline-start: var(--roo-p-space-3);
  }

  .roo-bar-chip[data-compact='true'] {
    padding: 0 var(--roo-p-space-1);
  }

  /* An interactive chip shows its box at rest, the height of every other bar item, so hovering never changes its size
     (Raja, 2026-11-17). Rest is the raised fill; hover mixes 10% of the text colour into it (light: raised and raised-on-raised are the same colour, so no existing token is a step darker). */
  .roo-bar-chip[data-interactive='true'] {
    border-color: transparent;
    background: var(--roo-raised);
  }

  .roo-bar-chip[data-interactive='true']:hover {
    background: color-mix(in srgb, var(--roo-raised) 90%, var(--roo-text));
  }

  :global(.roo-bar) .roo-bar-chip[data-interactive='true'] {
    height: var(--roo-bar-item-h);
  }

  /* A display-only status chip in the bar is a bar item too (Tableroo's toolbar status): the bar context sets the height, --roo-pill-h is unchanged. */
  :global(.roo-bar) .roo-bar-chip {
    height: var(--roo-bar-item-h);
  }

  .roo-bar-chip[data-interactive='true']:focus-visible {
    outline: 2px solid var(--roo-focus);
    outline-offset: 1px;
  }

  .roo-bar-chip-leading {
    display: inline-flex;
    flex: none;
  }

  .roo-bar-chip-trailing {
    display: inline-flex;
    flex: none;
    align-items: center;
  }

  .roo-bar-chip-leading :slotted(svg:not([width]):not([height])),
  .roo-bar-chip-trailing :slotted(svg:not([width]):not([height])) {
    width: var(--roo-bar-icon);
    height: var(--roo-bar-icon);
  }

  .roo-bar-chip-label {
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
  }
}
</style>
