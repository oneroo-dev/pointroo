// Window frame barrel. Owned by K2; nothing exported at 291001c belongs here, so K0 created it empty.
export {
  default as RooWindow,
  WINDOW_HYSTERESIS,
  WINDOW_MAIN_MIN,
  WINDOW_NARROW_BELOW,
  WINDOW_PANE_RANGE,
  WINDOW_SIDEBAR_RANGE,
  isProdLike,
  resolveWindowParts,
  windowTier,
} from '../components/RooWindow.vue'
export type { RooWindowParts, WindowPartState, WindowPartsInput, WindowTier } from '../components/RooWindow.vue'
export { default as RooBar } from '../components/RooBar.vue'
export { default as RooLedge, LEDGE_HOP_BADGE_MS, motionIsReduced } from '../components/RooLedge.vue'
export { default as RooLedgeFact, meterPercent, spokenTone } from '../components/RooLedgeFact.vue'
export type { LedgeFactForm, LedgeFactTone } from '../components/RooLedgeFact.vue'
export { default as RooTray, pickTrayItem, trayWaiting } from '../components/RooTray.vue'
export type { RooTrayItem, TrayTone } from '../components/RooTray.vue'
export {
  default as RooDivider,
  DIVIDER_DETENT_RANGE,
  DIVIDER_KEY_STEP,
  clampSize,
  limitOf,
  sizeForKey,
  snapToDetent,
} from '../components/RooDivider.vue'
export type { DividerBounds, DividerLimit } from '../components/RooDivider.vue'
export { default as RooSplit, SPLIT_KEY_STEP, SPLIT_MIN_PANE, SPLIT_SHEET_AT, clampRatio, splitLayout } from '../components/RooSplit.vue'
export { useWindowMemory, windowMemoryKey } from '../composables/useWindowMemory'
export type { WindowMemory, WindowMemoryOptions, WindowMemoryStorage } from '../composables/useWindowMemory'
