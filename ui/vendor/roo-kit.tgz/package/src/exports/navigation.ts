// Navigation barrel. Owned by K3; K0 created it holding today's exports under today's names.
export { default as RooTabs } from '../components/RooTabs.vue'
export { default as RooRail } from '../components/RooRail.vue'
export { default as RooRailItem } from '../components/RooRailItem.vue'
export { default as RooSidebar } from '../components/RooSidebar.vue'
export { default as RooSidebarGroup } from '../components/RooSidebarGroup.vue'
export { default as RooCollapse } from '../components/RooCollapse.vue'
export { default as RooTreeRow } from '../components/RooTreeRow.vue'
export { default as RooPane, PANE_MAX_VIEWS, PANE_SHEET_AT, paneIsSheet } from '../components/RooPane.vue'
export type { RooPaneView } from '../components/RooPane.vue'
export { default as RooSegmented } from '../components/RooSegmented.vue'
export type { RooSegmentedOption } from '../components/RooSegmented.vue'
export { default as RooToggleGroup } from '../components/RooToggleGroup.vue'
export type { RooToggleGroupItem } from '../components/RooToggleGroup.vue'
export {
  default as RooTabStrip,
  TAB_DRAG_OUT_DISTANCE,
  TAB_DRAG_START_DISTANCE,
  TAB_NUMBER_LIMIT,
  TAB_OVERFLOW_RESERVE,
  dropIndexAt,
  reorderIndex,
  splitOverflow,
  tabDragIntent,
} from '../components/RooTabStrip.vue'
export type { OverflowInput, RooTabStripTab, TabDragInput } from '../components/RooTabStrip.vue'
export { default as RooCrumb } from '../components/RooCrumb.vue'
export type { RooCrumbItem } from '../components/RooCrumb.vue'
export { rovingTarget, useRovingTabindex } from '../composables/useRovingTabindex'
export type { RovingOptions, RovingOrientation, RovingTabindex } from '../composables/useRovingTabindex'
