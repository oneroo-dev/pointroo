// Overlays and production barrel. Owned by K1b; K0 created it holding today's exports under today's names.
export { default as RooConfirm } from '../components/RooConfirm.vue'
export {
  default as RooConfirmProd,
  BULK_WRITE_ROW_LIMIT,
  BULK_WRITE_TABLE_SHARE,
  CONFIRM_COPY,
  DEFAULT_CONFIRM_METHOD,
  PLAIN_CONFIRM_MAX_COUNT,
  ROO_CONFIRM_METHOD,
  chooseConfirmRequirement,
  isDestructiveConfirmKind,
} from '../components/RooConfirmProd.vue'
export type {
  ConfirmMethod,
  ConfirmRequirement,
  GuardRequirement,
  GuardConfirmInput,
  EnvironmentConfirmInput,
  ConfirmActionKind,
  ConfirmedMethod,
} from '../components/RooConfirmProd.vue'
export { default as RooConfirmPopover } from '../components/RooConfirmPopover.vue'
export type { RooConfirmRow } from '../components/RooConfirmPopover.vue'
export { default as RooHoldButton } from '../components/RooHoldButton.vue'
export { default as RooConfirmMethodCards } from '../components/RooConfirmMethodCards.vue'
export type { ConfirmMethodOption } from '../components/RooConfirmMethodCards.vue'
export { CONFIRM_ARM_WINDOW_MS, CONFIRM_HOLD_MS, useConfirmGesture } from '../composables/useConfirmGesture'
export type {
  ConfirmGesture,
  ConfirmGestureBindings,
  ConfirmGestureMethod,
  ConfirmGestureOptions,
  ConfirmGesturePhase,
} from '../composables/useConfirmGesture'
export { default as RooDialog } from '../components/RooDialog.vue'
export { default as RooMenu } from '../components/RooMenu.vue'
export type { RooCopyFormat } from '../components/RooMenu.vue'
export { default as RooMenuItem } from '../components/RooMenuItem.vue'
export { default as RooMenuSeparator } from '../components/RooMenuSeparator.vue'
export { default as RooProdBanner } from '../components/RooProdBanner.vue'
export { default as RooProdFrame, forgetDrawnConnections } from '../components/RooProdFrame.vue'
export { MINIMUM_HOLD_MS, useHoldToConfirm } from '../composables/useHoldToConfirm'
export type { HoldToConfirm, HoldToConfirmOptions } from '../composables/useHoldToConfirm'
export { ARM_DELAY_MS, MINIMUM_ARM_DELAY_MS, useArmDelay } from '../composables/useArmDelay'
export type { ArmDelay } from '../composables/useArmDelay'
export { BAND_REASONS, bandReasons, isBandReason, isGuardLooser, looserGuardIds } from '../band'
export type { BandGuard, BandInput } from '../band'
