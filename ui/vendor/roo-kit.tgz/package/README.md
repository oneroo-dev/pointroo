# @roo/kit

@roo/kit is the shared design kit for the roo apps: Tinkeroo, Stackroo, Tableroo, Fileroo, Pingroo and Shellroo, and for the Oneroo suite site.
It holds the design tokens, one brand layer per app, and the Vue components.

The kit is MIT licensed, copyright Oneroo. See `LICENSE` in this folder.

## Install

Each app uses the kit as a local file dependency. The folder must exist on every build machine, CI too.

In the app's `package.json`:

    "@roo/kit": "file:../oneroo/packages/kit"

The app must also install the peer dependencies `vue` (^3.5.42) and `reka-ui` (^2.4.1).
Check with `npm ls vue`. It should show one Vue version.

Vite bundles the kit into the renderer at build time. Never import it from the main process or a headless core.

## Vite settings

    resolve: { dedupe: ['vue', 'reka-ui'] },
    optimizeDeps: { exclude: ['@roo/kit'] },
    server: { fs: { allow: ['.', '<absolute path to oneroo/packages/kit>'] } },

## CSS imports

Import these in this order, before the app's own CSS:

1. `@roo/kit/fonts.css` (bundled fonts, never loaded from the network)
2. `@roo/kit/index.css` (tokens, motion, reduced motion, base)
3. `@roo/kit/brands/<app>.css` (`tinkeroo`, `stackroo`, `tableroo`, `fileroo`, `pingroo`, `shellroo`, `markroo`, `mockroo`, `diffroo`, `oneroo` or `bugroo`)
4. `@roo/kit/aliases/tk.css` (Tinkeroo) or `@roo/kit/aliases/sr.css` (Stackroo), only if the app still uses old names

Tableroo, Fileroo, Pingroo, Shellroo and Oneroo have no alias file.

### Layer order and Tailwind (read this if the app uses Tailwind)

Kit components style themselves inside `@layer roo-components`. CSS that is NOT in a layer beats every
layer, so an app's unlayered reset can undo the kit. Tailwind 3's preflight is unlayered
(`button { font-size: 100%; padding: 0 }`, `* { border-width: 0 }`): it flattens kit buttons, rows and
cards (found in Tinkeroo, 2026-11-11).

Fix: put ONE layer order line first in the app's entry CSS, and wrap the Tailwind reset in a layer that
comes before the kit:

```css
@layer tw-base, roo-a11y, roo-base, roo-theme, roo-layout, roo-components, roo-lock, roo-modality, roo-app;
@layer tw-base { @tailwind base; }
@tailwind components;
@tailwind utilities;
```

The kit declares seven layers itself (`roo-a11y, roo-base, roo-theme, roo-layout, roo-components, roo-lock, roo-modality`). `roo-theme`, `roo-layout` and `roo-lock` are empty today and the appearance runtime (node A2) fills them; an app that writes its own layer line should list all seven in that order now, because a layer an earlier line did not name is appended at the end. Keep `roo-a11y` before `roo-base` (its reduced-motion rules use `!important`, so an earlier layer is
stronger). Tailwind 4 already puts its reset in `@layer base`; make sure that layer is declared before
the `roo-*` layers too. The app's own CSS can stay unlayered. After the change, check a kit button, a
dialog and RooAbout light and dark.

### Text selection (family rule)

Clicking or dragging app chrome never selects text. The base layer sets `user-select: none` on `body`
and turns selection back on for `input`, `textarea`, `[contenteditable]`, `pre`, `code`,
`.monaco-editor`, `[role='alert']` and `.roo-selectable`. Put `.roo-selectable` on any area people
read or copy from (output panels, logs, result grids). It lives in `roo-base`, so app CSS can override it.

### Focus rings and dialogs (family rule: never feel like a web app)

- Call `trackInputModality()` once at app start (`import { trackInputModality } from '@roo/kit'`). It sets
  `html[data-input=mouse|keyboard]`: keyboard after Tab, arrows, Home/End or Page keys, mouse after any
  click. The `roo-modality` layer (declared last) hides focus rings in mouse mode, except in text fields,
  which keep their ring as on macOS. Chrome's `:focus-visible` alone is not enough: it shows a ring
  after any key, even Cmd+R or Esc.
- `RooDialog` leaves the window's title bar draggable: a transparent strip sits above the overlay
  (`-webkit-app-region: drag` for Electron, `data-tauri-drag-region` for Tauri, which also needs the
  `core:window:allow-start-dragging` permission). Dragging it never closes the dialog. Set
  `--roo-window-drag-height` on `:root` to your title bar height (default 28px).
- Only the dialog body scrolls; the title and footer stay put.

If the app keeps its own `--tk-*` or `--sr-*` values, its values win and the kit tokens never show.
Remove the app's own definitions of any aliased name.

## Theme attributes

Set these on the `<html>` element:

- `data-app="tinkeroo"` (or `stackroo`, `tableroo`, `fileroo`, `pingroo`, `shellroo`, `markroo`, `mockroo`, `diffroo`, `oneroo` or `bugroo`)
- `data-appearance="dark"` for dark mode. The `.dark` class also works.
- `data-density="compact"` or `"roomy"` to opt into the v2 sizes (see Density below). Leave it off and every size stays what it was.
- `data-type-scale="1"` or `"2"` adds 1 px to text and glyph sizes and 2 px to heights per step. `data-host="suite"` inside the Oneroo suite. `data-motion="calm"` drops Pop, Stagger, Hop and Breathe; `"still"` gives every reduced twin.

### Density

Put `data-density` on the `<html>` element, never on a mount element such as `#app`: dialogs, menus and tooltips portal into `body`, so only an attribute on `<html>` reaches them. With no `data-density` anywhere, every density token (`--roo-control-h`, `--roo-row-h`, `--roo-menu-row-h` and the rest) is the size the component has today, and the arrow cursor and thin scrollbars (scoped under `:where([data-density])`) do not apply. A kit part sets `data-density` on itself only when `<html>` already carries one. The table is in TOKENS.md.

### Export barrels and static pages

`@roo/kit` still exports everything it did. The same names are also available per area (`@roo/kit/controls`, `/overlays`, `/identity`, `/icons`, `/navigation`, `/states`, `/tokens` and the areas later nodes fill), plus `@roo/kit/words` (health and status words), `@roo/kit/format` (`formatRelative`) and `@roo/kit/types/*`. A page that does not run Vue imports `@roo/kit/index.css` and then `@roo/kit/static.css` for the Pill, the environment dot, the prod button, a key cap and the card shadow as `roo-static-*` classes.

## Colour roles

- Orange `#F05735` is the one strong action colour.
- Danger is a quiet crimson tint with crimson text. Add a warning or trash icon too.
- Solid crimson is only for production signals: `RooConfirmProd` and the prod-tone switch.
- Disabled controls are neutral grey. One exception: a disabled switch that is on keeps its tone colour, dimmed,
  so a locked-on switch never reads as off.
- Warning text (`--roo-warn` on `--roo-warn-bg`) is 4.5:1 or better on every surface, light and dark (pinned in a test).
- A selected row uses `--roo-select` (the neutral raised fill, no orange tint) at normal weight plus a 2px accent bar at its left edge, inset 8px top and bottom. Put `.roo-selected-row` on the row (it draws the bar with `::before`),
  or use `--roo-select` yourself. Never a ring, never a solid orange row, and no bar on an item in an icon rail (fill only).

## Shape and type

Radii (CSS variables `--roo-p-radius-*`):

- 4px `small`: items, tabs, checkboxes, tooltips
- 6px `medium`: buttons, inputs, selects
- 8px `card`: cards, menus, popovers
- 10px `large`: dialogs, windows
- 999px `pill`

Type sizes (CSS variables `--roo-p-size-*`): 11, 12, 13, 15 and 20 px.

## Reduced motion

The timing tokens `--roo-fast`, `--roo-base` and `--roo-slow` drop to 0ms when the user prefers reduced motion.
The rule lives in layer `roo-a11y`, which `index.css` declares first.
Only inline `!important` or an app layer declared before `roo-a11y` can beat it. Do not do either.

## Components

Exported from `src/index.ts`:

- Controls: `RooButton`, `RooIconButton`, `RooCheckbox`, `RooSwitch`, `RooInput`, `RooTextarea`, `RooSelect`
- Icons: `RooIcon` (names from `ROO_ICON_NAMES`; includes `upload`, `download`, `arrow-up`, `arrow-down`, `arrow-left`, `arrow-right`)
- Overlays and navigation: `RooDialog`, `RooMenu`, `RooMenuItem`, `RooTabs`, `RooTooltip`, `RooTooltipProvider`
- Esc layering: an open overlay (`RooTooltip`, `RooMenu`, `RooPopover`, `RooDialog`, `RooSwitcher`, `RooPalette`, `RooKeyMap`)
  consumes Esc first and calls `preventDefault`. A window-level Esc handler (stop the query, cancel the run) must ignore an
  event whose `defaultPrevented` is true, so the first Esc closes the overlay and the second does the window action.
- Jump and keys (`@roo/kit/jump`): `useShortcuts()` is the one registry of commands (menus, context menus, the `commands`
  provider and `RooKeyMap` all read it, so words and keys match); `RooJumpField` and `RooPalette`; `RooKbd`, `RooKeyHint`;
  `RooContextMenu` with the slots `actions`, `open-in`, `copy`, `destructive` (drawn in that order); `RooPopover`; `useRegions()`
  for F6. Cmd Shift O, Cmd Shift D and Ctrl 1 to 9 are reserved and refused at registration.
- `RooSplitButton`: a main action plus a chevron menu of related actions (the macOS pull-down button).
  Main label in the default slot, `RooMenuItem`s in the `menu` slot, `menu-label` names the chevron.
- Empty state: `RooEmpty`
- Production safety: `RooEnvDot`, `RooEnvPill`, `RooProdBanner`, `RooConfirmProd`. `RooProdFrame` is deprecated and draws nothing.
- `RooConfirm`: a confirm dialog on `RooDialog` and `RooConfirmProd`. `requirement` is `plain-confirm` (a normal button),
  `armed-press` (a button locked for 0.5 s, no hold), `hold` (press and hold) or `hold-and-type` (type the server name, then hold).
  Given `environment`, the kit picks it with `chooseConfirmRequirement({ environment, kind, itemCount, includesFolder, rowCount, tableRowCount, unbounded })`,
  `kind` being `'delete' | 'replace' | 'drop' | 'write' | 'unlock' | 'export-unmasked'`. On prod and unclassified: every destructive action holds; the typed name is
  added for more than one item, any folder, a replace or a drop (a single-file delete is hold only); a non-destructive write is an
  armed press; turning read-only off (`unlock`) is its own confirm and is an armed press. A write or delete that is destructive in
  effect is treated as destructive (hold plus typed name): `rowCount` over `BULK_WRITE_ROW_LIMIT` (10,000), `rowCount` over
  `BULK_WRITE_TABLE_SHARE` (10%) of `tableRowCount` when that is known, or `unbounded` (no WHERE). Exactly the limit or exactly the
  share is not bulk. An unmasked export (`export-unmasked`) is destructive too: hold plus typed name. On local and staging: ten or
  fewer items is a plain button, more than ten destructive items hold; the bulk inputs do not apply and an unmasked export is a plain
  confirm. `v-model:open`, emits `confirm`; it closes itself first.
- Helpers: `useHoldToConfirm`, `MINIMUM_HOLD_MS`, `forgetDrawnConnections` (deprecated no-op)
- Token name lists: `EXTENSION_TOKENS`, `MOTION_TOKENS`, `SEMANTIC_TOKENS`
- Version: `ROO_KIT_VERSION`

## Production safety

- `RooEnvironment` is `'local' | 'staging' | 'prod' | 'unclassified'`.
- Deprecated adapter (family rules, 2026-11-17): `environment` goes through the contract mapping (`tagForEnvironment`): `prod` is the production tag (crimson), `unclassified` is no tag, so it is never crimson. It keeps its hollow ring and the word "unclassified"; any guard it needs comes from the guard, not the colour.
- Any switch or `Record<RooEnvironment, ...>` must have a case for `unclassified`.
- `RooConfirmProd` needs a hold (about 1.5 seconds), plus typing the server name when `type-to-confirm` is set. It works with the
  primary pointer only.
- People who cannot sustain a press: `method="two-step"` replaces the hold with two presses (the first arms the button for
  `arm-window-ms`, default 5000; a second press under 500ms later is ignored, so a double click is one press; blur, a new server or a
  wrong typed name disarms it). It is a real button, so Enter and Space work. `offer-alternative` adds a small button under the control
  that switches between the two methods. Hold stays the default. `RooConfirm` takes the same `method` and `offer-alternative`.
- `RooEnvDot` also differs by shape (`data-shape`): circle for local, diamond for staging, ringed dot for prod, hollow ring (no-tag colour) for unclassified.
- `RooEnvPill` with `interactive` sets `aria-haspopup="dialog"`; pass `popup="menu"` when the button opens a menu.
- No kit template binds `:style` or writes a `style` attribute. `RooConfirmProd` used to, which kept `style-src 'unsafe-inline'` in app
  CSPs; it now sets its progress custom property through the CSSOM, which a CSP does not block. The kit has not been run against a
  strict CSP end to end; the reka-ui popups (menu, tooltip, select) are third-party code and were not audited for inline styles.
- No prod window frame, no corner tag (Raja, 2026-11-12). `RooWindow` draws no frame for any environment and ignores
  `drawKey` and `unclassified`. `RooProdFrame` only renders its slot and `forgetDrawnConnections()` does nothing; both
  stay exported so older apps build, and go in K8. Drop them from your app. Production shows in the Pill, the band,
  the Ledge's words and the confirms.

## Commands

Run these from the `oneroo` repo root:

    npm install
    npm test -w @roo/kit        # vitest, then vue-tsc
    npm run gallery             # component gallery (kit dev server)
    npm run check:vite8         # typecheck and build a Vite 8 consumer app

## More docs

- `TOKENS.md` maps every old app token to one kit token, or marks it `app-owned`.
- `THIRD_PARTY_NOTICES.md` lists the four OFL font families and the peer dependencies.
  Apps that bundle the kit, closed-source apps too, must ship these notices.

## Exported tokens

The tokens are also exported as `packages/contract/data/tokens.json` for stacks that cannot read CSS. After any change to `src/tokens/*.css` or `src/brands/*.css`, run `npm run tokens:export -w @roo/kit` and commit the JSON with the CSS. `npm run tokens:check -w @roo/kit` only checks. The test `test/tokens-export.test.ts` fails when they disagree. On a merge conflict in `tokens.json`, regenerate it; never hand-merge.
